// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (lin64) Build 6299465 Fri Nov 14 12:34:56 MST 2025
// Date        : Thu Jan  8 13:07:14 2026
// Host        : amd-VirtualBox running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ char_fifo_sim_netlist.v
// Design      : char_fifo
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xcku040-ffva1156-2-e
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "char_fifo,fifo_generator_v13_2_14,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "fifo_generator_v13_2_14,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (srst,
    wr_clk,
    rd_clk,
    din,
    wr_en,
    rd_en,
    dout,
    full,
    empty,
    wr_rst_busy,
    rd_rst_busy);
  input srst;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 write_clk CLK" *) (* x_interface_mode = "slave write_clk" *) (* x_interface_parameter = "XIL_INTERFACENAME write_clk, FREQ_HZ 1000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input wr_clk;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 read_clk CLK" *) (* x_interface_mode = "slave read_clk" *) (* x_interface_parameter = "XIL_INTERFACENAME read_clk, FREQ_HZ 1000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input rd_clk;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE WR_DATA" *) (* x_interface_mode = "slave FIFO_WRITE" *) input [7:0]din;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE WR_EN" *) input wr_en;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ RD_EN" *) (* x_interface_mode = "slave FIFO_READ" *) input rd_en;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ RD_DATA" *) output [7:0]dout;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE FULL" *) output full;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ EMPTY" *) output empty;
  output wr_rst_busy;
  output rd_rst_busy;

  wire [7:0]din;
  wire [7:0]dout;
  wire empty;
  wire full;
  wire rd_clk;
  wire rd_en;
  wire rd_rst_busy;
  wire srst;
  wire wr_clk;
  wire wr_en;
  wire wr_rst_busy;
  wire NLW_U0_almost_empty_UNCONNECTED;
  wire NLW_U0_almost_full_UNCONNECTED;
  wire NLW_U0_axi_ar_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_ar_overflow_UNCONNECTED;
  wire NLW_U0_axi_ar_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_ar_prog_full_UNCONNECTED;
  wire NLW_U0_axi_ar_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_ar_underflow_UNCONNECTED;
  wire NLW_U0_axi_aw_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_aw_overflow_UNCONNECTED;
  wire NLW_U0_axi_aw_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_aw_prog_full_UNCONNECTED;
  wire NLW_U0_axi_aw_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_aw_underflow_UNCONNECTED;
  wire NLW_U0_axi_b_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_b_overflow_UNCONNECTED;
  wire NLW_U0_axi_b_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_b_prog_full_UNCONNECTED;
  wire NLW_U0_axi_b_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_b_underflow_UNCONNECTED;
  wire NLW_U0_axi_r_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_r_overflow_UNCONNECTED;
  wire NLW_U0_axi_r_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_r_prog_full_UNCONNECTED;
  wire NLW_U0_axi_r_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_r_underflow_UNCONNECTED;
  wire NLW_U0_axi_w_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_w_overflow_UNCONNECTED;
  wire NLW_U0_axi_w_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_w_prog_full_UNCONNECTED;
  wire NLW_U0_axi_w_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_w_underflow_UNCONNECTED;
  wire NLW_U0_axis_dbiterr_UNCONNECTED;
  wire NLW_U0_axis_overflow_UNCONNECTED;
  wire NLW_U0_axis_prog_empty_UNCONNECTED;
  wire NLW_U0_axis_prog_full_UNCONNECTED;
  wire NLW_U0_axis_sbiterr_UNCONNECTED;
  wire NLW_U0_axis_underflow_UNCONNECTED;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_m_axi_arvalid_UNCONNECTED;
  wire NLW_U0_m_axi_awvalid_UNCONNECTED;
  wire NLW_U0_m_axi_bready_UNCONNECTED;
  wire NLW_U0_m_axi_rready_UNCONNECTED;
  wire NLW_U0_m_axi_wlast_UNCONNECTED;
  wire NLW_U0_m_axi_wvalid_UNCONNECTED;
  wire NLW_U0_m_axis_tlast_UNCONNECTED;
  wire NLW_U0_m_axis_tvalid_UNCONNECTED;
  wire NLW_U0_overflow_UNCONNECTED;
  wire NLW_U0_prog_empty_UNCONNECTED;
  wire NLW_U0_prog_full_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_s_axis_tready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire NLW_U0_underflow_UNCONNECTED;
  wire NLW_U0_valid_UNCONNECTED;
  wire NLW_U0_wr_ack_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_data_count_UNCONNECTED;
  wire [31:0]NLW_U0_m_axi_araddr_UNCONNECTED;
  wire [1:0]NLW_U0_m_axi_arburst_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arcache_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_arid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_arlen_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_arlock_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_arprot_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arqos_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arregion_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_arsize_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_aruser_UNCONNECTED;
  wire [31:0]NLW_U0_m_axi_awaddr_UNCONNECTED;
  wire [1:0]NLW_U0_m_axi_awburst_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awcache_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_awlen_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awlock_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_awprot_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awqos_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awregion_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_awsize_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awuser_UNCONNECTED;
  wire [63:0]NLW_U0_m_axi_wdata_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_wid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_wstrb_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_wuser_UNCONNECTED;
  wire [7:0]NLW_U0_m_axis_tdata_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tdest_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tid_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tkeep_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tstrb_UNCONNECTED;
  wire [3:0]NLW_U0_m_axis_tuser_UNCONNECTED;
  wire [10:0]NLW_U0_rd_data_count_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_buser_UNCONNECTED;
  wire [63:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_ruser_UNCONNECTED;
  wire [10:0]NLW_U0_wr_data_count_UNCONNECTED;

  (* C_ADD_NGC_CONSTRAINT = "0" *) 
  (* C_APPLICATION_TYPE_AXIS = "0" *) 
  (* C_APPLICATION_TYPE_RACH = "0" *) 
  (* C_APPLICATION_TYPE_RDCH = "0" *) 
  (* C_APPLICATION_TYPE_WACH = "0" *) 
  (* C_APPLICATION_TYPE_WDCH = "0" *) 
  (* C_APPLICATION_TYPE_WRCH = "0" *) 
  (* C_AXIS_TDATA_WIDTH = "8" *) 
  (* C_AXIS_TDEST_WIDTH = "1" *) 
  (* C_AXIS_TID_WIDTH = "1" *) 
  (* C_AXIS_TKEEP_WIDTH = "1" *) 
  (* C_AXIS_TSTRB_WIDTH = "1" *) 
  (* C_AXIS_TUSER_WIDTH = "4" *) 
  (* C_AXIS_TYPE = "0" *) 
  (* C_AXI_ADDR_WIDTH = "32" *) 
  (* C_AXI_ARUSER_WIDTH = "1" *) 
  (* C_AXI_AWUSER_WIDTH = "1" *) 
  (* C_AXI_BUSER_WIDTH = "1" *) 
  (* C_AXI_DATA_WIDTH = "64" *) 
  (* C_AXI_ID_WIDTH = "1" *) 
  (* C_AXI_LEN_WIDTH = "8" *) 
  (* C_AXI_LOCK_WIDTH = "1" *) 
  (* C_AXI_RUSER_WIDTH = "1" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_AXI_WUSER_WIDTH = "1" *) 
  (* C_COMMON_CLOCK = "0" *) 
  (* C_COUNT_TYPE = "0" *) 
  (* C_DATA_COUNT_WIDTH = "11" *) 
  (* C_DEFAULT_VALUE = "BlankString" *) 
  (* C_DIN_WIDTH = "8" *) 
  (* C_DIN_WIDTH_AXIS = "1" *) 
  (* C_DIN_WIDTH_RACH = "32" *) 
  (* C_DIN_WIDTH_RDCH = "64" *) 
  (* C_DIN_WIDTH_WACH = "1" *) 
  (* C_DIN_WIDTH_WDCH = "64" *) 
  (* C_DIN_WIDTH_WRCH = "2" *) 
  (* C_DOUT_RST_VAL = "0" *) 
  (* C_DOUT_WIDTH = "8" *) 
  (* C_ENABLE_RLOCS = "0" *) 
  (* C_ENABLE_RST_SYNC = "1" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_ERROR_INJECTION_TYPE = "0" *) 
  (* C_ERROR_INJECTION_TYPE_AXIS = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WRCH = "0" *) 
  (* C_FAMILY = "kintexu" *) 
  (* C_FULL_FLAGS_RST_VAL = "0" *) 
  (* C_HAS_ALMOST_EMPTY = "0" *) 
  (* C_HAS_ALMOST_FULL = "0" *) 
  (* C_HAS_AXIS_TDATA = "1" *) 
  (* C_HAS_AXIS_TDEST = "0" *) 
  (* C_HAS_AXIS_TID = "0" *) 
  (* C_HAS_AXIS_TKEEP = "0" *) 
  (* C_HAS_AXIS_TLAST = "0" *) 
  (* C_HAS_AXIS_TREADY = "1" *) 
  (* C_HAS_AXIS_TSTRB = "0" *) 
  (* C_HAS_AXIS_TUSER = "1" *) 
  (* C_HAS_AXI_ARUSER = "0" *) 
  (* C_HAS_AXI_AWUSER = "0" *) 
  (* C_HAS_AXI_BUSER = "0" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_AXI_RD_CHANNEL = "1" *) 
  (* C_HAS_AXI_RUSER = "0" *) 
  (* C_HAS_AXI_WR_CHANNEL = "1" *) 
  (* C_HAS_AXI_WUSER = "0" *) 
  (* C_HAS_BACKUP = "0" *) 
  (* C_HAS_DATA_COUNT = "0" *) 
  (* C_HAS_DATA_COUNTS_AXIS = "0" *) 
  (* C_HAS_DATA_COUNTS_RACH = "0" *) 
  (* C_HAS_DATA_COUNTS_RDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WACH = "0" *) 
  (* C_HAS_DATA_COUNTS_WDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WRCH = "0" *) 
  (* C_HAS_INT_CLK = "0" *) 
  (* C_HAS_MASTER_CE = "0" *) 
  (* C_HAS_MEMINIT_FILE = "0" *) 
  (* C_HAS_OVERFLOW = "0" *) 
  (* C_HAS_PROG_FLAGS_AXIS = "0" *) 
  (* C_HAS_PROG_FLAGS_RACH = "0" *) 
  (* C_HAS_PROG_FLAGS_RDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WACH = "0" *) 
  (* C_HAS_PROG_FLAGS_WDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WRCH = "0" *) 
  (* C_HAS_RD_DATA_COUNT = "0" *) 
  (* C_HAS_RD_RST = "0" *) 
  (* C_HAS_RST = "0" *) 
  (* C_HAS_SLAVE_CE = "0" *) 
  (* C_HAS_SRST = "1" *) 
  (* C_HAS_UNDERFLOW = "0" *) 
  (* C_HAS_VALID = "0" *) 
  (* C_HAS_WR_ACK = "0" *) 
  (* C_HAS_WR_DATA_COUNT = "0" *) 
  (* C_HAS_WR_RST = "0" *) 
  (* C_IMPLEMENTATION_TYPE = "6" *) 
  (* C_IMPLEMENTATION_TYPE_AXIS = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WRCH = "1" *) 
  (* C_INIT_WR_PNTR_VAL = "0" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_MEMORY_TYPE = "4" *) 
  (* C_MIF_FILE_NAME = "BlankString" *) 
  (* C_MSGON_VAL = "1" *) 
  (* C_OPTIMIZATION_MODE = "0" *) 
  (* C_OVERFLOW_LOW = "0" *) 
  (* C_POWER_SAVING_MODE = "0" *) 
  (* C_PRELOAD_LATENCY = "0" *) 
  (* C_PRELOAD_REGS = "1" *) 
  (* C_PRIM_FIFO_TYPE = "2kx9" *) 
  (* C_PRIM_FIFO_TYPE_AXIS = "1kx18" *) 
  (* C_PRIM_FIFO_TYPE_RACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_RDCH = "512x72" *) 
  (* C_PRIM_FIFO_TYPE_WACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WDCH = "512x72" *) 
  (* C_PRIM_FIFO_TYPE_WRCH = "512x36" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL = "6" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_AXIS = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WRCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_NEGATE_VAL = "7" *) 
  (* C_PROG_EMPTY_TYPE = "0" *) 
  (* C_PROG_EMPTY_TYPE_AXIS = "0" *) 
  (* C_PROG_EMPTY_TYPE_RACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_RDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WRCH = "0" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL = "2047" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_AXIS = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WRCH = "1023" *) 
  (* C_PROG_FULL_THRESH_NEGATE_VAL = "2046" *) 
  (* C_PROG_FULL_TYPE = "0" *) 
  (* C_PROG_FULL_TYPE_AXIS = "0" *) 
  (* C_PROG_FULL_TYPE_RACH = "0" *) 
  (* C_PROG_FULL_TYPE_RDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WACH = "0" *) 
  (* C_PROG_FULL_TYPE_WDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WRCH = "0" *) 
  (* C_RACH_TYPE = "0" *) 
  (* C_RDCH_TYPE = "0" *) 
  (* C_RD_DATA_COUNT_WIDTH = "11" *) 
  (* C_RD_DEPTH = "2048" *) 
  (* C_RD_FREQ = "1" *) 
  (* C_RD_PNTR_WIDTH = "11" *) 
  (* C_REG_SLICE_MODE_AXIS = "0" *) 
  (* C_REG_SLICE_MODE_RACH = "0" *) 
  (* C_REG_SLICE_MODE_RDCH = "0" *) 
  (* C_REG_SLICE_MODE_WACH = "0" *) 
  (* C_REG_SLICE_MODE_WDCH = "0" *) 
  (* C_REG_SLICE_MODE_WRCH = "0" *) 
  (* C_SELECT_XPM = "0" *) 
  (* C_SYNCHRONIZER_STAGE = "2" *) 
  (* C_UNDERFLOW_LOW = "0" *) 
  (* C_USE_COMMON_OVERFLOW = "0" *) 
  (* C_USE_COMMON_UNDERFLOW = "0" *) 
  (* C_USE_DEFAULT_SETTINGS = "0" *) 
  (* C_USE_DOUT_RST = "1" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_ECC_AXIS = "0" *) 
  (* C_USE_ECC_RACH = "0" *) 
  (* C_USE_ECC_RDCH = "0" *) 
  (* C_USE_ECC_WACH = "0" *) 
  (* C_USE_ECC_WDCH = "0" *) 
  (* C_USE_ECC_WRCH = "0" *) 
  (* C_USE_EMBEDDED_REG = "1" *) 
  (* C_USE_FIFO16_FLAGS = "0" *) 
  (* C_USE_FWFT_DATA_COUNT = "0" *) 
  (* C_USE_PIPELINE_REG = "0" *) 
  (* C_VALID_LOW = "0" *) 
  (* C_WACH_TYPE = "0" *) 
  (* C_WDCH_TYPE = "0" *) 
  (* C_WRCH_TYPE = "0" *) 
  (* C_WR_ACK_LOW = "0" *) 
  (* C_WR_DATA_COUNT_WIDTH = "11" *) 
  (* C_WR_DEPTH = "2048" *) 
  (* C_WR_DEPTH_AXIS = "1024" *) 
  (* C_WR_DEPTH_RACH = "16" *) 
  (* C_WR_DEPTH_RDCH = "1024" *) 
  (* C_WR_DEPTH_WACH = "16" *) 
  (* C_WR_DEPTH_WDCH = "1024" *) 
  (* C_WR_DEPTH_WRCH = "16" *) 
  (* C_WR_FREQ = "1" *) 
  (* C_WR_PNTR_WIDTH = "11" *) 
  (* C_WR_PNTR_WIDTH_AXIS = "10" *) 
  (* C_WR_PNTR_WIDTH_RACH = "4" *) 
  (* C_WR_PNTR_WIDTH_RDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WACH = "4" *) 
  (* C_WR_PNTR_WIDTH_WDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WRCH = "4" *) 
  (* C_WR_RESPONSE_LATENCY = "1" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_fifo_generator_v13_2_14 U0
       (.almost_empty(NLW_U0_almost_empty_UNCONNECTED),
        .almost_full(NLW_U0_almost_full_UNCONNECTED),
        .axi_ar_data_count(NLW_U0_axi_ar_data_count_UNCONNECTED[4:0]),
        .axi_ar_dbiterr(NLW_U0_axi_ar_dbiterr_UNCONNECTED),
        .axi_ar_injectdbiterr(1'b0),
        .axi_ar_injectsbiterr(1'b0),
        .axi_ar_overflow(NLW_U0_axi_ar_overflow_UNCONNECTED),
        .axi_ar_prog_empty(NLW_U0_axi_ar_prog_empty_UNCONNECTED),
        .axi_ar_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_prog_full(NLW_U0_axi_ar_prog_full_UNCONNECTED),
        .axi_ar_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_rd_data_count(NLW_U0_axi_ar_rd_data_count_UNCONNECTED[4:0]),
        .axi_ar_sbiterr(NLW_U0_axi_ar_sbiterr_UNCONNECTED),
        .axi_ar_underflow(NLW_U0_axi_ar_underflow_UNCONNECTED),
        .axi_ar_wr_data_count(NLW_U0_axi_ar_wr_data_count_UNCONNECTED[4:0]),
        .axi_aw_data_count(NLW_U0_axi_aw_data_count_UNCONNECTED[4:0]),
        .axi_aw_dbiterr(NLW_U0_axi_aw_dbiterr_UNCONNECTED),
        .axi_aw_injectdbiterr(1'b0),
        .axi_aw_injectsbiterr(1'b0),
        .axi_aw_overflow(NLW_U0_axi_aw_overflow_UNCONNECTED),
        .axi_aw_prog_empty(NLW_U0_axi_aw_prog_empty_UNCONNECTED),
        .axi_aw_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_prog_full(NLW_U0_axi_aw_prog_full_UNCONNECTED),
        .axi_aw_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_rd_data_count(NLW_U0_axi_aw_rd_data_count_UNCONNECTED[4:0]),
        .axi_aw_sbiterr(NLW_U0_axi_aw_sbiterr_UNCONNECTED),
        .axi_aw_underflow(NLW_U0_axi_aw_underflow_UNCONNECTED),
        .axi_aw_wr_data_count(NLW_U0_axi_aw_wr_data_count_UNCONNECTED[4:0]),
        .axi_b_data_count(NLW_U0_axi_b_data_count_UNCONNECTED[4:0]),
        .axi_b_dbiterr(NLW_U0_axi_b_dbiterr_UNCONNECTED),
        .axi_b_injectdbiterr(1'b0),
        .axi_b_injectsbiterr(1'b0),
        .axi_b_overflow(NLW_U0_axi_b_overflow_UNCONNECTED),
        .axi_b_prog_empty(NLW_U0_axi_b_prog_empty_UNCONNECTED),
        .axi_b_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_prog_full(NLW_U0_axi_b_prog_full_UNCONNECTED),
        .axi_b_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_rd_data_count(NLW_U0_axi_b_rd_data_count_UNCONNECTED[4:0]),
        .axi_b_sbiterr(NLW_U0_axi_b_sbiterr_UNCONNECTED),
        .axi_b_underflow(NLW_U0_axi_b_underflow_UNCONNECTED),
        .axi_b_wr_data_count(NLW_U0_axi_b_wr_data_count_UNCONNECTED[4:0]),
        .axi_r_data_count(NLW_U0_axi_r_data_count_UNCONNECTED[10:0]),
        .axi_r_dbiterr(NLW_U0_axi_r_dbiterr_UNCONNECTED),
        .axi_r_injectdbiterr(1'b0),
        .axi_r_injectsbiterr(1'b0),
        .axi_r_overflow(NLW_U0_axi_r_overflow_UNCONNECTED),
        .axi_r_prog_empty(NLW_U0_axi_r_prog_empty_UNCONNECTED),
        .axi_r_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_prog_full(NLW_U0_axi_r_prog_full_UNCONNECTED),
        .axi_r_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_rd_data_count(NLW_U0_axi_r_rd_data_count_UNCONNECTED[10:0]),
        .axi_r_sbiterr(NLW_U0_axi_r_sbiterr_UNCONNECTED),
        .axi_r_underflow(NLW_U0_axi_r_underflow_UNCONNECTED),
        .axi_r_wr_data_count(NLW_U0_axi_r_wr_data_count_UNCONNECTED[10:0]),
        .axi_w_data_count(NLW_U0_axi_w_data_count_UNCONNECTED[10:0]),
        .axi_w_dbiterr(NLW_U0_axi_w_dbiterr_UNCONNECTED),
        .axi_w_injectdbiterr(1'b0),
        .axi_w_injectsbiterr(1'b0),
        .axi_w_overflow(NLW_U0_axi_w_overflow_UNCONNECTED),
        .axi_w_prog_empty(NLW_U0_axi_w_prog_empty_UNCONNECTED),
        .axi_w_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_prog_full(NLW_U0_axi_w_prog_full_UNCONNECTED),
        .axi_w_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_rd_data_count(NLW_U0_axi_w_rd_data_count_UNCONNECTED[10:0]),
        .axi_w_sbiterr(NLW_U0_axi_w_sbiterr_UNCONNECTED),
        .axi_w_underflow(NLW_U0_axi_w_underflow_UNCONNECTED),
        .axi_w_wr_data_count(NLW_U0_axi_w_wr_data_count_UNCONNECTED[10:0]),
        .axis_data_count(NLW_U0_axis_data_count_UNCONNECTED[10:0]),
        .axis_dbiterr(NLW_U0_axis_dbiterr_UNCONNECTED),
        .axis_injectdbiterr(1'b0),
        .axis_injectsbiterr(1'b0),
        .axis_overflow(NLW_U0_axis_overflow_UNCONNECTED),
        .axis_prog_empty(NLW_U0_axis_prog_empty_UNCONNECTED),
        .axis_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_prog_full(NLW_U0_axis_prog_full_UNCONNECTED),
        .axis_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_rd_data_count(NLW_U0_axis_rd_data_count_UNCONNECTED[10:0]),
        .axis_sbiterr(NLW_U0_axis_sbiterr_UNCONNECTED),
        .axis_underflow(NLW_U0_axis_underflow_UNCONNECTED),
        .axis_wr_data_count(NLW_U0_axis_wr_data_count_UNCONNECTED[10:0]),
        .backup(1'b0),
        .backup_marker(1'b0),
        .clk(1'b0),
        .data_count(NLW_U0_data_count_UNCONNECTED[10:0]),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .din(din),
        .dout(dout),
        .empty(empty),
        .full(full),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .int_clk(1'b0),
        .m_aclk(1'b0),
        .m_aclk_en(1'b0),
        .m_axi_araddr(NLW_U0_m_axi_araddr_UNCONNECTED[31:0]),
        .m_axi_arburst(NLW_U0_m_axi_arburst_UNCONNECTED[1:0]),
        .m_axi_arcache(NLW_U0_m_axi_arcache_UNCONNECTED[3:0]),
        .m_axi_arid(NLW_U0_m_axi_arid_UNCONNECTED[0]),
        .m_axi_arlen(NLW_U0_m_axi_arlen_UNCONNECTED[7:0]),
        .m_axi_arlock(NLW_U0_m_axi_arlock_UNCONNECTED[0]),
        .m_axi_arprot(NLW_U0_m_axi_arprot_UNCONNECTED[2:0]),
        .m_axi_arqos(NLW_U0_m_axi_arqos_UNCONNECTED[3:0]),
        .m_axi_arready(1'b0),
        .m_axi_arregion(NLW_U0_m_axi_arregion_UNCONNECTED[3:0]),
        .m_axi_arsize(NLW_U0_m_axi_arsize_UNCONNECTED[2:0]),
        .m_axi_aruser(NLW_U0_m_axi_aruser_UNCONNECTED[0]),
        .m_axi_arvalid(NLW_U0_m_axi_arvalid_UNCONNECTED),
        .m_axi_awaddr(NLW_U0_m_axi_awaddr_UNCONNECTED[31:0]),
        .m_axi_awburst(NLW_U0_m_axi_awburst_UNCONNECTED[1:0]),
        .m_axi_awcache(NLW_U0_m_axi_awcache_UNCONNECTED[3:0]),
        .m_axi_awid(NLW_U0_m_axi_awid_UNCONNECTED[0]),
        .m_axi_awlen(NLW_U0_m_axi_awlen_UNCONNECTED[7:0]),
        .m_axi_awlock(NLW_U0_m_axi_awlock_UNCONNECTED[0]),
        .m_axi_awprot(NLW_U0_m_axi_awprot_UNCONNECTED[2:0]),
        .m_axi_awqos(NLW_U0_m_axi_awqos_UNCONNECTED[3:0]),
        .m_axi_awready(1'b0),
        .m_axi_awregion(NLW_U0_m_axi_awregion_UNCONNECTED[3:0]),
        .m_axi_awsize(NLW_U0_m_axi_awsize_UNCONNECTED[2:0]),
        .m_axi_awuser(NLW_U0_m_axi_awuser_UNCONNECTED[0]),
        .m_axi_awvalid(NLW_U0_m_axi_awvalid_UNCONNECTED),
        .m_axi_bid(1'b0),
        .m_axi_bready(NLW_U0_m_axi_bready_UNCONNECTED),
        .m_axi_bresp({1'b0,1'b0}),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(1'b0),
        .m_axi_rdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .m_axi_rid(1'b0),
        .m_axi_rlast(1'b0),
        .m_axi_rready(NLW_U0_m_axi_rready_UNCONNECTED),
        .m_axi_rresp({1'b0,1'b0}),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(1'b0),
        .m_axi_wdata(NLW_U0_m_axi_wdata_UNCONNECTED[63:0]),
        .m_axi_wid(NLW_U0_m_axi_wid_UNCONNECTED[0]),
        .m_axi_wlast(NLW_U0_m_axi_wlast_UNCONNECTED),
        .m_axi_wready(1'b0),
        .m_axi_wstrb(NLW_U0_m_axi_wstrb_UNCONNECTED[7:0]),
        .m_axi_wuser(NLW_U0_m_axi_wuser_UNCONNECTED[0]),
        .m_axi_wvalid(NLW_U0_m_axi_wvalid_UNCONNECTED),
        .m_axis_tdata(NLW_U0_m_axis_tdata_UNCONNECTED[7:0]),
        .m_axis_tdest(NLW_U0_m_axis_tdest_UNCONNECTED[0]),
        .m_axis_tid(NLW_U0_m_axis_tid_UNCONNECTED[0]),
        .m_axis_tkeep(NLW_U0_m_axis_tkeep_UNCONNECTED[0]),
        .m_axis_tlast(NLW_U0_m_axis_tlast_UNCONNECTED),
        .m_axis_tready(1'b0),
        .m_axis_tstrb(NLW_U0_m_axis_tstrb_UNCONNECTED[0]),
        .m_axis_tuser(NLW_U0_m_axis_tuser_UNCONNECTED[3:0]),
        .m_axis_tvalid(NLW_U0_m_axis_tvalid_UNCONNECTED),
        .overflow(NLW_U0_overflow_UNCONNECTED),
        .prog_empty(NLW_U0_prog_empty_UNCONNECTED),
        .prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full(NLW_U0_prog_full_UNCONNECTED),
        .prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .rd_clk(rd_clk),
        .rd_data_count(NLW_U0_rd_data_count_UNCONNECTED[10:0]),
        .rd_en(rd_en),
        .rd_rst(1'b0),
        .rd_rst_busy(rd_rst_busy),
        .rst(1'b0),
        .s_aclk(1'b0),
        .s_aclk_en(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arid(1'b0),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlock(1'b0),
        .s_axi_arprot({1'b0,1'b0,1'b0}),
        .s_axi_arqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awid(1'b0),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlock(1'b0),
        .s_axi_awprot({1'b0,1'b0,1'b0}),
        .s_axi_awqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_buser(NLW_U0_s_axi_buser_UNCONNECTED[0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[63:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_ruser(NLW_U0_s_axi_ruser_UNCONNECTED[0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wid(1'b0),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(1'b0),
        .s_axis_tdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tdest(1'b0),
        .s_axis_tid(1'b0),
        .s_axis_tkeep(1'b0),
        .s_axis_tlast(1'b0),
        .s_axis_tready(NLW_U0_s_axis_tready_UNCONNECTED),
        .s_axis_tstrb(1'b0),
        .s_axis_tuser({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .sleep(1'b0),
        .srst(srst),
        .underflow(NLW_U0_underflow_UNCONNECTED),
        .valid(NLW_U0_valid_UNCONNECTED),
        .wr_ack(NLW_U0_wr_ack_UNCONNECTED),
        .wr_clk(wr_clk),
        .wr_data_count(NLW_U0_wr_data_count_UNCONNECTED[10:0]),
        .wr_en(wr_en),
        .wr_rst(1'b0),
        .wr_rst_busy(wr_rst_busy));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2025.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
UU0HctCtrDGjqiFgNj8KUV1CNrtLH1fzvWozH/S7aVj0RSc24esnSs0ybsApJYbLPSCW6MJRxlk8
TZTBIGKXHEs9iSJrHyeb7Q9LsfbX2O77j94jiFzmN8lM/LIVA6RCDBtX2LtKWWw0Ex0IvwdPy+Mg
2z4iCfTMzyceiAZWkhE=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GF0Vw/gqBrc9IHG5aASlKQHzVjMUtBIwjnrAUquexOCvx+SSWyZN88WoE2YOio8l2Mng8jmA3ELb
iVwbk5kPsSQid3iLelRIejTGTCNP7ErmhAyw9N/gInxZrkBgF+99fwCp/qSFsRz+GkpjXlmNPLal
1m+CmI2mtQjH/zDmulZq9kFS9URMU7E3TrKSiNtdLMYc1ulwC3kFJ99geu/tuMfIrNOmA9KkJtnb
Zoy9fNs53bR+fUGBL5n7AwoO6cdU62PpktsyWXh1Gp6Ylf2HTT0CPMyzWbJQve0G4+iszllRawxG
r+FcAh4BuFpKqaFogcTloexA8MTZ9ICsGZkzkg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
Hzytw/FfXpsPrE5ZowzcEV+nwakl1BirWDR+Iseu9nWPYk6Otw/UyzdfMGdUJQcXxjn8eODJUMPS
SLvHyIbu8M+iaMMz4+lNG/o0csNo8MO67HX9fxa4xkVOaSOTCzBVfRk3cjnK+OAXlJEZO2/F0Im7
evCVwWE8mv0p9yv9NZA=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
aYTxAf85PVmpAktzX89uf9AJXAUs8FLk2gaAmaPtMQhfYN72ydFe5GcOlR9/W705GnhW+LSDUX2b
XQnSvIzmqRMwIqE2sgix0W4aZDvptNpP2y+gttAzQaOhAd12INExGFaZxKro7f/cey7YiwGKPPah
zcBWMoHI2bIhFDe04i/Jt1MdciCe1haFyhwBCett8eV6Laia/DlHOXxqH2bLukgGZp5p2EYoM0T8
WwuwxJ3X0IIphS/uP6nXSuuuMQcAplYzcG4PLCMpn2Lo3HwmwSo5w+0N1NFI5LYfb6ZrdTXjRH+j
oHZlteBZzQ+4jNx7/nPPCnuUB8IFMROek8y3aQ==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
e6jDiYnzLTYk/3jC49X3YNnxEmaFBYGO/cl88hMTKYq1FltlAtsDFs47xPVxcrXJmXB6FiDcQKgy
Zcri+H61avSebr0yHZ1uigtfwqLvcivJwyCmMK1zZ+tk95pu+v8wQUekejQwCfm8d4EwcPtFRBCP
VuiAB7kH68VA/rKSNW/L3Ck+PVdkE6HHJnrneJm4Aial7Xm5QOsroJRJU/ObInH0MO+tgwAysCdd
6eCmjEBFQGTjmThY8W79EF9AQGGRTMTJSajCB65vB7j4uMsw7y2m2q5T1cf5FapbNOa5qVGM3ltu
WzPHL8ffpwsn/Um4FxL0m2OELCU3vijgWPxyYg==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2025.1-2029.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
W4uYHM01gGeA2MU+ib2L/ExIRZJnY4G/4/BNSFnBkDMClm5bxdPZWGZhCUejE4JXBUBzvBBii0hv
o/qn9snazl844XvvPfn0rjgdMjBDDTUc14EhQ+t9LtnZFAV+z3wAIKGQaUOt5C451j/28rPyPkS0
kBiQMKRYL8V8HYzz8PJCw/2pMZh5nAGYlHVN7x7BRfHg/eGLL9Vxje7mRSIq9oPfHNxp9KvTPnEz
BAbFFeUiH6gtQHgv3loUdp74IXW+8+uJHlh0BbE4crWkB23UetPNvBTz30q+iGUe+Uy9cDako55V
AVXIMgciLrWVPF+qY5b7zySQkB4Xsfj+udkVyA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
R0MJeGCQpSjYsGBWKKr56ZJi8ovYpLtniBxpCnrQicvQybY+fnPA8Daj6MXdCf3qwLF8yF5WCJ8s
qgsZvXSLz7hwsKVEId08i3cpwMDSnKdPTNXjuKS2h7UKOlcr6QZ5j31qcO2XbyCffpn/pAXTmv3a
wywj0bLNK61+JY8v+VTzUKzR370hK34Ryuts+hg1InhuHxLuVnu52lVOpk/PYUaA+w7ORS7AIzBm
Ic2Gs+gCO56TT/kHzEdPXDOhyRk/LG0ir7xXNq7VYILxVh4t9QTZ+TIjutFAhElz9ceEjJ95QYy+
i58LiAOmyF9ID0yxSSYM4KQAF2bqt9kvgdWRhg==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
piBTg4FhL4gV7WxO2j/dIDXpMS0DVV+BCPbz6qHH74TfGEKWiiBMU6gK+ZbplwJNS8NHNyEzAlya
r4wgVpBFLdWysNz1JTSjKKJCO9JEQN5/H5jfiaYLOSRwE+N3Opc54BvT85yu1V+zTS+2aJj4AQ/f
gjyVCtr2A8YVv2zEjqFuQcYlcSxHTEk5eig4u36hHgzGJsmifFlP0OtE2NeoOMzFbBJe4LR9f1Ac
XQfLq8HilNwnOz4EYZGL9iJymjQ63NwSYfWcRjHVPPJXQFZSrWlI6V5kkz1/IDnPuelueoAKOk5K
OAAeaRjYDKgXhfse4B1Cy+u9f08zryJez9v+yfA14jVDkQQJp6a0qHJYuemefEFrmwJxSLUqG+Xq
QDK6/emEA9ZXoln0PNQyFzaEVDeFDZBn8LZi5SGL6f+TpO0acfI2jxa5+vCQHX/boxpyVjtxPh0W
Xjk7+E7CKFDmE6T/ZNnn7MRpaG1g4A2TEvSqCSRRnPprcg/+bRR6T6Sy

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GlYhuN+XgK/dKipYGy0F51EWCsMzdTtEw7DUl9GCeVeyU6B0qQxd4o+WGLqPzleHUcbSjTY0Zsbn
PYVk3cx1yet4akcLytYAGFXC4n/Xi+1UqMz5TGn6+YQTvRIQ3rDpVCwwETOtxY9exyURa9vrZwN6
wg8aS7eaMRDPPrD9XOy8sQT0WrdKizBToFy2xoVRXceycyYYY7TdZikow1sCVE5Dsq8WQ5SRprGB
6XOvNlQnaIlUCVafx8nFv91VsM31btEViBrUpTqFHJAuoebt0ZL+JlrQ5nOk7XQnw6AQ+0ZlOKba
q3Ttg2CqLMLHVI+1yNiz+OEKhmPV1D5J7vlPQQ==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
2gbN0jz/o58BxZjM7+eT+qN7Q3qHE0g1JsI7dvdgaVydBYqQVWbzuiZYLMAHv8yrsn9b32oHcBSE
0o5Cui6GiD7neKU4AljBAlKAaN9vmM7TfUunNvBpRwv61T0jxsnbQPWfLrtpbTXbXa9k+COT+cqb
xPXfz1KFKZR+jUVQfqg3k9yE8k42Qekbv3kD1KU/qey8yzrOiZWk3YSqYVf+xtUpOvJY52CMhroS
XNjVVkBPUu8Qp/8HAzxqzWi+9FMbOuRKapPdzyPMn/9u5V3oDa03Jlbl/wNvQRAMkkI4MR0Z6Fef
acPXE4lO4yrbdCI+/JWNiFnMhbPxxOqB2cgi5g==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ijvB9ebv8UTsfEBOdwLX29OhkfU+M38mGG3GBCgYR1J/bZmxD6jFCxoFCEm1aKFgD1oURupMHfs1
c3MOeOmJ+miekD3bzrkO2GpRCnMbhKovUm5w9Qm7OnK1B25OU6+Xq1Ykk4tIi1xMOMYX8YKOrSrC
twPgnJ2VHr4FFKQ+p5YO7BYb6KtJrf3+2JKYjVPpp3gkR5SZklV/ugbHgXnKTC8NtjSnys5yM8fs
hXOpMWgzLJxxPm595q7fFP3rHvMyw7H7unYraHK+0uc9zTFZ4LHWuOQvc3TRUEmRmJmaag8nwld1
2cnhyhbuZqsuwb5+2W6amIYGSDb8gPS45qwzBg==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 51424)
`pragma protect data_block
yEkr9AtNM7FYTpMCcCicCa4sV9mXccOHJYa27Ec+AlynQlOjw8i/LXfAPI3yDzaCUKpsmln30x7c
X08BXAhyBzbSyHGij/WtYpw3W/trkl/Y6HN6k94gbUNkACTTuPmc1hgMiqlRx44eW06SLmUyiVxY
D4sAkyP/E1BH2NlGt7Ru9FSv10unfjrQmTvwAxMp7XYNi2+UmNA6N7glJFr0SaWTTzANmEW1wu9M
I5GCajZwWuYNAkKZDykxB/68rfZamaH8c65rag+PR/D/XTD9rFnaZMjVt08UpNFW80855jHHnmyJ
/5zfipEkVo4Wvr/pSK43bEBneS1vWmJaaTyNDWlcyOrjes2/e9qEEHjRGZGWdQfLo4/jdVw0EiMp
cO61gHixDvpwO75GZJUvu5SSp29RT5G8UEDvJ9Xp99+vVU38fVIR9ur2TAnbUilOiM8SGrYvkbm1
BqoWHWhk4PlRQXqzhW0CrRW9vMrDzWIbzaHuPioztdCukwkUTypTbAl754crLXYD/YJNKp9IOXWP
fp1JvPIBvPgxL9eXkILOtdlmd/pYSaIoS+sGbafhR5cgyHSD4S3/+xh6MEO05NPREQNA+K2x8KTd
aLvYUwjeNiPahcIhLI+GXysUm8N06khVIrK+EHw4yCYInkYhQedYfWTh0YkdmE/ClsKiDyt4ypuC
VeOmnfhfCCIvcGAsfQ0d7fi29N1rqU/xiLfpYfzXLhAUop8o/BZRFwhcIACrJXHT6vKDFfe5pUmT
kcfGeA8+pyXUU7zTM2WTymmPSvA47U/AytYZAzw6Jp8kfCEejs8TNtmD2rlQynnClCMdtE8EI3xX
JsXv1k/Enmo/pBdXo1bBQWjki24GmMlpOJHdWTeiJNca8zuYHkLcJzv7B9fPdW+ObHUm3rgsIZKB
xBPo5ImI2Qm7aMex6XO2BYx+vjupghy5Semy+lUQFnpfHdXSMNHU6xqdymlPKeL2OwjfZoZitpdj
sDB0qkUaYRpTuMNSs3oqV5UvmmlNEhFDTwha7ugM3yU2pvI/lHVh8xK1D3HzYQcCAf4vltEAOxtK
m40UwzrlPT1H0sxRomPJCR/mRkHKsuUrhVCwhnmfexJqqvbf2lu6regnoU30RZFMV56O36CYl0wQ
5eylOfMiyU8jAvlLOnt+sUOQcadojjSz34OwDc/G/eruMBrbH/wvDaug64zs0/65WsR2j372aEcd
UxKFpjs5F6lQaW97YY/7U6vvaBwzKyksTHcI6F6dMKiURKza9w1QHCPolBU7IMJMtWxIzacTCZwp
tztEwunpnyB776MugqN1GYHV5QuxPHd5N5Eq63FJXMoS/EBrXWMuMFhiPE9e9Nwpt2OOCahKrMhA
d3gkxD5zIqQjbPhOCOrNM1ainvHGGIydsHnnKSmFS55M4TbpygLeX4qWyntIhVTk/yNpp0GN0Vmq
LhwHKNJ73L7sS17c6mt8jOs/cykXt6QJ8uIj9aNPPDT+6879mBnWdZHRTv6zvH7a97EhUBzEQRrJ
z8HjO8FG2QN0wfdGFfViYQTuKrrDsnZHGCPndwg877/ot9wwvjWFrUeV0rF9D5hnYfdZZNhqU4DQ
0T1OO1MQRjc028Xii/tMLQ+Mq6dLQNvlVlKHkU1FgxZfWFwyT0O9KSh7apU1AaPXp+hWSDzUpZdL
7ptipEBkFzmGl2usF1XNLhyEu3ikbXVxh8imTapgmF8MPE9k7Z/+uwzfPnbVep6mdqmTPdiLv2Xj
UV0d2igjuZ56W4X3E8s4UsdOevmGQykdWQ5F4prmBFNQyCSSmTvQ71Ot3kiHdWuv8DQhKH2KjCUf
Y6hToP6EqGZhTaJNy/KWr0PCkz6m4c4Sm0CCXVX3vBfO1zmhsDbo3N5iL59riQdY0VBULTtXuu6b
VnDnwXBNTYJFlhX54s2Kr4MbWswV+ohLDFaGcECMLPtPznFXBp4GQzZFKR8OHnwye75SO6DyCFgc
Zcmo9pvYm7HPzyWdD18hulttiCicqOrj91wko6fJMaXD/aN8bb59/hQHlWUAMVwqd1lBb/qidQXc
S8nbcE529WxiHwiJrv1jZaAp4E7h7Zg4RyCbNPx9vKUx0VfO3jZyd1/cC2YDNWfKpFkYRAIdYnNe
eV9c8kTS5qtC72D4QwxvQZHJvDR9c5DRQ1ZhNwJHRG6HyAosB+Y+ZqH1p7h/HNrKJggarBTUcxrS
Z3vJXdET0p1OC4I4VGB/cR3ia6KJXMaqOiIselE7dQc9ShEAUY1iyAPWlFTiOC9RlHgCZm4jcOtk
YYk4WMkeM8569x0l2qhbM6DgnqjvTW73rIp8OjXOxdFP/+72T0HcQfU/F2ZKn47U514Zufs94w9O
EOVRB/fbrHHoIv9VqoLENqTEWQB4KK9HLuNHXyQc6msTGhO6htR5bzKHbkSJeJv0819G2266OlCw
FfWAd+f+3GM+LmddkG/fodBuJ8zZ66fmf7q922dPsjQx2aqzd0ixzLxf1TPugqxym0Uo5QEByJLx
LN7X5IAWbR8wB7Q+SQoPDMaPs7nUNHA6FrCcM9EWStxyIu+NNQPdvIaPpvf5ZQu/A6K8B3gGfQdC
DnipQNPBBT5jY66XZHGoKdFjK/SEMCk4GteGtLT4TdODph3vMfYShVxLOjUfXM+YpI6kbYpBjrP2
OmaaxhtwqyQ5tb1a3kFINRuqHIGA1rI6hpCEP5XqWEBbdndxehFFQSoeNWQjvwPrwJCllXZtOU9O
WkG9vAueCGxXKCKwdorQZ8s4rXOhOSdLhbXr4DxYNTpnP7qycDM3acu9g1YUEYyyU0JST2NbKgRQ
/93eACW7Wg5wsDW+uiBoBdA/CZiwDe8lSp0C3D2w/Thx04NM28zgg1MWKQ5Ql5TQqQV4aOIlij/a
H9QV99MbItAg6buA2RoA6sIG+WczoJ03NiAVyPcIUlQbiXn586nnUrcCsixuArNGROxDFCDQl4/4
WsZpr+15cjMo4G77p8IuHb/+GAZS2E8u+0HSlo/FTMF+gsOHuJnJEaV0fVRsJvQ3gdy1VeVb+6Ux
/1l1KRjdgkFZHH8CY9nnnL1rcSOvl5xvGHXd070/hRXjB3OfHooW7S+52SDqbo59Jv97Q6zUJKoG
Mpshxu5ks7vsNym6QA1p+VihwI7Hhwtp2E/im9ZTtPuVCpXLU3hMwRHHSR2idJmtnIq9yADTsc3H
sRtLfyRlS2sHEynNAQaT+ABXb52SibK3oN3Zo9BHTrJswC/Ar0R8dZiMgdIj0T2bwH8yczbJv4Tm
Va/5DTCEJhaNekrH9hXNvyYvk70C5decYlgwJm1SRskuNAhBffykpLxF1NeQbQC4Ao6WuwQcf9E3
NINndIe62vaDmL7mjCQ8XZhgUy9x8ORtBhuP1MG7rRC0lbEhMSozq6O/nS+pI8+nWE4/uXGtIaVw
Xe+OPzfjyUP/JiS9tWj9R5q+YMTSVQJPQ5ZpaNBvqjW0kODz0Db1+2rJQsJ6VfOP2pvGkl7bjJGz
4toUIkK1RBR3XImJV/4II8SJyFTJUM0mPkr4nar+0YR/cI7wPhg0dOLA/Nbkr+AsmTg9yjFIxmhw
FdU4dE/RWLsVMvepezVH1XDsHEiTlBlgF8qDciA3tBMd0O4tfNARMuTwHfMqRINKLBXkDwlsmG8U
wD3/zCE0VxOlUxs754K3kfdpQ1z3ie6bBvdFU7uQensSJ/Pn+O0nde5hHZkKdE7XO3oFEYoZXFZp
6tfn55l7+XikRyHBcGSc4KqG9XGQNpnrqe/VOmbrctiS94Z/U2fBA/hk+rBP7EqsgS5kdzHJEIa2
IQSbl1Fp5Qouh9e4/f2Rz4pwfvKEvMIK76jnefHtL1MX073IEkvQlT8RxfhYU04r9Eh9MMawM9xy
Mgs/QlY7UZZwS8u5qQmyrHuje2/TkSeYj0tx37xewUgFGDT7GjZFWoi4ihpialrXykUF5hmAvEsQ
WDcs9mGdaprBL8A9UWhaKL1UAbivMqbZYGjI2zQchvpylvrVr7Bw/J8QaQBCJ4NSo9k/IVJI2A6f
OOWAxDEE87xfPSQh3pGifckWYkfBeXQNLpFmckwTVJOuMCSu4cw9EOo9YQfEaFENpGSY5FYji/wC
/1HDDjE6X4fEoiwvRw3Aw9U3aKSc6ViX8S5UODPTLKW9TiAPos3YJmw+3isvJqCAlTAhz+CHHR5u
SaV/Zy4jIY/WvrcmIRhuItSJDV8hoSWKVfPOAlGmuDmx3WV3key4Su1v51X1JRX8rVFJrip2mjtM
h2sLRm25faoJQ6mcFTswksHdIHbh4lexoP4Y8wU4EcoNjJ27Lpp6eTOfJsCJWdJAFkLv+oXF6aIg
ohK6BM3E1yfUoW3N2rWPTgz5W2pEJ2rB15l01Ds6t4myhbOgWNEQTsitXpVLjvL05IUkT+g+BCuw
GzfqSK0pGx8iXC6MAKUZ0XlBmDsrL5YTGC6kfaye31anm6ievdE0CwDmI/0Pt41KcmM6YxTaRBeA
ti1qN3U+2uvF6svL0Ii9Te5quqgfN61Oz6lCiPZkOsM06+pBUD3PYz6pBORC/FYo9cYpwh3nSkjw
t/QY5qDOGAjRcZJOAZ5mn5AiYXPMMXZPeMvQIwqKUcrBaf62xzkLyKcsk6Cy9M8nfBhbbsyNq1aM
LnZN1/t3mkEgwdBWjJr5RPHlAe5zpQB7e0ySfPH5QXgEZR9c/X7l4ek8Sar4PnLdwFZOBm1E8mXk
lGwVuYNqjRe4C6tAv7Fbryp8q8RjM+6jZa2mZHNTDEbu+Zc/fM9wGhUMH2mYgqIvadNgbJvbictq
jWFNt7rjF00cwxN4ZrMmT9GYXdBzcmtgl+LtHnQ1uOLcmp4eaLnRXywfdBb0PI5I3tSStRaVhuWE
r/yOvEsFbCnOuQ8J4arJ4tYrj/VEXURvj1ah01mckrvRYf/pN7GjW9yooKQpmQx1Uun65iOTYT71
xzaJZAStB1buCRbzQUv8LSni6m8ybe5GD3+kMpJOkcmR1dHcGZi7AuY9USwQxMEWsuTY1RKe3mAI
h36jcMhNdX1U3PxSQjNwuv1I+UCD6MShro6VNLhm+mYR/AFPWVHigElnjOBMcNBT0LgG47u5KuCa
rT30gvXUevbu/GTX2qN137R//tiWT8RXVYAaN2jAhjvV8eIYpp3K19FBtl+d3DndZXZhTiKFt7p9
gWZpaaYbNnk8SQNeHb1+xeh+goYW7MBXZQDSDVW4eV15OvHuaLgPaWrCZkjzsc23qhZTmvegExEz
6LyYiW1xt/4owmB5ZDwjsnyUHaa3IhfPUikbDYDroJcx7X8m1x/+1Kwd7/q2Raj6dRZICPTyyfZY
eEqZd0cEEBW6jAdZvrLcmTLPKy8HxgrF2l3AIqQp1y+Z7IUo3wgk4WfweBEoTdSpKYgnZ2qQrLhg
em0XSiwmExJkXo4z4Oh6AmTsSHUUwzELiear0ogqvrFU3Noe5PgOLEtr1PxgZ9SJHxipGpod2GGE
5w5Deu4SIrNvmp9Gs3CDqkRZ8IfFBAk6cTl8Eat1LYTdRt1yn/0Xeeulj+tBtblx1lzLkbfk5Z/G
ejvBZ/6Rhsh5SJfyw0hxdKsTOnjSRjF7OW0pFkvV2rqvzX0rVxwFCQuIW/m4n/jVqzZPeo0Y12re
P2SAhvd2NLMMr/maawTNIWC5SmP1I+ElKf53qeTsvmPLEY9+L2SMVTIwKlIQMklyl2+MkE2nZpmD
V2OF3mRtWYWA4AItcjfYuuo1x3vD7SvF+O4B/fFHcfZRZNsIY9lzW1NrF0zaDCrbeuGwRCXLKPiT
6B/ZI9aMj7sZh6wciNXYLLj0UqoCWl6IViWimhw9Dn54l+LVdwev3gXQBkEosVKFk7g+U6JGagOZ
0te5dkoYI2bXzjFIdMta1uF9TCrvzlA4kiJIvQEJJsw4sU7T0MTI/0O+9gbEbumowuXIjT/4WdUQ
f1nDp6G8Q1yq7gNKQ+58Aic/MZiyP9RP2u4mhVrL9OfOqiES8xVNS6TVr1A913OJdCGKuptlJ+Iu
nU3rHH6e3J9vPugyA4FsbZNUnfyyqmQ+5TnlMYt3fHHVu1MRWhMGZXpfQaNRJ6i7d/agyGWfzZCl
W0OJljA9ZmOAtoemBi8qiRSddrDoiVERzAtU8whdVVEdE1pixz8rDsCNcIsH/f4G5s4IV8/sxh3b
rpzm1clqu1KuxMBR4Fj7CzwBQpd7l8umETlsmZv2IrH2CUMLq509xnAlrsPY3sTuu7ppYzJEHESS
XSs3rLivbtLGb6zBjwdvBj5euJ54RqvoYXxrlp/KbhkX6cL06umCaKhYiRKVmT1f28SRoQkXr34W
sLIlhF7XzfSmSoqo3Vq+Z67ramR0SmxHqMF/ZEGKdexkyuuZOexmPfniTxH53cyid3YfBLy55Vwb
X+hVwiOeN9lkbdCJnp8EKkc/gSiukFRDKJUFiFyGGdKVi+WHtkgWD2Y1DhyetWSD8lHhpenNMKzr
VUwKdxE5vq5ebvkfuKL2QYA2dWeYMAvL0kqC3SpV/mPF95zTSmo6pDH4WA5gD24JSXVcA2IrX680
bOQwb8WpLJkubH7pVhqgIurW1Mb1Rmevlu/dxeiwWyqMnnHJdIqOThcmbhhoAt36j4Yy57CDbt3D
FuTQUQlL9ytCLV74fuutn7IULvBIz+SxvxWs7lT8XHHd9ABrQOMua47rKwYKRJdivrsJ5E1O2t2O
ndkZib8Fv2k+h2QEeEFjoMnXtKKfPc36FQnGYOQh21iMiI50JuwZxcdnoeg+EYAyx0naPvqxgpYm
YD4yqHH+iVt2l/V1fIdSsRCg9ACX2HEROXcz4J4Cy/wRZh3qdBjQZHjAR32WN9M9nfBp2HlnZzJr
vcDYLupnOVA4HT/d6Sm9BBqvXvjCiBzQVT2hm8FI6faJwFNdOaK16qwdeKiyMPVRG4n7dt6u3o1e
8E9epmHn92f/XWrlaoI/6u4R5lG99SzCvc5u/VgC2+Ch7N26YkKTAcsUsk4Ry84blbyZVrSY8n3o
Q1kZfGlVnEK/0Oj+xi1UfiL56oOCBc/f+HZrB20LIqz1WqsPdm23leoa+SY2fcsxBwMFRZv13xlj
sHXAlqw7xSikyt9b4/p8NuDwjibFOLJVcvAmerLmG/ghs2cdWmUiIvALa3mgefTm/yVzt7K5FY+F
gFcpUWNQ0aJl4LT59VBJbTOvi6ZDXA0440QhukvnS8put+nVzcQhhPn6x6ma56F32KscdcdR7ITe
Iml5lXl+jITDnafTpCYrYV6Mef9EFqs/R3n4XAzEcDlzWX/LT3jH74ZzQ8xAMbKrnfXu7081lDot
0Zwp5aYnKyfDH/9uCoK4SprNjFBTYN1HS3ke+1+06fyNPLdsgfy6seBs6BQu/EjQ67oip+5uZHU8
vMk+fJGCxe4U3LTjwk11pVKhYBT0gWELaDl2x1KYJ3j8SOLuxDmL9TbDYlm+xIMbfLUtjZxSxNoK
evhP4elhD6GXRB992e3+tJytd75WYKn4Z6bYAYUU42efzzR0KxxQaNOoxKAEy21CGBseAZxGQ4Od
gwsQlSladjKRdlDmxi4y3gO/TeDdpkgrnjZsVWcaIyxMfyNsg1ic2ujcOxeRjsJlPsqbb6heq+g/
HKJtL3DrSC7s5botT2woTpki5PolCcHF6Z+e4gHTtKGXf/VH2VtE8WlMDlL7gl5A9zOHEYKTHsyn
xWVDvEXf5nV4TPCTivog7qLy+vGiJjhqnvxF2m50oBZOCPv/e0p8MZacw0IAsjI4X0lIS661vU3o
xl3iRDBFFtb22hPYKfkdLkqZEi7RGUbzB1zbElYIwfLeE46Kr5TL5uGJbwRNuW9o7sreD0FlFnOW
OGjzJlnaofegGz9SkW4clbazCtyaggTwibr9XgI6ThvOqVKV3OQ81iN7NwU659rOlgfXWL5YrViU
5EW/XtHLog2UhZkxASSVIyh+JVWgc+/1R6vhjpcY4CaJATXlViUSMXUlmNVFT5tJRCAKo250y0yM
J+VmNm+ElBxmAFfvOqn0p82p2F2jBRA4P14fSffPFpZ78qbb2zAuwB1rM81ZLoHSEjwqjQ7YghVK
+TdpLhO2xjLRW+o5UDe4ub9Cv5b/kXNLgQOeAJrEpYLqBlX8+0wdTc1Wnvn8CRuXdUTjvEoysJyf
2aSmSR1GBRxRxvF8pDigwSm+bPWW3XgRXNd4aiBzYV5oogAod50EupntGp9Xrr+wLURN/j9DSIMa
r/rv7eumMd0HyjrIFvK/QkR6ukx0RMPo1poNgeqoHEtSqMBUKX8LDyYMr9doZLTmsDg+4xPpdrU+
4nOBWVe0O75KOlcZzR532CRSz1TD043PmW+BZM/bXsPF5UkKDZa8Q8QwFXuxmwdhpoG6aSRvoVHX
LFDHX+UxBOELLTYusCe2RbLP7GzV7ugFohVG6cS2/EYql+8ynSdOr9kLdeLmGhe53s2lsIoiZUV3
WRWqmW6Xpel1UEpljdX7DNbH7FCZWI0kyZ67aXgAcZ1/3vQaGUQZvPd/77HNH8HOnAuvHVJzAf/d
IZvtJCI3tCcraygz+BV8TCiH8Ti8pdNcfxi5DJ5Q9gyjnuUlgthMKo63W88cH/QI2rsBzutJRKsg
vY59p+0pgXyzp1t6QC+lRtx4abaz9ahHDLAzaUqEcUwiaIOO3RFE0bjoefoWcCzRSIhbQN6OEdHU
E2Z5CsBn/3UsG/yxwoIRj6+whHTe7WfF7baAR/KjMlP0XJXcMT/gGNKh6CR+ZF5sWfj6cq1TBKNd
2EN2ZvOIrlUIPRYtwvneOFXDUyizZt7HWInN1ol03VmXUdZtsvV3+OBir7Ro59D+kcjwD1CBSJZq
V/UnoTFQ8kNGby8CazMqF3WKlmcQOEnwIAnYF4KnO8nZvpwmHG/LufNNFDH7Ox5UBvvifwiu3pJ8
zz2EQVDMPmB/lYu5+dWVJNkPQ3/aUos+nT6lOUROGzC2QniDpM4vmVkvn8l3PTb7q0vBnlvmQ+K4
5utpm/uLYQjca/BHdR/h+O87gyh7Hs3mXYpKoSDPxCZEHsL/M25Dj5ttYV22qyKgvHOkf/3HwVty
jcKffkF572icpkEbq/3UDWGAdOgOHmqn4JNWZqZoPYcPbRCSTewMAWSJZgV8+/yC8yanOE6oJYqz
gVCX9huFAbwIBwfHSpo0T4dy8pyI383FKHx6E73Q6FDrq7RstMpLkzZYxiJD20LhoC/upFY08lKg
LHXYCwu7qIB+uUk+EHseL/rzWLkTdWNyzYu8o0mG4bUby/2kVgvyJo/tVIEbIqBGvfi//ABZdkIE
iRx95wmUTSbwtzcw+3XO+02fPGaWk6yB+SgN1xjlhUubE7tVTlBTrKE9DRu9Y4zh3AdBeA/hIPPG
7WfKlbm9lUBa9SfuuAv9RSUxOA9s/hP8Dlg3lBXXqSuP46yj7aWMYp4pkuZqC3GCXBybp0lCxbO9
3vSuT2WTjluAv5KD7f/piNvkaBaQAwz2qQHx6tInRYud1nMdegQgvvt528wcI3LOMBLxkf53FqVT
2tyxTMf+1Y5Akdap7XsdL2gJ1ybSYCXaGI2wtsGcULWjyUzlcEwWKHKNXLIYfJAtd+rkNSjflQuF
kJPbmODdu5zEy/wCRPUaeGpXJwdf8hLa0EpZU1tEfsBKPdalJdZu4d5Pxr6UGyHH+1Zm7iAPCJz2
JF3iGRMugzuWWLHtT9WcKXDSCPfZLeOskxKQCyGhImf8tq81/9Er+6LWxGEFPu6jst9FqJ13Z0Qx
QtSgHikP2fmG11Hi1RePbb4HE7oJzmjKnIIDd3XHQ6WA55HysIjp06WcVqM2aTtiPOzB+vp++wiY
2EptGZ/UjLyi77uZOI2JK7T9NH4EokdF8TYU/uMcz7kpWgvPZLL7U8sjYgxeV+ZJHskHedc5/Y3X
ESIcid4W+uDIGF8nTPbLB89Vot9uZMvRwyjnwn2y/DMh/jqNMq7xinFM3CFCwg1C4Vf9yySVTibT
fR2OlOc+6Dwir/F2CmMbdP9uve22fxUzlV6XlEuyDyY6Z9rioI/4l6GX8JaCsL87OA9ZkY0oI+Pp
V9KiEoZ2jy3bDj0r3D0kF8KrN76PZVbUtSQAWo+KYs+RERafM2EmBn5cK7yjtwWoxE8ePDsM/Kvi
d7kG2uJbjeqOqufZUj57pwr+gHbQZK2Df8CMzoGgK7dDHjPsvicp+9oOMRcYUlxRfPI9ZXRBzzv8
c0MDDeEzDK+sdyfcszVoPpQusOsJMWqimlMl/qje1XpI52RMfI0isxlMJ70LQXqSDD1tymZ5/OKB
uhPXvYcWymQ8idA9zM1dp3vcKSv2GKBYiLeYxx89E8Uwx1kwB+RWww4VpZv6/W2gJTfrxNMNIozu
UG0ILi7GtTNjrtrdL6NS+/wNqCIVDkrwpR8G/A8587w/akUCkoAhD8WB0pdEaaLTn2noV2ge8TEZ
I5O64XdSouaGDzPyGHZLCgRf0lv9UDvhXYwAnJiUryM+bpRYqocNbRmHKfwYNg2p/rNd086avaWf
6FAsP3FIsMZPssZCC34Wwt0qnLmtE8InecD6sKBCYlivoS5DoYjLP0obhMTlKquOWsw7CWx8yIAl
R9cqDHEvzTsOAbSnavF2/V37Ndgz5X0GqtWWTfOOH309Q7j3rl0kIShukl7M47lXgzHTlGjul1p1
mpH8d/GZx+ErMvJZ5AHjU6xnL5lllv0pK6OimJM5c6xKoYKO+B02Sk+JbJulRV5CciS70EmAXxW1
hMtDpnyOZjjm8L3WZm4fxMPaK3L9kEHlo0fHu2CDDcPldulo32IU01LwMCFL+H0TqAYGB+Fhr7fQ
AtvB87ulvC41bFRf8s2gtKelRJ3uXGa01eaxsbNUnqZHOwanjnJGWw3zd/zzHbm69Rjp/ee+RTvb
nqy4VoKJowr2glswekbFbyXCa2JLcuGB7kMjCj7QT0IJzFjJnWc8HMV8Ex4OAT8NAhOJuC8dyxfW
vpWaHgPty4nEn92biSWINNaTT76hHIn9dJWUyVL9MEJk0Zgm2ahPwSe+miQbmHadMLwipMFn8N14
8HZgAivRyPt3DardxE9aaJ6rg6m0kcVBd55EBFGEGnqhtxSGj3bdR65iwRu3afPIMZ7Yr1hgtwfq
gz0otenL5uLSv5ZrX5jnsY1ETUNTnCna7DvTFGMjrbDuPew3xB/a1+1uVME9Xag/SSaYIGU9GI/9
ehdSlUHqh7sOYYtzwE3C8fr8Hq9wC8SaVY38IdjsW6RbvtqcEOErKWDttKuW9hrTjKuWQLzgW5E9
pp9WPg1+Wee/wtxBP1dVI865DhQ3HYzPrrBkZC08H2573c20dzqB7bGT37cGrJy0X9BtY+ovFM+j
M+v7XunaBgnyLSv1Dw0tW0C+7XKMnNgzDgiPBTrX3Tmg/O3YWWB7/uS4S++771nWZvQXR5oSpqpA
VLwQL/o9Hzh2+ZvaG5KUVmoQZGpwxq7SGRgF7KHt6f7rZaT9Y2Ic5oDDDhp22zm8f0hou0wQ+sEz
MNG/FQ3xa4EB8VBAjhzbkHd8hXtBI2v+iKGdwtBuxpnmYfYlW53skky34JI2193EKe2MvNR5hoOe
Z8yG5tkv785/0kWVmCpuQxPsOvlVDGlntjJR5sl5wH5WNtr3bLVYyRmwRd4Q3syOCA3rd7yjEYy/
P+YOWBF9A7/iWOK7UAGzKeV7kHAVCe/lPL7Jb9xCAebbNXaLVHCQ4LNqVZt8U9lRuIjFL3+qqD9j
bGNCbHVA0W/GvVxuUyvA8q+esYQh+5sE//rLVxVzTLpqGFo6kyxmYDlqQr7dQxzA3fh7NnwkvKJZ
6K0kHkD6/utPe3EFOzucZ0M9BELAkLnPyJAjq4RzhZhzu/g0C6agXNfeNtZpAjbT+H/EgyU1ERg9
+2HIgiujXO2lgSjpekD3975gpuv6feDg6xU68lTFlaBGPFZlhzPSx3OIx3KLkUxSbjwNUdgN/XKc
/ZqhfMnJjyUaM5MsTwScYCG5U5cHyz5QqBbDM/R9MEqCI12tkud24IMtLCywa6GMajrC4C31EcNW
VB6VMy0AoDA/oSI+zHnfnr90zXam0zzzQ+RkbqCChLDOt/2kfnMT8I+oMKhYN82Di79UPNUlsyOm
T0wNP/YD0HbjGC9xmpftwdd8zjQ0HdNnueansnFPhVGY4idp5OFhleSQkllD4IJz9v1+e9KRMuFs
XbVpl6bHWm1LkCoTDiJ+/1jEmuZ8RHO8VLjr1nKcLFz1msyyTk3LrpQYVl6Zy1Lo9fAg9DOC1mBN
KIIQVlHb9JCTqBrgBMMo9JgnrlbyDMSvY9jv5fSWpRL1aCT+0bG7ZQ4LAfcW7E3u47Ici092oTsK
Z8kujRJ4qM1uu4SrGjb3XzgyTnI4cez8HZvo5O85/ubWD4zOYBAtAXdDcx0qOc5mA1k8Xruhb6AM
MGO89rw1Rt1BnJBHMAdZ5rESj0qk+QBIBGGa5mpfhSs6PV8DVvN9scSYwt/dONjuTBR69sOo0viV
avOXYvnX0SVQGw7YeuQ67To9TfQjvD1HfFtJkS919gHScQr6njtGagpj6cmkXbavNlt2o2R3XZ6p
z7x5z36EJ3IJ/+tmYre4ECnrQhebIjgnCmcsm43Zm4A8ZX4PV2YTuqaGbEutujxzd8815bwiNhu4
m8iDixniUYwkTEvrr6UrEW98lRD3cZ7sjfXyXyc0ORcR4Q//fWs4b3ALnwVSge3RsvLVwK63N5As
h5QtnJ3CzRdCDKC6v55opXyjP9mcTgIG4+gT1RUyvgf1+IczOGsQGUzxH0dwFzYKX7/BOC7oV/El
AXwIhWFG4HrNvRNiFrOoPYvaVWkcU+s721sPShIlNTHyT/O2MW0MTHyZ71n0Z5V2OsLquYhhioyT
6aqiUNMhhbGy/CfRcMr66lgfAlvqe9vzaSUw9oOOpvqpsEHP2jMHKGo2hH+ZI+qpcgQUF0PaMjeW
kc/mCvxugOcnxQZC69GhBjwHl26Au/fxyWY8bxqu/nLMM7sB1kvNmA85En4LyA6bPlX7ox1n0IuN
vJPhyeG+yykO0wq+znjowWzl3l+mpyCmeR+zqXoEg3e/WDY3QMNBmkycpxVNG7s8AFxpii8HzxGE
gwXyQzAvWMFhtTO0rCQCG9WzawP7lsktYuuJlYGfClcn5oFVbYH8eoEii5TqRa3P9+HqKUo/9Ynx
0fBcBoIqJmx6MVYL99CV3MnyLPdTDXxN4R/w42zJ4aroU+TmMt5pv3ErDkxM4XouAUTcWE+oqHgJ
jQMmbGzg3hOW7Eu+pkoAqX/eEe5EaN0X3D4Sx5znYwiKgoJLJ6XXsU2OsmAkpAW15L9wNgEXes+C
b+Mozmg6oD22xu/FWPzJtcyFb5SmjDFx22D2PxlwtlOna3wiLwIlo/5Cm2j2cqYQdn2cydqQY+jz
EVWWmKUY6os5kadgU7QrXRMjDXw43rKSC45HVMpD7ajBpo6yOmvbVBFyxHggp1MunOtct78Zp6JH
udb0uNxT84AwyxHjjW/W6YlkWxzm5GgJa/3ggXFLJuFw9m4eJ5FnzXwBpzo6O7WF6n9DFfE8ODj0
fiClaHpPX3XG3i63hf5SOqX91S0XJD4M9X3CfLyrHGqVl83XVMe1Ajf9RFReYCqOGA8RYpWEcbee
9MTdD6uUOdY2qXmMMTKxLRzCNGRedfSDTuYn3SK8XTKSTRWPfZT0Q8LFnFdo9UGeVeVTtYa6Rs8v
n+bavIOw5gPIQPaK+ch4cFsFEof/bkZhrhmjFBMRm6V/P9gRSULFkEu/TBBQe5cxfp/BmG1fau6b
i5wRcT+XIaUZM2UxH/SV57jpNB0CdxzdAaOlApRKA6FsKTh3a1uBfHvDrAZAVRfn5J2jrfXaP+n2
8SYjuzr0W4TXpYtDQF/xG1u1cfLUnerv7W0YAyCLhMxlMvmdbEskrkaW/3JKXf/jTelt228o8Nrx
cEeNhchmlE8cod/v1+AcmDoWEdue8oKi9bv5GSEIpnPyBv0p2+rBz0NERkptqfoxFYsgGGxu+Pnw
S1H6simGtqXLy9D1J5qRrrynt8v0YPHjLjDib825/3k1oVUrhnUYnxiEq3kEYOU9ZGCCLooa/FVW
GDChSMwqj7CGiVmMo5UNBBDQDH6sjHQ3QzNiQM0HtYapW2TuX5Bvva0SHeghwk7Fll+SWhCcGIXL
/uDsyOVJTb6k+JWsuTGd83rijSpuBQPwTSz9L+lpZMzaYmEo9RGxj5z8ojCWao0wpIu4vdBSlt3r
dxbGfA13jPb7xFW58cPxr6rfgeQ4QcoA66VganMuPrYkTUTRT7qEJWvvmHM4XKOVPLMH9jX6VJBV
qSlmLFkMdmgPeeaxHoyrdThBr/0ISfLcnIAiWMgYy025J8HMTLXaHN6YpLLhRu3zB2m80hozZh29
+Fs01iKEzjDmWI/fnYx8lMIxG6u6CED8P2qC/bAewPAI1C6Id4NLvUZj4jrs6MK1zwmiqHJ1UnyD
2S4z/2x7InLz8u64ZsUsk4V9Y0xJhfspk9hoqU8vXcKBvjpLsHSFrmjLXT1LnonYDZhFVAopv0ol
jJFq6UKSE11lYrroKXJCD+rw9nraJcoSjcTaa+JnFPHlrtteY/eJK2JqgrWlT/eRhfdci/RyzPhm
hQq4463syubJz5vjTcO9is/e8SWzRnsVfUyrZaFBu7J+iCtKZtZW5V0GujmBoVXZdCRQW2Itd7pC
UgTB/4PvwLw94ExSInQOWdWrcy5t+CYW8SABlVrLiV5hi4lB04X5SwtXESbpdH9YqkrPo1efXDTG
qErbM/LyRVfGP1NPFos9CihDGn8um4P6v36FIfGnf5PuS4MnYef2clwBBH7kWjxRXy7Efnt7EXH8
Q1BsE7Pg9QYnR1+uAvFP8SfYXj9Y4AroJVZwA5Y436OZdO5brmSlt+cNfC3m5d46Yq7Rsqq/RjBy
pS1Vy8I3zhoN+sUbbR+BnbrMzOagdWIahyGmHY7VLG/f/j8R8DZgMrof0pcT+OltwOcb9gS7vPBc
Ss7xK6X92VGpixnJe72nqJXt61AIID/pnhFBBrkOXW5oRUjUhlnTAnSYl1qG0+qZDjM2ve4TpPAP
QiiHJVCsonz9WBE+KFCW6LDGuG2b06fLk5tJOHsl2ZtPknxryH18tOUDjj9/gFWCHetXkUKTLBiR
I3bN48xdjBRPZSo/PhfzU847QWrlbZYBmlh+O83ePWKldTMbOkWKnhU6etNaOukzzUOPlyIZe6XZ
ZaCxWNH/fJ3+t/6C5sL9EC99rDmi89gmY9ISEY1eBDH3W+tRByeR3xUg6sFzeNNP85ooqNkF25VA
HXmIXmuYN6ZWDyuT+AimGSIlSehErmOn5rPv4DcaMQdhRCTWttRPNMQazhDyj5LauF9Lp/DL+a5J
gb1aX1gPe2SP4Is7fMlSRnIV1GoPbrQ/JZAwjFgRlrKRxqblQ4+BoqDek5WngM4Jv6pHxk8cGVi+
iOmqXonsfPV5XgMkiSaTAuLeinHeSOoWZQBYIR3kqSIbiKHVoN0YcowzXGgVp6cWX+HSZX+G0eqo
6JFvUN6xnEyXvCFeWmix2g4uxHIvPTgNe3UNbxILidrftC3XTLcesmRAtliBEnoDVMW1qs1t68Y7
TqaGnDIAoIxXcclioxUC1i1gRyYGV/xlx+131WTgSGjYukP2cw4v0DwuCPgI/CQ22/TglzNobe0o
gRufOE/FN31iRTxF9OqhNtEhoUYq5TFmLjXsNVM6D8jwJ63RbBeyF354xrCGsMfV5sQeqIMarYnI
iIValYraIhb9Kn9eU9qjZ5TOXabboAh3mclRifqAbt+OOuJIs8Av8btI6v4YObPaEUtppxTgBvZ2
BXWJ23rp8O6b5xqa6ARl4gtSVlPjpfl6DwYW0st6wsI+zJX/WOBVOgEKZUt9z78k2h+qoTFOk9L8
xg7XS+jHC9B+OZoVQHbi7kckYKmwHNQZzxEWzkHPEAvgxUtdWfUUX39xCRm6wfwXt4rLLD+7vJBT
xWa7sNPuYW3W/TuXzQn+z6XhUonaqrsw5sSPJkeHQXbOrAWthxuceH7vp39Oa/taPFN1IvcBlCjM
z5eipcTfW761flqUAYQ1aJoU7TcjDXxNkBZT/E/Jy8n1hRATIAh5gLdfwljElRbrQl5jolmHTUxy
xJ6ewrEjNUQ+kA+RyFM5ulgxNZ/9oqu0/9dvyS5YfVQjRtwm4J3s2haJh1tIfLDN385Q7k/M8/nl
+QuwNKeILvxcXH3JuzcnQi2XEzLlBsht8ePaUheH+Tz7EmZBBI/Eii8UkuDL+dAyKCpMFtzIqhYA
Jbe6dDYEVwP4TuGzGaOSBqDZ6cO79yMUmJcWqENCkH4yhw5Wcvmn9w7dDolibnDo9DrJeLjaKJ6i
I7OTOZqE6HaNSf0HPAT6Tv2m1/6c8Z8E7m+HJyZNP3q7IzeiyAe8YHOYeFajeztM6bQPCaFuMFkB
fJLz3Jq4IM7djHg/CPliGqMEPeGdBKRpyjllO4PUhen4ruJTg44vN84eZvpzYB5M1uUUoch/bbxf
SWu6rRY9iEZF0LTP2QHvOihjMFF01l4ssHtY+lXAZ6cCDyAqbneBwQH2DXbO+xw3xkh+8fGsczbV
HPwsiy6h98q4y9laGJeVOR7WXmQLSTtkWQFrIr+fzYXrk8HQGnwt/mYzY1DLh5i7ibPc/GdwuwfG
Hs7ifHz8uUiPhdqy0hNbyp1mZPoVOxjGGAelz2ikOHiudeAjPnhi21hTxZvP9oghtrvnKQsK4tM5
S9Q70wx9ic5mP2lp8CXU2v73MhH0QSti3ENxyOoBG85whmIoCZOzgoPru/ELBht1t2a3ECST93yj
IDV0g/ksWyDR12AqcagbnS4/XGWmPqyXy44GFOctQ9gHCOOqquXblKySIT//BxSkURvS77kt4MOh
u50ljQS78uqZkUAoQ6hE+o1XZm5VmeZ7kJsTzzVOkvPGPCokd1iXFSF8FzubvkmsKZh+peKh3CTj
EHf7M99emMiqJVVVWC0ab+QwrbWhmJH4dlVMAndmmWDLK7Odz927wK1wu2qiMkrGFqgHQEoAF5HD
urVizqVAAApDUgSpB7MnopR8+O9bXrk7fGgAS8IlGCH2HvzXDaP21eYqu0cBK0tua/E+hhLDnD9E
ync3USi4npKNn9Uxg6jlbq6RuCaJv4hSSqicwaY9XjZpEOCGsckbk9/Y1C+xv27QkzZ0UdmTvWaX
ggFxgutVs1k1cQx01vRrTaTg9DMkRKHMl8oYVci6KyYkxRpS4Iull9jgU1MiYBGK0FtkMzWlkcDe
jdcipPEpQCAR5bPzgI16sYL19I//YO5YahkR8LBhE03a24OoaSpmWejAcwwyn9jUu/JPxKhS5B1m
Ep2x7mC4VStGONs5FPmgGKwb25hPQcw/LZsTmubejsGQRPMNZofx2gCIGSMYm+6E6aTv5nAAtNnv
W08cfdS8Vod8KkTThZXe9pCFxGJDKfQ0StZSeVDK0rkODM8PbtQeGGcV+KeE8+ILwGCFXQbmriVn
0/bbagxIjzxduDNarZVYbdhM9D8NQudZxw8BPNp298izjsa+3dk7SuAwi2uEJSuag7sRE24QKWQb
GwusoBbdZGiQ9P2TiZUNr0NnMqSIgaFYSwgiMtPvOefvXWeMMFmfIUGUPRxzqNB/l7BZXPZJ4q07
yBclMM4uF7NJSEqkQxXrZfhzyNVVv5H/S6BZ7TcMHW/XI9MZmbKjaaU+X1r/ATxVqQjXJ0TaoPw8
uVUcGTcgmf7ym4i+gTwGn+84QQvBcbI8MXFVd1AKUnm+ESzxeLx3FxJjrRWD6zPDPzGpTHhnPLR8
d2e8Yw9TWrQFjMbwfKrvNCAW5YJlnl2aCSEiDMFXs5+rcWDwQBWGrz0iWrP+ib+7/tzw2XCp0+J5
aALouSsnbpm8xlPi7PXfhUBx3AKRAvN9omdHFRM5SC4sQlrvwVknFDTmjIx0F8fZ2AwTQB6TwuYa
WIVwZgAJrB4qo8U4+hhjjFVjM3gUVPyz84QhwVRMC+8xqzxZ2VR5kN3jPcNMzC7DVg2s9MZkCJvf
r7Hse2yjqW/vH8ply8aYWFK7VylYe2rZ5NOpbmNVhFZTQrjqmhuO67X1tL7R+UBcR7t4XdBzKhk0
7mVbqvFLs7j4vB66EQwza/nD/9nXLAMwqlDdY/Ci45JNJDXzZ7acLgpSqoXh4PUpwSn28CpkOdzU
FU6n529/2O9cEY7kP0mdeLn+cQqvhcm8KDq0VAF3ij3T4OkCArVTclgE1X5ixW46SQPEOOk7dlVY
dCQe7w56DHQlu1/nFBsDbvpUR0m2Mq+PdVgftK2p0KiP9NHzJpe1UpKr6C8cgNlo9EXKa2g3CEML
iUI4R9wyaVCFgW3C+c2eAwW17yE+lSWXYeDZ+bw/DyGnu0eWNozkm96saUmelv0gFPXJXy6VSh2J
VzJlZKxMCbBDyJOcm7e1YdNYzUU5fXIMqIXGNa74p8LZVrbGYjJDtYRXah3RScz3y8wTO+K8SoV/
1zugAkXzqhMwWhrwCKKbcMbT18Qy9Ti1ELpdFgsxwdjh81EJndJT8a3xuM1hIsaIVJnJKgib/IDV
MO9SE6Lie0whQfhN/tgF0gVPFsVMntnpLoT2O1Wb0nd2nRdP5AXtHZmmvY6Ki+rrDLiYMr33EZTS
Un5WgRZRB5b1aDzltpSRNK13TNEb08AqL7GZAetSicqx72lXIt0eRR5M9+s1ZLsvij9PygLmfJLc
Q1aGkw1UeQq+Pb0jrTDQWYanotw91jPmJh2CE6Ihnr5p9pApQTSfPTCBKJzO45Hwcf27FMUzNEOm
+gayRlh7n5YpU7cNuL1Q744DWj+/0TbqAiRnWshaBMxROKaVMWVHSihjYEEia8n/XJ1CPLCcmbb7
j+ypT6GYFLP4LOYhMKRQG2/vNSI2IzOCXCcgdfLcfLwqrQjfBOIGHmT41t+RhUswxD4mFAgiCBIZ
NvhiplJtRXvTVoS+QFXAcKHlXHCYhcjKuBVZph3qzhm5OQ06oVQIhUlwJo5uMtwoFsNXH7pcVr70
wv3cC1X1ZmGpXp6Si7g3V20MOlvbfeDhCBs4Fcq7CtQ2dKecHG0tHZcnnyEZCghk2d98/TaC1yOx
NJB6dyu3qPgh2CrTRumNNn48LKObnfjd8HIEvBnZ5YKAOAzTlQUqLkGq+6v87vVwYomBwgitTr5M
TCSDxGp3byzUzTTlrGR3WGdsAUVga1cBq9d2gf0HgjO2SCBtDlg9dVo3Vhl4Ddp1MpiSWMUBcLwc
/xKiaYgNhUW3GSUttcjAeXkfBrqwBPm3NgW2zE9feYR4jK5DjqwXey0Tcq2hY4kRHwLQxAilIGNc
qP7JVy8HVVEH7uKcfYnzIzvrhtKTzuPIkSNffdni8L8tPrV5AITPeTW+ShR6V7LHF1ePjGBAExY/
UtiIkOyrp+uXDsRuRCH3tU65VhpgfdEsVZZcysrL5y97BvwvTA4JeUzPq+6IxDUuowkydRaorZoK
czyl8kuYwUKdlFCCUHgc+rhc0iWzcoNJAb8RrHCUdDY0ABPYoQgUq5fSqiW9V3BMomcwaXmJGt3I
suNrE0gwQiVCNEyDNJLKmd7XY88gHeSZKMXHUcZjBypL6KqJ3+FQGtziCVG9gfYiu3ZjwRvZzXsb
FAAUV9kr+hG1LaneSOzz6JnIIvX1SYVi72zKP67d3FTw0YFXoqRd/yhAJds5p6Dn1/S9TU0usRHc
VeRebPBDRaMFOtVEO2aTyMYKT+Loatt/lnYppUiDE6qFkPRjpMOnNXY4z41+fRs548+k0OiNdeVJ
hADzy6zo2vFdWGad2tB0vRecwQHoo3tMfo4PM1yoQK99vlJSNxDkFIPlClO7kCzVDX10wvJmSv7R
t/16dYl0gSvNQKvpfRbWTXjTyquzI43K/1TAUzbIctlNykwzzKUwTVRwvxsjgMES31qBt0Q8FpQy
z5anlQRmtsJeHR5GBeBmn0Cz+oCiTgexBEdIbSNAL/A3YJDdRuUwLO78BRQXq5SPJEy9S1Sp1IVN
j09fTON1wsB6eTWttDoMoK9YofvhTc5xk4PVHsKzAvHdDCQo+MqIO9harCewEr4XI6ALsPME+yFn
taYEk6N2ZMshsn+f4SfOicdjUHw57u+ZzRhDWBXpP6uXD5qQUndNDiS1/LbqTnl20HqBpQXhmHFy
9I0LFVMyXsHLx8ZnirqKIxXAp07Cskl9D6X+eT5mVolKFPxu/BSN20xjfkOulsKRBBxsZSaRmIEi
vRzuzT1Ek9iUvCK+Cp4cFxdDBaImoyxYxAt6gn7CKr0q2PSDKgBjOQDD2CqfeE4BSYkMR/6x/+Y7
jlz3KTa6h49Thz67+vBgSZhXtFpmWfjWgrYA672zYVq8ByC/n1RH7Z3DUlcTAdkm0qxb9ffTzOMJ
Iqm97rX839rrvOw7hME5GPudw2U8khrQlIpCPBel6r/OOmICZtDPtp1urcWqVw0BEvJMJn74aR0r
4/r1owzB7eJTpPoWLbPlCZkS9mUioGXrVOc9F0eF0/X3+HvaRJtXseRkSvJYEViAIafm0KcvIGe7
WjhmDPtc3Bt4c5AEoopid89tf9TXrVHmXE9VLV9pZv1kCe2uHQ1j5caWCSexlXHrHvtrrFVz8Hdx
8ZasD3B/4rceS8p9pN/D7vjyB1Zu18RIw1FT486VhDIJmA7xS4OGFTLtz6NcZVVun1M7BPt9uHHA
2EizEfVXLIRCyKDxx3X5xYTgtpZF5MdExJ6z3RvlliG7YxEp4YTGT30l3EiRb5+KGfkcbD7NPo27
NbDRG+oAuf8rUfKTfFL2P7VekhIWDXP/JdtI/bX4vHKt2BHsO32iSh0O30gVwwMFJk+ShKrDJ1ag
4zXb+4+dDEZE3XAdjw5Slj0gLJ3t0ZfWF/GZGkpvxYy8sgj62wwZ0mam7D2AncI2OH/OJ3oNYWSO
q469JVCoknUFEuGzYJa1SZVOqve8KtO3ZTZ2D4aSPAjVkzo0Xmc0p9VXG8WLAmU7Z4//DSgCUgMH
f3lmZ5gnkGeepXbShklehKg7zugUzJKCZZGoZm6oizI5jxOyXRpB9s0f61lyK6TcuCy+OteZySZg
e3dZSPwKyeXPmpT4jlpFrOukGrXFF5PUHuRyWKNnRILYXQQNRe3ZXACwAVoYIczMXXvdJ41H4ZvF
WYvlu5X6sxBwqkKoRVy9R2e/N7jgzoFepIDEEmGB0NiUvYRa+kj126zWqfkiIlrCKE7nLRlQi6bE
R26WoIV53vQUc2N5rVa5j0PIF4NxNqF11gxGaXtrWNv8VuuK2YmTyowA+cC0Tf1LKQbfzQjFeGpE
WvgLB6WG3fw3MTfS8fNJuWe1YDdQj9pZZCeRWn6CcfBN3AnVBLk+Ou4wyaxvQzfx75fKIV9BSr5i
CJG3HPf7xmo2j0A5DIWcW+gufPya26602WPAFNMSa9KL2b+L/RzCGrXeKhTP2ApW/uzqRDWqaQcR
r9urygoRcZx6NBTPcn4OyZuADfwRynJ/GuxONOTKGQBsIlpS5OB2vs2yUvJLPQe0i10NUQcClQ4P
vmCKaD1ncgoitHtpjfKEReyQ76FZsA3nMhHkXjFCtsxsKGEqhJ/ButD74Jf+Zalew8zy171Isr+5
jLXkxyvoYmsEP/9cnQaGw8jLlR0fXKTtPtXOCV058CAvFdlX4F2LPtNKG+9NyFl33iLwxqYAWlM1
dPAHaFQ0Hj8a/Cw2ZqcOIs7c+hxx8epUiKv9LgYz5+dPwG0fmICDmcmAJTXPIAyK/H47v/NpJVg1
7LVhZpOfR2peLLYpxYXjk13DwnYPtUYYkur4pYK6eULXd65YEdiYZuN323mSy8j6OwYGCE0q+zhi
lDOWzyEMs+F8XIV5KALGonozl+ke+OVSVy4W9AJ2T5wfTG+MClm7U9aiJyn9w/PYCweTK44SATqz
Dfg4QAI6BYrMP8lJ2uiuQtOuuvzqcZ9sr+aiodbKa276kGKicJtYXE2hS8YHjl68Savak9DPabjt
kgYdukAkQz78u92c1I9J062M+zjNVWr8gTQnoE3VR6JBJeaBK+R1wXqvfiBRnBM9IJmdd+lqiiUL
CyUI6hJ8bB/aJYEpaREMVQE3cW7ClrKBT4iZydqV4f6cthOggnkTloXPV8qXfuzeI5B3wHg7GbCY
CHLcnVlNIzmuGqQgRJeRUVPFtPvf6aP8uxMP3/z3hq7KgApNuHyZdTkTgzQJlt9WeRutn8s53zIU
JuvACG9W0ywXlNJ92XirzUDI0dBOCxww1mgypDhY+UmOGyK8zEqhGLJ0DYGe6Wl9g/RDY1WTJVkB
N57zVVC+6qGheTy51/o0z4pxu/AmdnNzmF8nkBd3o8o1Hqisw+Z52K1OaxWFUGRTGEjTsVEiGXH7
Lx6I5JjeE3zgG97XaQpj0p/ETBlbaOCNdMpFhDcXvoElKfznAXN6Kcbw+ISr7LLbRXt1AJ1/Qt08
xZsSbqGygNIsjeVNTLrayTdztmq5jnhjycRQk5xRpKxSTDhHjC6UTX/AcFm0kP4IHB1SZVSaOArd
f+dLQHV0YGGDXBSQB2HMT9CAUT5G+4DZU0/A1hVxn8VNb2LvhvSWR2o/iNBK2kr0DPSsOsEW3HeQ
da/4DzawYX9KUjiZFOuxDN5wW8ygZxjfmsD4mNwDHqkYRAGzcMl5n7zAhKubSspBL1YJvvN2+X56
3cW/aVgc3dF0iCdzyy286daI7tOFP60COlyf/PrEHXMyMUv2K7ndMzSX4f1twyb4eE7zc5kVWh9R
ayPLn5DjYf3byKnNvrdzTAvx1FcX3zspQqK4Ksry2i22AApcZxV40P5YC86rjjZnFYxo88Ryu4+7
0VE+S+CPwoPjpi+XkyKbNtQ9czppcnKJwzUpaeMhsZgxQtmj5us/l4f34vsd/Vy6wktOd7/OmVkg
C5O9p7wG5FdIw6vTfhjyYJbQO8uPHh2/FAshJ6fMBO1V0rKBjBP1tBLbAuWwmcgOIQWBs9YIcQWp
BOsumWJrBZzQsOT+S3DhoFhkx7yI4xdk2JNPep9R0c0mDKEwpqka10iNm2d8pvMby82W6pC1N6/F
dJip8LQUg5FbSHGMTohC7b4RwNa6sgtv97FlOxRrSQu0lbl4acqQBbPdIQAhkeyzy+KnhXLjWxqu
ogUZ+xoEK6hbvJPBQpPyld1nrV8FquUXQhejMJUOk0BKv89HfFo7mUZJkIirRDL/M7EWYgolgihR
KS3Y0F2z5CBPWVdOWjvXerIY/SOz4WpXmYvMxp3iM8o5iRPBL7RAThdkx9OwHGOCknudnX0un1nB
QP+lRmtmvGlmD2VtoronsnPoZdtP0JGVTXxLiY6DT5XijNQqVmZt0oOD6KIOB4G5TayeLFZCIfKE
CrjEuKJ+9NfrPoU7PM1H8EfdgxeWVgwKz9ytZ93rao9Gx/PbstwWzkOLiSjIqEKGlAP66ZFz8ZIj
oSQ9DR+z1H81AUkftNMLCSyRJSvpmpeRyiD/IWmqqxOHgslhxB06pNzJ7n9poZvrNKcyYtywbd2w
14ixAMv5ipuf0fNikCmqIQlUrEVqSJ8AGlI0OrnQVJ9bSlWye6aN/BteYyrSxZhIT3d2pYHqFZzz
M5Pz6XoKHEsUIZJNS8jRjptehYohN68QqhPLEM7hMf4viAiLSRnWoccjlTpO2cIFFWGyo/mI8TdD
+ThwXXe/RJdL773C/jGdOW+b++C72zJ5jL5KVIyKgGs0jyE2rcveUgu8fx29YzMzvOwhajcE64Ll
UJ3zZR5o8C78cReN87Ytict0PiWv1wy4oUBjcI2WASe11LZQCoxSsCCL96QAweXN0K+rhTHxEmPq
uTBn9ik9XS/mE8RKMrLu+oDm7xSq13Gn9UZHuMgZuz4YB/UyVk+uVZNsaqsmdRAufg6I8N1sZzEs
j+2zozhmnD5RZsTDfS/3R90pEMdc4NKm7jyyh7a7e05n9FJj9wb2g65EuvOT7a/i9GdNe035ZJ4p
sIZkxnPDRW+QWwrubVgRSDzuXA4Ax1lv5OaQddT6f/myhEwDn5BSC0zQeIfg0UZgdj6R3PtnWh6M
xXeSvnczcgEU4CzD/yN/NMmcI5ltuXa4wqKOAZlfpGSRow9JCIBzTkOcTadNBjEgPWBNdOhLAwzW
x0Zy0yrIlorcya6p5yiXNXZEYonjgn5ZdbFYaPj99XS/weI3x2UZvZJLF0nzZJccOzqfQmaUK7AK
temP1gKZizW6Rz38NbKRPnb5/Jp9Q09xzLVz3ARro8YfdkuQ6R7KcjXcCYSLH4MkGaW8fBRJ2+O2
jEBOVCa3CuwvvDyFzd/9p/lJd43RNBq+KTLt0gt5/mRAYawbf45copLE3dJalKwRhczY46L6/Z03
atLmWMPAHhdiHes/moRRpYyD7pYKhLMU7CbO2PgQrxGKIAFsKh/hflUF35ABNnmVAKwRFZVEsDo3
nreYO3cxYNMbF7/a3Pe/DPqcIR4oceb7C4XiCe412VMhyY7zj3zFgTuurW/BBMDLfu/gaKlH/scC
iLXvza+st8FjXeItlYEr7VCFTA/h/rDg+vn5OxxYZ1d5lTEf9shqYDJ4kknyk4F5JzSLeYTnvBEY
gNioQL+UYopq/wvFtIdvr9quxMQNrIUxMO9CCB9j4MGCJ3gD8nmttpFCRug8IeMu95QoYP2qmkIY
E76jXEB270QmjAaSPGjCTE37pbnHONMgF0XV7+H25ybjyeE9Vjw/bMqTJt4AiyvJqSOzF5SbcVHH
u1ZScPYYp2LuF7LjhHSbT+pExHZHJ5EgoG81NVOsV/gVL41m8oazfClAlDIS3bxOigJ494SJYVPj
kqXR7EaO66Lelvrh0GJx0H2JUvvtN1w6+T6YEEZ4+Vg/+Gyrmwm98mHnRo+d5yvA8NyER45KW7qy
HJVRRiLJ26Wg3a0k0mdlDXLIfc2Sxw6v4crpN4e3MdAyk+poe5kynefwA+VpCeaiS/AcX/bjPL9k
evo8vIdB3N0L1oXaDqwAcMwO6bxSau+y/nU7RW1O8yaiqvGsTgKge/N1QCddofkugV/ijt94Odrr
9dSzJSI7tiQUiFrDXsO2eZ6fDXFj2v8308YKCIkJwGfkJ2SREJQdh3XKOaGK4uLp5EZCxjVuL6Lb
pcixyTswV5PjTOGttxd5x3pO6F62gvF0POjXW3lVYYtdGhHQBQiwc0wKqsD5Eyk0bGuxxz87C4se
R+0jQXla5XcbtwAL4dHB4hJG5tctp/5bFl4sGTPwejbgnwg4DXha4j1hp3aliSWzDrmUwBf/IlZo
HVixjr5xEp8xtKv6uLzpuwzToxrejr0A1CdyOI8IRzZZwTrPzTV8Wu/GvT1+GKBvl3hFJYPLZjl/
KjWb2kpy1OzxZlKwMiybSGKMiWXgnb5J6FRWF3vqwsd43+gX9ugm6doIltb8q3iVK0snyQxZtAHG
rDXVCqoxAG1YT7QP+oLPydtsUDPiZzfJpOESDa/SwS63sB8xBtYqARH9v3EFsu0mc6XxmA+9935R
9ZbrzOXAzhzpKJBNaYlKw9l0YmV/5RnefuPBP5vw8tLKyo2ge7oR530+XPOg+6FV1kuKMP0OXEQp
i5UttI6buKjotcDQc+x/ACJivqJK1X2U9H4DatOQ9ZqIrY90mpSXhIVaQQ1fU+3pVJjrbzzoCsH0
OZ9wF5FaJZhKGwZwmz9suOdRoJxCb4ejTE7XCBP0K6Z/+S+nRVgVA7EF4X+/TZw2YReAHksswzhN
YnL68yfLkhb2+wA/bI19+iGZ3sr3XLp5MSbPnrKdfkPyDpEk/KDdA8fzIICmvj5eHZEeuhzAgqLA
b1kBiLFMB32XA0/rzCZyLW1vxaR8poDw/sOH6MZwxc1hMnHalmAUZZvZcJUTQ/t6NsjbyUETDXI3
n8q2qKP0IvKt5FVa4Yug2X7PgG10ZkckUxJHFrHbmCgVlgpayu/GxrpQniGTeDJnxBuTAvVlLKdR
gBbCxKV//SRQwS9VX//RFdoG0HFuGpCjn4bgk25fkK8L4vV+elg7LBDd3+gpLZhAyA0O8LPerjak
p7JLzGI6Q8uFOVUauGZOl7JjMfelSIx+t0E3j2blaHR+FI+pOOupfbpQlyUQR0KfekgiNLy7d6VY
wROBRiXggfHs/KTNsxcD56HFmcoFWo8XtCE4+6D43Z4higL+Pcp1okc8clGTXDJKjLI8qOjrfB8B
YSmpNmbXMIlExo8BFovKzx5jfTuMvmfb0Apmv7lRAXWwbpd1EcVb6DTahO6+Og/ICcjBaSd3sACh
ZartnWQa7Y99LjWTLhpEJKi+f5h8ryIpBVPHMLkONuLCyPNuBt5T8lLZ+gcydTBZW0Jiwc7zNcS8
LC/2MM01O9sn5mGwL5hDsJ2igKVSocPcGd8UBqaq/2NpoewCTpSj0n1Abu2QJcGW/PDxUuzOXWA4
NwYqYl1jFfXiU6Pmt1PAXXiovTVfMZhtQDJaKIJjXzCiIGP6lw0Q1oVuVaTPiPF9IhmgejMV6Fus
t4/xkzc2eWEcwcud4K5WyzbNUJFpGxyGYFBYJfikz90Ps5hLUSGWizAAYMp/nfnobymvZghAKRcC
zBcdLprhJZ7vcoB24dpTjo0d9YLlG8jwzM/aQRVN5iApj+7WHI15EHNtd/dC7ua8sGiNuP1D2o/K
Go+oK6O79W1REqdIu0JdI7BVIW+jyVFaNAsnSeqSGMCdFRaTmqMOpVJUmh9G/Ky/4i/LR7DPIhgc
/ysRcQn5J76Ycqi7CxFzLxvDgn1/MoBqiTnXNUotXMKf6NYvzMo82oGyZ62eICNArO65hwg5THzQ
1hHm+PAu/ZV2B+Zt1rN+ujpWswRojNk+AMUelA7FaaufCkHTK7QS1/HAKNerRtel9wJT/q+KeT8Z
xIMImsAnuQhzEYCZRvbnqAsoV19gBtGTUaXlsUNfs5+t3na8gXPTQTCR5Bqolp1irhcerk23JONU
ph0CSrWbUCRtUoDyHrLvszzmnIUSRRXVdUlp1Kc0wYQ/55bXqQYGCdv0PjNGHv5zDJ74EdcD1JkE
0KWyvDkclHAc9ezsMGGnry0wNHQpfpTvMpam7tAQX6rYMjVLKW5jued1PbEYETlu5Ym2Ln9mbfmZ
llj5gkoTnukzY9LkQVNz1dmKI+DEnbEWukEcwkUbllNoAE9FUzoApWEPpzzTfQ7DRhRttSgMvJFi
4qvSd6JwWI9Wt8H07GeZovwppy58axGCKr8MSEr/ZBVAIs39QYP9rHY6gYgYnKd+lIFTPzOTPCrm
cOwGlzAQ0o21J2NL2B0FUUCvCef3fH57M/kX4e6XtZTOhPGaqWxjY49ZvON15mX3GmXhDT2qOJO4
k552AwdBBJIcB/mHk7oQKP+6MKMlXqbstE6mWiGMLnjX2fDM1Vy804VYA5OfmaVD58YTldxrt2zh
SD+MbeZIzAsEFDO5k+LjeEjHJv2YOjIcvx+UN9inE/neBlAQRa9erhWECAAzGoezxl7vawyhdRUC
JwxqntMABy7esbOCze3ZG8T2jGzzNbWOaz0KiWUeRTWa9QBh/gUt95fLKfMF0pHyfFdmaBYdz2/t
QEZv68rfS8vb+qYlGenQudVHhojh4TkkWUQHCIXuSYamYVN2N+RgtEaBj2aXCLFmueyuCLlmMm/y
9Kl7nBLGKuJNgJUv96Ljx4fWAVjl0ihCQ0BOon5+TinGXdADoLBqjTCrVxu3aGS5S8iuZHL+kZB9
36zotp+cxVG745tZUv5VGCLbOeQvkYlwlUooak7cczK4EMOBGvKnrpsHnguWCvF9C1q8Wsbf5oau
qIOQHG020hohaCRuYAQVEPRv1bnIMaKBDm7mP2TrgfL8Huq3Wfo7/vFwrwY7GmbckwajqwW/iHXE
PYdv9AibbD38hqbU+m/Cx2ZAEuGngQncxdo0sYXzNyBrc/KMCXOmjFRpQ+p2KV216L4lBU1ok1Q5
Dlxr7FAORD4xJqgaovpIQAegWXQaxrNBTCK1RtXiDDHtIollmPju+fH8cqtolnCOmrYKn4VH/U0X
qHIKLAB8SZu3LbiG12yt7cdcMRl9PfagwPu0zRJFU3g1HVr1YYBUqrxkhq753iIB5/Wpy8bAQVMe
GqSzN2FcjSMwSoz30W77j3HCv70uuPczapQtvIpB7a7lollMqUwoVMD0BIzkdO7PEnnPDa5BJVjk
u2cCiDPkV5D4+3Zs2X9vumzg9VZf9nbvIatRsDluNiUkx8TmA364aZ8/uRnMW+w+XkNaXCkPIbjJ
sji5WUHH8gIWM4kR22BwdEoD14pTkQZ7ccRrE6HqqZWX0zFGV25COGwDWiAFgn2tGrma7w49VW/i
I1+w0PtZrnjocALDmjItcY8LAE6iXRTNm+OxNJuhMhoWzklAvE53GBCYQqCmYsfDUH2Xn+hdM2Bt
mWboC1qnC//MGvaOdahwS7xX1aP/jDDpyjxdHrTlUeQDJ3GgN42r45KjcXHyori4iZzCK4P0wWDC
Nlgv8K59dZJ6JhcQ+wfMo9rDEA/LUsYWygN6dW8KB8q0Bs4S9dQQWhhhQnDnf2r2FVQLArdN5KRq
3Qhjm7kNIVjtln4OUV30GIsN5PrUJgyl0UtFm2lskfuaA5FmrgGYlVqNVR1gij6dRCOes1W2Ppmx
x3/S/A0Qmx68ZjBCbg+Ctp+UcNeiNRyxu5kbbdju0SjAiDe4pAP7lxwV64Cb6e1id+OKsLO0nvGs
hvfVbrqdROIFontc8ABOSwpriKSA5hVcJfVQ9uJ7gBEbyn+kjJo3jSXfbT3b4DVkk5Yq9fNv66yZ
rBFdgiHDZEx1N21Q91SNctDvat7mzEN2yTvn+adXRdIMI67ESJSlWHcf4sfolXIug+UOWO9+i/rO
Iz8aD8KM8QouolP3RqKsODYJO6J2Fw2T4YcTy7fueVYXLAHvjEmSikfxpRolwLkXcRolwEF6Is0H
7CaT0U/FtoK8gGYSCkSOYQi+XFWuY0dEI/ncCoxptMrez8mBDrfQdlHTohOP8O46F2PygI1Hr7gW
f/wio5sS1HPLl0vyiec+6u2zOD13KHJRV8fHToNkZkQU/UJfOPIACth+eZpG39ugm/aySGrehP4o
O4JD7rw4blhQ+Y1UHRsUBJ7l+eVmciuDzR+3CRIfFJu6ElwHarR9msHMVCUprKHoQXadnQOw55FL
d66KRkEPA3po4mHC/vT68y39rWY5pXGMYp60vsae7YMVJpSHkPugUhLVKY0zAJ63nh/w/8PNuJT1
hVtNl/yyk9BlgM8XaKV8euWgEcaVcc+RZ+Zb4uCdbUVVSuLOvwE3cXuq0sCQae3s1kbqINTE2pZS
jvoxy5cWauguKXas4TwglBGUZ3NsRuHgey2r3iHJOD+D0dyvCwLWLhpHWc6UKXruCOS3sLhGrgi8
+DIV2gXBrM3XJKLj5QqGNcP1QWKTwPB8/jvnHA6gCdTuRgzMCawqfeA0/f5tkUF+cKPXfgPQT/aq
HJY4OBognq+lPRy8qnnyVur9sysoQNH/erupPHuV2CUUOl8Eg+Gcx9EY+GhRYpWjpt+f8nNOZROW
mOcBmP9UWp/xqkxjvFSxeCNg2imji07/K5k0IGDwgYmFYvPcQ6sb7AkvJPToHkLFVqmbIyU9xldy
pE7VCrueoh7+V92ceTMaggKQlk1ZZPOJetxpLo+lCFLmVcmWGgglq/MSOIzATu7mToIU69o1xB7V
CkwXxr8vLBcGgQYleeD81CIQz10CprTVSYEEeih5s1YrOQRXQLba1xQMh2B4FXTqqKjXy75X73qZ
q4LkD5UPG0ht5Bthl5z45T2Lts9+Yje06soA9ObUe1tYVmtv222i5Cik8mLX1y8uQNH5B4SHyvdB
n2hZiwo8AA5B0ToE5ee2DyfC+3fE47oUW6ONPY5f9VBChHsi8Ia3NFVIbhQcus3HyENFNlz444Ic
KvT4xjaqazvjbglXxomU5mIXvJKfgOWVZZHeRF0xCh03FdHUccEPFWbWH7Q/mvXIZajHkfplPKPw
U4claJoFPXyoh/NZMk8tRU+wXCgUJeLX8BOALGGCfP67Own4sP0pVXbsdV+iQhdJrKmqwMZQU9zi
HvccfiNsFushb0jA1XYk6Y3AM7QiQ2szk1Q3xmR75acNlRac4vZ8g/G3vA5Ok9AiAmG8e2nxUVN1
copuPTljpUAdogktDEzt5zNUUL6lhCld69b/7oVmd+MuA39Ir3gPskbCoGVUC7doEwtWFt8PBuVb
GDHaPY0Df4hOs+scrqyKuXYeYxduIcCstjmCOeP7F7rzrxKMX4NMOlY698s/G+y/TmSf1sNUbAEO
DEzR4haHKIy0JzsRCLa/xiSrnVcxgI+Z68YuYkjnXiZSTOIdv7y8tHMtZ4rYSRndZ2eVqM5mr/WV
ubaeKLHvY0StcmKp0rW9JXols4uLaC2k9gQInzYE9GA33BfQxDIo8AWt5ailjuDciWBYfrmec3wz
ldAP7ZQuWVSG8WkeGqSqNRQtNMPTGH0gRV4Mq9lST/wmW6x5HBCPN+7uC52Xb8HP1Zc58A3KFEYx
Vjfi903fd+/nA5uWllISxHxwsFwjqPDYhTH2rwQHigKEzjeUFwEQ4vwrdb5Hk/vn+EQRkQfINmhe
oChHTPpRDMuXruwAR28sySQT+gExfIo5CoDF5sx5+fUb51FPclFjoSmGxf1tOmQmE/+mujUuJy3z
v1qqBOkWXpCOyFJnR1mapbBDHHogicRe5U7F5fBY8FNnIXwKaN6ei4UCwIabYtFG+jexguxIvwAZ
IDhdzEaSb5m8FIBSP7ECfOTDhhYCHAP4lj6etqjA3o/dXgCf+Co4zP502JEEBHvLBR4vxrO2XRtk
HopsjfiMH2P/EvmFq/9mWELigQKfA/c+ZBpE7/QRHLW3M3JSPbZUzCl63m23NFGUKpWBi7AKqewx
pb3jM9AMBxFgqpBGcZrT97ZYHRD4az3rT8jGTkz33AvIYqA31B3d7T8tJgyiIzsXh8DluxU8IrqA
Ft2Xrr9sA1AI9Z+4noOZAaLIwvmb3GETwkyx7a3XcFVH0yaL4ICIxtJjkA6bVXW5xe7yvdL31sz6
Aw7l6BGw/agvM+AYAHFn2a71IRA7WGJamnB8pb0LEqKhtSY6hFgnsQC0DiGfiXYUL2GfgERCIJPt
FIZ3buBjdA/HyCcROfHDh02G7GclxSRAcg8rYRdX+lpJgEOyPXMdm4Llb6VzX7ESxNz1MltubXhj
MQaeFYWRCcKPmzFP6twSU0n++UxHv30eAvzKQIAW8N9AuCn5JqM1LXSIGau/eoo9ZtFhObDeQgL/
JUuUM9iZaUppPTumyuAQgmf2qRWxv5m2/4wMv9atQ+M2TSIhOWrFO73z+/OTCfSQhzkTMkdqhOY5
sPCjr+Fjr48f6Y7bMRichUBkOEwVtcsRKb8NZRN0TWl1mfSxJN3cL4uGEn1pZJ5YBoFxfxKaf4Es
zTZ9K/8I+DlKsdCnnbgpz+ViWDqG1QUtCTbVWBQn3pJoMafFKAVfw85U9G4Jv/Wejomi82SqH46G
ytu9vg6VGf49vgWyH45Kmt0ApIPSg2efatW7AeztsULDrzy5ipjDqWnDc2jjfHaadJyra2ySoYgR
MY5kHnvOqYZ0cQLk/Wl2wJUkF85PU24CQq2QJ4GxOIA2VwbPER0wO9t4QgTiuZT3sZB8FnQ7bcMA
hUERXrEo5NjX/D6ekskPxOKVXpSujJk1qRusd1MPS/FB2yyM92Hvn0vnJE9tf4M6R0oLx1Zc5Dgk
ilXYOOrtK+JuDcT4/oEeqIzQNQQH0KTWmc22URKKQkgOV5awJlTRo6GRtJ4n7I9RaoshOzcUGYyR
DgqLnklGr8RHqVKG2FoAwKOrZ3Q4fQcsZfjOd4mhyZ9Rr2XTqbKM9p2JE7/aH2DrFR1bBTK/RPY9
EINhteIbQN5Vo8zVv/m83VwL8p+8FkZWmapQZmfDPv5ZXJcwiuwVcCXzoc5d2Kt2AzfViOm19yed
YuLN9x2RkdMLNlce57Ho4XQsYabY3HrK4nFTwY8bDZGoqYSGx0IF2YE+n4swBsUNS/yEYhW8i7MX
3doo/eH55DkPOB/DkNWX1VVNhN+eL9W+RdfezVuqMCweOijK6zmzcxV7EzYJRoJbC5FR5O3KsAMi
ohE0PrFVTftnZZRvUyqiwyrAswOXjtFoZUYjtjmedt1iN6AoTWIT3+jmPnyrxTRHZRmZb0zNVb2E
gjruQe/pmrpyKCDtVhXAdUEPkP3Fe2ouTHWMzzom9/92I+ZezeiunBOoGx0zK/YHmz31MIzR8pdc
yRqp/+RQBROIPb6bAkSeMPMhrY8GCffFRDFtze3mJIxdqlLN1gC9W7Ts7zZ8KOvHRx59NPnwR/JJ
Oi3DyDhpoL8t1ylmy+UYbOMVUOVfucLqWJv0FTmp/YGoKLo/wr4p8ARq2aRUMm+/6BsweF/ODKJy
f+q1Y+x7O3qLkLVvd6h50oodrFNSE259rpRGzXN7BlQX1mevE9xtiMa1N228ujNAMKdNzjangV/F
U15i9Nz2hwhtwh/GzLYrEW6rjKZgsGQxU3NXTaq1cMQ23U6/GKiMchzZa6rfDTTl/By1M/NFive0
tHoXG0S6VkqQQ6wKdbgkQCcCfi7rcTYHrLRNQ3ldpZTu6ME+9L6gXxjHdj/hXbml7qIK/pAuk41o
L8j6ZGMX4W2l5SOCkKU7V0H7AGWOxdMr0u87V/5W58QKjzFiLrkLihSJZSqUCMHj6RdTj5GwPM7R
lYJOfGP5hS8Zi+wGi9pMBHrplT2NuCLKZAhgveHOltwccfR9MR4N5Ot8uVyV0/oQyC1hdFo+pT0H
9prurSU+7HAzwXbQtnAbWX/PgsDNV+rqy1/q1eYzlDoNOlvWcPPbO3qx+kCpq8K/OW79o3fUzCOr
HQbXa/Gx5S/UcYdQKKbe96Fd3hTOJ6rLoxlmsyZ0dGYQzduyyTK5TASTYXvE7or9zMAaslQfwcKT
AlTT+yJ67B4Zm7bRuUhwwBFw3PtF0AczMSw2FKty1G+A/txGYGqjqw7unxCP+uHk7aWkBI4zOiVt
hgZ34XFRLvnVqy7GDxZe5PqhRzBuGotK/rBhykA/ABYZcHkmZH1s7OLRV6ZMp8EuGPIQP7z+ANPS
4oL0crWoNZkJ8Q98ni1L2tr6q6aWDPWNjhwh4yDt7+qr1AybR+SRGYd5qj/rNJ1FZl6Ecks8+Yub
l/wMINDAKxyFLyPuq4y5Am5LVswFmdmkjhhVyr84PJUwh8X3CWkAgZqcG485tXLF8JsSzPljZ6Ok
llWWVmlWoGhxq0IsqA2Bg2tihD1TzGBwrld6LUx5hzJTHShciDwbq01xijGuRLDH6i6H/kw8VNlN
hbSNJHWdBXc6aXt6lEFpzjkfnyOxH8fWxuIgCNEt6b8X/gTEre3OnuHJmewq0cQyMnwCrZLBHinA
Ie7ohjX1khbWjaNAMFiHKh9spPoQwN0ia1LuGpiNEDmQI9jtKn4TM2wj+/MkSAfPGvdPDWL5c07m
ckVdWsWfJwgGDo9Ub/t1JBA+RcLN/96TdjF+KEkYmFNEDQSQKbnSGKZAErss/+ek+BMPBKOW/9z7
lPnFUwClF6D6UVsfWcxcPRB/fZCCim7BWxotd+igINFvC5yBjXr0U5ToRCVOjpAOQqZqG7udEGVm
d06937chS4JYflDPf9xRiPf++uiLu107FRgdSKe+02dSnUufb8wDqsoxXQWSdfNputmvAydwOF4p
gPVApEiQZF42rqJfDSdClfg7PRl4ltIZVMFdyT/dccpGDndBdTTLAKOYXHbA6cqR5FyorM5M74DA
KeMjE2lkz27x/5bZCrBeK1E4iJ/SP6izf37XJYEA8TzRHpUHMPZ9xRK49fGpgBUWj4j1dfQjGKyK
x8gwXFgDnDyvNxqBE7KHkjVRT3KIVa/VpVxPCvTFAXUfwQogX6SyJhJr3s62ITLa9KYorQ1Dtb/Y
3vntghbc6mtWDCoGsNGqoJ1dN3tmOp/1GbUFSC/JH2Tuft7WIggzNOGv2kXDE8lFMUJJfkR9BhRu
dSCP2oyIppz1tgAd680R/NlmzpRAT8dCMqCSYmYGxkUEQJM1fg0z/Hgb301yjJI4cxBAIg3eMFlt
nPL3adR/d2pevTtU80eI8onmizU1va/IF3diZoxE1BwIzgUPA9vRVpSQ5zpv9qeitcK+ORneZOMn
41S/0DwdSbG2AsQ+qdvFwegBC7L0OGXWLoVJwkvNbPEOt66s0wK9gWEDEfKDcqvdpmy9/a2wk7gA
UPyzWbfWwn9xg4TabJcbTSZPNOwOPNkVxS4hhTble3SmGYYTtnGj2885Hcorb9+wXknVLYE88RRi
BaOjyIp1fP9utATaCyZDrXF+i+KSQ5OYPwHQBLG5USeN5oxWEOW0HRzidWNfkEgTnksm3By+vO9B
j3t+JmwR7BXY2IUUEWPEUe6B8fqd7xHDuGpQf9K8p9soGKhgSdBG9Y3UB67P7XbwV7vB3EhHZ4q8
beLwBm0I5/pOVsGKPpqEMShk+XFjD7Ly03MC8hPShOiMhyN1LOVmKR0TbcwaLyOpOIIh4LfynH3f
pVL+ECkYJ3q8QgQwgY7pTWA84MoZv3mlEnEneIBnD3PzkPoLMKIuQwnqnmfmWTM9AdU9xchYqN4X
hTb1RSJaCTiXcd3P9d0T2+rr2TsNBiDhxXRINwYDrrg2DiHqRTQse92yySiyrG5Ub5b4o08VfEMb
wkOn4IUR7A4CfqYLsneF69xext4kVVfeAg4GvtpG+tCcio9ep5SnoCDsu+5/WMUd4EJ0vBfWi96G
B7gOG7CZcyn0VlB+qjfPMVNXsKn3GEuILPZvm1GjmxJ/cxau1usc+QNaotQXCX61L/SWp23bXhPS
1B2p7Rog1+xffCPBEF+j2WRVHpipbPzh6Pr5suGtrE0ktP3N2MMJroJxGVcmjdKkjsXqHGVHhJZ6
aX+Ivelv35aJlKaMr/JvLlIXesUhI/o1ZfDoORM17bENMnQlp+etbqsvb2+yyD7Dh7UJTLyv6isT
IHtliwN5Iez/nWmAyc7lye0WLfcgiqUckyTcGLrRa5uzdb9VZZUhpZFnj/ixI4WxhjEToQ4uh924
+a2NkWLRipXQIYoKXgQocQfE7xMdYMdCx//WUMrJnR5v9IyjtwhrS2s3+qAI+bBXPxIlfNYj09sT
3ivPU9dnTnzDVR7u4m+GpHp2gJMP6uSeQvVcRPPGAfudrnjfuprUkU4DzBy7r+CaMLG20ORXBbsm
cqcOL7iek6k6wQafmGrb43c68B7EjN09q6gQGPOOb6vsQ8XGhp0KLdNE4y2C88b/mhPShgB26yJ2
cK6PirixjGfa1CYx222d3I76ny0Y8P8t1TUIu31dygbfq+WnIOsF9+SdTZwsWw8MDmyAiYnnnaFA
tLCYRbQWKeI1Mz2P1i0dPdJmH3Iq7P/8s/JfIpkKceCieneRyEZTdl9Le9tQisWp8vhPyodPNnJW
WaxlPB8DRuiqJnGs7iZRCth/WQTfzqz8hG2xISbZNwkgb4OjW+CX/ejrRsaOEnZPRyIApxjXyRdo
rl7jKt0h2fDkZeEucdrWYmufa9l2AzJ2+cGTloZdyRk/sWQ+4RfOC7oxV07JRMdJzFHNtYkclUkg
Uz6ayBf4o+g7qZYEcPDtBaisWrLEpvXQ9SyioZBFv/9QCtq62Om/rQ54Lvg6aOoCwaDfJ7H5suP6
C66Wff2SUsHGgT7h2zHSjQ5J8g1vx0QoycKmvaDRhIaLg41qwpvMZ062UhZwT5asi3BOeZK1iWpw
P5z/Ov0D9C9vjrA3B8XAwl0WXmEYGL2bVaelh/1lWapFK/dVInHl+GdNIgYR1qKWfW9vXCnDXuVX
uvZA787/09wVJ5Q+FPySyfwV3S6yLneO+KFyz3nhQC4awt8pVsOrH09dnCbB+9NNw9woxZoK0JS+
3wVc42kM3RW3ozPrkduMp2p/1Lr3eVGA5LJ3l2RoXdvHYeSP9M3X7HNH7v9CxkqUJ8DkCw8zc2U1
OTC2xc32Grk2C0mz1Qp6yjZ8CIDT45+FTmkZoHmD1gf7dcG4S5Tr++v4qfXOL0KD2rZXjHrVDyFw
nMOvLMwu9KRO7X8PCILJhP2BNWYQF7Z/V97xZ+ZQ/W/3+cfzE8x39WDNpzGSVGDAl2PiPl+0QZ1S
peIbLwP1YSC1BH/B+c4No9Eyx3DL+n+Tj466RR42uaZULoJRvfeCxPlLBYS66RX1EonWxCSxBG6P
r9Jzi8YXgi4bDXh1gVFaBlJinGVwKBicwTpc+ccvmmXWlPeIHwD7NWMfhG/EhTXCCSuzKmEVhWqJ
NTImqWMxRM1BQMz67c5JOeK6tzj32U/wxtPJEZYnavNBJLGa9wMEm0p72u5c9jtwd7AQxCeg2t4s
BVX2aJlJjSoZkIGDFxhyDzOAocvhCP7PvnLd5A/fYlWFEyCbyDiLEWmnuNmOpDVBNi2L3bBw5CLJ
ncQbNiEuRES26zPX2hHsqmzy2qjDAgcYHnt6HnjjnlnZTLeFv5bZKxAk6MR/B8BVd29zOZAwFJhX
PzqM1htpSNuA/QV55pC995kEX0nP4oUqI1iVT07SmEXTJBtyKhNr3x14B38JqSHKDgr4Qp+TKavz
DOu7ZTLMVu+fz0AXtl+ARQTUbJQJnfaaOt88EEubH2kRtUC3/n7okOj5tfe9cjuEYM7bmgtNCw7X
KJRb18nie/jORCE7MTVGtQx4q0IpJMtJGgtPPucRVjQbYe2R9SfQj+/Oa+GJj/CvgIwOFWWeoyLX
MRhah8LNlLGEVVIcy/3QJYogfz7HwIWKT2GeQMY2RujVmTKevSASkg+EsjGFzAtdWRY1ECsOs54y
v0vnT0+Y19Xo4lw4es301mDHsueX5TT/zWwSIH4sNGVbevT6T1Sv5BZsa+ea+wkDdEmV7JQjTx8B
FbuuatavwbJmlyoHAgOPiHjnpu3quHSHxh40NwtY4AFhJ7f6NvBPv9lSc9gYlfRzp+jdppESPzXW
HyI6TX2TbPdWXWNJdH4Ig20iUx6MbrXbC8Xq+JN30stkJeQ3qBZTbGnfCI9HatFj6xySBFeowiHn
jtnKsX2J1LGFb6utdoi+aTa/RqrBXbwAHlkda60v4S++3uTJ8GVRC+SXf0f3X1TmXacU8D9c5yeB
CyAswZbha4ye2D10Z1xiY75ROgvyw5Nzn92oC+yJcG7scVkl8wyuN1uZUELKvuEUJKLFEPzF8LES
KwftVQkGby3r3BDfVrka1YqFDPACbEU4tEcIpwkqMua8BQy9lQyw/CG2LdBiMRLCm17lk0u/nOA8
DnsYIzgV9KP1sQqk0N4RO/QYZaF8BOAQuAYi8RzWV8X2l4h2VHm0cqElDSHvA7UsQqvozRGkpxQv
isF6xUNUR3MxuOhzB1g5vnaSnC0YGokdxvLAl4Jtfo4JparX6oKgybuQzpp3NIB7NGdRhR2D5dqO
3mU+6YluiRD53vMihjRLHd0UQ4UyXy7w5Gow/D9KtRpqy2B6qiYh4s3KVKGZtm/cMULgCO/H2pTN
71nvIn18Vj3AdAPJVev98nlwh+TtlnCnMB8MtLgi71NmqYeuOkisimuIo9yIcvamHwN2pnPlsNB/
F8ELO55xHNWnjr7+6dJhbvumYu8xMoGtDa4eh15cHNPxoH7RUhpbGxDm6PBOxi0YzGvwr+kSq4aV
U+4W59wpuxlCup9VuFx3Ird859rz01iq0Z660wQwD07T4n+EOiL4jnxf6KiBhzyaP08Jdl3NPsWc
dPEl1tZ+cLcmMq79hkhQth36dZ3kOw0L0L1ltGne11xqudZ0Gep5ditWgt/uINj1oFPl2R/VO4IF
CIVd16fssxlF/QLJhXi4VE91KOi3D59H9YPAoAS1GYvXB6kaRn/iPltpHr925GRAboxxgSpfEF/T
O9dcq0AgBkiw+rAILV221r9NalGntg3HkHQ+RF1txGesm0hZPkBCa3LuNgWWOtmo9pVShXXF4XN7
A/VPPt5TmR+8R+G5GQFUQVzTKyI0gjeBWkpw18c5Z7sCzHMvVlvy2d5/1/9s3JQYn6bN8J5diHoT
i7sNyOgJ3mthfxaljGjeXgkvEyxXlzxnEmORw2ijgm6m0Gex3XItYkD3KUN4AG4Kqkbso1j5SunF
pCmX4Nurknchj7IgEC16mDAnE9VMG2lBPcgIYU21KvttBz3pCRvbuEudyvAA+W60hrf+VftCx4B9
l5nZK7m4T6C6Vaf7q/P2HfnuDS0s+ay3ODOZbdazIgGUNKjwfPoOMBPeNlZKyBjvJRTs5ujbJ3jL
x/U82931XkzbduE81c4/wtzE7zooFkh9L5KI68KWo2xp6TSrDhVEtL6+GiCvOhcK58mAGqMXiH3g
FXz7bh4/rD/q63fHV+LpDStzXtp8i2elaxQnSFMaas1LNox5s3+1Vzx/yFa+QqZ6dYO177jQO8fT
jsf9o9vpHn9WIGzB8vnTf8yKqVIzaX5vrKFWX9BuT3KhoGZFnllSEzkeKjhw5aiMEcSvnXP6jQPx
zizra4Ru0ik0DmUe0pMOv9DjCKQp25WxNMSodo+3a8wWWlC3N+yQzr6pB8DR6+CfZoH8N/fJfm6U
oP8+voaktQiCPW77yc9Ul0a+1yx+5+ymKhqq4M3ToFWSUgOC0vip9B9vNm9qYnO4wwnQUqku4hnr
iXq4t2NQ31bpv1A2Q1YnCqiUuBch5Lyrd3bRNvboBKbn5GA2JlD16Fp6SJ6uUSTDG61uC9gQBVnk
sFTeZXtJeVckMbRTSeMUjZvcwZIXMeLXIAOUJ7/BQYRPCzwPNM3yGTIj5WYaigHR4QbR3ZmQ0PQW
yb6Tbmj6P6mMP9V8NcbFe9d6uQJ5AjXFLy9mCcxIb+XbcYjRID04v6ZyHDJf7R4s/Y8hvBeUZ0K9
8ltV14pfJ1ipVy0gvmfSkc62oPGn7fc8bsbYrSAsxdARcofOnpOnJalW3iO9uSB5K52+jqhXC6JB
RYvGAaPhrbxNAxEIro41o60yB0ilMCTReBiBwR9scNbMijvp06As/66qGSI7mGWU977rkoJaLLaP
JUTPsM6PmEva+KZRIRGC6B+jpQL/VQS0xi05wkp1Tjjcfk/pS7JZHE+paZ6vOC0RujvOwxfjONTn
UxEDRbsjndFFkt3K0AfXWN7DiS1xk4E1okxVXc9yML9mG93aTHwOD/FpD2oPotnC96adu5ZYOhRH
vIOHU2g/CDg4di/RSL7AU14IclhJqy51kX+gax8VMBqEwepturZFue/1zLXHq2+4db/w302CacGx
dp9yeL0QyD2Vo1A9fGPZ8ME5NWfgIx/8+kXhhHvlmpSfWyWvEodoIGqhu+MR4TKBeRZa6lW5b4Go
7R7ow5rXiJt0gM+XQzNyGlv8W9KESHGtqe2PcCqod3uP+T2lzuOjWd/nWUK2w7CntnIR6tBrj7Ba
r66+CzVcjwB7qVn6uw3+04bc1AMK9kotZpGOyXWkbEjXpel3OL6e0MWdZxHrw5pbEKd58uPSkBOJ
7W1ErRVfTuo89x9jSi2BAoHwoXEIOLmYabXHMAp9TANLYJ8GAiF8yoR1c6D6p5uZVIp2oCWnlAX9
NVjEqj5hvOI3JSECP73J9bhHeSpyMvpeIA+qFLKmJTdq7vplVx3RInqxLSU/PELC/pUW0jc+v/Ko
Lrg1kQe/a1cvEy8/OUBpXTCLQg5e2jwjLa/gU/dUwyQorncUZFcyuwS1ikuNrlychEsByYmMp7Nc
ohVcqbIvF5WfrzPo4cGm0f6k0q+IEj+u7rn87nzYcyOvff3pN2FEKYEWmdY+dPavRPaHavE6Ts1p
UvjMhW4JR3y1QaaWm88XlJ/wdy5lG0CaJ5XWwnGNch/r4RPVv6pJVCnBIegifct5K99NNN7S8RDs
MLOR31VHWGYlyIbCiiUPC5Gq9JyC0v7UagRAbAyGZfa8AWWYfel4xf+uH5wdr0585oz6jaZFWiPH
5tFO8tM93HsawmucYxZML9Qiurq2jc3RlUTBZTdFp0l+OjP1Iio5XFa8IGAd4uAoQpkVFqYGQQb/
rCeFuLuuO2sagZmqbx859BXBFNgfT4Q0eEPpFRCLyQvuA5iunVnitybKdg6HiCg4Rc9jdQfD8p/S
KJ7htyNf5a9QscQyMUVNsJ1Mc4m4HIdNfUkBW0wMvXZVpeP0mWzGa3rHp+YiLRDRwCkUQwMmO2Tf
J/T6blUUKgPrw99GzhpJaou1xYX5cObCnmMKSR7km0VYV8Bsn68jeWOfRz+4nykKjtrpAjAc1xQm
xAIDCcNneJ0RM05XXj0FA8fI5h9DsIb1t0YmZyjEkGPtzzzCLWQKzwrmnoSwI7KlgT8cAwgorv3r
0ZYh20OtadLH1I43m/iJqcV/m9QP/x/8YKSTEQwyGgwZaxD57wnnLFqRJJr4raq+gpqLsg6jC6Do
d699iGcI4B+THcvXe01Xi1yUC1qD6vVeDUgDPwat4FT97el3CTucr1e/TGX3a0gxVvxDCzDMy1fy
hSIq1ySXX9gSOJ7qAy3aMUFVZsMM0nkXaGfUr+xv93sBSzNdPKPKsh++3OvpsG9l56ilMpTKsdKl
t8P3i2+a+Zr1/2eeNSiQWGTP4xpFsuoWX3/xKGPg2tuRbH8KxHm4gmLjV0dETqYWdYcyfPU7JnY8
HuLOPbIURSA/Hwz0QKxKBRlizcOmRun/kj+h0V9Ll1nI9kH9G2E5gyhu4n/8pdt2cjM3OqppS1fg
8/KMy2jZ+iXhFmlqT3p37z614kEj44kazvi1zmlKX1uVa34GaA8xAePT8wISokeFuhUuZ30GDLxe
+zhEgPeE9vf1LZiySPs3zhtimS4p9FTmU06rnH7+gOzYmFNNpH3jv0a96oF6vZV7yojA2SnnVvHZ
SAJIjEx9sxuLm1rNZQfbEpgm+zlbe7VXeW/7KqODhw5+wXD6hYEVe57oHCDOG03tRVQq7UiKTA8B
Z/0uHRCzz9TstMxG//WhMy/VGtZrHizvw2kn3FDj0H1sowLr2EGAz8yeqR69ba7xKO9lTyDbHIaL
I7z3ly/Ue+8N0Jdqyuuq7Nh9xGcHdBYWNJ6KVyiRmPO1NiIR9pmSOYnqqHHYxPMxgMEiVzNiasUO
BW+plaL4yBFzzHfl+fb2Lu1spOWaT6+QR4GUzyCs5Yahs3Hh3zwMR/hNLg9kNSM0XKqy2G/1fj9I
t8QFoUy/3DjBSMMJQbrU7BDvLeL4pTlQw2p9LMJsNkIQezeSHvMfkmaLJ4XgkeHUw9u4wddxE/Q5
ERIP81ifc38/WZVx4lqmjT7/3rvJs/INdozbHoSh/DmFQmg72l6kqmzlqVKCtg6i/yD3oZJ/3jhk
VEIknsdajraPmcUw4TFH2J16z/8FAuEvLAtT7gEq6VS/sj0fHDnMlkiddYMxplBWvN+FuDBN/xsG
XoX7vF17GWCPjyJwTCn/FGkP8+A9BduLt9gN583GdjveRgVNE91TUebHeccLX6vg0/P0r6ldSi7a
ZZnIlhJ/B6G5wTB2Ce9w1Ov4QYCDK6tYVWEyqcpJ6gxT+Z3pAfIdQHqyU0RzAxb265veNrbq/ak7
al0CLoWcdziIhPVBqtRL6MI8NbZKgZVbpUB9lko2ArmqYf9FnP10AYHK6SwrpIWfFCkOHZNYSMah
ATBfuwIkbd0zm/KHsQkAN9Aev7jwn5nCwggyBPjaZPsXIpPDLgxc7cK+tYQQfOx3zvB/bH1uuJNl
dKiuZCxOYXXVWhtHdCQEg/CoK5X5jH9owxLPxXWJQiXISHQu7uOPLT7hVW6T3ryJrYv+tA46qgD5
XmH66BwV8G693npMNIS23axQrHzFT84HA7Tv0X7LHxY3NgZ+jWp2JZcjd/dhLUPGWKm5aHz40/Qd
BZHMB9DZru0kf4KOBp6JfpRvDBCvQaNQcJkSV1SGPyV0NWsv0yXrP6nvj/15at8XRKMwrIIB6xXM
usU0r7ezR1PlaIbwA9QCHNhh/Y+FTgMrSvZK2J3D72ixgLRZM8waXP3g3OulQktkTzqxLSVPPp4L
ZoAmEalSOj3pZhMENyszbsA309xq/d338z7E+AqbjtCAIdiktjPKiFcJ2/XbFd98rnMB0gqfX58y
gLGlax+OCNKXI4RDJritE4giKZsLJfhgHZQ0Z40/sCZG2n2sK29QbYtj2QhlJG/7VsFVY4tFa+ZB
2lDMaHPN2UZjuRqWaQeo4ZlI7HJfEnUvuQ9Ok/QWFMbteZ0pfxZCD3K8wlMV7pkMPiHICYNCVD3h
LCaF/o+y6bpHpNJvQqLt5rzIji+W13nd7IlpoPl8SOlFLb95R8rzT1ldrki+svZzB0WgtFNtsEi4
5Y0XUib2fV/wqoME8O5ov4cpA8s88KV5GWpHS0gDVcZtmBhg+63db7UoVnjO5GM1MK+XYLTCPGdN
/3Hc4wHYXsR/tLx1b9ZRmTe+6rmZf64WUuJpJjNH/GpUs+lgJEpLGyx6Vlb5DPp8SZbm2zcICOgb
w/8n31N2Qdqzi//rmy2LFlu9sDKJ70w74J8H1CdAg469Xp08CdlB+JPFOpFqTsYgxpx1+rIgqIwR
pnvUfDjwB3aNGbatOrfAr6+NhrxIkihCNHvhLU5ThvfPVP/qKvI0hlKlwkrPD8dlj9fjmGpw9ojH
rBYFddrMy0RRLYpDR/YWXIhvAVjsX0ulBIu052jA0mzJaANhdYTKNNVL/WSMQyw7diCCJ0QcjBuN
MlVCm13zDigZ4ieMUamEN0bNYz30sowwGILVsUyWCSMsNz6AT4eEckfc6L63b2H6X/5rHPC8Oy8P
5Hrevl2ewpalLJkYwj4vp78vgKveAcnEeKM55wwQginB0QMXXs4NaGPm8SNzBS1DPAzov/uE0Kd9
s/Q2HZ1zL5VzyOQTi+d5gPBAYQyURcHKSvc0N3cMUm3gKs0UosCDwaRRz5JqegNtH6aZAa5xSaer
pu8O5lyZmokN7K010gIjTkDfUF+WVULERBlVnKmSTMoS3WPvJV2vcfvoh/cDKkwY0gswMRutt+xv
oH7u8umTZDk8h4dypYET9nc4p/Nfr+A3mboP+36u/RCcSSX1X+sxjRe2SLzmsEgN469Z1OGB/qcm
GkOlfacuxyiZs1xrewWdy97ocGQrabMaavN1c0aZZIBKToI3DYztUonmS8jHb7TT5r3IYy5oOIrq
/Xa3JAoQ0+S2LxYGj/4opk9GD2iueaIoVU3fGcR8u2aD4V9zWC/sTsdyukScpvFuKyxPZQWbOf8+
U2EqzQOAJKj4ESrh394kYmhzRqAkXHu8xoTPztz4b6svLvCZOBnpiKi84gGi7mb03jFwHviwi1hL
xpPTm0MopwGYnMNrbIaJAgftfQHavHQWTnpf7U6TCySIU3xXQQdt/nd6SPL4PhZtsl8df/QLYobs
574e7RI0Zqg8yRrtwWEn4gbsJz1SjNLIc5bVfBK8U0BW22jtf9phbvTr0Q6GNTMHw++CTH4whwsV
BwyPRAlk8bkoevo5hlKitFTZTWDTIMoCuA6/7eEp1Tdt+PjsfQaRkajf2Vi+Kxt5Jw3KnTDMKDgV
mBNpouoRQ9Lb09MvRzl3Plfmxr7HNAMR8UC6oEps3e3r0zRbbWeyBcLaDCpEwAQFXu2PRIu/iYQB
BipgX3UJBiZJgR+vwrvyIC1mUcLLRht+9mSXZFiWyQFNb0yXHqfvjzca0MiOD3dE9hML1bdEUy17
Wwa/+vB6uvRoYdkDcR6IdEI0ORKvcoMeaz4KQh4b3YQR7WQDG95PkW8orLJb0AmLdjWiszerkJGh
tySTa9K225grSf3VIxKBNzHeIUiaxXELW9wzTZeibn1guoU5GezXtKOQGI6i1IWJoOFgSk//xfHA
oN4tPtAJE/+f7PPHg3db9WYhdG0W65pRuwWCuUIRCYOrxmoCuUckgyGkl60tAbHL4QNgRHOoLmas
m5wnEzkTSRM3ePcJqSDVskpbtyorkDioNiKbnMj7Tlu8WZnGEWTf2R9xxRznIY0aWhfGiE/F9Hip
w9uNEth/muJn1rKWnG7n9eEwF7jge6Jp4SVOC0NuB+j5/mCed12fdPG05rl0VHLPzlSZk+XqBOWx
0D+g3xUcpiBRSf6GHUx/6sqWZWPf4fXfPtB6UcX5MhiTkw+mq2uhf1ZEGhwHyfwKfim7GESPYpsw
KlCzDw1oLzrcUgY9GTnpw56SK3qFgm9aPamqC6fLTSKD4LjIfQDcvVuJzhzeoOtAI6V5j1WqZ+t2
jcgyugEGLmkx+RZShVrFUHK05eCjB2Fne59SMnLlYRG89mVOD7lgHg3JRVzy2M9uzz7MiDnELCwV
M2wZEhOrki6TCZVwjmJJVQ1qlF5mJ5CdHE8tgmhQb0oOGX6mV2x4KcwTfh/uMCRvT8a9QWy9eIQ8
haWnNjU1ik0o2uFZe+eTkSFXlr1RWZLgqJx/wFq4dCVXdQEJ7Pif/ujO0tvS01HXSDt1jcIUxBEb
SkQHvbIPsbekrYzCiz9pwL23aYP2c+LL5b05AVLZiljMS7ksID//l+2n2i8bmGUeqJOoS/WGGord
TIimDg91Ly/of2a8PfmlsuIyh3lvt+rwmzk+36nwLTqVZjP1WPsYAhC2GvpMxwYc9Toh1kRkOHW9
k4tPzkde4eFMk20mGxNLIiPCvp5o2xLqn/hYKTXRzyKgj6Fu5zBs4ILT3Frb4LcJslyngs0200JL
K7gASoeqgoBHOryHzgQ2vw+7wD8GPD7i0z9UCan04mOkTwviI8VBmjjo03+9F76wKmH7Be3PUXyi
fhxCkDGASvwfxQlCSMJUbpwI29E0gyj6A59vl0Ygw2h9vixpRflZvrWX066sQpkRDDHlj4k8wS+/
1K0p54gBvv6+dfoGfqxisagOvRfRGXJno5k86rYULRyYGIiQCMKrruRZ0rVQq8KfEekPT8/hDV2U
hXP15C+8ztv2UKX7GXUw3GR4AmdKP8WT6gA0klP6B8Sd0oHChPPlMQ6dvO+QYgIYkxJlHHWcqbrc
SECfSZx6Y3XPJw5QY+e3VYipMnbbrdZY4Kuuo380Ugsq8sK7x7Mv6truHECoxwkLDfUG3djbsAFt
sg6QX72f7YqzB4SX1jmX2FGKz+sFsaDMgPOpxi75oefOFtb4dokV1yQm9DQaMfP/n80Dhz0lKoX2
lCzJRcZFicMKCDx2CHYm+k8BVmm1U1a1i7SUKKFO1EIDOsNjyCEx2rERj8cdD3cLbiC04smPZDoU
ydZFCs1NBsr2y2ipzV2kGguYOgOY1dcMLKJKS5ZiFJrHMfyo/26U0jpQSmOgnLMA453pk1oIr1ap
OJZRpJFnBP2fQ2HAMEA8otKy35c6Lwg0CW823PKCPcueINHUTSfLAvR7TNOVLdqC+1Fqda4NhNx7
zsm2M+PSYRZcue6XS+2SiWfruerdl2kd+3vttqKdyk/LHek3O3BRuzs8izFgG7K+n4ZpLBAWl573
10MJpQd4wlObqb0BhfUuWFYaoOr/YJ33eiwB/lhFTnF4FdvAtZ78Ubzv6V4NELATaot3NhN0HeTF
px7OZkRmZjL7lJQZZ7fwgX/gDxgzZKESxzKSkSK7idtMZczTOa4UZ+wgyHBaKuiMLf9Kdr8pg7zq
pSgjjnQJeK75FGqs/ECw7k/1dWbA3/ErpZUW16LUt/cynbz5sroDmQyjen6/204VCE099qZn9OAS
koWQwEJ8vhcijxMFlqG6DzxgASwtHOoi8ku2BelHEJF3VxMBRX0J75KrN3Sp2ES01NeP2ycaL6GM
1o0qhKPFDmYFJVmAPVJOZ+3wTQm6++2DqAHRAWMHJvNdaXL82/RycY+mM4FNvka16yFd38VKTV7u
xnpTbhKNxu58llhYuS7jcYbO3PJy8BImm7pmuA8xOUndQk1yq4MxD9JV1sLxuRIAIpX0pf4VetkV
V4j6gDpsVJF7r6gWmUzAQIj+9YGqm2aH+5y+VfD7NFe0iA7DXc6GOCuw2Ryn6OjZd1CdRzt+SA2+
T2loK0Cw4mJCIquTvyWcw7gM5TQfJq9UPr1zB6bw8RQLyGm1mz8rQzu0/yB2g9/du47prjJRtf0I
3I9WWnCyEeGVX6N6uzIRNSuY0VaVrsLmSycEqgZ9CjPhXJ7c9XBjH2TMTNOjee3uQ1POzXJowxyi
fedIj1WqKDpD2olZAFUasbVD/IwWH9/Ln7gyVUckTLpzm6DoAotV4WxaXltfgQnw3R0mQLCUeDWz
w4WwOjsZHQ/pa/GEsXs3bi10P8kATG1JP/x7u02lLhsGPAJMduBcyl1BbKNzAYyUeLxFwOtC31JT
ysCDhA6NrC5qBpHVStBi8L6hv2V/Pfg57dWykGzbu9bAU7G3dZP+oPYieQLMxxy65NzrNDE9cD/u
FhGtedUlleGTxUj8y34K4mzCact48Zf/1DQ0piaXrnr4CdDM21QNCBVUZ6HHvamM0mATR1LFy5b3
dIYRA8YVvDQP4apPNjt8+LFafi0/z5m/1oXU48iDh24sdmeXSgtwOxSBM9cQTPSHgJKKrX0UTipb
jj3S2LWOJOkvrgf51siacm21mpY9eytcwCw5SAXKvjAHPdsu0Nn/+HqaYoMKCtrs2VH/K+BQNzgX
2UDsZv1XuI8PVZju64fSnfN9aXJO3U6Bu329FSWBGF8Xxk13v9AY4QQW0kAHKHEIrXupYk8fXlmm
dK0tKB5F3+LRc7EbLXYArc47esI5DCtdBkDYcGsGfaj9RJ7xGSq0ZloxIHwZXKx6u3Frr/DndvE1
L6iR1TtMFtxCRJbdlbVCnT97c/Daf7O6utQ5VMGDrIBnHoqQxnSDwtlKsHoEzsFmcBBBhSpP0Xi4
37foGumvh+Su4uCsvmwDu/sCovEF4rPk6MKGXUJOAN43BdwdmoaixO1CjYYDtTjVhtDAsd5hICVn
0CijePOrzTyQgFr8ZV8crAekGkftROWfZmGxF5vqj14G9uhVAzk1XHBfai8H6YrC+8E+cXl0eG3f
lLKFYGp7H53p8tN0LQxxvI2fK4tS1nC6eC5QVMoMqnF7nbQmMqUn53WrGKTTCDC63aXK8Jxd9fop
f9VW0mgo5C/0u1HVhJqaqREeoDTEH1PfQmoXR1oHoucZo5QUqZaAVX+sJaEWyys+K0ya+PXzwVIW
yy1MMhfWQXQdQR+Y8arP0tcj8FXDqrSSlaa5YcciZo3p6qWwyp+sXn1aWLVouVHnRX/bWji62URn
HgDTmHh67SaAozhKEhrWvVDRxrni/as0gqfs4uEpEghhxtPfzLOeBpayCtqs3jpesvkvm9AGcBje
v75wPOjWBHfGEOWibDJUXpRbYUl5JOVAtNiVLGvICbksN1vUBJwpaHQ8SlaM7OCMeBUtxoIxijaV
QY+Kcad8jm4spPti2apaW6ojhdU2ntIEJw48fR0bPQ79NzHM+kJ0aJp2VWuQw5Lm5h2vadBl1k+/
9Wkjqpzhdi2LpEMNuHkJnD4ULYgzCLuokiPyabi7643xPK0vtL/4XUNVBA6b2r72HTt0LJxIEqo9
OpgBZuFD9XvdgoBlcaf7+P3kxU/a2u2gG8T7kCcs/PQRbJGtucV/i83BalmspXGZDKn11JohRsuh
QeMaasBrUiqKpeCqgdmn9F0OX5SVZootMVIHwGHjEVwYQ75bKNMmGmD7ShzxWkV4dxw1K7J1pjZT
MP+LeDi7zrbTO9Y/kw4FSMuVKiq+xDPbOEgA9YWr0kjWtGRay1N4W1XZ8+aY8k8gN5Q6YPEzsge1
MlkVId5k34r3R/IEiMSN5xQaAliavkbefLvGUkoi2kWt+GR4vUs0vxVUlJbI6vYhf2eUQUrZh9Hy
+lVPaMohTZhr83FwORcIT+hTB+Skp4HBn/g7QAmZi3zSJ8CIA/Iekjh7kpRXMMcDG5MBfjyq7wxp
Zwu2YkOnAl+EnTUrIWAewsk+zHmphn/K1VXvlfqM8Qmru2O2L9fSCC5IfCVEnO9maF8dDg3s8NWU
hYGLoe9HVJ7F5ZPmjgEtHvd63cX5lJ78hJgWPrs/v4qQ5MFVcO9lbOmj9LFyNXcWbCpRqh3I1NKi
ywesigeEoVivcu90z/nlkYYZ/oWSOMQr8Fp+9mVVSE2c5ksHbBeFw9ACPt+V8KB3Uub1W2G6g0vN
Ij84Ww1gzy1/9AzvI3BqbJcy6T59s52zn9pKMYuh+OJPg3xCkmpk9B2Wt53FTSYVqYv5tJTj5mmq
fHspyY1xoSmfFLdtpoyskG5KvWExmSIceS5ZyGS7Ot8RimH0HdkMXxMIlONDvEdmzycZt9H39owo
Qta9yAx53UhRJB8eDtjvGfIzwOo4ddWmRzh+8QlPpDKkvA3kO9AKfPHFCIpSS7tzGyQ0AoA0BQ6j
24N6V9x2cH4q0QbQ9sM7CJJyvq3II2iOJXi/xQjYlPSoiAyevO9pcsO6vBmxPYG6AvSs/wKaOd/7
ZEqOOsbfqkyAvoHueyJ3Ia1AWgCzEDrhwWwGs6siXJZM5JATQenvs/AzwHeEJ9ggGOJ4aqXGJrur
aihqlAsskd6ti8pJoCECgz0Qvt1uwv7bgCcA7htzOVhS9oP/yfjRxeE2BxtbAQpt+RrWJhIfFBQE
0sPrNo73o/2r3PhViYIhHOdcospVlQ3puDaAmOSxQQOb+kXhXFHnRKdCwoTLWXJSGvBVFMIk+YaA
S/gw0mINqAp3MyTh12V71nURUrwYGe9gkC8T+yZpOfe6t60aS2TsXRp3ZkihwYgHVQ/grgKpL5T8
rrhtzri6cRNTva5X7y7aea5+58jlRlutWXjvJ3OrS/kIid1w+Wg5STnsAMBQCIOqGU+3CNrqkac2
b/OwNl64FvJyxb0jumKhfIR9nb4PbOtCwQSCQZSvTUghYiJn8qZySpwFnzsA6aiwNJAz0vjosy4l
H550XbV77I7+wJskeq0NcmlX0xyVNo4HBciFMGBs0aHkcm8jznEJEArA/pXcerCvuY70U8EPKWlh
Eh0loYouHGuVLGomodNbdXMqYTNBOs/fCG/LxFgzJEIXKL/V64vkJ/ZjsUTjMETHisCTKkSv8+Fe
5VLDSOdOZ60ActlIx9hTR2yXswyySCB8sovFsW7hZgDRC/K9o6dQeS4xasPEd4XwxR+0z4ZYUqok
bvEbuQmulDD2hGeCCJDendu9BeBZyIXC9xlNZWsOUOCqzTcha0o4m/WmmoDONdXD1DkmIk6+jyhp
CAZWskpPu9lw88BRxg++wyHm75wbzSPmBV7EPeQDOn0OExmAcRLh+lo82N0NwyI2/x+WUHNqE5Fn
KtEKhUy8ceG93Kw+uwuoGKXvLz5HRYCzuUTueVdHp6zwwJ2aqT6/PY/ebBPuo4LNxjKB/y45dol0
Dzv9YStPznEB6kCTDW5b/3hrRWsmHRuKy0PYoTn0fOL6g+IfSD/su34c75QXn9fRPnULv3INDn9K
Iuog6duHZN2phr2/3t3QMfRW5hupys/4Rs0n9cW8K28cS/Vw6rt5PwwNzKYs78Nw0q7nMJqmxSCu
efw1cmwO2qT1ivAW7Mv6738bxcxSpyM90qFRjvmahxHmYKyQf5ATbig1pBKzej9sXEsqyM/z4PQl
B+Xo36aThWySDi1DvRlLMFFFvGCGspRiNcyiQclC48czo7nDTiAC0JrVWXheFUMQwQ7uobf+scdt
t/hVZQf89PyD1ART7Svl4OX7iqDP9fSt6p6w4so+xbGo7Yzx+TReT6YPO7cuye/ZyKBJPuraYlQd
b3cKM+RuNT2y//xfGtC8Uu4CzHAqexiwhlzVfrruduIxkSwggMNPS0Nic7CZIlRAHXS6vyWuhgS6
DBnEBqdY0MYxb+cGP7tT2xL8sucKwBYTRmKv3zyV7bHhzz+dRJdJaiskNrLg9Jx/DOrHugt9y+Ak
kT+ntsRFzwd6gZDpFkW+/2BgRPemy8E/zUrM0uRTotG83zV1RWt43N9QhKhhR/ExQkF042osac1q
uSeao0lCPu37qy2pKOzWixf0wHFf94XqDwLLxVrxM4FfNZiqKO2eY+uJAbTSqTX8+MVb4Zt4id9I
PWcmh2MGNDslI848v6rN+MNh1YFU6Uls9DkXuVALBPZooA6MRNvu9ezPdbeyQZAvJqQBZ64dDRxy
DITGFadCjQT5fZd01iNMWR0QA+HIJBSIKRyDovLrwNrSMIPzjVlRplcilzM81dpT9vx15i4ZGawx
O4B0vfQQXuWYDny/eY4ico7NQLmhFBhBLT4+k6jK8zCxQv8yxl1U2eHXCbcR6yVu+X9t5im8XB2s
6NOCWmXuA0EyTbLtHwAVEwcHpEduaJF3cUHjAsb8EfBLShKPefCnpOMzx+mwHR7alaGkVjqzms8n
Ee0axxSkgAoNTqWPoRbZLUG/304NGv0re1KxElFUZ1qqNict0WJxSFuEhWLlfCLrlfaABI15M49t
WfcKish7Oc8Ov/NCP/D443e2Ky0EMk3VCkUxqI2skvEBY6mtUEwm1vYtZsLgwkQ+QOrXJTPZOQn0
xuMBhv4t/3NFxfQ0cgR3SbfLxqOKpUloEjvcPTELMfHWANrdO6LAKCu60WD5jCtdhGfXZrIdVqo3
9/J160j9k+S6WLrBAlMw0CjDm+p9QrWNI3Vr78Fs+gRVfhMO/fggSZfkkj48iQ8povEqVHp/pRMt
V1/pDP/5AJKe1Jy2TeEIxrD+2ef19D9kXd8C1I/v7cp1tlR4MJT9REdTMPI8woc7fGfP6XifFVWe
Gl2vLlV1Z9yxO1yRkqBA8oVnGLvrRXH6L/P7vWLV9L5V3uZKU0oSDCfGuzQre9FA3YEbiSKlUCTZ
jJm1peTiYCuTDsfDtzEYPw6eJC+4WWj8JuYYiJmK05Twyqlw4OI/QkKT3wM0FrfrhyuM+Ls/u6Y1
prKFL5604hvxMhfJafwdfY8RVgzZn+EGhHwegV/n7gg7pwdHCSbWMUahcp7fOquAKH0M5RFS5TPD
V/XrNFfuGYDX8ZAwt6jYLa1JuTVawYKKTKA8u89mvk6ucYBUQjnho0ZSXI5DnHfeH2WWxKUNYA9s
YiLaxkh44/9QvvrqQBjLTkUbHo0tyKGKcTt2Fp6J0IJ07LxjAInTKf+rfeFYhM8xhP8B2k6vRgyg
K0SQV0SGKZDynVQiEGVAzoJ9xPqpM0O+CXxj2hNftEpBhy9fpY35oZXbG4AgSFngMn0Gb8MvJHZd
PtZ667mSw0iu7nAyRxVy8+KR4OLCaKZKWjFjjLrO6N8iDYp00AKV4duBVOmRMR9Ri7PippX9YowT
jHNikifpK/RgVuqbrHvvIkB7HLPwMwhqGho4i6dz2hSgucgvEO3kpYsKmOQlkRKrKthaLmeIDYPW
RCY/rcgdu42ygUT6TV4yQtgxiKcEJoTc2MfD4hZ256sIuIfBhQxBrj+G8Jg4By6/0EgguEI0zE10
r+r3EDibOZdQm3/cxrSxylumyxDj7dyILw27UHYbfvXDAEygZjSq+Nqmzk58QB0Mnw73RWatgvRK
yoH2oBUj2f5OGv6Hlz3yba9IkhlrVzmWY80x+OEOhOlzarmGm7TX0bjkwhgtHWxLFASQNr8yCE5w
mmkRRQkaHaAysjjvX+FuUN31S6yy/Vip+l+uuAXOY9nOHSUPqT+OXIlSM3s+yetUs561v13wnDBr
MtabY3/j9ytEoDu+KgV3EOb0zWMXAjLuFvYe5CvQ8cku8W1WU8PV59UXMDdUpmwk1ha06kvxMrpA
Z2hlLo09USeyhKvvRLwoY8UDF/aO+R0nON6BamhW1bjbF3WRJrwyxkuXqJ3+3oIlIIoedmRjZXD+
FP1xh1Kzv3HXvLhH5nZQaeebhkPJfcaerMCj3TCYRu12W/UryKVKLpaBO6zkdNNROfh6RgqDdsux
fauliwuCtt8JJ7HpCfz2iAjb56jMRhPjMobpCG+i9DQi6autBzn+J29J/0iRAMleUVC+9mn6khoI
OSIw+wigjEqyMBilnX2zUx1tugSmvL1f2+uYzTWwGfyg1QbBNCWV4quwWLllHJH+vDwaSQluEqNm
GfRH7no23B/9AXEU8KZ9kXQL4/NoDQ3VynGBY2BDiJJBkC9Txkke9WafPAa1I4Jp0056u7j1EG+4
ivDuPJI+EpJZ8KSvQwLujq+HWrEXq34M6tBaO5iRg1H3YFNkszUYRZEah/+f/I93Zvq2RZiQcEfY
vCCVx7LLjGX+X5KNoHwy4rN/9a79AJ9uvSpL37inhsXty2ymtcEGSZTNEmD48UQP2Sn8mPEKFmhZ
ofAINo1ahv7zTDraKyXfxanfZ6sDRAxuxryUzZZBSm9XJ/8kL4ccFb9gr9U+OZqqyEnN2DQzUv5Q
EUWpy/QjPgwFEtdWvolwqO7WATMXjLUN1X6Y3WXczTUoA/xOzYTp5kjqp04Uu4dV6gYHoIj+fKSB
gJOPF/WJfKrNmfF0yFW6MnBp9Yq5IQjtC5idWNsqGhpdWFZa3As0khHv0xGhTB3Z5cusnjdOQTV0
grjkH8/HM6/TnU6N2uqOZ4vKPuiDWtsv4RU8nh/hzvkHyeCPT/5X7xmS0YYq+jV8cRnpfZeqzpBy
6Lf2E/g/PD5u7Y9MV8QDqSVjnfo8nwznI5PBXkeChidmAT9F1MsiCXwlpp3v708Lt0eWbMfbyjOd
1Z0QW1PFKjykkBtxK4MvkIq5EaMfDp7soinWOUXN/jdVoI3rV2NVrB37SKO4sDbPkeaxfEtP1qyI
WSsojEJOPMIAJgtr3slSBt8Wzo7vlibiq/zhMWdzVq37PEH3o+NNt4oN/knZ7XZfwDBKG+6lVs/I
2wwbUyKPg75DZiJSGhtd7twA2cu6mccm+iKjy+4HRA/8iL3O62sfjr1/TlqaK75yPhMPf8WT+QEQ
tA2sFUFpdpk89xyKvtiJqj8uxwbVS1owMy5WLxWsso1E5S3uQU/FpTFaeKJRGN/nfpQVozkHSPP3
u1dqlMW+JUdNXHJjkKdgNFOuB3TGWcgxeEXsfFeOkiuYd7VV0p/bIEe8E01aPmD6V+wmk0hGT9OL
UKZxbC+6Fw7guWXlsUIwPzZYziu+1uKSju4/ZlVlhT+q8WNncklDiPQW7hDPyU5KUXdwvjQrgHBT
rN3j40G7tgTExhKIO9RXtcUuDZ6YAPwBxXB7inyhBRpvgZtA1EtiGC9khummgksVmbLcR2jVMX4/
U7VXCgx9mRWGV8jgcIN7Ow/djhEgGyumYDfdtnyBZQljCxo9a0CfHC9QG38lRnlU1qnw5AadkiAV
05iL/v0wmirYtlVDW5q/Z545OE5VGxNoD+c9QnS0cY93qq2IOsYCEupjG1CnRBFo3apc0LvmPDGa
2EEdXJvOyO/BRCgiQyvxy59OA2iCrB0ZpOVHbFyUOQnS04cBe4jmtBfA1I7rUnYAjApqE5RxnjuX
K9ApN+B/hHfesgELUKJuR5ni9Kr+5PxarW859WbAHOW47ym8grYCyR3PSsuPZtLPcThSrMWFfcs6
Xlpwxbv9Dh1s92BfcHGvBRtjPXKkInoMVdWJxHZSqxUnBSxNB/VXOTOCEAi3W4zEwr9Hnofxe8dN
a857qWojj5m6HqFWPtqSPyUhUwsLaWWIZF2yuZ3IYX9F61GURof11gSB2694mno4nGreYeSH9JFw
l9DYx4+4OfAOcwrZ+YXNsw3bTlASMOilwkJ0smL+2ZepoeJ7YF+yVIcLNy4haM3JCLdCiA+f+lCi
g6F7dvbIRIuz5xbItBYWE/uD4zJdCsKN8sYRJk2g9cdyonwzh/0Mtq2fvsPA4M6TvnJJKFh8+NVn
LdkpdkiITRCmcaWx9Z0x5Rl9diRhTxpavX4nqQNOlTiRILb8u9LUdFepZuoKS+xNVUl840A30zqV
qrSFzzyUAVBr+9Bl91ZpwcrM21dKIbB3CTmSZES8FEx/n9Hq/BWGDGOdW12YZ4X+9L4SDerAKueZ
jq+Hx+QSV17BnL91mh8QepGEqv27JohJNzjrZgW8fnWzOxB3eKNJhI9fCz6xF7+VIcc4ZAmZXqgW
DRPO8IEmoksZlCVll+/kV5Vn+bKP4pa8x2ksC4LNqPUoNiYnxbC3LkwfPCkzJbaheHSPE7UhZwkH
vdbfyrrB1s/CU/NALdsFv6liQX9+lBBNPbsJYtt5jqxn1Gf/oSdoeoOJAKrii8OUxXECvmzeJEg0
lKRBCnkD9Td13ypGzIufMXxUf06tq/rNl++nrF/osGzEQ/YcNhC99g4/4ol/pyraPL6CqJ7DHEpp
Ypbp1ECUhRK/OLtVc7qAml3t1qhV4iHfpol3I14aIhwj/7hdFarhyz8G3skOTwoHcIDajx7oEDX0
hHcFRtFmkmWBD/pI1hdqoYRHMY/K371SGKPXd2EBU5nVoorsJSy+8faLJPFg5QP/w40T1knAOqkK
JNnf9o4DSzcP9NfJ34XPd9ogYgMBAInphRe7awYCnznHi/dtxkG3hOdclpXSgPILHoTMSBdx4giH
PDtOwsFuwRsN+yQAolwFvXCd+AOt7CQ+RIhBvvYHrJ6sHHQJ6KQ7aqW7YbY8G0g8sQAR6AoNXItQ
iVBVdJV854zr12i6SwFLzmRLZDzlzGiTilfuvrLCwcGCW4AD4TSfGpJJ3bObVHkyCRUEaF6FP8ds
S/90KwrgmJcYYBP8Ak/JsALZvhDCKElPwCVbYEUf3jk3KffQJmGyshEDj8qpS9GaDoew7LE/vadY
eFf8RBrGA444jsRfpFSJSPVfnSEPvus4H7mKzjzbQSRKpok6at34Du1aj2BnsWIcgBRDNo43XeOC
W9KgrHZj8g88Cva7XYmmmQbT9hqDXZBxErA8RppQyY7vjsRlhYzJW+6p2/MPGysDfOeuOFbUhCnk
Pf3aWle/QTdJMTLmRncwH1OIKD+0CiZclta7NnnfjkrWwWeznqwlAPWTw7s38v3qrp18CMIOo3fi
MplsOSt8pW/u8tJEMyjhLZw+ZR2u8GeUvk8YH5nz2VjkzXunjQRvzdDvHB69MYvO6KqqdMwXNF9A
9odl9KVdQjyvu+lT8Fg3879Q+DaC96A+ufS2kv+r+M2t11wAELI3lQo9H3gSXSO8i+hKW7XnihHH
4MCn04cLySNQryArLfWF+3K+mSaVwCDSg2FV7cDc7v+mTbeev/jCegDx8qHZJXn2Qv0j4mAJGcod
pXFevHU1UT2SxVrazhvn0hFPbppE2LpXqLuQo2Aro3b+dUPM6rxqPcYsZ7ed2T5WFZT9Qij8oYBy
mU2dr9oYTuQeP4aMHRUsrqbxsx0/vsdoNZQoProGzfD6o1cDUcDos+H5LbpAkhW2K8ch9gU7hFWo
N5n6FNGGmxqxD4hQJyuo9K6p2BNFr9LEG8nMpgRrae1E732h/2TuHDyd9EkKWC5OPPHEAvw+wnXj
VlcDEjcas0FMDqPS7O3lHZkYwt6DCJ4dEQAp0+fRnMrbqlOR+0EdzrRieOT75xUqF8EimckAMXgn
ltqpRXxCirk29Da3XgOkgIgzAIXde1W4Ex/ap1MIVgiNfOgIjld8Aqpq3HXROuvTe226HSxKkRiq
M05ucZaAj8K6jggUhsZKifaguzBj3DnFGH1n22btUZvBMvOse7xKWY0mu7VeClNlGwj8ApdplYpm
EX928U0LVGQuDiG+Bb+Ml5ysmi38/TlG7AJcO0pf0++xmsWcJrfrJtivFCuDNh0tc9KkxR2ZV37I
SC09rH/jmb7XU0hWPmwwsicnukbKuvfJy12QB0OQl10O+vKvKKZs/meIM7uY9TUC9BkVcq9i2k+v
g1wzqiX/h3IWux7F23QvvSv2Bejcov0v3hL8dL3RjRHc89l1hSHkxXaUSYI+3s4qr7979l4altar
jFveLxbn/DxJPJN/j7+fuqQgKaj855gQCeO143NbDHBYxAelmpcolKst1CAsfvbC8YXtuZ2YNFl3
iKmOD35utr0+wtfi7PB0/AkYe3ENBILEvKOkKgcRg1JsxKgPSDdrz7l1w3Qv6Y16gzlrtK8nwX2A
fyhB9HUrjaSaQ8difih6stFAnQKudure2GZD/UEwLgT19Vm/jULzmvIzaooevuPK82lBDJ8WB1ef
MM/0JymT4CnsEvgV1AuUbFAZCFFlmfDc/mEEWHe/KcDFtHuhCUG1j4QOHhZWfy8tctIQUaFuSdmA
sFMGjtCYaS+jfitNrMFSzUHvTAjMlQfncZSG1zgwmhkTEOYHMe7H+h5zaSqIjZ2eTYULJQYCO7s/
KyV4rj9s1s3CF8v/vy8tHc649/4ur8NyO+DyH9GdVL2oMBh5XHjt3WUVQYTSfBh9jdeqzA+qBkLo
226A6/jB6Xod4J5Wt/LKeHVVZY8KyNaPkFy0UiXf2Zs56tXYq9xokIdQsBjU48UgNdLxa1KUCrti
DJzbiXpNCkEHCb883qgKtpJ2uZu2ax7OLstahjRbVgsu06strUmjuYgy4s1gZL6fKNLQDfCD77Oy
3Jv5Pi2oh+iL5jsmW8YgKdPoN/yuGssumw+qO5m4F6aFPBRAr2SC14vW1NIlr6EHs34VxRo86bsY
g1l2GX+KdAvqNLCRbM24Eg94U9R00+6FD7h7K1/wCmHFkzi5mQpGYDSEPbTZaGeA3DMiujS9RzWh
C+Ey+PWeh6a9CApP6EZ5J12Z+P0i07GdjKBOhC3VDBoq4NwT+3dbjn+Kn7bWO4gUjdck06i+cGSL
kExpuvtQHZJ1yJMFNKdM+w38735koUqArtdEoj89++90nc54D6faIXHeUeVcaIr/kfX1l42c/T/M
WSgVt4ym30tJt8G3Pfwi9/gBjpBRe64pcmhVvefCD4Jw9XPKK0dyG43zTtzvhStJmxaIRQ814Ud+
eMlVAwthE5meKyhAodvf/UrndpQccnrJz78ETAV5I3nJpgDAgVBz1E1Wfo+/GUM41tEgJf1FVasO
JEpLpOAVOngRaIYZd23f83valNnahxOKCfzF+42UB81UXUwJFCxhjoYnD/PP0EI5T1M+l2S3pCKM
dnxI8wQsnfGfic/FjMSzu2YavzRlzklwmC5QSQS7QRF3cQTCezgKsNCGLgarzq3lSVX2lq8NJcGn
BphvWCv1RyerljTF/hFQBsySXH0dFTVwo7FpWkL5eyGaRkhqC++RdWI/9VaVAVvRKUBd71wuxZr/
WXkUxIo0bg7iGS71gBde8tuJr6jNkkqj+bLO055NH5odQ+GfkhiVr/e6Zl2yUgPwubBHb/+oTQRr
WcwhomAAkMFrdEh+aRz5METu3cFWKJtuaGh6tsVZc1TVNwIZ2SihPXFRBAWs3rnKCKRwS9IDP1d/
tjl//AtCibjJoBXWB7B3evO1ndkG+VuNI5XmaAFaXMscTArRgXm7vNnpd+/AxgArdd9amarv8ymn
jeF8Z8Hr66kLGtebQg8uDUffe12p/b3/LH9hvGULIXcgW5ekLNB6FqBiosiaUTeVh60Fu4f/SI5z
FflZzCg4n3C5at7XCpEjPxCiAwOeCxMa71TRvl0qZUVZkJz3b1Pf296kCQAg19/PBFnyTeHK72S5
p/dHnvbWjkTfDU6kq2SIvqluzmXPm/ucVJ33PZgqxbg7P1sjv/VLyVo9mTdB6JoB26Z0E25yL2gc
byUG2ENUFS8qOm65/uEv/prcZthl6NUnooc8enIisZC5imVr1RM824DgVrpN+xc1yNJbvLuUH1Tj
hSwHDFItecQF/dil4kvXbAyyGL8JPHQiXEg/kUeH3neDxG/477RViPzNI4CI4PUKtAMpz6ntJt85
9eIPxXhuSf5Zf7rQwNeQdIkz5cYPC1CvPol0K4QQZ43e0SLdMVEDBYzrN8+ord7bhzowy3+LUXrF
ZSFcUWk2snv5KDm/vfA2zsF43OWP5oGq7uGguzTVIZ8lSZgjHorIMVPX+p+NKpSddZgLy8EV8vRR
nG6VLSqHewXMctFOPg20woLIl6zKAkvy3i9eJEDRSEJKRmrgEUR/tovmtYc0lERwmK3MazsFyjQI
VCGli94dtf+hiCUpiWu6rSuX7C87AzeEh4AJiEeA366cHmvFkan2CxDfOpTwonY8p8kSodUpggMT
FJvp5FTXmWItzlDiYypRpLErT0WYGuYq9E2RDiSxnzJ3w1ZkCd0Dbnq2a/LQa/UZyCvr/qftRxG+
uAyriZJ0whS+3hmQEZO1yEyyk3s94d9bTfFupzQ5dPcB41eK0na6BGT81vtq0jvc7J2hjar0sjBO
Oqz91YHmyCeSahKpc0BM3gwPvhF15Fn0n3Vm2DmQghqjAFOwEjrmF+pIA5zOMH096bllvmu5sdGb
9ULV3p7yTI9P/7PB3iaV4nglwNJDP3zmTavId1ij2BOyuFioJMUnTV1HlkDS2m3eoEfZTE48jhw5
FG3AeTjVpHa9g3tMtulZ3SgJRhiar2nlT9z050mLGty18ekWfejj4I8I3SP7XuxtbJF0Js76+o0b
fje/2ZZas8yH4u9DP0fruPUjbD44jr4EBxY+X7uGSi+7cZ5wpLEesRNxoXWBk2F28p5U+i1el7ZJ
QEieIH636Z7vukrAr3KfCQ3YOzGHr0z7ECF2QA2rJVR3PZ+Gljdqt+xMe4TrX987NEjbebc6SSq8
fVE4CtWBWdAUkZusdv4iYxWlqRWwKQUoiUF8Lc/Ql7E4P/HAMRRqaNXcJDVTDVkRhUg/t9PtPXde
VNazx/eXGx/PiGf1lWRi1OPl/6+0XGsAVsqfXrvQhUaf6CTv+DRixvE1BupWypK9JASb8EZS7hQY
NlVphMmNrPsdQhFztf7Vo3VqANZxLN8eQx6PhoZrO9jEG64Zj1prRk/FvZanhro1I5rrb2MXVe11
ACC8nbPb70Tth33VV39+gYvJXK1fkG8iVWt9S7qAsMCFRMMJ7W3bts6sO0+USgHsMlWc4MohMz/J
kiQQIugrUx93HJSEBsZpARgLCMT1tuXnV02VSnIZ3DkZDc8UGHOgdsB7WPupTsZCwgGZf+gKumVk
hKtLz16FIHMY9+VARdAXc8RywfVSZ+QJzIkgxR/swLO3dm0zO/mgcIvpohBYIPDg6l0e6mqqlQ9b
sXxJ0KMx6g5lsAvsrHgpgSNu91xDLXJ7+QbH7vbcrxgnNAxbwaqVsPgHZew7b2Z8P3qNQ9G73DNM
p3UcKgfz7qcg0GjSf0ueHb7uK36wdOqaRUNWwIBrKpovgarVhT3HoRAru13NfDQnUEj613DzkKii
lmF5PYOy5hQom9CSkq1jqGddJSjE9ExKmDcWOnTK+iDmtulzAWwTeK8Hvd56Kd0wITJQrcYxw7XY
2G9ZTw7wE7rdBvtbQuDRcvfr1+kIIKep578DEN07qI37e12umnzQW61P1wjl8NJ9Ha6kqQNbiC06
FFbbH+uwt9FkNDEuwUKmSPW6ndtdpOFTUB7xZmjFzQCMXXYPpZNuAV9DDhSfWwVFLXJ0F+ykdqvb
YC1cFv2LkdvlLYcS7uyS6Z/hTAaGF+d4vo++QG4kIvOmqCuqVgsNJ78wXHg2OUcL2T/hZSN+0PEs
O9Y9FaccSdcDGf6NEzZ1dsG/hYbhMVVoCuLO4VNryncJy3MO3tBcBjcU9/8EzHPZIxtNF9nxs1GV
iSvi0M5KSvBkVEy4FXr6Gn2VnMXSVEjEsINIYgzuX8b3VjHWBvX7+VPVL0uzUZlFbiTXXAQaT5z5
QhwBWYCKfQPCK5zwujVKE2vOeTjiBZq7fVEsQFQcSHV2TwhgJjouC4OcABfAiQKK/qV08uNmVtLO
jEVbIHNwKu6cOTB6D3Fu5HbsWYVGyqvHmzNKTaGVMN5aex5Zxu3x5+OV+OHQy94Jr7bdvvBJzEUj
oJbmiV5+GhO6HI/Lq2YTZNqbI65kNdMhtp4QGWu3SNpmHI98ZuhxQKVYTjNlI+uZxkoltBjUGTel
yvUyJkvHRpDZ/BoaMlOs//lY51xHelo9nMDM7i4p8exHd2smVlexJNJHAz12sMGcjKHNnvndI0z4
ZUPxZ5rX3YN54o8ZkqFm0Iit6atk0kG1iShANSoq/lt58cCc6YES01+iCpqckgcOwYgMTEg8Rndd
ojqQoJRXcFtTfef2lYrweQ1+mWM1bUGVBRqHq6s1PWA3bM/3l0gh81PCzfKZPfd8hhDsEpuwHGUQ
D8M9/ziqW2uwd7DzKUTDwAhFG1p/sWxVghtZjkOSo6JaITPYT8kBtCnT3qTT/FVoeosLLzBnOSuh
ypjF/1nYCSOGMuU0hOLt4fv7k057lsegGO/UaikOqLok9Ao+kqVXky4N9GPha86qNnJM9Ull2ZPy
eF/B7k97OtMowy7laguxf/xUjAXocMq2Auel1M+eH+jVKdjQYauBImZ3c2+6sS0J/7bcRFeOLDPq
tWahraP3hvPPm5GKmaY9CY30hyL4pvu7EnDlDlKUrieqa/T1Hf1Bss0ee84ZYLfaP1SJtqBbqya5
gnZ8CGQQ5gcQVdO79R3byEQXzjzUO1FGfh04reo23NszuiQoS5dKwT/ijbdYJEkOsiCtNzNDam/b
soIQvFjnfpSYZhZnKrpg+BbxPjj9ZEYiFsd8WCzSSrZ2m0QYxvwPzOA1T97UrhAZrfP2uZqmT5B7
zrNDhnvwN29CxBSYFaBeHVo/gr1KhqyozNC4xpaDwQI4jzAdk3cVhexSMCw4KGWMz5Kij+6eTIc6
w3Qf05jPJeJYGna39vBo67T1VKLDaR+Bi/mfDzXA98HPKuxHAQPBZ8Hh9l4wb+HNlnLGABqpKgw3
44OePHyZxzkPUWvd6wTxdqLq0uMHKmMiCKndlXUf08YtnUtbWLHf+83Yi9TC5KOE2jmu3G3HaLRy
4ld20gP+loIqQqhTDP1uhPxgPs5o6z0ZPK8D1NqpxyI0BaZkGjGHZAWXXaC496btfzYeGlZPsEpQ
mX5ReYOHHsXKYWb8BeEGf6U6JIFLd598yoVXZiJByup59VDSN9Dkq1jpEVnUHgiC8OD6zbPdHk0P
cEPkXxgEl1SzI9Hd6BfKK4O72G5OilQJXnNm5AF0zWduubW2EUbgpIY32W8gWur6eba327gGYxnf
O3qKTToz9RkiurnJVbsAW5SX1Iddm0lAr+IhrOwuM15UrseNYvAO3lSh/feJo8LoYN1Ds4T4Pz63
ZkKSxm9fxIZJBFmQKtDztMww4tKL9ekPjR+JhSxRFUl8YrMRNciqRzq44N49qv7rMXJc/seXtTZN
4BwmZC4NVudscjt1E4Vl5id0eXRZKiLXsTymVJmPLNej8mbDdFudteKOCRYqA/zj68qzXxm6d3Wr
qohh4oPdUSzlTtoM2kNGZYgzRnGb/McDfClMgjdg1YEnBujy7ZnSov7BP6/Y6ybGyUGZmBGhaS1f
z3f4vTR7BHK/a+vSTVyQcg7vAuBGYB2rIrNKNoOpEZiyEv3vEWFp6Mi2+R+RnhFwGFAiPSS1sq2l
tdMRMZAmpT6nZ+BJkGummrMpt8rvqoL/phTjGfdO/u41lZgkTOjxLvy/VcIMRirk6HqqjgxQBlDl
73RgpnQWnuWUX3f29K0Uk+VyyVvflKyYCkRuMDOzrsXShFTuj7Dhy3aGIyO3y1AwX4JOub2opuF0
7cxd9ty3v6Pp36WEZY4zlaJ6sliC1dsrFnCocuzoGEmOfuhzC+APrYo//UXtMOC78DZk0EhIfqLh
6bossBb8dmxZy26H6yXtNeBZ01sMSLCeMX2iGlHquFT/NMQiUf+nS3PVATtLNujVijsZij/2NVhU
Xk3CA56J9RLnavDC9HDCBmw2opFZgz0hh0YUrPdwjDDTClj9mzMLPrFyV8rFszuq5a4HkQn7aBHp
4sCvMNSD+cOwQatBFH5haSFHTZmvRYE4G7/t0Z3jpArONeBfYJ3gdN6bUimYRdJcsRWAHkB5KiVC
Fyil4OXWK0sZRMeVK9HgscJinMzml/7tVUWvzlPfrrLkcq55E60MMMBnXQT4usP5lqpd4/3XmQlx
TKZ8vbLOG1n1WPF9nDn3eIGqko2bxfR+2gBQ/qg369R7chXVKMBVaCMr3t8GjOEA0aMv+ObXJ76W
ktfo554vV5Tm2+cmiuvmN/KwpUCVPsrs4msuSxbplPIqXAUINW4kcCPfM6aWvYAB4oP5k5Ipg4H8
C8V1SELoFF5GyzGFd3vYDR5W7TcZtmwmELy2x3w5x1PLiGV/uCKjD+/K87WGPgquhjDUMUSRLGXW
TDoRK98lofD/7zyYgBSxUzaZZ+DhTuhAwzHqbCFLQYS6OuZG1m+8l0KmVZl0w+U5KaTPumBthX/M
vhyoXToADB7p1wiXyHzRYXQnn+OnSLtWkhtzN1UE2R1tN4FBiokLa1op6UhhF0xVBOE79LS6Aqgw
xnB/gS2lcu78f6PrGpw/oUNnqnvCjygSjVgFuFovn8rNHOSrpMR9m2B+LQHgP/JoIkTt/DdRpuAQ
STbE8V2GCYgVftqz209YjmupMAO78Nvv1Kdfp72lrzcY4z+iRULCYB58Sm7cCYKiw9ToBwopipAm
PfG+WvZ8GauPrn3kNfRQfHY0xDcfqKa3AjG+PXtLUSPS9pfpMDwrtGbREWFu4RNUjExbQ6bk3WH4
TShHcjQr4uaFEQWva9bSmORiS21OE9ObgDNEqU5ad69WrcglubizacUFLKxTAXO1LeF7OP20lMBJ
wEGIDiCKiFCWGpps/CetM0IYF+6sV9THnZhQEfWqnX2agsSklOLNvQABRIjqM3Rk95IT6571Tky+
tFzMBtAWTuL1O0F8+WB5vUHRAYozI0qt2OtL1gc9bzkBW6Kfu6oV51icsoDdIYcIXH2WTFZSMZHs
I33h57XD/v+U+P6Nr1surzi8NiEAQl0G2pBqZLWP9QZYX5a8mnnXR1NIjGkDObAY90vDNnUsW0Lh
y2ufpCzfnFceqVgC0c3w5LDeplvET0Pthl18KwnQ1MeonH9Yb3JCGY2As1gGERxtDgAk5I74IEKQ
PQfId9iadhclVqmKh9KvrH9/+qW1GpcgzC84NVajcUp8yy4N58kDmWXDUXmMDICepYYSmcV7Va0Y
vizbDCgqdcMH1+xEjg9ddDqc0qVypEZPO07JTWISVLmor/ctvmsRcRmNkGUmIjuvi5Hboga0Nqfr
/82PxJ4fsb4mpC8PoKC/M3bQr1QabY0YRIS/idfN+fYp+YXfnen3St5GYMmNqjnIFCSy6IVtGaAF
5zYFFMkMBgbGctlYizBiQOoiRv7tMJItgpvwSfQkBPq9I6RfosEGepl95buDz0gN/nHO7qmYXoGp
7oC9ldatNwcARz8b+7QhJAmC3j0hEfczcJX6wqtSxvjWxg5vOoqwSOLRoFnrOrTQZEBNMY6dImdL
/Xudtbhb6enXLZHKXSD2aL+catVrYIe1McqQV9nZIGs+r5ndB0AMLOO0iKLAVUalK7rg7BD0rmht
LBLp1adf5Z6E5TIKlEX0m/JJWvl/RqCJgjUMrWUHKVoV78jE66qxzMdqQ0g4MUQszhbvWXfQvgQ6
C26yrzUhl/w88neqthwYTMOdNcuoPDBbbCHRUZJjrpgFAQYDhk5xY9xUwTJH6B/IUumQ8ff6+KnI
5zu4En/yT6/dh2xqUfvA3i70lYe/T3OB9Fw3M58+2SJHwSRwNAIBxItj29RPIVcpBx6Ark/w7PB4
H1dU8oGyZUU7n95s4lhkKxqvSbwJZP7dzaZJBsiVXjXdSSdb8K2N70RXUT5gtjOm9fLWkrORGdWT
8MGUcExqW0/N8RMKfkeHV1vWdp6VZv4d5whLVkw61IP7FdVmefJ8DhqM/DkCLpc5uK9Ll9f1p2Bn
KwroKvmoRJGNUoavT8tsrgzg5AL/dxK4TtWIb9yZi8DeC38uXy4FHSuwAKvgKvmQU/5vHY8NpcDW
Ms/O9SpwDa/47p5QcP1tN1ZsxtlQgbv/svdtps7gquACxYmfIS5z4wzOpUGxQxEwr/JtedYK/AqV
Pcp0pMQw3zOwRdi5JSy3Y5T7r/gtKEDzwAcJm16t6YeYfszzzPUJxiJvNDQLA50/wYuD7WrUZ5mR
Z3TuwWs4axEysQl8cCTV6wH++eA8qeTapJAe85wakln2K2okznJISdcEaFBTYe9nEUBy5mD37xt0
SXfLjJr8Iwn25OHLlMOJAvVZ28ATwe1PkjKO7xZ7vu22T20bjrzgFixXCzdoQ3S6zdkn7vlKfTHf
aIRl4WFZFd6Ym2JydJJ0JB9ZU0zkKQKsCcM57mxxU57ZvAKEwylEMPOCqAgUocfpaUwslNUVJFkW
b03YKTjPDwlZ1H58YvBJzApJEpx9FY4J+l2bDavYo/MfGgjwgC2EVz7SIMS8IfZ52YGsYRWauvzP
9i7667zwYkbnnytzedasEqZTMZ5CyUkBkNG4V92ZTdaDn5nFl3Xqg1fRhUHDEiLrB77BsiOBEx48
hbOOuvDpl7IdqpMyy1NDNycRwGpMXXygPLFMQlulHEtwXFij6F1Ozuwsm/nk2rjBEuMne42iFItF
jaQg6geO6I8XXHxweqJfumbLJBiNMO8p1ZymWXQ9MCMmcGi11Y1kJ6pcyZ/axZAekG2josrpR3tl
Kgji7fS7FWK2niyp4VT3+qe+kf8vX+rB93Nt5jCsJ/D4WqT7U0hZ81NkX301pTEr0Tpjab003ew9
WmM9lewjP+1f2kIS7xFChtSDaD/sx5xIBrRF7UII5jPGVxhoHOaQcBZrL/FDfDJK5NP2ACcVm203
DPq4y1vhs6XivlFiESUWoGaVq4I8g9+0JhBYnTN2eQLnpblVRGFPcFiL87ytxaiK9dKiorzzAxYX
3xu7Bg/24DPLNLRKU5x84lE2E8T1OsvK74QzoZ30nb9aammw64qNtQlG/vGynU3CWw0K8/QohLuu
M7ULGNEa1njW8cfXHEp9IrDegqSzFoEDttOsGo2GF5g/lx3FRQcVY4OWJwN9PVCIYy9YRdRTndIN
u2XrErUdA+VeOaOE15Mhu0k2rVpCzp2vBdp54mhhqS1VEgakeytdj5GUszSroZcJ+gbl8/Un/kDM
E3OIMjC6+lv9YiMkixCaWK+RAVXXlpWnqfuJDrLRx7REg3tlotXF9MmZsVY/9cGyi4upwQW8/Zqj
rhNTQk+g1fo6FksRnjLKpGHI/YzeSs6DiFgMKw7h9vRpoO+XDPnFXs/PtRxglRMOPTtYnxxU2+qX
f+RnTse67+YjuuK8e6O9Qyr6hGmjzlVqI3OYpcibP5l0VNi0hc16/bK4VkJsVqosm87x9nJXz8Jg
KVeK72sWur8vneb38kmkbB1vGo9mQEWoxRvzir0x2VVurxiNVrt6R6kvIlN0MI8irF8MdTuc3kr+
+H4JVtXKo2MWHFTFQov+SuIKnXm1GSh2wGnT889N1akGsu1guKaMoVLxz3EY/rmecxyHQLFxOMEa
8fpmLLV8gGxY4uAswqaL/1CvfZu2xUOstWQRT/O9XP21XMDZL5ElmRBDjXq84zmfloIKnbqMkExc
Ljv11228fZRqQ3GFalxIbzemH+WKD5Qb2pFRgB3sQ0f1Ahtn2atEdrdi6OT4xC25clBAnKiyxYBP
duf0lbeKaWhxyrDATaAirNSi3BzHOds8Pc9+251cTTv0+V3oTimUPbGfJKxQKCAG3DCLQ+cQFurR
I7JzTrC1VIcee3VN6piWyhrGMKzjjgjwhSS3whYlmevC2YFZvQcsU9uxjTAykBdJr9tu2qD9FZOd
xWZmIlfCH9yHBu7AjNhJDZgKq9R4Yyea9bpotBDMimwaKt3WUUOSB/I+VVeKiLqrJmiwG1IkeA/1
uUYUOXb6iruzoIidSag6mMjVVagUP37AWQDmR4ChwypW2zy5/cpNm1IDVZjbj8yVMCB05gpr5dLk
HTAYWPQYFJueE+HBy5+mwSk5rfJPmKSmHmKpR5KQ6zRO+B006EOM0ATYTO4JgKLKZzm5sr+CgmRz
/iZhiU+IoClQqMILeO4xsllU2ao1zbNFK3jQ3FQZu3xCDngB5siRgFo3BBvx/wUFb1MQLloVq1ag
nsbtvsYFlWaZ2KlAV12b2UwBJ30fNgM+H1CNFAIJdV5aqYv9Uu0aTMDqqV8YlT9jA5vvvGD2dVss
4dU9fLlG4rGKKoYKP3jW+uAnMfO5Ge/4kJAyQHx7Oj2icr0CD+Hsvn/KFc34jVHquP8QOOCeN5xO
E7GgTiZNJ6wM4urcuk+4qg1VumvAC63JdpyQEEuDilbn4tQLAy7aazqoVrcT7TAFCdKKUlOEBZg5
0rnLf7pg3sgt2ctDum2TMeOX1kLRCFTCMoBoxgOXEciwVXJrdfM5vcDqdwO94Xaetxrxgaswt6Cf
imtUH+tAEhpsd+8Vx9EfsdEfZm4tOMCHG14jr++quPlwg+GcHjS8dmAyl2sikadxAj3B2UK/SkLu
g8kClJoUNnOo2SmLMusYwVoW+6+2PImDmiXIvoz+TbSs4DkajpnOuqmw0toxIne0xdjPbtGp/FJN
dpFqXPkjbSHM2SBtbCadK2FMD4Iwl0bheTyMPHsBzLDMHhK117VHtZmKk+x5vJlcllbw5MEqblJH
yNWBXkClS+XunHMs84IwqXp3Yr6ENnXcbENvpBAn5fVGrnCuyfyh7GsViAzTWgMR/i7YrJRoTk2v
Yg1w4p9LCRh7LhDiklMumBzbmf2VfMpfnvQnPpYHX45LfhPNkipUOvBtXI3QJ5o2m3g8G0x8Paq8
5DWjFA5iRzofrePdAZVOYyLg7+BS19sPlxY8EEu7LGM9Bx5w3Fm+u4HNELuzocsRAmNQisaUSzm2
qWXJez5kmrXV4GGkGim21LAByaVRc79aznNcY5r054QT0ZHe6MEt2a36LlH8xErJOoCWsFPXfauJ
H6+cpdYAqq25gC6WrCL20bEBa2+0Kq4U5oUkVAfHqNFxHzsDKWmLIROYidd0tOZs8YJ/LrUGF+Sn
kXJ/T0rpdNUKDdX20I8bt+KutOZIPWNS7LeLlOMp8wUNDYyyxE5AOMw23edHWQdQJ675HXzFtAxj
2XnyNHprpxfDH4UOcGXczTlz9CzOUeqkrZWjEezKWgoFVaYgwn2lPDM2RB5JUs8c96bwGvP4WrJF
OGrrcVxnEWr93rQlYVWd6lnUjEEafzcSmR07DyzLBIFMGtomr2/pz9CD02h31VineoL4hvWS4xcX
6PbCQ+AuEDm1dSB5bPTpwTTas90/+KeOZn9HCK5bLq6Y6okfzN4NAPz7KZrrWZtMqeP/RhWyQ7pa
AogQdcL9a2FPAI8nOcaoeixQSxeJnCcaLgjdcU89CQ5frpdisVBx8iYkt/xMWodmEByCfj6V7mPG
YSXsShOb5NsefposiU/gHIsK4dvv6lnaPicEiFzxZlnu11dzF+E6vzzAwaz5f8RWn5oYZi33ndch
athJhLSatO8JKivUjTNWalAs+4S/Aca7btdvVNy7ETb9a6HEUiKau6pTNacB8IkDzDyFQRtfby+J
uq7IHkIrPDoWYEQq12rcKwLZJlVdeda7OuRB9mKJ4JbNkkHkqAP/TAOpBNEoAQRzX4Fn/XWLaYb/
HwKFXe0KzxlyNffd6LHLDShUaK+PuCm3ACjFyvJi8c3J1gkBfmUebjjI3tVHOJZuCJfyWeX/aMYX
PdFg0UL6hg5Pgyc8QEjTrtCvFKD66XcZqIHGgMvmoSGKZBCWbuHjJrj0OC62ztrio0YNkdaBnOl7
CywM1xbEqhF6lgcpNj6gEJZ65OS7Wh29B/PjGYIunMftMnpHSgi3lVMf68gimQ+K4wBAzlqHFp/4
F/bIlkXfBaoFid+YsY0RvEzpQwfO6x+GVlx28EvRvq0yk23iMWxfP1jr2Joh98Pl1Bd38nZQ1Qag
27pfYaKdO23vsaIhdNlrFGRJ+vHGZ+s5yAN46sGCB6AO/kbY+4OKIn9Vry7UyE8GG3gV2Hxawtdp
DPB/Qbg6y6m867KKy3y75RU8rg6SIIoEnRgSxRWilqXb0iIfL2dpTXFmwXVZ97xdZykGGmx4v62V
rJZiktgp70IO15mYh9J4rMbT0JqEkfJEh56GLqMxt5Sws6lJB3ukwnTbxyATK0eS1u6aZp9ZZ6Pz
8ktBhxUexnyTTQ3UGsecyJKJM8gix9wHXjsWqjabcdDNiCbFvj5reakvaP4bwlQsUS4CvIAqSpRu
uLB/HxPr2PSTUu/7Va9mbyyKMFIu/2sCHIOLUJIoKydDFSQMU5BmPbMikOugtWxVCXhvALYoLNIV
EG4KYD+rgyFlEHJ/QvboLDa0rqCraK3Ez0yFNBbnLBl+BTNUu7aBfbXUIoWgA/ELcGj3VJk63vnj
tFAnDmf+jXu1rTkOH9xGmJJmcpHWOCCRirWI4gonR3mMmm6/xUHA6FQAHD2zFEIKMhjkQqCSGgqT
6DuUZVJ+Z4EVt6XUPgl6DOvJpVTG2dvXLdezGlru8s4jL8NgQha1JVkSirK21E5V1CGvU4mPPoCl
GGo9LV2kZwwxBteQTiBj1Xg8qDXMHJd3Tw2ujQylp2j6ioUX0iXMYBPUKuA5LhiLH/rbwpVMLav2
8vhrd1UNts0a6Xqwy2HGlk6nWHyQ1Tsht/KXU2OgYvVJZKqdp4H4pjtkDnq6yVfarZwn2FQSjXFA
vIErMUWxc5oizPYzU51TmmMO49QHFdR3+77X4OcAQrTQnY2P6/VVfTjmGfin19lPrs0lhKtmdPeC
7auMdzOonKR0pJy/g3nI2pMWsQxLidpvhPSXWBvTLVCbSJWmA/mEyl8hUhJ4L8ws6daS7iG4XnXo
BzTKuAzvTB6KmA==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
