// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (lin64) Build 6511674 Tue Jun 16 11:01:26 MDT 2026
// Date        : Wed Jul 29 17:56:27 2026
// Host        : amd-VirtualBox running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ char_fifo_sim_netlist.v
// Design      : char_fifo
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xcku040-ffva1156-2-e
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "char_fifo,fifo_generator_v13_2_15,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "fifo_generator_v13_2_15,Vivado 2026.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (srst,
    wr_clk,
    rd_clk,
    din,
    wr_en,
    rd_en,
    dout,
    full,
    empty,
    wr_rst_busy,
    rd_rst_busy);
  input srst;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 write_clk CLK" *) (* x_interface_mode = "slave write_clk" *) (* x_interface_parameter = "XIL_INTERFACENAME write_clk, FREQ_HZ 1000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input wr_clk;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 read_clk CLK" *) (* x_interface_mode = "slave read_clk" *) (* x_interface_parameter = "XIL_INTERFACENAME read_clk, FREQ_HZ 1000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input rd_clk;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE WR_DATA" *) (* x_interface_mode = "slave FIFO_WRITE" *) input [7:0]din;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE WR_EN" *) input wr_en;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ RD_EN" *) (* x_interface_mode = "slave FIFO_READ" *) input rd_en;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ RD_DATA" *) output [7:0]dout;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE FULL" *) output full;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ EMPTY" *) output empty;
  output wr_rst_busy;
  output rd_rst_busy;

  wire [7:0]din;
  wire [7:0]dout;
  wire empty;
  wire full;
  wire rd_clk;
  wire rd_en;
  wire rd_rst_busy;
  wire srst;
  wire wr_clk;
  wire wr_en;
  wire wr_rst_busy;
  wire NLW_U0_almost_empty_UNCONNECTED;
  wire NLW_U0_almost_full_UNCONNECTED;
  wire NLW_U0_axi_ar_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_ar_overflow_UNCONNECTED;
  wire NLW_U0_axi_ar_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_ar_prog_full_UNCONNECTED;
  wire NLW_U0_axi_ar_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_ar_underflow_UNCONNECTED;
  wire NLW_U0_axi_aw_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_aw_overflow_UNCONNECTED;
  wire NLW_U0_axi_aw_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_aw_prog_full_UNCONNECTED;
  wire NLW_U0_axi_aw_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_aw_underflow_UNCONNECTED;
  wire NLW_U0_axi_b_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_b_overflow_UNCONNECTED;
  wire NLW_U0_axi_b_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_b_prog_full_UNCONNECTED;
  wire NLW_U0_axi_b_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_b_underflow_UNCONNECTED;
  wire NLW_U0_axi_r_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_r_overflow_UNCONNECTED;
  wire NLW_U0_axi_r_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_r_prog_full_UNCONNECTED;
  wire NLW_U0_axi_r_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_r_underflow_UNCONNECTED;
  wire NLW_U0_axi_w_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_w_overflow_UNCONNECTED;
  wire NLW_U0_axi_w_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_w_prog_full_UNCONNECTED;
  wire NLW_U0_axi_w_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_w_underflow_UNCONNECTED;
  wire NLW_U0_axis_dbiterr_UNCONNECTED;
  wire NLW_U0_axis_overflow_UNCONNECTED;
  wire NLW_U0_axis_prog_empty_UNCONNECTED;
  wire NLW_U0_axis_prog_full_UNCONNECTED;
  wire NLW_U0_axis_sbiterr_UNCONNECTED;
  wire NLW_U0_axis_underflow_UNCONNECTED;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_m_axi_arvalid_UNCONNECTED;
  wire NLW_U0_m_axi_awvalid_UNCONNECTED;
  wire NLW_U0_m_axi_bready_UNCONNECTED;
  wire NLW_U0_m_axi_rready_UNCONNECTED;
  wire NLW_U0_m_axi_wlast_UNCONNECTED;
  wire NLW_U0_m_axi_wvalid_UNCONNECTED;
  wire NLW_U0_m_axis_tlast_UNCONNECTED;
  wire NLW_U0_m_axis_tvalid_UNCONNECTED;
  wire NLW_U0_overflow_UNCONNECTED;
  wire NLW_U0_prog_empty_UNCONNECTED;
  wire NLW_U0_prog_full_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_s_axis_tready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire NLW_U0_underflow_UNCONNECTED;
  wire NLW_U0_valid_UNCONNECTED;
  wire NLW_U0_wr_ack_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_data_count_UNCONNECTED;
  wire [31:0]NLW_U0_m_axi_araddr_UNCONNECTED;
  wire [1:0]NLW_U0_m_axi_arburst_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arcache_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_arid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_arlen_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_arlock_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_arprot_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arqos_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arregion_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_arsize_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_aruser_UNCONNECTED;
  wire [31:0]NLW_U0_m_axi_awaddr_UNCONNECTED;
  wire [1:0]NLW_U0_m_axi_awburst_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awcache_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_awlen_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awlock_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_awprot_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awqos_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awregion_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_awsize_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awuser_UNCONNECTED;
  wire [63:0]NLW_U0_m_axi_wdata_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_wid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_wstrb_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_wuser_UNCONNECTED;
  wire [7:0]NLW_U0_m_axis_tdata_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tdest_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tid_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tkeep_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tstrb_UNCONNECTED;
  wire [3:0]NLW_U0_m_axis_tuser_UNCONNECTED;
  wire [10:0]NLW_U0_rd_data_count_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_buser_UNCONNECTED;
  wire [63:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_ruser_UNCONNECTED;
  wire [10:0]NLW_U0_wr_data_count_UNCONNECTED;

  (* C_ADD_NGC_CONSTRAINT = "0" *) 
  (* C_APPLICATION_TYPE_AXIS = "0" *) 
  (* C_APPLICATION_TYPE_RACH = "0" *) 
  (* C_APPLICATION_TYPE_RDCH = "0" *) 
  (* C_APPLICATION_TYPE_WACH = "0" *) 
  (* C_APPLICATION_TYPE_WDCH = "0" *) 
  (* C_APPLICATION_TYPE_WRCH = "0" *) 
  (* C_AXIS_TDATA_WIDTH = "8" *) 
  (* C_AXIS_TDEST_WIDTH = "1" *) 
  (* C_AXIS_TID_WIDTH = "1" *) 
  (* C_AXIS_TKEEP_WIDTH = "1" *) 
  (* C_AXIS_TSTRB_WIDTH = "1" *) 
  (* C_AXIS_TUSER_WIDTH = "4" *) 
  (* C_AXIS_TYPE = "0" *) 
  (* C_AXI_ADDR_WIDTH = "32" *) 
  (* C_AXI_ARUSER_WIDTH = "1" *) 
  (* C_AXI_AWUSER_WIDTH = "1" *) 
  (* C_AXI_BUSER_WIDTH = "1" *) 
  (* C_AXI_DATA_WIDTH = "64" *) 
  (* C_AXI_ID_WIDTH = "1" *) 
  (* C_AXI_LEN_WIDTH = "8" *) 
  (* C_AXI_LOCK_WIDTH = "1" *) 
  (* C_AXI_RUSER_WIDTH = "1" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_AXI_WUSER_WIDTH = "1" *) 
  (* C_COMMON_CLOCK = "0" *) 
  (* C_COUNT_TYPE = "0" *) 
  (* C_DATA_COUNT_WIDTH = "11" *) 
  (* C_DEFAULT_VALUE = "BlankString" *) 
  (* C_DIN_WIDTH = "8" *) 
  (* C_DIN_WIDTH_AXIS = "1" *) 
  (* C_DIN_WIDTH_RACH = "32" *) 
  (* C_DIN_WIDTH_RDCH = "64" *) 
  (* C_DIN_WIDTH_WACH = "1" *) 
  (* C_DIN_WIDTH_WDCH = "64" *) 
  (* C_DIN_WIDTH_WRCH = "2" *) 
  (* C_DOUT_RST_VAL = "0" *) 
  (* C_DOUT_WIDTH = "8" *) 
  (* C_ENABLE_RLOCS = "0" *) 
  (* C_ENABLE_RST_SYNC = "1" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_ERROR_INJECTION_TYPE = "0" *) 
  (* C_ERROR_INJECTION_TYPE_AXIS = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WRCH = "0" *) 
  (* C_FAMILY = "kintexu" *) 
  (* C_FULL_FLAGS_RST_VAL = "0" *) 
  (* C_HAS_ALMOST_EMPTY = "0" *) 
  (* C_HAS_ALMOST_FULL = "0" *) 
  (* C_HAS_AXIS_TDATA = "1" *) 
  (* C_HAS_AXIS_TDEST = "0" *) 
  (* C_HAS_AXIS_TID = "0" *) 
  (* C_HAS_AXIS_TKEEP = "0" *) 
  (* C_HAS_AXIS_TLAST = "0" *) 
  (* C_HAS_AXIS_TREADY = "1" *) 
  (* C_HAS_AXIS_TSTRB = "0" *) 
  (* C_HAS_AXIS_TUSER = "1" *) 
  (* C_HAS_AXI_ARUSER = "0" *) 
  (* C_HAS_AXI_AWUSER = "0" *) 
  (* C_HAS_AXI_BUSER = "0" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_AXI_RD_CHANNEL = "1" *) 
  (* C_HAS_AXI_RUSER = "0" *) 
  (* C_HAS_AXI_WR_CHANNEL = "1" *) 
  (* C_HAS_AXI_WUSER = "0" *) 
  (* C_HAS_BACKUP = "0" *) 
  (* C_HAS_DATA_COUNT = "0" *) 
  (* C_HAS_DATA_COUNTS_AXIS = "0" *) 
  (* C_HAS_DATA_COUNTS_RACH = "0" *) 
  (* C_HAS_DATA_COUNTS_RDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WACH = "0" *) 
  (* C_HAS_DATA_COUNTS_WDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WRCH = "0" *) 
  (* C_HAS_INT_CLK = "0" *) 
  (* C_HAS_MASTER_CE = "0" *) 
  (* C_HAS_MEMINIT_FILE = "0" *) 
  (* C_HAS_OVERFLOW = "0" *) 
  (* C_HAS_PROG_FLAGS_AXIS = "0" *) 
  (* C_HAS_PROG_FLAGS_RACH = "0" *) 
  (* C_HAS_PROG_FLAGS_RDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WACH = "0" *) 
  (* C_HAS_PROG_FLAGS_WDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WRCH = "0" *) 
  (* C_HAS_RD_DATA_COUNT = "0" *) 
  (* C_HAS_RD_RST = "0" *) 
  (* C_HAS_RST = "0" *) 
  (* C_HAS_SLAVE_CE = "0" *) 
  (* C_HAS_SRST = "1" *) 
  (* C_HAS_UNDERFLOW = "0" *) 
  (* C_HAS_VALID = "0" *) 
  (* C_HAS_WR_ACK = "0" *) 
  (* C_HAS_WR_DATA_COUNT = "0" *) 
  (* C_HAS_WR_RST = "0" *) 
  (* C_IMPLEMENTATION_TYPE = "6" *) 
  (* C_IMPLEMENTATION_TYPE_AXIS = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WRCH = "1" *) 
  (* C_INIT_WR_PNTR_VAL = "0" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_MEMORY_TYPE = "4" *) 
  (* C_MIF_FILE_NAME = "BlankString" *) 
  (* C_MSGON_VAL = "1" *) 
  (* C_OPTIMIZATION_MODE = "0" *) 
  (* C_OVERFLOW_LOW = "0" *) 
  (* C_POWER_SAVING_MODE = "0" *) 
  (* C_PRELOAD_LATENCY = "0" *) 
  (* C_PRELOAD_REGS = "1" *) 
  (* C_PRIM_FIFO_TYPE = "2kx9" *) 
  (* C_PRIM_FIFO_TYPE_AXIS = "1kx18" *) 
  (* C_PRIM_FIFO_TYPE_RACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_RDCH = "512x72" *) 
  (* C_PRIM_FIFO_TYPE_WACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WDCH = "512x72" *) 
  (* C_PRIM_FIFO_TYPE_WRCH = "512x36" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL = "6" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_AXIS = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WRCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_NEGATE_VAL = "7" *) 
  (* C_PROG_EMPTY_TYPE = "0" *) 
  (* C_PROG_EMPTY_TYPE_AXIS = "0" *) 
  (* C_PROG_EMPTY_TYPE_RACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_RDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WRCH = "0" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL = "2047" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_AXIS = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WRCH = "1023" *) 
  (* C_PROG_FULL_THRESH_NEGATE_VAL = "2046" *) 
  (* C_PROG_FULL_TYPE = "0" *) 
  (* C_PROG_FULL_TYPE_AXIS = "0" *) 
  (* C_PROG_FULL_TYPE_RACH = "0" *) 
  (* C_PROG_FULL_TYPE_RDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WACH = "0" *) 
  (* C_PROG_FULL_TYPE_WDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WRCH = "0" *) 
  (* C_RACH_TYPE = "0" *) 
  (* C_RDCH_TYPE = "0" *) 
  (* C_RD_DATA_COUNT_WIDTH = "11" *) 
  (* C_RD_DEPTH = "2048" *) 
  (* C_RD_FREQ = "1" *) 
  (* C_RD_PNTR_WIDTH = "11" *) 
  (* C_REG_SLICE_MODE_AXIS = "0" *) 
  (* C_REG_SLICE_MODE_RACH = "0" *) 
  (* C_REG_SLICE_MODE_RDCH = "0" *) 
  (* C_REG_SLICE_MODE_WACH = "0" *) 
  (* C_REG_SLICE_MODE_WDCH = "0" *) 
  (* C_REG_SLICE_MODE_WRCH = "0" *) 
  (* C_SELECT_XPM = "0" *) 
  (* C_SYNCHRONIZER_STAGE = "2" *) 
  (* C_UNDERFLOW_LOW = "0" *) 
  (* C_USE_COMMON_OVERFLOW = "0" *) 
  (* C_USE_COMMON_UNDERFLOW = "0" *) 
  (* C_USE_DEFAULT_SETTINGS = "0" *) 
  (* C_USE_DOUT_RST = "1" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_ECC_AXIS = "0" *) 
  (* C_USE_ECC_RACH = "0" *) 
  (* C_USE_ECC_RDCH = "0" *) 
  (* C_USE_ECC_WACH = "0" *) 
  (* C_USE_ECC_WDCH = "0" *) 
  (* C_USE_ECC_WRCH = "0" *) 
  (* C_USE_EMBEDDED_REG = "1" *) 
  (* C_USE_FIFO16_FLAGS = "0" *) 
  (* C_USE_FWFT_DATA_COUNT = "0" *) 
  (* C_USE_PIPELINE_REG = "0" *) 
  (* C_VALID_LOW = "0" *) 
  (* C_WACH_TYPE = "0" *) 
  (* C_WDCH_TYPE = "0" *) 
  (* C_WRCH_TYPE = "0" *) 
  (* C_WR_ACK_LOW = "0" *) 
  (* C_WR_DATA_COUNT_WIDTH = "11" *) 
  (* C_WR_DEPTH = "2048" *) 
  (* C_WR_DEPTH_AXIS = "1024" *) 
  (* C_WR_DEPTH_RACH = "16" *) 
  (* C_WR_DEPTH_RDCH = "1024" *) 
  (* C_WR_DEPTH_WACH = "16" *) 
  (* C_WR_DEPTH_WDCH = "1024" *) 
  (* C_WR_DEPTH_WRCH = "16" *) 
  (* C_WR_FREQ = "1" *) 
  (* C_WR_PNTR_WIDTH = "11" *) 
  (* C_WR_PNTR_WIDTH_AXIS = "10" *) 
  (* C_WR_PNTR_WIDTH_RACH = "4" *) 
  (* C_WR_PNTR_WIDTH_RDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WACH = "4" *) 
  (* C_WR_PNTR_WIDTH_WDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WRCH = "4" *) 
  (* C_WR_RESPONSE_LATENCY = "1" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_fifo_generator_v13_2_15 U0
       (.almost_empty(NLW_U0_almost_empty_UNCONNECTED),
        .almost_full(NLW_U0_almost_full_UNCONNECTED),
        .axi_ar_data_count(NLW_U0_axi_ar_data_count_UNCONNECTED[4:0]),
        .axi_ar_dbiterr(NLW_U0_axi_ar_dbiterr_UNCONNECTED),
        .axi_ar_injectdbiterr(1'b0),
        .axi_ar_injectsbiterr(1'b0),
        .axi_ar_overflow(NLW_U0_axi_ar_overflow_UNCONNECTED),
        .axi_ar_prog_empty(NLW_U0_axi_ar_prog_empty_UNCONNECTED),
        .axi_ar_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_prog_full(NLW_U0_axi_ar_prog_full_UNCONNECTED),
        .axi_ar_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_rd_data_count(NLW_U0_axi_ar_rd_data_count_UNCONNECTED[4:0]),
        .axi_ar_sbiterr(NLW_U0_axi_ar_sbiterr_UNCONNECTED),
        .axi_ar_underflow(NLW_U0_axi_ar_underflow_UNCONNECTED),
        .axi_ar_wr_data_count(NLW_U0_axi_ar_wr_data_count_UNCONNECTED[4:0]),
        .axi_aw_data_count(NLW_U0_axi_aw_data_count_UNCONNECTED[4:0]),
        .axi_aw_dbiterr(NLW_U0_axi_aw_dbiterr_UNCONNECTED),
        .axi_aw_injectdbiterr(1'b0),
        .axi_aw_injectsbiterr(1'b0),
        .axi_aw_overflow(NLW_U0_axi_aw_overflow_UNCONNECTED),
        .axi_aw_prog_empty(NLW_U0_axi_aw_prog_empty_UNCONNECTED),
        .axi_aw_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_prog_full(NLW_U0_axi_aw_prog_full_UNCONNECTED),
        .axi_aw_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_rd_data_count(NLW_U0_axi_aw_rd_data_count_UNCONNECTED[4:0]),
        .axi_aw_sbiterr(NLW_U0_axi_aw_sbiterr_UNCONNECTED),
        .axi_aw_underflow(NLW_U0_axi_aw_underflow_UNCONNECTED),
        .axi_aw_wr_data_count(NLW_U0_axi_aw_wr_data_count_UNCONNECTED[4:0]),
        .axi_b_data_count(NLW_U0_axi_b_data_count_UNCONNECTED[4:0]),
        .axi_b_dbiterr(NLW_U0_axi_b_dbiterr_UNCONNECTED),
        .axi_b_injectdbiterr(1'b0),
        .axi_b_injectsbiterr(1'b0),
        .axi_b_overflow(NLW_U0_axi_b_overflow_UNCONNECTED),
        .axi_b_prog_empty(NLW_U0_axi_b_prog_empty_UNCONNECTED),
        .axi_b_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_prog_full(NLW_U0_axi_b_prog_full_UNCONNECTED),
        .axi_b_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_rd_data_count(NLW_U0_axi_b_rd_data_count_UNCONNECTED[4:0]),
        .axi_b_sbiterr(NLW_U0_axi_b_sbiterr_UNCONNECTED),
        .axi_b_underflow(NLW_U0_axi_b_underflow_UNCONNECTED),
        .axi_b_wr_data_count(NLW_U0_axi_b_wr_data_count_UNCONNECTED[4:0]),
        .axi_r_data_count(NLW_U0_axi_r_data_count_UNCONNECTED[10:0]),
        .axi_r_dbiterr(NLW_U0_axi_r_dbiterr_UNCONNECTED),
        .axi_r_injectdbiterr(1'b0),
        .axi_r_injectsbiterr(1'b0),
        .axi_r_overflow(NLW_U0_axi_r_overflow_UNCONNECTED),
        .axi_r_prog_empty(NLW_U0_axi_r_prog_empty_UNCONNECTED),
        .axi_r_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_prog_full(NLW_U0_axi_r_prog_full_UNCONNECTED),
        .axi_r_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_rd_data_count(NLW_U0_axi_r_rd_data_count_UNCONNECTED[10:0]),
        .axi_r_sbiterr(NLW_U0_axi_r_sbiterr_UNCONNECTED),
        .axi_r_underflow(NLW_U0_axi_r_underflow_UNCONNECTED),
        .axi_r_wr_data_count(NLW_U0_axi_r_wr_data_count_UNCONNECTED[10:0]),
        .axi_w_data_count(NLW_U0_axi_w_data_count_UNCONNECTED[10:0]),
        .axi_w_dbiterr(NLW_U0_axi_w_dbiterr_UNCONNECTED),
        .axi_w_injectdbiterr(1'b0),
        .axi_w_injectsbiterr(1'b0),
        .axi_w_overflow(NLW_U0_axi_w_overflow_UNCONNECTED),
        .axi_w_prog_empty(NLW_U0_axi_w_prog_empty_UNCONNECTED),
        .axi_w_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_prog_full(NLW_U0_axi_w_prog_full_UNCONNECTED),
        .axi_w_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_rd_data_count(NLW_U0_axi_w_rd_data_count_UNCONNECTED[10:0]),
        .axi_w_sbiterr(NLW_U0_axi_w_sbiterr_UNCONNECTED),
        .axi_w_underflow(NLW_U0_axi_w_underflow_UNCONNECTED),
        .axi_w_wr_data_count(NLW_U0_axi_w_wr_data_count_UNCONNECTED[10:0]),
        .axis_data_count(NLW_U0_axis_data_count_UNCONNECTED[10:0]),
        .axis_dbiterr(NLW_U0_axis_dbiterr_UNCONNECTED),
        .axis_injectdbiterr(1'b0),
        .axis_injectsbiterr(1'b0),
        .axis_overflow(NLW_U0_axis_overflow_UNCONNECTED),
        .axis_prog_empty(NLW_U0_axis_prog_empty_UNCONNECTED),
        .axis_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_prog_full(NLW_U0_axis_prog_full_UNCONNECTED),
        .axis_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_rd_data_count(NLW_U0_axis_rd_data_count_UNCONNECTED[10:0]),
        .axis_sbiterr(NLW_U0_axis_sbiterr_UNCONNECTED),
        .axis_underflow(NLW_U0_axis_underflow_UNCONNECTED),
        .axis_wr_data_count(NLW_U0_axis_wr_data_count_UNCONNECTED[10:0]),
        .backup(1'b0),
        .backup_marker(1'b0),
        .clk(1'b0),
        .data_count(NLW_U0_data_count_UNCONNECTED[10:0]),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .din(din),
        .dout(dout),
        .empty(empty),
        .full(full),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .int_clk(1'b0),
        .m_aclk(1'b0),
        .m_aclk_en(1'b0),
        .m_axi_araddr(NLW_U0_m_axi_araddr_UNCONNECTED[31:0]),
        .m_axi_arburst(NLW_U0_m_axi_arburst_UNCONNECTED[1:0]),
        .m_axi_arcache(NLW_U0_m_axi_arcache_UNCONNECTED[3:0]),
        .m_axi_arid(NLW_U0_m_axi_arid_UNCONNECTED[0]),
        .m_axi_arlen(NLW_U0_m_axi_arlen_UNCONNECTED[7:0]),
        .m_axi_arlock(NLW_U0_m_axi_arlock_UNCONNECTED[0]),
        .m_axi_arprot(NLW_U0_m_axi_arprot_UNCONNECTED[2:0]),
        .m_axi_arqos(NLW_U0_m_axi_arqos_UNCONNECTED[3:0]),
        .m_axi_arready(1'b0),
        .m_axi_arregion(NLW_U0_m_axi_arregion_UNCONNECTED[3:0]),
        .m_axi_arsize(NLW_U0_m_axi_arsize_UNCONNECTED[2:0]),
        .m_axi_aruser(NLW_U0_m_axi_aruser_UNCONNECTED[0]),
        .m_axi_arvalid(NLW_U0_m_axi_arvalid_UNCONNECTED),
        .m_axi_awaddr(NLW_U0_m_axi_awaddr_UNCONNECTED[31:0]),
        .m_axi_awburst(NLW_U0_m_axi_awburst_UNCONNECTED[1:0]),
        .m_axi_awcache(NLW_U0_m_axi_awcache_UNCONNECTED[3:0]),
        .m_axi_awid(NLW_U0_m_axi_awid_UNCONNECTED[0]),
        .m_axi_awlen(NLW_U0_m_axi_awlen_UNCONNECTED[7:0]),
        .m_axi_awlock(NLW_U0_m_axi_awlock_UNCONNECTED[0]),
        .m_axi_awprot(NLW_U0_m_axi_awprot_UNCONNECTED[2:0]),
        .m_axi_awqos(NLW_U0_m_axi_awqos_UNCONNECTED[3:0]),
        .m_axi_awready(1'b0),
        .m_axi_awregion(NLW_U0_m_axi_awregion_UNCONNECTED[3:0]),
        .m_axi_awsize(NLW_U0_m_axi_awsize_UNCONNECTED[2:0]),
        .m_axi_awuser(NLW_U0_m_axi_awuser_UNCONNECTED[0]),
        .m_axi_awvalid(NLW_U0_m_axi_awvalid_UNCONNECTED),
        .m_axi_bid(1'b0),
        .m_axi_bready(NLW_U0_m_axi_bready_UNCONNECTED),
        .m_axi_bresp({1'b0,1'b0}),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(1'b0),
        .m_axi_rdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .m_axi_rid(1'b0),
        .m_axi_rlast(1'b0),
        .m_axi_rready(NLW_U0_m_axi_rready_UNCONNECTED),
        .m_axi_rresp({1'b0,1'b0}),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(1'b0),
        .m_axi_wdata(NLW_U0_m_axi_wdata_UNCONNECTED[63:0]),
        .m_axi_wid(NLW_U0_m_axi_wid_UNCONNECTED[0]),
        .m_axi_wlast(NLW_U0_m_axi_wlast_UNCONNECTED),
        .m_axi_wready(1'b0),
        .m_axi_wstrb(NLW_U0_m_axi_wstrb_UNCONNECTED[7:0]),
        .m_axi_wuser(NLW_U0_m_axi_wuser_UNCONNECTED[0]),
        .m_axi_wvalid(NLW_U0_m_axi_wvalid_UNCONNECTED),
        .m_axis_tdata(NLW_U0_m_axis_tdata_UNCONNECTED[7:0]),
        .m_axis_tdest(NLW_U0_m_axis_tdest_UNCONNECTED[0]),
        .m_axis_tid(NLW_U0_m_axis_tid_UNCONNECTED[0]),
        .m_axis_tkeep(NLW_U0_m_axis_tkeep_UNCONNECTED[0]),
        .m_axis_tlast(NLW_U0_m_axis_tlast_UNCONNECTED),
        .m_axis_tready(1'b0),
        .m_axis_tstrb(NLW_U0_m_axis_tstrb_UNCONNECTED[0]),
        .m_axis_tuser(NLW_U0_m_axis_tuser_UNCONNECTED[3:0]),
        .m_axis_tvalid(NLW_U0_m_axis_tvalid_UNCONNECTED),
        .overflow(NLW_U0_overflow_UNCONNECTED),
        .prog_empty(NLW_U0_prog_empty_UNCONNECTED),
        .prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full(NLW_U0_prog_full_UNCONNECTED),
        .prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .rd_clk(rd_clk),
        .rd_data_count(NLW_U0_rd_data_count_UNCONNECTED[10:0]),
        .rd_en(rd_en),
        .rd_rst(1'b0),
        .rd_rst_busy(rd_rst_busy),
        .rst(1'b0),
        .s_aclk(1'b0),
        .s_aclk_en(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arid(1'b0),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlock(1'b0),
        .s_axi_arprot({1'b0,1'b0,1'b0}),
        .s_axi_arqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awid(1'b0),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlock(1'b0),
        .s_axi_awprot({1'b0,1'b0,1'b0}),
        .s_axi_awqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_buser(NLW_U0_s_axi_buser_UNCONNECTED[0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[63:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_ruser(NLW_U0_s_axi_ruser_UNCONNECTED[0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wid(1'b0),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(1'b0),
        .s_axis_tdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tdest(1'b0),
        .s_axis_tid(1'b0),
        .s_axis_tkeep(1'b0),
        .s_axis_tlast(1'b0),
        .s_axis_tready(NLW_U0_s_axis_tready_UNCONNECTED),
        .s_axis_tstrb(1'b0),
        .s_axis_tuser({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .sleep(1'b0),
        .srst(srst),
        .underflow(NLW_U0_underflow_UNCONNECTED),
        .valid(NLW_U0_valid_UNCONNECTED),
        .wr_ack(NLW_U0_wr_ack_UNCONNECTED),
        .wr_clk(wr_clk),
        .wr_data_count(NLW_U0_wr_data_count_UNCONNECTED[10:0]),
        .wr_en(wr_en),
        .wr_rst(1'b0),
        .wr_rst_busy(wr_rst_busy));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2026.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
dGu72XHm1SGA216zirXmRscTLLxxgDIFDG1CSj42adYdijKpZDYj+ILu+mshlOULAXrM6Gzh8sqR
gjkpzk2bTqBXI1oAKib61FH9j0h/c2Kk67bAnIohh6OhVjTdkvwLBltIS6uYCO+SVX+x/uca8x0J
hS271jg9N+9k3174JEE=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
jAgKubpee5TGRufSmwz5IdjfscFwjHc1yqlNg9LUyu5pHMpAQHQaMiQmkQjbj5fYZ5w4EdWylgqy
S3eglb573KQ/3EuMsXaSoYyZWrRaVw28x01p51Wu/eTaa1WdSHgP+yW/req9kXycB+UV1GAU5xdt
108WyFRDRm+c4TRFyYjhPe05qVBC7KYZ6CfomQYV4kev3Dk1ozrvXQFjJjLO9Z2jVTtpT6u7zYIg
PXli6RBthoO6IIpAZPN70vnTGgKEUaIykrsMwErjQiqQqXX0SjLimfTf8oVNXCYIMkkpPo44A8vb
xbUQE2IuuVT5OUOh2iJYNm9np3/RCXO44y1TWg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
ofHJWAAWazm87fhFR2lyQWX4juOLKeKf8hjQHNAv5zwbbXR5g4D/wjJgDTFFbkeRy4XuOyS8Cpev
BFfyCoZybCYHLvUxNlHNlsvvU9Ux7dyWWSpM4N479ZnquC78QmbRrkLsx9oWSlf6Vdwauphn75+U
GIjP2sYPUOJWr3u3J4I=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Jsw64pxYqcqVAmPKqIusKkdRQB4PFvfnT0Euam7IyIPJxaaaeu9ieYblbNy+y2oJ07eQr4LN1EIu
evo6gymuqY/LQFZ9Nb1yy63anHFP1AEw0+0zjJv22W/RxcWecu/xxe53akubf8kmiCLLjcOEbvhr
WUPY/11WLHxq1gnwIp5yO4Xk2Q1vu8wH21rHC91wgHd0IsIOy7bzkDE0bpAI/4NU5SVOxDqxzLuA
KsAt5tHuDweZmpJ/rWTH2oRh2z7rXtQxcuMko4ci6I8glBCI7XAugBbCH2BB2zp6UWIfGI1rQ0vX
zETq+wfrAzdwZTdu5INoadPCTe6lslTS9UAkiQ==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
awF0UjMZcCSeDeqx7MRqHHTRr4vMwGmArBKeAVuvTLkLc97chMMEhaT5MZwPl0YnpWSzzmOAxmsv
CxzAjhssr1Y+4/PTt6QKEs9tBg8Za0PJuk6EhTTsq17Dl9znTn4YpZeqiwTqZAhmCiDSybWzoAtb
3xy/LiFqf56ZS0fLgU8rXGpM1J6fl3qCrR0nNMU524RVnMx17AIqO74WrcpwHtkNqiBWMBNAGSCt
sPBAlRHAaRn4xKXgRP8hiLg47GBEBgpljP46iiQLhsJu8SDRRW9E0u6G0xJWTgT++sW7EWtcWj4T
o1p7FJBZmE2TXA2tDydEDhuak3qEsUx9bo+E4g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
O6g4Bct3AvdCEa0UcYgIOeIRMvgI7hOrs54EFTgH0vBQpYdL128QBUfbklS1zJAurm5FZvD6LFF1
bdla9ZI2NlvhgskosJM9NpVVArV/DbVEncgt9XJhTT3OqhZdRSZrQRcpywftfeQFXwVMkVwdq5NH
4ShbQTTHmWGAuSbkoUYHbQawmaGs799oLqORxYgpCkG4CHB8Hw1r/keC13gnVnk1GH4d4HQiqxjb
rqO+v6SAaJf8Fyr6Bop1rVRzROp+qDFcisFY9l1FUGn/aJIDM9QOpWhcDrG4aG1YDWfDVDEX+TTz
Egv4jzRuNPMVczkJqpL587RxQKzEBYhElPzp2A==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
V68jRgp2Idh8t2VkW45MCRphFQ4jl6V0WK7N7hXGZhaQFsp25eBN22YnMQHi/vKVgKzINwWdgrbw
TauibdyLbetzAsQFObTjoyqh77h2kCz2iv0ei2wyYTiiUwCB9NABDyUR+ztAv+B+jYyE/uZaSidM
n/zZBomwvV5Zd0hry9RDCuuZKqSl+zwT9NcA20nIzIcNX8IPpFvcXz5N3G6K9gZWbKhMty4t5tkb
GBYbL0QT0p0BNfTZXNQw1Gt4cBSz/qYNJ2Xu/YZ+V2jdOpiw7Pe0tUloRyD525dQkGM7uD4AAZ1b
83tc9Q2pUphUI37u8ekjug7Q9kOBAFz6rVkB8A==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
t9b4xEQcRDnFfZmWCQLVBO9PewphBWYN6oXD50CF2LVB4GR3tWt62L4X4xNQ6zNZSLMMtF/1Dh2w
W0jzUUEQCgZnr8kGvxNE+R52CG8D73dLyWEBezD68MtX/dd2ezB4nrfnFg4evJFJ/9F48pjyEA5o
eutM007fUI8YWnW7TIkzHPZ+9JtUvDd/2tTgIAgq6oOZGT5Cs4I1Uqb6oab8wRyxwdFK7oZVP4xV
gqt/GKZMUQAjWtA43uf3aYkOx9nhDEXiBItzPa4LAkZpGjc0gGyQyVShxg8zUzSWEJR8L1o6vMAX
rarDYDTIk5yY/eQmh1c6TA6ZqJ7UQXMXRTDTiG4h+s9gSb44wCGbqkOmCyA4gu7UDkCBNho4JM3t
0Zerk+UAsp5sh3thdVCr0AS6WQ54pj8UaXpk+1u9lqn4QRys33f5FjD7RC9cc3mEAyDHoyCaWGWl
/2yFk0+ulX3d0Xi32n8Qs1csusgVZIk/BKb159i8IWltRgQU/7GAAqC/

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
J/ylEIABu6C1a0vR6D5fz4s6QhyJCRQqJ3LfWb4Xkc5EUgf6DELxPobcA0U6M+Mkko3Sy4sKsU4f
yQIugHb+jIYdRO+T1fSw8guFqlHtlNiwUQdGSIw1rcuy/R07qTzZF3GumIKCyk+TrvEOcVqC9+fH
as71DAS12EFnukvZoNtoXSI5nZq5LVBPHf8wUzZxpI321LyJQLaFU4JJFGwcavsd++9tmra91sVN
BwDwv3mgQfT0TqE/TdCX9Zwy7zK/jW3EaOfoo5325gcSUR1jjSYwnWmM6Jy9vziqWHwvsjDhQJxl
aeqehWJ2yNrgq3TDVRpUY+M9W8QBiAjkbkTwQw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
G+y9CtLjIQklJRHMRkGTB36EEOykn/z2Rb9FX8IZujxNAMVZjI0+MC2HSZwAzMJiZ/ogIA+Axwli
VkLXpi0D85gmlZ9R4Uy4Qg2cJQqn3X8ZPVEGOrirWAFPV6I6DLgiuDyblEbGT+jAegiYgxOdmYzO
rda5v0cSXpnfMFyHbUQxbket+AHbf/bIePv+J96W35zJ2j98Mzc2hLPliTDmteSe1nP4cpQnxk2V
5/tAfDdod46lN2rH/hTPA7Fa/IZpncNG27QQHpYAt+spI8YH8R25wbEreqhuV+kam8wXF7r+vUlN
kqz9GkMcA10m1F457xYENfO6RxR/Eacf9s6IZA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
CZYvRQs1e7cle29/SJCfOGN0qoef3T91yEF+XdigtvC+8ndM7QsKiobbpPCboNixCdknEuxrAzJg
3RzWEAjWaGsM966jIWJ6g/DOod9MXgQov1slH5VvCGn6SQTEkJ7xBjAcuMaMFZ4QkFKWi16EHhSY
w+iKhH3jCMHq2+05eyvFVte/6liuwhLASVXCYyqpUZX/pGwIRDAjIMn7I9hPW6J8cvUKM1CjeFve
nsG9Jf1JsFmkLaJZA8EWwb+hO9gFGNUf8KY89/0kDAANM0sDW3D/jI7AdnZ2SOEyw8ZnLR7bvuxk
GnvM0uSdkOq6ub/Db/5ToWmsDfvbMVwx2qyjzw==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 51424)
`pragma protect data_block
VJ6y4heLu2K/yCTC79qGK3R18UglCSme42KcTyQIWRL2p/4KX/peioaoJdWGl2E7hu+SCamkmpyg
Rjuuo0eIY2GaDO98MisQsoGu/F2zkjSXpeodaFj+UDgQUewzOVfFHjLuLWFqN4VfhrksYjI6iLSA
QMjivrdP5NRsD1YWbYphRRbk683fzH6ib0woaqCjcJurjBnBg7taDTBKAtllxvOLcVsu0pduhtcM
R0P+i36I3ef2vvIM9BLDDqPyoQikxwJCpA04IDwHuUtTXgAVtEdQbQFGbmFfeG6ZPfTh5lBlBK+Q
jffOABPeqsAH2eXdvdSEyWIq6hN1KmKM6dNDPiz3lckW0o1d6VFJrKBeuzZeVoUxq1DqJx7Z3Cdw
4aJg0uHb0FHZcRZS4Rg1UoT7aBa4oZSkNdh7PyY8OgIkpI0UyozRHQ4YPMV7uD8T6E3Sjvd83/KD
Us0zKdEx3EXfgvDNLKldMdK4pEk7trkmi+H9J6UwjW742EICrXfDz5qtzs5kkDfDDEpm4eTm3/hF
8OTBX42nI0PYtkwOYvoTCUiJQo7D4Wjl08qGQJeZ3musFBLh6jZ0eqBpVZUqLn76PaqLL7VdX7LX
Q6aUonY5BsZ9qVihFe/0LUpb1Bbjjv/+VffCMpr9LzXSRfgZD8JjAjJ0SXZrjrrQjvxfxCEg9BSZ
7nH7rVQiEogAhOK7UogdPg4py4pmNhuYLuGOLz6z0JnlPiuw3l7BCqOjA5GiEah4JGdYNsH9BWR0
+i9q0Tpd5jXbc/rD+aix94rTdFhEEOSyG39JkvihqPnGK38E/g5TtzdG/Eb8fshKLlyYePGRKGdw
GPmUeVHlgVpo61qJsrUFSaGm+25p5Jv2sPB1O37e9SDdVno8VUWV6It97VbU+QloXcytDEvek9jA
PWH4FcZJNm66kI5zrCSnihyfSrzs/6Myb3I7FwbllOHnNAEp2FidWpJQoC0TSWezKCMnBry7CDdo
30vacyEo7NSQUzFme/GeS02uAyE0uoavv7NkLSVtL6yeAr1+ctLUyuJkF0e4xqx51QYCFjGKXMt5
YHn6hsC4ZI0PMuKCYQSh6JB4fito2wd6zro1s1nWplZtOv/M/I3cQzvp3f7W8iZZPcPfi2i3Q1R0
kSQTf/ZBj+LQ+I5g9LVYtfWn0/MNSB3TlpSVb7SEjnGKCRJcdm15tIU6XbzlCLi3ZNzftDt5IaOp
SBx9sbWk8rFhWXlghHHYCNeQkgX2aXca+uHaqcC/TNiV1jdFVAt76kd5XMbdEEyflIF8k4chDQzH
5XoR3SURbVbAYGqTxxW1cwqQOxEEIjBuCE9YXTTMkg9GHjoQOSIn6VtZkJplSkDOw/0vrl0gg+KB
78VuFroSlA0rOIQH1fvfKKmgZjsd5Qgj7/+cTSY9727rY02Z2YwYE4yu2W4vFUbPC/+3ef2hiBNz
tP9a6AQHuhz5HkoYb28/1gLZTjTJMal49NnQNeLw0Ti2lnTZXOcQwOO/xX8XvPbmYlJmNsWyqLt5
wyV8YGEzHd5IW3T8ip7aY+aDV3RSEgLGD9/Dzyvt7fFHsnBHWboETbQ/Ih9Np7EUH9SIt4FvnqM6
SpilyHBQhXkxdbRWo3pRyjI+Gcg/8qU6zIL077KzluY3xBOHEjPEtkY10e7w/xPq3M3shD34MkCD
iyrbZn/RpSPQmYh41Zmi5HIymH63uBB1r9Ftep901kmsMR3iQGv1XajyWOUQD2acoYcAzESLtBE9
Iw9EAqunb4bBhbkNRAM4P+XpPMxKB40E4sSPD+SCczk+OhVQZ79pgMj6o+BLuNI5Y34ysFGEyhk8
fG7UIZ8qhoZds+bNgegDWVoVU+gfvgwZXhac1CFrJ6OcnSiyK3yzK0isu738HXpvgWbKFEzWHmWT
p//6MG5aTYUuZSjONZQRfn9ezOBKlVkYcjCJxpsbPYyEpL5V9RKNT6VbHFgb2rV8midK2R7Um/0v
TbqfpYJUzhhyO5lGmXtpzmajiJT2VRS++9vcQBaoeIlRNDw96H/mmstkBeFFdEYrgTU27asLxFwH
06/1voMLKDO7/GuxpYpG5LclTmdVxtCr0kygmwHfAANAj19ozUSf/Fe1ERb7xlwa7JkqeEATJBz7
O2Sm6Y56jRXXKri7HOETLwXe122htj70zGOAiw5Njslei1GHPnxo/tZt6bEoACwVrYnIq6d8gfB7
4L89tNV3vZQPRhg5jiVDDXzVO8LQsEXTpWdVgwNhW+1mgwgj9x2ekDkOKHDizSoKyQjnhkmtVm9Y
X+oDPcCjrr/4h5rBpf7vynynkaNWMrsOh86dk6kGgH6aSn5HLRspp2jOxiqdpxio7rkBeME5nfc1
XR4OQxvwhHv5yw5MKg6o+yXDyiKXFiTAclIYDmhpVNYEVj0bNUFWD5tqDseIJKEURiTUpqEkKw7j
0v8ekp5OmZPE9aFEFOzDQ6wpZDQvp5d24wWczChVOakZUSO1XKoprbjTZfoxwoLKnEXVhEK50eCr
WDQOzNKG4HouthnSZ8wzgxKmyTmp+BwiN8bY1mBjbaVv6qEARsMn6E9MGr+2ltWzPuMQLYoBUYEc
2XjqvgiWX1Ns2seuliPv6SugqxlsgmWgBHtgUo8FyItJTza0CFnT3vMNsNSbjFvpMygNJUVPeBQm
Iz2LgsH7xLBCi0pP0X6rFOokqcb5Bw0UqmuJ+ilq4UWTx+Asf9uj1LdeSJHC/AxxsrZ1CWUehSR/
quhpZ/CGNpSSuKJbek+PZdnUn/syDuT8FK1faBR69E4S57PlUWPBX/YSMZyMu9veBA0LEnvQS3mI
KcPsy+rlDyTDvknaCFGryoZcci1BwN8CHb0r1ebDoAHG6+E9y7MXeuqryLtgct+IJKapjlrzSYrR
JiLPXWph98ozNxIqJeQp+SUtAcTIL0iX+fO0JF1H+j1ag2nDxWiwKFeX37jqAfqGHlC9OVPcXOx4
DSGecbw+cEH2PR7lpv//FyBDA3y/0g2cf0iL1ttyR1HR5joQSrEjP/nHnQVNXW7zteg7Ig8WUSih
EuIUN+kYJU9xFMtHXxOk/pep51EL6I6IXJkntEt4dD1QPTce6w/5D01crV2zr3w1sYNOcY9DTw2y
vRsmi4G2n/7wJJRQs9LXh5kwvWbhc0/tHzCxlG2u9itbmUOol4kCkotwfi4GzDAjWitYXwM8QFjv
ldJ9lDwgzABQ7q/ohAABmoiostAyDM63LJbCsLTJg2hriQ8pE8ZHG/iy1TBfPlxu5SSYIhor7Uba
09WUituHu4uoYvcxvknPk6p01MmvgJim+lxfCQaakGoIioGTktQBlvL6ZrdmvXrBrv2WuTNhcQH0
8oU2HD3AyZb5ux/4T8fEbnQlMwjZK/mcJbvz7sDgotk2vUJQRM04SdompQ3USV0qfu7nado9y/9X
YtDojJGG3eyjRiictIWqIglkmHQl54IMAIwNqGqZjk6f1FshbCmF/A37QzS23f/PSKWtqsSOjaFE
bf5zbjBAp4gfpd4cTgFVjhJUj6jadf0Qh08/CW8rTOY06k7YEOYHvODMbBrEtihReRyVfOPbnPD+
EKJrmM57xxwz3Lo9cajd9aNy6MjjK7xG2nO3ZId6X4Dk9yiC/QS5tn32lAtc0EddZ77NAvPxSKPS
K0xJn1ZxCKplOvvIGTtmcEBhThtdfK3j9sSBD2QGpIXDeGRFYbtT55jeKyHtzoJ0ASKHTWNUEyXw
+rKoEzIXQ6gdKdqKvd2LRjn7GrR/4ppjLKSc4o2hk9IfIUd9OiiZTlsRRQ1ialRXRdCKf73CHWa+
J/FAl9veJJdIa/kYkyn2cLmCfJYgB5CYZhnU9PnrlyzGUdK80AHYV54DTqGzapyy8VvGROEFCkZe
EYDLE2JbPNnKDgh2w3nE2PWbdCOBlo0P6RF2WRSy2lduuihdTpP2Nw5E5uZGX4afVLCuYm8Yy1j5
MntAYeYdthNc8sANgOs+ssUmLFN43SGPUPvcGPFEBnvjJSmTqxoQ/3LDAqWswLJteH4f0nxP00S6
gmb0O3CDqQeFsZ+aGZqKzD8hK6ZwhCzRwgJlUcnXq3hHtC43MIRVm8gokkfVAo5h4LXwQ4r5o9Lt
HWKtat0LWKiB75SVR+Bid4d3QxZEVRc98V/tLq6pMyuX7m6OUQGCtQ18EPXH4n68yJBjpw8OFW3x
owKB9PU/hPUOQfm3zbLMxtYbs9WKWY50C2wosR3YCqVBTTM8hqy3eopbdxJg6+A0Bk11WKvM1pI4
U03npP6Q0zoHAKX7B1m4Ljw6syHi0OLixLVu1SGH52yzS1VKNYlSgJEn15GPhn269GpIt8JbFX18
fQaiGPfXyDthpbbC9B6QRuxlQ4/5eJaQf9i/BVjSKr0hTXIPAn5OfsERUiq5Vg1qs5uC4+9YJAuZ
1NikpJxT9uLPg46jyh7XLmFG91kWyR2PlUU/HhWnre28gEzFI3FFmOK8ncA03I3O0iDlwlqX2LDx
xkKNvfeoIOhCGrZdCUOMyJc1ljAwu29YB+p/AjvAzXKPdytRRUiGy14BP3aFnIwdjKL4JZ5Jv4Qv
4P5t+myT+E5UXTaIzm5kXWCXKh7ZYJECbZcnCIuwhXWvoPLtXaK3Bm1Bu0C48It3YCfuo9oVLyCW
zXVyYRFOcASWqFocgVtodGDnRTP0OsOshIAdpWHu/mB/UAzqPbdN2AvDGorQD9MwVsRAEszPwHDU
FJ5NHPxKgR0qbWa0ZObqPa/hDZxUroJzsrYPz6dEfMh4koOzd5+4tXM++HhvmY4CjzLpnhkH1Q6K
7medSpfIMhg5VNlfbDrt1iJS/R1Obdk4o9+kgYqELC81zJ3wthOH5HsTUSJQ9oMl3ajxPXBP6jKT
xRvVx3XqAHVdGkqHxULJAbrwvtrutb0X9d5U3FI17sLw6CICbwB20xUgnzvhFfADuV8SGLUaq5HN
sJeOXVnJsQCRkvqpqaFDMWUsagbboGezU+3WdJ5ysWIQG6kma3rZehywNmnBzKrbgYuoRiiFR5It
hFQDoIBOdw6CjbYSsCHoDo6C9Id2ibWwYn64WFWmFeG9M2xnj4NW67m4DDMZobddgUaOI2R5sX3+
R03a5+fGhKpsl6BZc0m8HMM5+782TA3M20Hp2Bhq/vcwXZpM/nGnZm01mTXTdcoR72FsWXGAhdht
AyDxMmcY/eogC6RdbK8+IiBlMsFO1pLV7sCbKzPrM/qIiTgCdwebxJ/tfYENBVS4SlHX+61vKrvY
k3absYzS790j9EuwPCjjPjCUpzTBpuhMKwA3P0ijFQ61P2ugo4DLHtCzkuH/mEA/+36k232ap7R7
pZnRUA0OxFs8J58YcKqwLa3fj9bMv4rmvVuwNYOGRndDcdVx4ZDAkBRjTow2wISvHJFdq9vhKldM
gAtow5StvvSfb5U3ATrTKQPjbKCzLTExXb1OkWz8/bsan9gUP6AN+5DKODLeu+98uLWeVHrbnnQO
tKTtjFBqsDeRx3QWVNZMVs0A2jYXU/D65athBFbjJAW3Zjq8EyQcO9DeY+rlXkqXZOMzS1A/OQJ1
5KdzI2Bqwu9WOwQweTuNMDRqxwBgNIAsFEts+wnAc722KAlKg1ihSeV5OT48siHieTxisCevDMsk
jnVeNLzfYyKicV2FFZNaaVIbWatvbQowsfkIxEp6sYZ26QISX7gEt5Gf4BHvNfIzWPybhGkK6y4n
oARfjh5IO5Zk53j2WMP+xMFGNlpdkK794RL/Bd+BAn7PHIawcLeqoH6qn/zBzvNuPyl9LjGdtI8m
YXJrWR4dtZsxxONKK8m9but3ys1jR+kujLvhGRH5fN62B+1dgSMlFTqC6rdtEOsO90HpVslY3GNU
pcmB3uYcYy5MM5keNXIIRZ1RR7oDjtUGUecc9ILuJKVJ8V2H1ju48DGAH4T6XFvW2KvL65paO5mp
9mLkGmypKDOShILSjTJ/PQH/glpDyj/ow5uCCQRginexVBv7upgNB00/hBSbkTjgUObdP1fSq9Dx
mtj2UfZ/m4pPiEmjLP2E6oUigg5mt1CP2L7ytCtHnMrBYN8iTRm7v2p9CV6VDcusGBMdzOjhveI5
qpwFAIL0lj/w26roufypazq9toVWKuNz4BsnhV06uZ1QYCYfd+hR/0BhS1ye+uR5XmPJtFi9pL62
OPRq8Pn+6bcbgXy7BBsEsVC5kzbAvIFDfoAi9OmXaYuAd3pxxr0VwealUBn7WsKwLxoEmxRkAmwB
dYgphtlC6OA/wP0zw46PFHjqggMPrnoIfvwXzavtoFotqvjykxXSnhv/zhN3ZqAJ8w1L2P4BqfMn
jA8MAXUfIyfcypgwngn+0n2zaAX/yIIc9aXbSG4dmnELIM4FZ5dJhKJ/8rLryecnOH7nCXxKHD+1
nTfiiVWll99sGLx0xt0sb2/8imuPh00Ph1qkEXDbNJm4/Nf4QtIOMlXqAnSHBIqIR5D1DwRQ2MHV
V4WF8TsFRL3PxGnCTdIoWX8sQpuXeFN3qMfniyjjfBNq138yHqoDAzzWDi8Eu6Xl7vz6fQjTA0R5
UB/eq4iQGZOol0o6bAGlC1lWHoYcgcG3mB/R3uDSOi8p7vtBD73HdjORpI89PqLSMpcIOZ0GBwAU
uszT1hf3Bb0XRwHy0AIWPHl/RAyfs/0D7TsWpIiT6z1wZyrgA5bgyPeD6RXMAoTBcyVoNSsgjG/3
lT/+0LsUOuWRkXmC7oTmpZ5ccJbG3ZvhcsBrRahYTKMjGE7YPOPKYsPMTAg5Fjs+7GqL8KODE0Kw
Bom8uWry4B7rSci1S2PbNjy6CoivIKAeC1g66uZIeu95jJfhzOJdkCGXo/FJ2bYYESu9dbCMqGIH
Ax1mhefrnnif+pJpIe/o4Whuw6nDCqYa+6ZeJUkkDfJoD+Lf8TZKdQ9+0uwgGpZiTc26JOkmMCGZ
3TVM/Tn536qHEKAZG4p6HQ/LrIf4NSfLfzEG8n9Y4LCwsvbQEMkYVXbKg4qe+v/fljbSdWXXwanQ
BulzKKBJBvMSWbRUxaPt+Z0Q+7TpjwX5O4mQ38FjXtBZB1DnUMJnTjWILQEOmC5GS+J4sgWydd4z
NkJ38TUFQe0PEt4sE4ilOToUt4KXLVFG8YJTzpJrpvlaFXT1xu6qNuu9lHsHQm7W/lu+NUM5C+MZ
SR7W24+f3/ZDuEHCVaNX9aZZKsOJulA+06IORzrMljeKodiOOe5ZhQ7eh1cRfcXc4dhD59215MXX
aJZBSTXa0/+9Y+utEmG884zYlEpW9m4mgoNLpMP3X1laaq/MxYpJUdgjIPskSwVWBkpTEk9EkQv4
eIiHAMnm3ndgMb6UB4DbWbq1nVRMNkdGRD6YUTBEgMhuMXrYbn8XCTC1Z7SuSxseYHMrSYyu583s
k6Z3LfNZSfx+OqZ/bwtmRx4B92DL1F+iyT5R8PjA9zXg7U6gSSrmH/0AUfAWrefzVukN0KKVuR5t
2SPjgZADSc38PUL29skFh/uHr+rSgBC5Cll/Vi28IJu3ClW/2IEJ9TRxHxy8bvJOZsl70573DNuC
SXTgtuK8qZ6qPioCF2uPTfkls4/POQmCJDgO2Te7+vEhYgCxcjJBt7GsKYIY/GiSOIDvUMFBJMmP
4wCR6s1BKgKNSnM5kZ0t8834M9HFfYVWbuQNXv2mIT/7Ll9F4/xT5THAwCSrN+7b8QP++gA8l6w8
9C3fN4LJtyLQhggSNwa4Snkt+31bGisCD2ttZgLkDCLdR1Qltr2LPoN3ewgIEz00sduGf1z0xjfj
NIXr940FEoBXH7Y8z7Y3Vnq/RBNuWqpf+bg0yIy+HYnET8GviKIRhlYkNHywgvkCGUF9G73h+x3m
I6+LAtaqC2J7im9AcLJC01u5plYEnG1waVBMVylFler8f2ae/9Sdeb7gyiyNAktZ8B2z8CqhbU49
60TY5UA6NZwr3N95XdYdiQlXbCusebxDO7bihEeoZ4ml9SgAZZE0/s4X6iis8dv/w7qbsjDpR9ZM
I3MLzG8EbslPfYEnBlg0rGn0Fk8G0auMlhsR/BODDm6sD8pzdhOTBXSmXNyroKcXzrLbjKdoFVVz
qKasHLh1SooFnMGA4Txk+d2obi0ndYvd4zDeg0kNZ8UhwBPitNP1xSadV7gKjCP9ihsX03+FnbJU
I12eZ4DeGrZRxWUdIlH9qb5H7PBt1dIBkKQLFqABlp5xX39c1iUzKhr3K63pz1ttQh9KEKpOWLCy
Fwskx/zfZBgB1SrOw0WRRDblNcsVwv7ppCG+sCw0Rs+Qduw2YZWyo2lCEmBHnny3Z5XoQ3Ox8tlg
TF/HmGpr2JXC10d2Ll5SDwGCY1fyk/tFKWeq362sBWtuFc03TSWYAdWHlRfN1/XsjFDfa62kOtpE
8b5S4UsP6bw6GPfaXcMH3QInd9PJ7ImGM4nDtlFpqHzO9hsjHunr1xmvpSWyf1Wp96DqcGwU65g0
lepXD9dSoTpcio7z6UjH5Q4wxZ5i4h9ltGq/fsyYhP/3Oc7L0JrRHePWKBGpgMmf1JXx0Ugt11ro
ZGKfTnpBHUiuhS25oOpsY2diNwIyruP9d050SzYGyNPhl+9euZxZWpGRRjRTMguhJFMVGNWSU9D9
kbr8znLzfJ9++QhKwZjMITrJIgg8SnQMwqkvSVCkurVQ6WSyJMh/bXlNUQ6DYFEMgIafo+fGOBYt
QnnuafP7wkHPHpsFRrGSKU+sHT3RzLdMV1F0cJ0ABEqxOCw65DOhxbetwryw70fCwCGJcxak4yr+
AbxIsET+etBKfsUOF4QBpdVMAXn31v8T8qQ4MvGUkBlfOXAbB38vPHaowTjjsKG5ZGnQuTDy2oNi
58s1+665UQgrF4Chdlujg8mDkkn4cYHTdtP6h4RNt8p64xY+ZfyGhQWNpB5QgIYmAuVIv2qmbMd6
/s3Ae8q3dCVfgXxm2i1xtEoyHG+7X8mCiIK1ueqb9bgIEuEEQlV4Ydu24rR7mZasrYw0TGhLHbxx
GNhwEcMTwa1SBHSWmStD00kkZRIfRLTOojHxjBxGGu7pGE1u77n+e4qJ0wgnNINQUSFUmI2/+DLD
IoJnPLZUsaUJCxUojCBU+r+rR56k71WjTt3/azSnb9vM2aLuRdin6JkiEtAAOWrG+vh1NO6/DX+Q
YOxA9To0x+Gz4DMu3n8ld6ghCyckD6hOCdsiXVHvG9ECHEcdT86maV9nrJ3rf1reOfsmgKOi0l8S
teJ6sCQRZ/790+MvgCVU5Udub2rFduwdhad2+8NSkrWV1kOmYDZXx7gI4tzJ/f2Xkr4ZydU4bP+X
lt2KyJPoW/6zAGs0gtTppwPIxp4gHwXaVCIL4XJT5tst55ENHvcpZcbmGTGpctX/3kje8PABEUaQ
ZYwiuO0AEMQWh7WrEqS6uc662OB7pJpokAOUcSRn4peY6zi6aZEw15+tAl4mcdOICA/XYfd8Nqwd
qlmOdMgqVv4jKo1/qdDi0BRymMNCflK1+bgWaYFtGk1rm7KW4xbCR1xi6pMbzQx5YH1Ym11lp1d8
L6M40wSzO8hHIESrExzWxoKtEakV8oBdd5D4VgVnWaYBD7Un+wmeF++cvrb9zIRSR4jbukUopbWB
3LWOy8NLuhFFh6b040JUQ0edPXhHoz0FsH2Vsed5+MlgCS8AQA+/RV4kSzdftqEw0pXKjN0OIP8h
ASEcmzDi+QkuicCaemYcM//jJIEvTfmEfHUh36vHVksl161R5NtgZv4l1G8SujogztMiO+cPuCUo
M4/CD8EhwaWAWgcTI80Th2822zc6QvG8Sx3QeQ9+viX/Z6c5aesct8EugjhnZoU+rAnLhGj4rAsa
aCKk7p7sklaum18rLWipGWhuywmwmS16xiYwU2XLXVJ8l6iHfiMpzrWoGjEIuBBQHV/etVtyRyo0
v72MhNLhgp743k4KcU+fUaMPk0PMlZgA0K2rrKPBIOWptBp5i2gn0/KZ7u9xAU6gzSBlNeq0vPFH
xwFu/85RUMKox4lz+6u+lyF1WL89Trw8RfDH6KjbCk/n4KHw5fPHUTEuXaFabWre00BOa2ONbz7c
b9/wiJV2obEykRbX8dgkj2K+BuwJDtcz3nDD1L3gjUgilPgCpdKqQeXS5paOy131H0WJEqfJz62M
Kad387/HtpSMo1T69b34mGVQ9HB+sncmCt1QI5m7iGZ81vReuyTFm4R9VIr8xQD0U6SKX/gUgOyr
9kIlUnABnzpGUQuBQ8r79n2wSKYjz6Zl6rqFX64aJxpJ1fYLmGENkL60RGnOrQVH7BlmkhtnB0jF
NPVH9wCzMB+Ra1LUxrjEGckJhPAg9xYiep7Z17U84uEG5O8jxoPe5bmmWJqtNlg962CGViA6dR/E
dZQvHm1F/DMCkRbNev4X2m4KLP6uCdf+nqbXmX8nls0ex1RGHFmuknl7zEtQaKc4If5cS7FcNqKJ
TFqUqTTtInLN/EL2Jc4lsgzHGjrhq5NEu0G6N9ry1BIWOZa54OIUNU5azemX1tw6tRQEMBrpKSTQ
Cedh38mFNSD6CMFOfLoMrHArfIXDbDbKmL3LG8CieuWsB1wF6oC3+LsTYQLRd2YDYaqbddpdnvik
1sal9G7kZhGWPLJlLUPbjPF+/sqhMaOeflfHZCVCQIgXnA1QBV1RjZ8WMg9otQs+54mrCEygnLNa
A+jOQrcMrVtkSXroglfIwuTIGeV39maF7539sLgFNlQk4XN26oU4ZRFrNLd/UcLqN4t/QGuCQ7NR
TXqRyVk2I9dSn+fqwivou2xmHZD2T1e3hzc/+mcZe5Qk7bQmrHNSoOa7vfksd/A404LphXd4LOrO
O88W8A5pMLCXei61vNv66QvawwKSTq+227sIuvBBs2deFbUHJC+mfd9PYHMeoo5h/k8UF//9SKJU
kb5RlKZ9AI8hCvB3OKW87f8ND9E2dfAngBYYVz1pYcDO43WwmYFRupH6p59OXl1CiYnJ3KmUxs+9
GkOimBJ7D0+ZnBGOzsTeXrDU3v4vy3aBJnWbnspEDuARm4iFEueSFswS+d7JZvwrZTnPuud8njv0
O4p75+G+KGPOQnwNPZg9osds7LSC+NixGzJEDlAZBKJJjrWl+kiOdgWRIGqID2LHCgVCrac6CYRJ
hXLVQNYLKShttOwOcgXA67JiUAJgNRb+JjhzVuoVDLUA/KS/oWHtM+1AXxAEIJEz6kyLK/SFXCEr
KaL5ttOBwezXKd5Q3GSZQBMXL/M8moKqsPWUTMqKKwA4z8ltxIjZJqH8kgcLzcHFBU2EBV9aFshL
cLbUzE5vjQ18wCeOtni5ihpu0SktsK00fSrDJQLwhvHkRGa8KREsD2SCoskd+MTIXa/P1SYR5/dj
uhu46XhA0D31HOfPiwDEc5L7ywfZ+MT0tyB1Vf9MG1B+yu0sY0+Ak8z6Mhu5mUaXXSyo2XzGRSf7
BhnRl0oZQgtBHXJdaD0ASH9oLN6qYKrsk7isjs4dSDKBB/Djpi5ieqojHA6E5nhImAXmC/8hiC6o
mrJiLb46FKa2ewN1DcInQztbqFzZwOdnJD+3SrNUxs1/lJMcL1Wvi26Kn/vtSUn7wWyTvjVOxOF0
2MBr4dMvY2arb9L4XYe76LvTAgZ2NM8NUwLn6qkA9dVO+bha6Xe5pXb7GBeC7Y+GA3/0JiCHmGVe
ffVAbkEf+hPPqNGjxePQ0O++oMHKaqiKCRzmCycEhbH521T1P3InB+9XptTkDu0hWOqD8kbbAIbw
APJGUDUxic8XtDGQXANKob3VWoCrp9P8u14/0ZNWf5CoBPlR9Ds9l8DJM47TVreHb/qOWw+e0XKx
jySaLcqmsPQwdQlq34wHI2RYOCHdlymkA4obe3djzbu6JP9aTG7YcV7ioHTjbhPM+6loHuKWIJn1
lERxhRvioEqnWNCO+kT6UEaDGx+5pwgGl+mWqvhq1B5lDaG/+tK0TCKwpd+DhzTgG/HdJKRH47jL
ycrTGmP1J7AiFjbdZxckdjZzLXaqlnP4ULshAHuFFOSKeqdTVFzbm6hyrEhqxSiRyWfto+AjYfVu
wZvDWmjJLafv7EqF4eagY0N5JnMu2y1t++FBTAY2CpsO6g+S63zNh0IQi5iBWMSGfnpvD8M+PehG
yjs9MZzV5fkJvDV/dB4wiQnOZW6wtXSnpTtxIdi7/lRjPFgedWEJbHWpUuAI/n4YTjtKEvyUaldk
ZmuTKvkV6XORio7JGXd069b3MqVLzc7s69AiNTrmLJFrDoK631/zSF9clXmQd/OE99LCqIMlJUYU
wbm5tH7kS8B8NZj9xoZW54aG7JkPIDiJLUsrfpRpX+hkYaYmaotGkEvRqBTl9WfC6RLPlzOV6TI2
IwbYpUCta6gdWHa95mDHdkeuK0W2mSifdccS1VPrKZ54Iqavy0DS44+K//iK/7Pc+DfhcgflgFJA
FNcbAexv1TvSehybnmZ9xLNE2tP/unr/P8Ns3irtthXoo8TjZ6J/medRh+kvf5npjBZf5wW/Oank
iZhzyRlOfL4LD8P9el8Wt9bDhZhHIjdKQfoT5SnvxmjxPbhbYC5W6qPzHK0ETrfv5iWy6zH86rSS
H21vS/GlWVTAPnbvKkRAs/acnJRAsWxiLx2cCzoMBojmrjQ03RwgnWLB+QWnJmCsH5dcuk13NKL1
W1CQPIZPBdsqi897Gz3NQd8DoqFUYA20Qvg2VVk1PGL5I7oe/G9FSOm3BCyIwVEI/0qveCtzOgkc
VcSI51K9eHcMZtSrqEpQqb6oUjV06EcU1XiSD99Dq1sFEqdUwnffFYEvGFqwIrMedVjrpDP0WWCz
VCkGpZvtCdzg1XSfjr09Y7JWolVXReH5SV67giZ7upF67LnHm1VzuJkpBm41gSrFGU4xwBZuS2UP
q/dVMlzgZszZ9W2YncEnVJGGHSVK45bAHUIpCAPHd1pPpNRpzqrG3XEVNJ/dnoI7DiH2rov3id+5
Nx8NibIJkmNMwVwl/cXKPlQcWps2jpYXcSeavhctWUMqOKgmCdfhZfwZyKnyLWbIBzjma+tOwbRV
E2UcFdWEGV/QkwZ8G7IIpobWfkGZ70nku9VpqgS56uzpn2XkEJFU43cLHJbI2O+3AIzSfELsqLyr
NXy6yfwSsYsl06qMx8Q9wYYm69oJgYqZ+moyp2MROie6Dr62DPGChZ+LcLX+8ncvW05jL51qi24e
rp9N7SzNQzCo3wSSY6tlwMZ2NTVGUEAXchCEHW110YaBqgwB3qoHdzMuOrkBg+lBh/2NvIC1U3W0
ahKWsoEMo8d9y2J3Ifrjw/Gt8MgWNxH+APi+VjxzDnw3vC4mLPFxOHaRAx3SaUjSuEHqPfbQ6cvE
FuYdhcZxpCeCEGEbsAZOJ+0Lk42R/D7hU8CUwSN+8qCr1U1PR8np1hoxDBIAuVpnxOTuk0HNHApK
Cnd93WiThHYwCEkPzQXUvodk2Bl3VHobz5tXNva0W4WAxYYl2GBX6OiskcxeNYyjjcvBrG6ItiDw
Cr/uPLO3W9CcYSX4b1+0xLt2+U4pGyUaB0yX+faAlfX/eXRRPNP58jvZphC9h0a3dFI7XjeH4ByF
yCH9El+78KmiL4Ucn1BeZg3+8iNoifsi0Fqrg6xm2gBZGyolbdE+DGQqqMDUytDxz8JUaeBHHe9B
2a+rNtvkLfaiLQI8lKVd0uKCLhSHRzvgtoOsLRafmzVA0Z+17oS977vklB4ZQl4bdQrLCn3fj0vG
yVNYZTxQSoH750uY1tXsyHO7yATlQ1tGrR1Dk/68c74r70iBQR+LkZC/fo02+FFWyRJxNU7IigY7
0cpL8PSWC/KZjazLmKsrXwgB6rZYwLRo8o7G3O/hIusIIowEagUf3pbe2PxiQQWjPG/O4c7X7mnZ
NLIAAMiiJlLn5apNfieeI2otXLjROoc0zKyNw7CZidnSwzy4hK3qD2O8qRIZVNiUq5X8YQbCbOZQ
3Rp09tSRX2pU6wyNt+IqYtsYYo04ol3Avkdt+Fo+Y9cYL67S9cWVzO6A3VM0wq73vYllfH/xozIn
wFK6UyC/wo7l2Spa4KXD/qGbX9wxwcl+fU5ND/xPxn4Sns024sYh9eG9/EwLjzM0s6dTIQ3RJ8q8
l1XIxgl3y8kKTYyU6okGnKn6DkTaAocWODgxc9Pg1pQ01OiYF4+jlQuyUlI/tExBWdpRhxRo5CVd
Kcw3pH97wJiwVuozV30A1oaKBD5Z/toL0dTnr6IGrrn22LTjW2/VFWiWtJwU5uCQ9/Z20VY+yk0b
hmCb3gIKZrSMlobC27/4lOYSFpmuxj3GEaQIgi7R5pX+BK5RsF0CuwcJrAm1Ag9zsOJ5RHBMzxil
qumYTg49wXxNAfUOB/hiFlWaMFR45pRGfaGzwHRKJtRZh62FXkrey2/gT10leRP4BXApRFuty5p1
OS4hkIVxFwv08pFaJDY96fpTMKL7QXPmcovyfGYXQmsKOETwj0Jt73zjAM6eo4KJArvxnHCtOxjX
BJutgeSvzt1MydQ1t+AbzK/QSXxPx7xQ2aUTbXEAEZ+jK/0cvEZd/0if11VGSx4Her4OtLcuN6jW
/yPeur9Mh5NumJG/pIM+3tPRQrENk5m2Ekd5Tn/Kn/nkZ+nzCSovoiQ6MN7dZY3MNQfa4c9vB1m1
NnbAwwS6ACU/D3WssLhpf/RY+cUJuyWq4dFhLX+wFbj//n+lutQfyKVXBuwAhBY6hEj52UYOMm2V
/ntak5DOvIoPbB1hnvIRAMA+vzD8ymfC5fv1nY+YA1F4gP5evdbcMjMB6tBDVnHjyVQ6VssFvqhb
jH868NJd75DAhkX2KlejQ8+7FOvBXCozaGb7kfULp8MkXmthLc+SDv3Sy5mkYxiGGbE7AiC30qmq
4VXDsmMnXBTJNRTes/kuqpFSYBJa5tXXi5V/nW0eUhkxUleOHxwZTyfSqSjKUpxqjd2f+zJOimyQ
tw9j6/nKHN56tEUouI2gaSrRJGffxu1Rjt3hfowt1YM5rqnwPyG4ITeDrwILeS/xrTzqhD82bzpH
I6GAuKxFSpxYJJaJgJsPVcwpjxD3f5MCTTCd48BfWskpP7EGkVKFLIzsitIiCe8VsL4EO/1p+EXw
RCprb3T+vROAz9YVE8mWGJ5j0INp+zIe1MCHoqgX7FUHf0q63NtjdwtMC8SUPSun+XqfK/xwBLtv
6Yp7UdQwKA8ppzE67SFCZ5ofHPeoanbo0EpeAasjMcHUXK8Ma3OnEUL4j9ALlvQMKjMiniL9VGKw
JGIMNKBbFeg1iWvSR+UcribkXZIFsYEYmWRPyzfkgjKyRtMfRikZwsmMuen26nc0HrGB3+MYqnX8
k/tOrO26y9Skv++uI9NNBcY3CKTDrRxPHWN8lE4K1R1yPHrRZkjhLw39o6kyxUCWqJvnPnW36WMB
dgYHk0cBJzBSdgwj70PakuS2taxu41zoXjVwTMiijouVogpJSdwqB7dgYPFdLdar/9M2GaEak4BP
o5reBcQ2KXYIiiYkF+qt2yLbBvEFmJP3RRDU2jGe4QpKMXPhggYVci9mmhDliAR3hXyzWll5wt+v
gtbp7wRRwAW39y984w0za/VJk4RCozxHi1V92dG07R45CMDOoCyg9/JusxpTRnZKViVZJkrXXgoF
nfs22wS4ZBhkCylYteifp9i0o597g5Dr68y84y/Kzk2WL72MXRKblQ0JYkc0FDhBS7vs0HrB18NO
XoPCmiAK7a8YceTWIaQOkJpEGmi08SlBx1zO1ltFEoP20xdvOlwc78tA2PnYL0+/xB3oe2g5ABIh
ir901sh/Yke+rSGmCGOhN95JaUDMzJ05FMQntSEIyvFcL5YCfW2+FdCkh3jE9t6JaCfPHmTgPurK
i6oQ72uUsJiTInpsJm1cjNb95wNAGnZAM1G7xGaMlfLASyc81zDp3ioddhXXGKKE/ClLRdHEYpXH
FXHI9U/5GpbNYxdqCOHrBEImZx+VxyvongJinHRv7MMS9hKSVLDJGQRpR99OSE2M+rj/IIe8x1JB
ACCrqTyyaZ0LY3NEI2aDxFx3mYVBsQliy5WycRuUwJcsZPxclAe5Fvu7LDljzXCMs6BUR+FNbZl5
o3XJTQaletoyVaAzgpJfzRW0LCkIEnveMJpxGC0GwHxjf4PtQRBe7dtfDNIoudgIwrqqtUZPIvcw
Trs3xpSN9TeN4g1p9U6+jTN6LmiYhjCoz3aM+iGQzKwsAhTzVGwhHdWf1Z/dK9NTvbU/upqeRUem
VyaEsd2Y1PIE2cYCCU01m4MUiXNc3pMNvO+AZuDZm+JvRMvFd8J8JInAtwOaf8kaSGy1BDJWzvgO
lwN0wUMHm7JIjyYcR2gMBTdfND9s35FzFRi+HjMF+O7dZZWb5d+eqhSSFlJ55Sc7+nojLIJEfL7N
pUclO6x4FfV+QD4gVlv1jMkOap5GTMOhyP4HQJEAbsPb1+qjre1ey5fdqjT56H+co70GZwoVOV1z
GLNbGCBSQjNBWY7FskIbRfUyogAEtscN5cASdU73MU0Ty+Cki4i/7yysHJk9yKjQiojH0o/+cLKH
Ggn2wh1oJwlSzwu/0ka9B237f9m/HZVxxMpuIExeCyXmbuEQqkDQPjGWv21Dkyx6dD/Uj7ClN5wV
kIO/ceYL+sx+uPEHwUg/ev+HK/AkXXmGqqXmK1l10HWGvAQ+XkT5OCeK5vW0yNfORusWoiGMF90n
LegpAoCJ3W+ww02V4Jwv2jjM+BtcQhZmP0Cf6sRdQxEK6xBJGuuaApQJTN2mx7sxS9WwjSYmaGxo
u1yTUeDXaKo+RSGc01Dlg/JmFdjD0kH8A+Y6kYNACVYI8rEboSsGsfq7k7AyV6yrhwspKD06PVRO
/NWEaz6vo4CBwEfaMMb1dmzuFtafDezu8lKMOkGKa80g+yk3c1F+PpKKlQB2iJ2L1oIWuzQ9gNK7
dLju2uWtdhlB5oD9Lc4VornydEA8uBqSJxFk95LOTjf6MMl5VkIBcjRocrnrw2q+nHhETWI8pp0D
iy0rdfobGrEmUA91imwLAnV9ahFpbbQlt6ixdxN5MXBKK8Ks0e5Svapp7prtdomQAn6CaorJ46j3
CfM/6cuh6fORK6upSGQ4g6sqoifZU31Pnd4/2bW3qbJdXeHrldxU5LYqCq6/0SlqnzDjgxf6RBLg
eR5CGYfQdCGsA+z56neo7AfM6Vxl76x6ZQOd8qILR5uozzBYY42oCodheJ/Wjjxd/F5xF89ZO+Gq
zd4ZtDYqR/84kce/UcZnbRqv1QZP2V8hry6o4PW3FnPHHRLb4cPyjsoKZzs21M+p7hYO5SGpCCaS
Q9AlFhPKwwznUrZMxm4lQBnZsDZ5UdjKVoND8Cfzt7tIfhVSr571ZUjjuQpIiZt9UhEf1uidSuMY
4csL7Fm01entzjIQf034r+swe1fXKQm66Kx6Kv3+7iDCeqttcfs1PuEM0Tb3WjliJk6vC5ReL+YT
Py3HIiQDbcDHZrRkt84k5Zk8fOp0jNHjVkpGa/Wrhr0UUIS7S1jtALMBojfyOZlYwlC5EWlk6okG
0W88FLDGUi0zdgPZzttri6Ra2nF7BoIeBo8kN2zJLipriWakooOFpM1DPeyB6J/h4pUL4s3Majw3
bxG78IIEWWO3Q9haVjdrEhiamBhDE1BvlRw6xjc2GfMtGiGZp/zwxEEsIOQY7xg2+3LzqSCRMqqM
bdxvqsdbsdcaYRH1HO49QTvE+xYBf31WvldflcZTPHyDm0D905wH3U7Tr19j7gP+dwqoU44a/JwP
YhU8JF5ULwM71vqkxnvrAMwmrAN5dZ41aUINB3Cp+S4OG88YnGg74Cr+D+Q9Zx5etv43o7bdqGKZ
OYybfyLp1prhem6NC7ctkwR8DWUBN0Kp3Gnqp8cMxo6qP/gf9K6fFUE57xhsrbyq33BiK0Ds4FvB
f43M6JsO+bV3D1ItDfVSwB0kSoWgsSO6w5tXvVXUBGhel13uz+hnbQ9xs9nSNuRD7Y9n4GVBDGyp
hGBQeJRutlVpf6fr/lL8LiZKFVYSZJKSOKfI0uhVHdxlbxVGZJLJLrQ+PHUidw8u0oG22E7CguVZ
OWmqN0flg3ldOPzfBAvIeGs0R3HXAOmRcLBtWXNnBI/ZZvLexdo1gXlMCYVhI+1CJ83l7uRBUTCc
tk8+CET0hNXvoNqAmmpQa73ViFs+cXTaZxQ4XGLYPRbFgug7uwJKRcL9Cstm+38PD34X1a2CWnAS
rFV1vPXsoW6ryizm8A7AUnLPelnBxqnfg7L41IuaYjGisidn31v8qj+4BW7I9uAF4zX0/DUNX9Ti
3VoDiSKvnnm6jZCTCgOEbgjI0N6697YPhAlY7k+mPOVMQ9aRjDO5Pc/fMzY4B/CB6w5i2SndKqsV
AX6c+SeEJ8H0CJBQ08EiX7S4Gq/arwTZqRD7JcWsOL8OEUBR4DuA3MrIhieqVeTTRvge+wUFBR9o
O1Xcz1nZ+PyVSo+1+q4vAD0tAzeEw3S5u3XCXQIZ9TQxQdFyCEwRNQ7CX6n6Qe5imjaF4bX3m7mN
E502FE1kuro1OtuDCHWnerwC1dLbkhrKHNSSI5nVyyrnDaQHnrB7VXQAzt2oWea9Od+I2P/uAUaO
FcePocAEN+KWAdQqgydfYgMIiBI9sGu5ECAGXil7V2WPpJGXcvOTo1I4kDwlwjRhOQPI8xaHaVXc
RYDGQwR3Pw33we3SQQ6HGTHWSFV1+KvVhWthCTDZNH8WbNPXPfBi+re1LskMo2LiQW7Wy213GpAw
iZQ/nS9abcrIM4mb5utlxQKUIjyCWI8rIpEeQdp6jAHc7A1976B65dQ5Zu6KVuujjfoEObmQOFTT
AejSUHTXm0qQ1UO+P8Ih/ftu1yB6LI1JeFRuTGER0dMFAjvM26uVmkMdN/qCCSdb/Yfcpnke8feH
xVM4QYmRqwDLjydJY53pj3sMiohG35fmKazuy9m2gx79EKo0hfs5e/6J0lQuG3v6rakIPtWr6c2k
ZQK4Uo3GYv8F27kse8ubWl4vJLpph/bolSIhEmCtwfgxdMt223121a60jSxabAsl5Nzq66Ck07XH
2dFroUCWNh9ZpU1nAvrqOj7+CJpgxGJnKJgD5kQpWXByR0crbMJ5MeoxFnFKR4eZzq2k42z4UDpV
ZCkNBF+i+f4z/vEfHMoFhDSemMwoU3V1tA260ivC/EaUhc8noG/uUJAqVjM1Kn1aHlPzDjlIa2Ou
1M3oO6EY3mF1g1GnYg/FJ+zOpNmxostvoVNZN47f9GAk27B+QBqp9Bcq+0t6sbXwejjWSyXSSfP+
gahDGLDv44Fu1mWwax+SaMld+o/p1lKkjDccdi4sz4DJ9PPWOC/4LHHZ17rfIESFcaqyp9/k01ui
BHUGBww5IOFzvrVqC62keqkYPv3+4pAanmyBPXKsz3cH4x1/X65pvtnNI2Aan9QLrc6IxhvQCTK9
W9KIViNo6IKXtqpPM+hYDA53WbT0BU9F6gwi7aGxdo+wddvZ3KGfvcwmq+K2Rs3V//GGlSHoAeJy
CHp/uO5zbrbLzKLwZLJhPnIB79S954WXimJP/jO4+sg7EnGUsuYnsM4kIFUwIHWMvAsf6NGvOYmr
cdKj75wjAehwJ/W8a/ecwC+Fr03KJXqNUO3EJML1wzFusgnGN4hRQGgVSvFwFVsECuGbx61+Kwne
iB7XIi8WIJSrao4pQfY2h1FGKo4V/0qznVfl/E0ReiemZZnyl3KJvLM4Tezs55RYbhCjeufy4YaP
2FZ3pXf/pC8cPLuHbejBotBbMkSNTC3q7M+fngG1X8XzBYWyw4v+ccfH/Vzl67SfnqfGnyN0iEpm
rGkzkbwEWsX5NyKgFtvJ4MBHBU/Pbp7heATZhE9XzMHIhtlyFnpaKVMj8XR0DEPXG8w1J8bt2lIq
hsJHhPvn4Q1hbvd36V/FP2bzailfKmh05B5rNNJPQ5Vfs2Cd/UimHNdmgnuZDlgqWZathXx82G0h
+wO8m39AciPsMcdl6hD2eCzD+yxvK+q4Z/dlb4SDtKGsLlr7jsCHhSJZ9aRGCqvNPwJcYrrJF9Hp
5DMQjMyIH3fkSrOylwTAeAHzpB+wXuURS/+rHoHZeMjjjV56qeqWgLNUc3Pv5tSkVCDgXZ+w3eA0
paMdHnby/sTM7y+6ZFGHQ6jguYZFePA+rwcA+XJhba8qQHCiFYsgrOFAwWd5vq+bAl90H2ZJNWlR
vGdsrG8EdAhEAUGJ04fS1hqXkACv9mgHlugjDxv6n13UWSJ532DfB5M9TlaP+NM5yrhLcDCFRNrW
ABT3GGhETnsfDgX9/goO8qdsL4MlluSxJhLqVHziJH6h/lIr0IF9+kBjvo2UHEUYlxpuDHCXEuhp
oSmcyGx47vEIgQhFQ9F/c/D0H7a4Sy1bTcmW4rwHJ3aXn0NO6j7HQNxt1KBUVWTKJ9ch2ckI15I6
buSiAsHJggAmoBC+xgtDslWdaadm3RERnMfa8OOxofz+vwl7iEmzmWmVBjenaqK4bh/EnM0Yvz3K
wt23GXOSd+dQyCbfcJ3y79toZaWRNsAITD6wRz6xnX9sItb5pDKZkIgUnAXXyCj6fA/WNU8p1xSn
H7BK/vtYdU0iriR0bY+VsEoXobn2GHBMmDRuh2l1ZxDRf3ZZwYC/0zDXJfJKGhFi7uNQLNnEddUt
op4l6KarQcy45YjwWh70Sw2EmIYipAzKdBaBI9W9OQNMFX8Iq95Va4jznVb/AUTDT545NwZRSM/m
2weQx/H48tSFY22/ExuLuKC8gqF9ElmyY/7hjFG8LPjRNZQ63O6JdYeYtL82C4lKxH2jlpvwTfnQ
bAzPohoYOXCUZ9aZu+bpm1df35TW2It85N8ksJpP41qqAdh1/qrh71zO58xFwkDYLVcUOgdK/REM
CzMuQgrZPZUeJOVih1dH73ub+Yd1ryYFmzS28KCxx1cpuDW64IHhxuZfVyc530UGAVeV7qXv9cPu
HHXu/5v/6NTkrlf4inNxRX/PLX1neFyoTU/+8ILQwX3uxoDnWAJwgP1SKzIPq0nXcC0VKR9nxB6k
R/+znlEyQdV3oTnLZM6aw4snn7ZncaD44qHrLP/YOxi7O5wTIL4GPG6znrtiVfko4Zj5VgYNmCk+
6pHOcyNfiETmALVZVmx57YdFlCHj4zImsAbNv2hSDSBcR+Lb43cXZAOKCYFL/FRBSJn4g//9fTGW
b9LtINF652EOF/tbsQddMYL+dkTDIz7ZU0Xz0kB/RmYONri9lqTPkMxjUk8Sl1wB2z44v0RGgPhR
pXTwMGp3/vFG0wU4+PmJA5qX4fxFjnhWm2NX0qYSKJGblwznzjcGnTGUoUPBPE2UTbNnLwoAS06y
Hr+koZ02h1WQsEex7fHHjm+IiSMXNP5ncXRRKN55YmRTBaSlh6xqEneGE94yEIrm/xOTS0tcmHMw
4PKgGm2qhQDY4yiEOf66nPxC3YVL/MNA3ND4ZfwvsfirIrpzsMyaIqGalBWehXM+Ud+Ce22k0W1l
a7LAt230Q6ZqS7NixTUjjy0YcklAOdqGt6TwaXxS38Qtbq5Bni6ac0ZMuJ9u5Sv2fYL1gS0/j98R
RfzrWuj5uGEHPaXOE8GwPTKXWp/AOnor/bRqRRVULaGqEysKahU48J+gk7WtcU/rjFBbfM1mzDQf
ZJkxJd55ABSRFc2k0zU3HSxFxDjBozKcAzZNHBtJGb2PzSFinmglXnDQRPyTDP60NnG+4eUfSI8z
f6pppmArtN0GfLGAuBaFLT3uj449xptGszD97tRTcgtSOf9UaT7dqCHtO7kaBc+ZdnuKIyo/ahvV
twVuWn7FJjNYL7bJzVY3itMeUsznZUOfVRbvs9/f5MZXu6GUtZSEuYL9KK3qLdyFAFEJyhCKE0t5
PZ4qOREDs7N8tw5ix0L/HAAhIp+n8HxZFB0CPcx7ntWIPiFdSMJUoL/SoUB961k1WX5TgKBwNqah
1otv0KsJuK1Gw2M6yt9F7mkiWx3a/gQ385QTLEYAYGByUFZt1DPNJEOEDzXtBWv1C7lopz3l3iX5
NekAsXARp+CgNbwWY0EmARHBe2XyggXeA0KZkpvn2SUYZnw2DQz6Sn5/GWKcJieRTrBAEmz+FgX8
PV1pL95DhjMpB7XI/fTR//Uz58TG3h+U/wNjyroemRytsP6VnqZqDrcaOsnVq5Aw7zKvM5HXJ0GC
UIHdYBAogt+8OC7fhpUS3tpjOm1m/RN8tsH38i7LGnrsQa1vdboTuSbVj93F1fMYdH+VQYTYVPJR
p4vFIrVJ6iE5tBwg3spgCb1T7QIB1saj5t4chzb9o+HAUiC+ob/n7iQURXuBXMVVBQ2NmBwSLv4F
fzmGGMqLk6QTjWiiH4P8+tfx4QOy5QRnpH9ddm7riLfdwROXGRbTFIYmEq/HmYYP1AL0VMo2ilh8
EDIo1iwVNeXWpmQTN7LpNaIE0AlkQ2UGhe0O+8P4ZCXvDKNahS/ZYm/AfxYKzhQhyIlscS1Xcsmj
HTs7d42Vdl18yveod6zE92Jlk9L+MNQjboh2QLNEsO7L2Onl16aC2l9hiRTP+rgdgz1xu6GVyvpF
nrPmhLe6yCT0KjmM2vgBbRDn7qn/Tp2qwl5dXdRclH+f9ut1PTeVwOQJNWHMWzlqCv2D53Z8DAZL
zI5Tll53dQE+TuThcjsjmh4Re5PL5pxNytlryJmvMULlC+wnXQ8pSaTAi1S9oC2JqcOgZ/5lWOSx
FQOsIFh9OXGciwSna1iDyW6I0KwUUzVR8Yn238JTc2okSYIbnHjo7AaHEIvZsEYqcbmF3GWPgNXR
gqam3kHDThm685e7gEC4BtdehC4TXwUY8MCTe8kWVuqk/esbOqMTvAhDqmmYstknOUTVu6z8oUtb
cokUkAGEboOV5bYciTr01BTRckVkDdZDNeM6y2cFP5auj2bYgcC+SwUkrDAWuEklUktOx3NXmUmF
oiT7aJ2MOvOXReAI2WFY/NeXHb+h4DKwSopwk5iC+LogfCDly+htODtdU5UhJGjmaucw47NbXUJ2
GBNnt9XUz2FtPI4YPW/PsgwQm3hFuF77edTOrrmAmOlmHknrBT1kF9Ymd3GlS+c9iG/X3HS1Grgk
bn4XhTBdED+5Ys71hRWACO2AgXBz6Fn/1aEyUN5q7VgD1S5C4OljxPg2PRHtwuBD+V3zSkLGHm5x
xob+FNw4jM75DGHQabegaXMolKrjjY/3dr75Ymp/4XHJenZG4iX8H5H1QuawcGxsHgt0h9piq+GW
FFpCeKRS337D//W7TRPaJiYPm/bTfJTXPzhvmlBNdsvpAWZoMbDMOFREGh7wa2QBbwKo+1/STQuI
v3yoR4tvcc/0um1ttHZZ7dBJTxrXhpm9J5b9fJmXK7cqR75x2oO5cCiUQLpWg05Or+URXcLLf/2X
OKJVAw1NRLDrMiAAy7y0gmd4FsyUbUtacbxIVlVyOfm674GrvqzV+29FjAttv3gXGtxH3Mhj2wbE
UDN0AUEz1zaHhf14GyBT1tbHG+vQUNo5q2/894GwXNQfNtKyTYnnXMkkFdx1CPzx61ziGvBfTK5W
o+9Qy54BMNfVpmZQfAUjwsRqmGs2T4gqKDYwOjt0ZNfcespjTshNEgCDhhJcmBtR7KHWGWxiwn6n
8sonwp/yGZqro/yKWAr5MbsEHI3l6QpKNko/Ju4v3TOryCcIdi1dRhCHW9cgmsxqm7EF+q85aOOs
p5S6t/nCV+cynAk2Ng9GgZ6U13MzEg+9cJbkVoIPV9Q2rv06rwPRdBusr/Iao6hTFmPqxQnZsEab
Hrr08RrojmPXQdXOfqbAl60APYiaEKZZm+k1DnZNeSeZagkUQNNWEwyg+/cSIXb7OmZzvLNI7Avk
uN6SZDg/IBxZ7ojqooKm5D3phKHEU5NT/i/mB54TELihl4HROGs+x3hqR9DLldhIpemL8VmndLbw
/fzJLG7t8j6H2BeGsZpANfoDy8VCxhRj764j0nOrV5Q+qCKJ/XPffPdd+b2kqruL0av/Oep+EzyG
8IcTnAcunLWh4zWMz8Ev5CD5NNcUWDLHBY2Smb4wh4GDSHVSyRoVXSRNsWullUcRqiU/BWZsrpPd
xxH184LWyrYDuRSxcS/HYkEUC+aRxwptsBHe9Rj3dmh6UZQfCe1gQ0u4Zx4xYzynmfEGl+muCdsp
qlIWMNyb5tjUUylgAU2uLvgR5Z+I55Yc+SQHek3utExlwDbjObXknG1mVI7oNmZHcCXM11+GAEfj
T3tqyEegiXfREjW9DZnDZ6+5m2O0l1EgF4k1KAdSCI2uwknczsdpatbJKZO8/xeDngy/kwYThNvu
WaV+r3V4S194xRkIUDHnJunaVVpXH0BuBy3NCy7lT0LvjVzg9XcwmY7Nf6KmQaX0lcc4FD76FpWO
LDAr3bTAQpsLt6rXl1kLXzhwt8MZiMCeKa2QblwIkuZBoduWKLFcEW88/KMlF1OlWo1W6yV6WGxr
pLqVax3enWO3dmmupxduoGze2R7VnmJIMMAOik0PicSQKld4zZJ+gchEaHVrDTDlwwCDGqxHkU2P
IhsN93rGSd6BopHWimMuIQ+h3WJo5OCMmsza2c88yefeeebuZFMPAZRkeKtXX3umKLbAUXSdHwcX
NvOvWjngoiDxhNXZa027t2TcdmklTf6VSQgF5RJ73z+Y/1BOmpL3k9Q1Sjv4bB6H5lnZVTficbW+
FZ6ZLPsyvU0kniPLbhsH9J/JQZ1COg9XAsLo/XPhmnmnnwxUedsZCZ3Tw73aWh3wnr9aUaKPyA8B
jKwXKiKhD0T3ASetW2LxMWuAeClnvVrTPWVxBWakvNEFkS0RhUHVIdvmL8qFlc7qKoJgARqDQ7P8
Fi6TXxsTxB1gk6ci5TtWyJ5kjlWkgGNm7LbWDVltvQUVdZL9Tl59XuAYqXTkPQ1Y3GsqpZ/EqNvo
iQusa4WU1xoFW8pIx2+NeQ41hC04bD1JBnlCENImHAcgjNXbYwrYLUrKAZu33i56QGUjMxCBFzN4
BX6lxA90p8MVVxV8+xc9g/020o9vCAdZfItZMViq06X59IejE++3kLx/jDu7/MkEvjOBY0TSDBIL
zYWWyKQaMSBtI9r7rTxoBGtOwbT9u3RNch7eOj4e4NtLZ5OREufSXdS0AS5kbPGZAyg29p7oVu9N
opzE/NP/VOhh75fcSzuinjUz8FnJHyZIdo9l7TXArND3mV7mYGaNeaEItvW4oDqwjtVVdJAfo6ju
LKTjXEg6giGM1M/6GKAxfV+vZH1Mv5p2WNnNMDPsw/5JMLLCfPiASOdEkkP29NPFUJO/HqoGTJaF
4Jqs6xYJJe579izo6LZkAhRVwG5gx+RrilYmlppr3M6EJrd5Ub6sHgB/G/0JCjcvsWZVsr62xXK5
Hqup4+Mg772Agszi9PV2gc1W+Q5oJvm5YtQvqrUAYmJkTWKqcI72ObahpSxvnNrUPtsvg4ULlWWl
tgoXn9HL6mxqMOvDefWFoDrokCJ+Ni25uIkH+PJMvjkPFosRoNyI+LNQ2WF3dJEYU1Ml47L6oTxu
wOIU8mJMDh7+UE94ce1uJ4oXJ8nFdpGA7s0Y/A6nfnY0h1+s978ni5eT5iDKqEVMvzf3XKuBDwd8
SZErMsQr2uF+ZiEU+0NfiiDlfymelvcGOax48PcUrUA5gG4xrpIDZsvQ7BuNF9PkDbwPLA1GbCGl
I3BvCCLxQou3CWPpUIXcSKUPu2IlfJDdo+PyE9L/36Vefsr97mVYAfp3xQvQHDx8mWjRp+ERjAvg
RRNq++tJzbbum/MqBFL28GJx12JaMixPc2S0W59A6tNqUSmUN+gKTUoXq4BMydFR5j3iPbfSscHc
ItgCfnQ1VexWNk4mp5SJh66o0Ui1mQSf2VT3wRFnKP1C67qRpYUTYV/+rZrrbmJ4MtvMRkiy/5uT
nYBdbk7HpS+mU6/q8ahHR/rdHR0vJcEYi4Q20+fAiQLNJLskSqhhgfe1DJtNa0CcTMU0TNbtboxN
PH0HubG8jI0DMLUTRyrkaNsPrGFf1txdRZWbGBUSyu1z3EMiUaWGlEJa2gUN5um4mR93lmypvgqE
0okH3x0Eo/gc7BOLc7NGkX/wPJ3LmcGIrTxVILfrCJLL5EItU1sMw9K1WSD74Kr21X+xuTQaicNc
N5v6I3fbA5RE1wsPOL0HZy9jV2dlI8YrHOEcta4092E/XjJZNxXRpl031OhvhoFyZoDL76eYURp1
FP1LJKFl5b+9LEg5moem7c0+2+4bChSnWawNXs7yikDWAjClYvVxTl0pBSbQp1DWmKzfL3EoBt8Z
1zlaDX7TN7+nXBY20oAo2wRa0K6grykWqKxufgzlBUwBtNZ58DYUvN+2vdDdG3+shidrwseyVz+O
P4uF7JCMz85AbV9Y+4lhROUc0C5EHcYIz+4sIGqOrgWLTzLUMn7TvhkUxOpA+SfimWA6w0zCzlJX
VATVglG1eAxUw+SS88eV8t7ZsV4P2ZDDBmaYA9nmCzD+033b3+ok8XtzXtJJq8Anajz0fAcfaRpa
r5j9nHoFE5AvL0pT8U7UzB10w4OkxmjE2RoVnCGeKJ4wE1giqL6nzt/NNUiZ1BzYS0zxXEPo+2PM
mk4BpF1EfBcbTRY/xUpTlnfLiJh9uICOk5L9FMWUoLx9ZZfFCUskkhrOXrb+qGmAmCiyJJa9cTSg
9oY3zNxcTGSanMYl9QE8A35wjnJSj5OHYaosLnBt/XgsQAUM1TLMJg/8xZ5XzRK82SL0025lVf9x
UrbiSeNAUrKWuZxhhIb/6sTLLU5UBWeE3f1xAp+SJYcpNpWQIfkk/bbr7IFb2G8+HCjJERFxHPue
1FVR3Dq3/Z9aKdxkopoK/Bx49bHro1fQvUCUu1O4Gjhnb6td7KTpyIvJZHtdiWNz9oeOcKEFS0nf
mN76fYvk6cRJnkdHt2cnKrZz78qi80hD/01vql37Voc6HBn71wFJUgk8KA62zM1SBBHktFjT5NFs
wbHhbU3Nhbkgx+h8kB0JWzYEVTJy3lWQa40wBjQZObquhBSrgEc5iR2cl61lguAXstwry4t6eHR3
FxSiHsXzrzgeu+2o3OUj+i3rDR7CC+7iJq+XIvkylJXcVKH9ue62joqzVD0AHbIdBxdkiT+A+7+U
OIEvKrYUhI6oZbyLPGFyMa/mibIbVK+FJgnqXjuDwI4+sRtnp61cL/RANo5o897cJ5VNvK02ovyI
seLd5ip+iZ778ziERLs+lWxBYaLaZkcZcil8m3/3QPO1wK8T9NF6ozzpEFGfvz4Rg4TwecimnoWS
n4NKj9IT5sWn6AQCxlalijzinUtDBCw7rYwBdvAz/wvxEWn8bKXg5TUk99loFfh9FcG2pUiUJwTt
0ZdUrmYJeyyFOmGr0Pn640M84kf9/mzCc1s5if4rI/jTdcsGujvWgfAkSohQiF9Cy+QozDLBvr/l
vS0YHrO7PIDWYGx/dGudPJfLKfgxdUDdnw0gcWgj4zFQIsBnzaQdHBESP5uoCwfrbgaiSJ5mG5Pb
UihzNYfIogW6vOxKOiUc3w3XEgmRvxMLh9XrOc2kysIsY/VqxMaI5n47WVp5nvB1MpHfQNPY8w0I
462NbhBuZZ3Gd47i2LVy7HmUAKEsLS44iHtVcJx4bl0/tppI0YZywDeuQHL7zVyMl5kGDqHu5oeK
et2Q17SCq1054CJROilMuUGnuT9UtTAEDnmjHjZ5vTbqGDiWYEGhnSgPWH7jBsPtX+5jh/PxKaYt
UUUrCdgcm0NVdclOROvU2RYC9yQUhiuG29fDPMcK3qDPpyPzKo/9N0ysuUGjWdbZuXGm8N27xb6e
XpA9k0wg0dRMX8v/AVDMASegBfU1Op2r9FQs+Q9S8JhXC9mE82l9Mx3sGHaqjm0aShfQtYQBoQ5Q
IA4uIKohfvbtUqxho5diglgmAE9MSX41ggwKsEiP+ZCyfJSvmQGjFz0WDye6Y3KXqhxSmMwUE8YQ
85wSuUppNXYwisqzn3uovNNCVzSyxXzExU48MFKxx+P/MItzcxduQD1vPRAcmLR44yaq1iEkXYSR
ppa4TOGXuNrAlHcYXzh1dWmS+AmYmoPeUDMkGa0rHaLFeORigE3GW6kOlBlr8tEUgB9ZIqjLF19M
rxrZp8a6mksgLqReuN+p2+0GfRKfQu7+w2chHXthZFpw7lH8VskpaHbD6W9oN40OvI2oit2N8KhL
KYPKuHsD3GdASpbC6GdUx87SX7/0lJq2h9CJoXqMNIl7+ynB+JBHdJpk9Su9rQasW8JtejId9mTe
2TWQ8TMRIZF/4Obv7fIkQ+xT/vhAGAqW/m1DyiM5HEj9DTfJNiLauIDXIcjrchQyfz7awkpswmO9
j0AqW0lG3mY/6pJRZfObdoDn4VnKL4Li646Knvhu45wupisktTl1NKFpUeVF68qVJaErv+apBzFd
BZzPZo27Z4tHgHRcBYsPbHANos7ByKJpxnP6tSPe0mSbkErPznFwuVypdo0Oj5Jes+rjUwnCVpHH
dCZdIEOpZF5PhYDBOZJ1zYy81HgSk65hwW89K1wmaUr551NCFgB4lukupv4Jw3chXgGaXAlqSsCg
d8AzNlj1uSJYzCPG+8Ov/LPC3wwOK/r8Lz45OgHop/WaawF0fytdEst6r/Auk8aaUspqRBC/zNS+
Yq8Zwxjx5gN83VEDLRXFehT5lHTQFnexOY8UvopQsxic4g8uOBYLQvQevqZqwW1/f53RxeJGMjvR
lfYHo4Q/9nk6E3WGqTBveayQT4R/rv+REAZCQVhxLzdnKG2Lz8NfTHnaV97XZqClpvCr29v/3E13
ZbuYVNek+3nVgj4gZleSL8McrUFINYD0yNPIkIx2L68TG8x9HiZCwZodFeurieV002Vh7i8UFaSt
Bqo/ZtosfhQ5XvmbtDvCeDAoGQ47bbu6w4jMIwY2IarfHzn3upL2L58O50AeQedAnammxfS+/+ef
X7ocJtLUYXsBC07Wq+kvXX3Db4db3ARgbQXiiqeyfElpvBoSpViMiNmyjImW/p21em1m53Aq+aJB
nj1m7WxFnnIm5nh9T+0iZ9q4GeWkCYCCe5NuNPOohNgSxQd1nc4PmC7Fjs5g5PC8hvCoK6/GmXVf
mp+CpDwnK78cTuJ41ROyMcSe+gHeU14fVnr3iKnSd6KYnCnJSu4L6e8xAtajnTGQcC34M29r79Ex
zZyo1Ide/SUrATfOG32zC3IsM9LSNkUKpGJ6to3tP4tRGpFzfMR2uvrDTO9CguhUJtGg9Y6ILa0Q
76oMr24l2kcG1hpbNtR3SgBEyWHrsh3QXJs0IcVb0LWw2f2DklgZA342suNs17qOBW+9XWCO79+9
UybesEcSThCCg45rLCsVA9nlfGn0xH3FYXMs67DCkYtlvyjnWTwBHrtcTCGfP061CkGq9NOZQ4nj
q7ouWqXh+QrGiUV/EVqaVWVPPu+1hLDYBDRO/0fyeP7FRAPYV7RuSBFAGvJulTBDkI8HRiQWG0gi
CcYeq5ir85SuDzQ43FIyv9bt//KR/T5SWJieFJ+K2HfXNwWrJ99bGIPBCbovFRCpWoFQNQNZqlaY
KMWv8GgUcmfBIIc3hTolWi+WC69VfKDLsaBxAYiBfvwM8Q1ykaMZPbm6gpEPXhqJnSPEfP0Qo3tO
7TwcvhBZjZQ5KO11FqAeI5vYMu87OAZhqEqxhFtl76qtjakRko8f0enLR6Z95lCO8BxG1T59NnRu
JX91IfweZ8nHTIaTVhgLODsvdDjOJ/oGWMXKsbbwKqLXQpEAekCFB2pWwfVBEvjIxPgukt3mbVr1
H1/2YvAm1paJuPuPsaph4VWGbi4kGKbBlDf4KzCymRNs2pOqi9K82pux7wZwHH7VqVG+SsPNFTdG
IQ/E1z0S9u0RKATCntmk7E9oisyIV8GsXcQ8M1y8uiKGbbAyi/jyMw26+ajmu+EJv/mFvT4cY52d
w1q9kb6SgflsXbtiwZqG3TGZYTY5MjxvTZrlLZvyXS5iqwpZxLZjcvyd/eUrLUcy98K7R0LgQAUG
CMjyUskmti23A38UWEkzJ89Byj2h/V7G8ZgestPLh0ch0DGrv9a/Fl9B4bGbQlHXDPFcH8BaDHfk
VUdgZAOBscaqyxbVwuaTl67N5PJMsuXHgDlCzbERLjY7rAR2vdWSzBpYpM429W55j5vMtPdu9pEf
2g3z7Gnuz1q3BA6JaxK1cpQVWegHzLCHwn9cU/5cUZ+mmckMvTf1OR+LUjsfHTsGve8HSsF9sz90
euu0Svm0IlF0KPxv5RppenvTIrv48fteTBOt6WDCwCZXBH/OzxN0pLEp5csMmRKz2QeT7CTH76AB
8sQ+txL8aeE+CFRuWp90UpDduNy0WcIJy5XahffoioM347DReMeo6/oNaKI50Pm+JPiQDKHtpghr
cCqHFE/t+ydY/gRzxBBjBbjjGhuCG9eEoNUfDEoKOMuypivfazp2PyMcAEF2lc1t0NBuEj1GFHAU
uYuuqjfHG5uB5nYz7VEpoLPoM5buBjT0/eRzHcUnzQLkNZ0rogFOPB5oEHCtTE6sEH8Q38GCWjlM
kjxJvK5SW1XbKLX6FlAfICvdIzF7ATLnlPK5fn6E3mvpKl2+/i9bo2mQJuW+pp3al9z5/+2i+NrX
bmiMNK5sWTJLbaBKRGCKGWxjR4SRa8ScxZOj+ix2eN+lshLe+i0X9DIzpftysOZqV7vDG7Yueb1/
xSTtAva4oqP1TDYJoEp/fqwyBXVKmjwYXO5V/ulpXqMRIFRHqDe2OQIFLJyyo3Ib5r4DDzbEYovy
iqq/BfQdcPwHIq5zgZ4KWTjJ1BPgCPTa56EyUZUemMu2zDLEOOJf9GiWYwcTPtpbE+q8csvlbTYd
gPSvjR2l3mdqmuuNpEAoXSbVazIx3nuzlWBafa7np4gFOzYq2X+wugtj53p0sS/9N4VCqXBj3MkG
6G0lMCsFhjlttDDBnyxMunQoKeQ5qIv+CYHktS6rl4bkejMYn0SIQp/2r2ZyfLshJtzOIZEnLcgJ
eyMP5tOhmcfJEBAed2FLIuAEifxTYDB452KYCQ0U+WSIE44YYCVcYcK24vXFVGGNZ+rinV5895PS
sIVIYmlv1RnG8BeWfX61WcwMITqKBsWr6nqO0iZsU8teJ8DT7bg5ZGumSiiLyO1gEq7z6bc43pql
TAsVrn1PZWVLPtIlClkBCdOzvTsJj+dVi2SLZdDdrdruWcRmUWg4BQGV54qxEu9z0P1ln2gnImyJ
XXxDzpKTsrZ98mPd0p9jvdMQPAGchFSNN2xS8je96xYoer/rPNpaLTUJLGQ7wvEmh8p38crdVgca
cLTMPNgFfpDJhldvLJptmLsDnEcbxyQlqg8WJHqhFfVI3UB00khstv64AUHJzzQiDjSvXycXRGVR
RDX2PQ+MQhG+p3RYPBcz5bpP3Gs+9uyIlkJUjtHyFfYb1QnBjk+3c6n2oO1zFrc2QfWCoz696YWc
xSideWrX+zNNtYmXL9TYk3qqRC5UJ5MeqEyQayBEcxgz7qjg2LEge6VLEWYDJVCLsKov4+Q0f3Wa
n0B0Ptlf7lJgnvBAyUI41ADGKOFcgO9nNeEij0F0jVnCC4n15gh7TIdXspWZRgoBa6raAm9pgJrm
vul9vDsTxWmteHWRZfX8xNABKR/zwLlISuMqHxriZgCZItcoqQrmiV1XltT0gsbw4EWNebU7pGm8
RoLw3J1qNqLDCivvAoz9W2dnD54u9XxhaowEFrUly2Gwcvbd7NwWO4sHcIzBjGy8ynuStTc799th
K2Kcwka7smwXsXjzbNOjREBZgLvezkTp+k4PKwVBiwK6XMBdLZEoFhFkehDjzXx5pt/uZxFMOHNg
dBQ3XOof1RDiu7UxNfBe9BnghpXUc7rZbF0mTb+sbDBRXikP6vNkpHc+hRdzl2LBONCY/m11gqvH
b8S0rvR2RT62tm+WLlCjtJqLIrPsET4w57Uy0KIU/bMR2APrg/5rDcS4cWl4Te3hqTXB7/pAeVtK
LgMYlwekfOOhsXVJD0FmUmqcjw7cdZwakLgF9nI2cuBEg0zOoDoX/T+zHYn+uJh/ir5jgvUJv+XF
OpiyJ5MZ3IednWBZax9vgDZC/z4Bzqyd9P/TaYGfwdVCYvXIU+fjzKx6OzCtg9mAtRhqPbE20FKx
xSABMRtYFSuWvcDVDu+0VluYD1CzmqhlVsEoWnHijZCzQ6VnMb1eKNcmVjiXLcPD14xGJ1hfNlpk
MeD9uXVShT6snu7dQFtcBGUxUlrNhRCmv9Y0Ki4lhipNPQ24C2yk2zphidGefXgujsUjs39ajn0l
uiO+L3a2CE0Lsjo/+6UHQ7JaOY3GcncwagwXRFMxbO8Ebw+HTFc4+1PmTm41SkbiPr9+gwGKLIju
CMyeaBgguLYA8JztW7m0YGUSCtcZakvZ4t4KYJVfME8a6V1nZ0ZV99oPfNuth3p+gbpNtpctlBzN
+zb0WBwQvrXTWhUcO+1rFdYmyrRYT1BtZVc//UwjgtYbBNpgjonqO0f3glgjv4Hh5TBtcHCPZWJY
BXRz9BTqemugtg5jKYmerAJO1j1q6dV2i6pd1oyJyn9Bw4Yl58hveEFgZAULj92vwgbxivZFIEG5
gP+NlCXu+qHGPZjOHiXyeoe5upqrb48YVRaLQEayJ/IJaczSHY6+S7tNfMiHGXufnwuFH9vQwkz+
XMeGUagWpV4uro6oUOn1jALIkI+f4dJPzsif80yIGEABR5++WFmUpsj8uBwIHvCkzwo/ktSrxBmb
4NjK6g4Tje2h35752Ms28N+5RX18doVFbbg0s7kbBsTz17KDQRdgp4ne2qYexb3c4DZhsOhUzxVg
hQfBWJRPQbde4/dc9fimy+6D12qGEB6xtDRlVsRaNIk7JA+GISZsdqmlI5Vs+xQxg+Q8cEMb52aH
hIMGadP3uLIaZH20gYcyH3kL6XJ5XOHU9bsqU+DKiIMRdYkFNPcV1AWbOuNXawY3sFuv2hsoS9jy
urO3SIbK8krModV+mncWhP5XfmkX+o9tqC7ocxrFTaR78PXgv18PRhK/jSIPXJxgmc1GCOb6sM7U
iv7XTjVyOO5UPGcrjOwLMGQBleUbYlcoaye6MZmoCD/HeoXwOUorRxoXF9sPdR0z0P/T5RHC9iR0
6RNcdUvfIeptDbhaYaE2W9A6yNKYe1PbpBwiaPD/G+dEz71IEtlEwma1IMcQTe8OiU8OD9sh3on1
+rqK/+wExmmBTqonUaLSm8DJWvcUQP05i69Z74v/6tTtKIgBBXviVFQLSTFTNluZrz+BIzUu7CbY
bXM1MQrUmibuG4s44lRZ7lhmeF13/7ArHi09FcR3wzjfO4dRkQjGA96wb5vHW5UwF+xAMJN5othv
0FtnF94xd0Bwt/RfV0eYs7OKoog1nCiRbFaq6wMY7BFM+A7F7EGLUtMlk2P77evsXpVMVJbkDSOh
8LJfJSNnNOzdz51oGIgMLsmHRCkDvFgvYNY3AcRYP6LbauqMNJECbFtbToTdkT+HmpC1WzJpi7xa
COy4/sQDfQvi0S7OreEiG2L5FBQ/nbuNE75iGnM71MXAGf5ymtj6tlYuQMe5TWx54vB0hzpdUbZX
YEJ/OX6lVJN945InAF+GIN+UCunTUXEQHdcRzDjjG1TVSLYHHSK/gkkR+1U9lOwnxpCJK0mI0vPi
mAtOKp4+SFn3x9Maie81VZEEiJTdhe7D4k5d3CIxQno4TUTsDs5s1Mm2KFfFWo1r48H4oZ8xvYUl
Tnq7XaJqtNpnlOyZbK65QCLXJhhO6LSrTj013hs0xQUc8VyKnxm0XzfMKEpoQz76JGqj7imF9DFt
BvPNUQzUrvKqbz7iG7piX03OMgJu1oBipvPPJQGmjoBdYcR/Sb6ykIENRLSdoQ+pZqeqVg7SXBFS
w5kD/Nrw5Tj8BlOYknOVUrCLiQaA1/SX7QBBbhGvFH+mdt5gp2ASo7a7fm83U12sITGwxBovk5ml
xrKKdjKTmFo67/o9D5eC/ocCnPYXDd/1g9+/jB1srAlM0xsKEwj7yaRAp6Q5i/P6qeofGKTuZ422
wfzYwbBAOJ2ZQhK51Ey0Gy4dMX8hyq6g73OLo8za0aaD0kRbpx/JpSbq6UM+xm1gmqI6x770W+7W
v+xxKWMNVi7bMkx996wXqh3z452hLdasS0UxFjUOtmVAC4f/1VkJBIglr8NCujQs785K9t4HV9ue
o91RZZ0XKsgA4DoH8EyKDfPTdGo7XIpxpUOhtzB0B56+D6dktOksbXjPV1Brj+ub51mDb8QvzVp4
rZwNLrMilF+7m2YT/ZTllIHC7XU1lgdLtgPXux3Vb1vssKrFgHdo10Y7IdgmQ/3OtAu/GcZh3kc5
fBW8kHurrQnx6+hA6FWK0adBHhHn1qfy1qs6vZk8fkoiog7TVilCxx8lxnT2aCN3M8GWHd2steJH
RhWbIvRDdXkJmZemvQjOZ/eD8P/fY9NowVUW7sk03OsUWSw1jLdvvv9iiSCGbrxn+KiXWqoOrFR4
Z3H8st6Pk9zRdBQ4MrEWpt1mTmCQbAaxMedawN/aBF17B9Yfjnz2Jp215uP2mBpoiRTjyphtPBZn
Th440ljl/8mI0qbXNPYzkotuMDTwN6iKZOCiw1U2nr8OJheD7uJV9aqHs5Wx+P6AUyA3+xGOLT0G
5KfDcVUIALWNW+MJHudCD2Qn+DTSId19vjAqNo/gyoZ9eSK7odzGEcP/5dQyxgBk1GCON7DMIaLa
z3fW37G2jnVwQTT4vOs+mGvWx6TYReWcN9jHmulUAIMkMUk3VBQV4vII7NhM9astidnCwpIlzj61
d/1dDPKdurB3tdt9RlL5vlz1EDNhdX0j/r/eWyjfkwbXZBD0V+faFJOm/51z33CWn5J7f5JxCQQZ
5VDdq684OfSo/gUwWYUbvhfKqY9eRLu4RvmvdcIDB7QM71SLQzwLqUcW8sogN5obF9WAa1hKsXr3
aopRMMTvQSleNC6v3K3On5lXzh4m0c/i+WP1YM5JdXcAj9RqURKawCaWdsbWkbN6wbHGOmkt2+BG
i7TmtMQEVOkCgFuAHAMtLsWEU1Ck2w4yJsznMw1CRVRmqCTAWx4bSJoZK9AZGSRwUEBNlmrSWmNt
WMtVm8PrMyBSDzFBYou5NdEcQcWo7b/zN71j3uW9Y5pKNtr8sGIyZxVrNtPP3nU/2Dp3hGcSLLYO
jF5XyhGlI9vrkqwIP/MzbT7P81mezYOoQcxUaiLrdmqNi7kz5X4YmOfeJdGh6AFms2ZG0GXZtxvd
mhZKGdn+GJXb3vJ8cqrP4XwWLDVL5Trpdl7of6EQJn/7o4jAwJl2CMqLOpajZ0q1vHy/aY2oBl36
JQaP/F6ECHmdNUgyjDxyw2OM3PwUHMIiJkBvHFHgXFkPiU+i5564N2vo/oADSjpD4XdP0LfL+zxU
gdmASqoPYZvQR1SBTapqrHlcBulzXL5u6kZTuc0yX1cGqJN7yc2uPCbwJffzhhh/8luIqv7lKhBd
5vI3gxL0qyd2CsqGTY1U+BHi4QdFMT38I1LUF32B41krpo0aqhuJfF7eqsd2qScu5zlSUK3tCbRI
iT57phLBCB03jaOr0umZ1S/8iHuzu4pOCRs/7RecRLPRlHN3sT4Ak/PUeSbH+ZXQ/ST0BaIYVwDx
686sgcBx6piJZfBe5JogOWvbhWBU4xnQNsaLrpj+uU5ehwz+AJkAYIF3bXTog/G3LR+EkC8XSoEd
x/Uv4u1uGimWu93kuZ0qVfjh52Epf+tcC+t/yLuzCwxrv1P7sPRcD3aH2dZ9ka75hlUP0njAFp6T
/GEF9O8rZFb7IJ29CXB/+5CQ/AaNE0eutrjicpHj7/didb+lQqbuQ8cIWkqQfWKXfQGxHUxYRlAg
Fokw5mYFBSBRhALXcw3Iqq82T3JP/OdPCdFKepXrEuacKvj2GvgfGBK9MqlZvo0QyE++YZX5Ibk7
xdNGTupfbFGgAPimg8QZzxF2cOxrECKYcl4FilTqhu5Z/yp6qHsTyNr/oPsLV1H9/qPAaawQWJUO
y0uSyps10+qaQQ94wtGZ9N+XxQV9tOorxVpSZ8vN7b5xvqaPekU2s1xId6QXMBCZ1u4ufq8qulbT
595+Cebt2lpwnBmHUygtmGMRRFukTnlL8dcbwm5cA/Of1pepIeuJrU9JRlNrcig9fJLJwvLBs+n/
nYMrEcKsIbm2ypj1t35gab6QZWJ8JUULdVix4zLNh52mum9aEDPM+NE6j8/zjPY+uKtQW0+2k/BU
37RP7rkGIfV+cfIHMv2rkYc5xe55vYhjQYQuq4Q1qbNAYLRk0pI1FTggcOXQSZgE2QvFfF6Dio5a
1yhwZw2K0wH9Rqto4ca4nKwn5x78tTk4KYIW1s6WwtsfK+wSFgBD6VnGrnfJACs4CNGiyTkJgZeZ
XEoZ7fm7qRL5DjDCB2Ru44X3r7qYWJtAIX0p8l45Rf0tZ9qwPyv+tYKqUsF/wCEvrYUrqfo0l2ql
DN/veWdvKOdDlwqFLQ9spwwHAkIRLWyf9A1qxFfYYlRcfSvX55xCnfNbcMibVfQ7+zYXP9wugYSO
NQrM4tvPbGnkW4vQ248S6KT3W6huSt58acd43kumRoz5n8Z1WY9eTWb+wD8UzDPGu+dLWtPR71Ax
pGIsxB7eQqROfJCSC057nIgsPP7HfE3xWzqps2XMQkSgi+4vJGsC8vQo5sh35BCyj7oKCmn8013D
uT4hy3V0ypgvAQeYlH6EAnt0UZ08jqcIbf7F2xd+q1lLbS8l0g/4fK4Z8cmPZqYfFT07mBe82KXB
/dvh0DBpw20EyleZYYkrqG6tdf5bwMOlz/fhVEaFeDm1yvbIf+6+AYRKw4TdroYFCN8Mjhk7+wKj
la8A41wAH9pPsJXgo1dDcuNRnAQ66MAcPG31CVvzP5LWWXv7lk6RMIXewcOcVQoggwScykgxsQDK
80nAuBz4rxbglX8qdUTL1247THe9v4WXcnasiQi79XFVJ+zYp0oxCnageJaW9XnTs+anjsLxIspY
8xHciCktx7gogUS4o75s+jZ1Jznp6rZou6pZZCDqMqN8AtMj0VfQQeIIQvWXIXOW470fUrRjSG86
OJh0alBSDoV7mqyt3fLXjXDTxxHRTLX2pQA+LNclcPJrKpLvJN6S9gEdvPKjgWg5DcqoMP3/tw6p
TR9WFnHGvWJcsGLne6i1pDB9aLqPUp7KIFEYNFGGcelZUCTzn3IJRoA7PZgaOj6tiVadH962yY9U
zH5iJIo0P4hfaPIgtJwzxWgZJFmmF+F+xfKrABp3Kxl2i4V/un8n2VlfVZrFn20luL27wztz/ER5
fUTmSz/rsIHFh6gMbACyA9JfOakE1JxN9Qx503J/YNurhQEDX38Ctpbj5CXqM1pjFGuwB5Viea20
I6rZjGStDAEG8ubCPJhlik7YdKuyMRp6W8tqLCFE7nDCdavU6gMoVFdU/rWJAxshI/0uZT/eb/Cp
FiP07yd77k8DVDb+MMDHAg/CY1bLTkFCdjDxGY0zRQpJCYD+GjzKs84BtFIK0pT2x1x9bX+h6Xse
OitsRRw/2gn7zoFaThgUHYDeuSJYcaD67jx5Fi/IXfRrdzLv6Jy6IN3l7GWQsTr1CtslqpOaVOYs
Mq+q4mVFxHLR0TLeRWxm48+m+KMKoiqpDAQQRbBshgSsd9uphV9Lfg2o9Itg6/5pVLsBA6ddOsZ8
dqnKPpVsPOX5lUCeBhnI6eG8/niaOnVbzoTA4iX0bIMrT5huwTeTEJdLAMf09zuiKE+CkeN/4+i3
61qpfRSzRpSiOUs3g8MYjWjleRk5Fwnxv98ubmXyx7GdAH7LINXFezRWUPSVr1RoftsWlLBS+gqL
nxPiNAYosbQdXMRxEOyI5sIksi23ivGU1w/Q+w8kiVcdVCSU+IkiIyO5El58hf3964XTj8ibSaKw
oWlRmv95bmK5THaV8pLUcP+B2AKpKSmd2iElKs6BlzEbPiImEbJf60NdScSQctO+ofbhQ80cksl+
+B/Sa2LLGd4ZkYcMu51TXJ3hTT8W9V3z23kwN2PhwhEc3F5sGbXa+9JeFfNKOeBkKKqzPDS3eA2T
xWHsJUQcmH/6OPuWlBmqA4zAmGYb3bBRl4LB0Ydb52AHOGU1JDh3NnvYgyuHKyzf1viK+QXrRNf3
krE7mOGrVMhH1cG0DasFEQdFGDjDvyeXJAduQoEVtBEIbPczjCkRW5yOakUE3Ml+yse9NruPD0bf
XuEdhU5MB3B96mIXaigQdvXoQ+it4lA2mj21CnTbA4i0sQ+Yz+qPSL+gxacRixY0eNx08WJjgjqY
RXWup3Y5pFYEoyHN3mYkRFdhlf8F7KE554AG/EZ8zO3rV3D/ZFRbzwZoR8DhdJ6jNsVmlb9/jLbv
UlRUFby72lbVjO0b+xOc09shJeVMm8aSdCROb3ImRW7Cjsj13ACmT0DTqatwYOmw3y8RusviuPaC
YqwlGf7JFa0UtWTwQko9SwB1b66jbMnEVhqNEtTNlCBz90EMeoX3oR77YBqd7MDePb4c6eRS44lZ
FabDAgDBUMkHnO16UJgI+KKZfzp9j3FgWfT5sXfbuEXoI5oB/kyF39cra3C9WFNYHDypm0x8KzuL
PLwXeNxwmOGZ7qlb884/nX5EoSrwiKSTouWPIDpH0HUxkOoMJxIonnaA2dEpxvd8vQQ8OlWs38nR
Ct5gsma8jFITWQra70ojIlOm50dY0P7UYcdECpbaSPHV4mT+FcD9dydbZrGiTjSX8B/LgdGQSIYZ
yB0+I1bqZ1Hz6Wt64D7TA032v143AoIyD8EQblB6YVph8xYX0qns+CKjoblmpJ8e8LeC5mgb+Rdb
4WyPZf4uGyrfaaeVbmI/8LXlkcYcPNw8jei3rnpGAsEDcemzAGF+mKm8jbq8kRTKjIHoVIh4bSZH
TCNMlL0i+XK+la3AT8fFcYphUzgG737Qx6UmLTJyLzgC3d+CMu0pYcEQlrFKL5oCoAiHch2kPfll
2XAlWM+P8wRE3ZSjedT19cbyCFhnKJjXhW6kxuhXkmSfZCluFqiK7OcVI8HJKjiLQ/5IaBwKhMM2
MR/dsvfx3fU5Vpvu6jpZjGqq+3WIEm1jQgIYu6xuN3j8jX+MyFLm0OVJxx40k69kD0dqjGil5UUw
MIY6i8ll7Ds39nmqWJlQbPzHAfckHVVS/SxKyY8HR4NgdhgV6ZrQR4obYxCkFa5jM7Mx/qIr5DWn
JD8ck8PMwHFbqjl2+RsF+jBOCwvks8TRYa4w7/+CW/Hd2G8/BYzDy6nQb/MOqJdoBo9GqWMFhRFs
pQMbHWAMUMDI60hzhzfExbGUD/xPdiWCjU+wc/g00kAxlBUtgAdPhMvIId/41qko8/WRbiGqRsTz
3+tPngkFBrmVESYIROxhXrOUs+Frj+WOn9gdH0KsLbOE0UMOrGWiVZU1efddQtQ8ETYveSN1XCvv
bVvcDjCrDhL5qPTR+LMb4d1ZrhrBDigVfa18WIwyGayzXA3eLygjD2t3ld4K0wMXGyMun3xE2RbO
59VDtKuXNGWThhA0doLNDpute4eFURzq1nIKB9K/ySTSdOOSGKaRiRrPNwCkYOWYk0qfYIxJ2xRU
YkfALqhYbrsagEsHrNWyy+F1KKG7/aVNNbPUGESbfxwHa4SN89Iw0G/DNOadggb+gEiFKBYhESmX
Pv5Y0qbRMW2OeMTXF0dB2cILaPbZLIk6RFjUHVQcKqg0hTmIodY7+rhh2Gs8p4hN3i0J9bLgVnd8
bou62dplZvhngIdOwvamO4zW5C9tB3VT6JblGoYzM7E/4FmPHqRIOE8XkbW6YRI+Zr0ppng9xkH3
CQ/PEqRWzFtRcB8LMMKFdU13xs75W2q1sqjU1fdOY/GRxWRqMrMhMSI8nEekr8mD+Tw3s7YURDJp
lluzK73IE0Dz4KATOacCK8bdchOgN3b4FLBrWhYwxqOUt+Pp8VSbo5rHxJRFAnwDvpvzDYTpCWaq
w7Y3W2Zn9G76pBVziHDRl7s7yOaEHit2NVL9OjGN/KN+32w8dDGOblnriT0frZ2PzBEsBpsQ5Rtg
6iFw/mMgUvPStQOxTlNQKY1JCr9FHgN49pr9ffNyHRXwJ34KUsVcp4c4sWxjeVy3NnyFiUmKOIL8
F2Z2P/qqTSHNJxjfqmeV5+U97JW325V9g5gAAnDY+TnVS4N7QPfnMoGwVDdROJu0lfGVvNFaMrSX
Tlo3cV7X8WDHiJCIymzE+4BSCGDJQYxgcqjsspcaPZH17IpK9DHQ8q7j8EG2F2hQ6t0aFbIkH6e/
H+/dQyqZ5u/bCn8ZqKvysPvZbcQ9nES92+RV/WgWoeROGTkt1xUMsXd2mDSPec863Bk1XaO2VApf
H/0oOi5NvG/TmCN/OgT7nA8S20QpvaLQA4Q/4PKKcXVOkouJYsNO6ubWwAF1nx2oocmEvqPGoRxj
wTb8sk/g3/8TuzV1acagwQUZhf9w6OB7Novh9OdlzfVMsbxyg440DYEozF5fkxTKZfpDJ/XaI1tj
S2kKTlQuPCjtrf1+otVhneC3/u14XelJLcndo3O+hlPGFSH0V5jTQvrd1Ma/FI273UYuUUotISA1
bsVBmDhzjUSs4wao8t/ftYj+/yXA0ZW13zr8ZiICLdTo+Yya0WmA/GluXAQvZlyDD2IK93ktB1aB
7yIgo2pStiq5KFQFiglm03UxBTb7r7jf8efbSJVKlL0GnvdO3UJmKRV6ub2hEgqbgutCZsZ0YJBv
HHVPzywkM5gD9wuOi/pdb6HW7lCs7KfFDgxEbyFe3JUlh6TLhw71AkHUe7XlaTJIVQuycqtZAAfO
dhe2LCN5/ZNh2yhMV/dJla6Cho+GBrDthjuXoRrR2hwpXT7LG05yB1HqL+6sS/f4aPY05r63f5gD
TpLqnx2b4cruxpLBEXnF05ui52v51HxDk75M0VMGYS/YfnpcWd2/OoXeUYAGT40vESQTsU3WK6Vh
vgTCuTE0U+wCY7N4wfWol+XnfEEY7lOw9AYqRHBoHF3BFIKvgmANbEqVwAD7lxs6XiWMMeJhvzAD
NqF1tPELbT2aO26+rTtzaGM1CgFLUjGQB4F8nUjh+GsFRlc906qSAv7nyNBPtHDKkrOEr1mmdMQd
JrV3/N62gplNG1IaJDmdHgFkFE3fH73wfFO+NuOb6ua7YE4+yFzCxlHBcv58hz+AOghABElgSGrV
8lisvoRHlV2c+l64SEmpEaOSaCbvB4J3D3dVbSEWRn5CbCcjdotbvERhqWFN0c0Pd1ybBPWtFNTf
+sc8Xoah21Z/GWKY07Qg4zYA+AgIQaBFLoXJm5MSY6+1G2vk4uXOSEu1vMuRIWvHMq3/SeSH8BUN
sWsmFwnKhOHEzGTDkiElv4eCeJ76xO6euvlEOje6PGrMuz9AZfSa0O3li0SpKiMrLHfMDjXjusqB
4Xvf7yL2iNbitKlwrlU/9q8C1qS3MK0L2CXTDZi17H5dC+56gdQ443G0CIBuwLvnsdboJpCqH7KR
eiqUU1rmX3yEKyLzJQ/QMveOrRpT4waWU6ZHmv8hAnU7OiIj4EWHXtfP3Se2gxhpjAx3A3OcDkha
EugVx5QZejXl+bA80eNhZDlwzlWZJKBO9oN2w7qSOMwUBh4rMOeB+OVEAdj01VZFq5ChuA+jPkqN
Aa5gFXEvn+genr2SLq3x+l7v2t8Re6JI+BW9r3EmSAsjRUjPnMDuK6Zq1QoZvBCGhZaLdZEh/AN/
eNxrZLJX6buvnOClPc01WHMm2Vs+2TyBYfRJdgeDoLlaBXI6sHk9Y6Uva4qnbqy9TCq6Gew3pVLp
m7dh5jPbMRNyiXy15/7pA0WMp7U7NlwzYgKUjAtMX+uUwPQMA/6lVPhJlgYvNUmifJrhV+8/R1xy
ywfKfQ8pvnfZOcQoRjr9iOguqVZ593wnv/c35p+9Kimyr7C+fSHSewQJ1fM/OTAQoS9o/YEPGXC7
CB/MkG/+8W2T/mNMAvOql3nc/7A0ZrIrt48w/yfUcz6Ym5sO883r6sW9FHYPJi/fBqzSVGuqyjgG
VLOw/atfJQuJxyWM82N60AweVu7a8O75K3GjDcsphlbXX4pkI4mM1Ofz3+KwlMRbChhbgv4nYFH5
tLmPiH7AZccdGyYvkrc/QEzrtipb6zuSAfIonzWCFUhm3tl3cEmsUDkI22d5eRxuQQWP8Twl/wPZ
cyXDn4nF2VILgZNmXtgNczj0mHYgj+HwigWqAgdBOmdYaleft39wk+trt+A+ExYfNOrYaslSoqo2
ppMCTdnKLta6jy5xEaZEy8MBJr8Jjy7lj+0L5xJU9LLyxqaB1dO1uUVc/ilBzxBLJVjAnJSoHmUe
luKsUwrKTXzvkpTP2FGs6btHiJC6ER6HUvN8BsITTnSmQaUc/V6+jGkAHrERkX//oYjHIrqq/pdq
9BT1lU9IsuCbZJqEqE/BuTYMu7hvQPvaEsUIVpnhIEiAaEvwgc5F0csiRlgrD1jjeMgjgddWlkcL
SVpVYTsbOZEf62HIFB5GnfZ4TYlw4FD7nul6xN1UylfJr00Ra5WBLxX07LBuqlI43iZ2GfT/yK8u
vruVNpHvae4tdQ59+skqsni4lFHuYmAYBz9GFg586EeEUf/9TBNiIptfB/QYhBC0B96MUfERoS2m
1+RO9Tv7BprB7k0uxN6FsdWOmyMpTvFGkpbUAkhVp8hFVv6zmCFP2oknq/IzRKOpSBpV2wsojR30
jLZMyHClA7jpsfuKhJn22ECT80XLsE3ylDV7IDlWMcB6XI7/LIB/PihEjCKmZSlb1ZATojk0Af6m
oYlM66yAStsW8a2hYgjcLgcGRz+DJY5q+eteRAbFTvVwo5iSpnVfLL1PGbcAuohjKkugbDnNLMrz
hjf7j/BddmOp2SO7LO0lWKwtF0ZJ6Cl0WGig129M9CrnBlY68xdvwExVCE5/TG+7VrEMnUtWjELJ
UIAD+I4dNJsfilzYV5Rby33cCWaAILHI8Ec9eVrXHUP1GjtXmScOfF7Rh47vkUnXSKfi1xtWlaFY
7aUm0eJUoba1DjnkVRaIWsweL8tYTW5xcYJ4ORqLlsDlWMQJxDBVfd+9BnUap2ONcSivqOQTiMlE
EBTe2n1t48XMwpUkWfAVJ2Hyt04F5l/YZYSBfZb0rmaLiJ8IbdrZvtaQpUQIFDlJOTtxzZy/0QTi
t0lBCiHTLCkMD7nEGijQ1OTA0+t/b1VhvYVArM0buXnnKBeGAg+idNB8Gov3LNu5f0ilxIrJtQut
o+5GKGID2I+RJ8MISGmtKF27YfFrGyy1At0WqwS9ftUEmCytHA+kJv6J83n3G/5IetUW01xTguBW
KN9exi6CoufYIU7CgIYZio6GLKstmASdf3PV+9qkidr7Ulx5dOrcH8Lo5a9PnYQ/xeco/+G0SonB
yzViA4w30ZE0Za8Z4r5So6OVNUeNMsYO2Adnk9bZz7HVoXZXJwUm2PoNzhDyfCg1bzXl9+9kkz0D
EiUmWmwFPAvTN+gHK3W1KPy8KiwC8wYbGrWO5P0cM/6VOGOGh1dgUPqxDbr22SVLE1Gh3RjWTJ36
BbEM3O1xtDGlwnGNUtl22gSko8nPx/8XvKn2nng8BHHjIg5sqRhQTGeRYt5lvk5NfroCI8I+lzHH
KvfQURbTPD8nAzvia7en4Pia938HYUCMatXtl80F78ceUBertwTgoXMol+sW4FtTido5Uefnmf4z
aFJWiGmpIbJGu2rY+lcdP4S3RVGMpEzPRchkgyIXwNYbQhuYm62BwOuEz++9rDsPciuFVL26Wdks
YrWGTB6bhGC4thn77KnTEjt1el6PZC4kHJqkU7M/oPrx8Ktw3mOF7XlyPkg/KTG0b3MjOlrjLnX1
j1Fl0Gxr2HlPA226XXXzVzzUsPptNNKOKzNVHyxkL0a6zZ0l2vH/xxrSSV8XviMr7CFLcQlOK0MG
CYIAcrqvwztQavcsBdLTDT02qqh3vtVt/dcWr3UKuLRawTHknc9Obcn7O3cuuFiXn7FdHrpxx7kK
08GOZ07erpTwCaNP4NWHj/Sn7sP7abYV/wsU+y6aVCrNB++BvPWEmtav/Puf4/OBY9eDxhRVzaO9
bWt8kAaSkGgd/ekQunl70ucaXoVp+ps2ILy4he9gkQlNbxqacJXB5xwjVqUWaE1VyK5v7+5nPjto
qlnWJjOLWHfAQCgB+zYG/QsBBCirkZ24MzU3O51xXvq0uZ9VrH4yxRShjZD+FjN12/UqFFoP37AK
kXc06mkR9dSFN21UoDiunLOvo0DOvoJ06GvMJXGbAL1hTTZ1yZvE6zV2wMH37f1iHKNWtwVHoKEr
D59FbpKkRGZrnSlu3ZLKfoauoZ3cQxY0IoH24y0cPG1NazT3SzEU6bZd1gLXX2unh4j/kE2IYLNg
ARRyNzdrL6S2khepbR0HCamdpfy47okQDn0HSPaXX6DPw4zU/gm4VKN8fXkvwOQbLsBxAviDFdMg
47maxguHXL6XNf+rHYxre0k2DATLau3ZMLuIOGbFA7cahg5W8A5MkVPFhuaiVIF+Qn56way25EJB
ZtP4Gw1hayp1zkInoT2UwAU+EaV9hug84wyS2+0uFCwIqEpfWux0uR2o8dYPznWgOmNrg/nZo3oZ
oXGFLLB23bdnQEYqDmtUf+xyFAZc5n5hwJCfL8PaMCYI65OsGv5PnHZqDYsotTZs6OlrNp2azzGQ
9vEM/HVJDL8mHIPPKq3IbHqyPymISw0lujmUGQo+891OzUjO8GuLJproDFtpltMBV8gaqiKwG7ZN
p/MlS6v1dPrjtoB3qNDem5ZnKoKKQvtjAP93WMPgm6YiyutCSCrA9hN1CABnUDImVUEFtXjmVRQ3
q4ynXop8PymdrwlwlYHzB/nsG8JE0EclnAJp7OWb3pUsecMJgjF/6+KghAr7LbhOb0qi+1TGl0TO
NFWU+PydK8yR8mU/mvrTl65bncZTASWSkas2cqqXnEOxvKkcWHjWzF5RB5BiT+g4ezLBcXJHEYBP
0VgNytqoHDUxudWkXgVW8jUQzlJATYTfxGTqIyHU9qto2Hhjq5lZNzyuertdsHOdT8usM/W/26Pm
17ZPz6A3ivTGq9SeuJKkV+M4AG5jcQ/yWayzx5kX4ymZqt1lvyOwT4FgxPS0nkwEftsrvBqiLUbL
ASD89wjcT62rZ0I+LHvwVdoA6CW8yW+V7cZxs6teuu6eFZfW4s9eKWBEqxzT8Njzyq37KZ+5v4k3
Fd+5xa6nVbZ2dwlWOO8dYXK/2jiDLj3k7wY2IY7xqgpPHvQfM/ybCAU4OdeTwepVVBPYIYqOXD45
gAShR6TNqSnIrpf8HIv3q5VCqWcunDKw7wzgQvBzvi4Koz+voxdZQZ8IiSk3Yy5iUZvLkdKNO/cl
EuLbrIKNiOmJBt8dZ+ye9+eJbDSywIjCx7em69ECzI+feNGCJdGeq1RGcEpEL7kZLP/SKdle4JP5
8Ki7Wrhq1Lc+YkoM0D7Zydbr/mPPEmzMBxbYVdIpunYC5aWU7uGR2zKTEfAD8NnbJZ4uCUUNBMRX
ambnK+UT6Ent/oTkBY0ObkNpUF2POSDCQt4qvlcR7delewSRjURJoY7LB+OxEnkqitMxD+bt62rS
jmo88CKGdXe3Z5WZ7RsA5ZHOgz0+k4vI59bUmXqk4tMgTZlfiNV6RvfzFMH8PKJlUKxDaRspoLmn
Xtv36CSeqKPMPCCPDztN9yscmJvhugDe9mfwNtn1Uz8gfaEIqhjPtMaAaKa9tMXf2WhhlqBd3IEI
kG88F1rb50gmeZ7ADbbIVj0psLaXlbCN3GGsWD1OAJJpJq5TBsSBfqZLZ1Qafhc1vO46/tNDZKmK
cMxvzkWB/Dsa3FYzP+7kKQs6019s0xmwwKezAr1HzCgjhxBD6R5GQX8NufcrDNLxPXe3U3soGkM2
YiE+wSfJ9nV4l425ZPxpeffTHLIKBoU9ncsUli7mo0SOWONaHO2TvyxH2DF/o5MQqe9tkFskzmRh
dcAOHEHWU4xjPi6aKD3QByHL4UDAGeFMyy6StfqJcK+waECyU0+duLR9zUs2Ok2WC93ZIvhI5SU9
lOaTF7gDTxEtGxsXqa71fbmRJT0LRCxmnku9jIv9OWtPrHzaMbDIMZ8oS2oEZe/LovYjOA5vMiPT
3f/1bTS53UEvfuGQEBkuHQtwBh1ao/2tbH4BhaQ6X8BIj/BqeByOKDhQI4TjlwPYfA350y+0xJSi
Ny0S/rn0xLa1rieuqmGeKJQkqJyQd0O8VnCTROz2d/qNtD4E9rT5jKeexbS2wiJVGX5mzgtxiihY
ubKhxYgpsk4TyGqLg61NkoskdGdDF1YzCjODeUBTCwcFitlXnu3wX7YhTiddzNSz7l0I4uGGQ7+v
UxB6TJ3s24vUtlPPHxkVgsnKT05tUQQBoUOFyd7mtltWo3fgzM41qq8KS0h2hUFJinW0ZxJgVP4u
Ujb3Hd7vNpYurxOHjMDEvcVfd/ZQSUgq0G60gIgor4m+2+lmm+vAcLmqlt+ALOIJwFVHo9YLCjaG
Er1ZuwPIn1U4w11XpAljwQoS3CM9zq8BFTfm6OyP0KgGC8P7MX/y93QVXsPZYnWoHS+PP4R0zZL/
u2fSvanVHjXSdzNfO9996lbzDuT8wxq20Brg5I9GYYzklRHz2pJcS+tt3vTwEzv0f5zDK+gnRKMS
UQT2qqWRdM1fDyl0JPXjQOHXAzIR2urIR3k8QPJlAGVy+d6hvsa0Otnys/kFTd9h0vR/FQ1OlbGP
SsO4UcJt6F1fNhx2fFfCyixA/krKGv0UhvB8K35Sy4TMswJEk2OTZLAKwi+7NLnuh+JAjy9ZDjyI
FFncuo3IwWNUmXKCXyYiBobEgCGaoLY1vAzJwSpJRDOXuyf3lf/lfu4ucZb7KVaQqDrMhe1Fn+hu
wVQhzthh/nt5ji/5QsfHkNBnh/5vS3tMABlJ/liW2dEYBLg3Gh1WibbS5ceywOnAZDJscq+MirsE
x3bviZVXv3UJ25MXGZMPDeOIBJsl8KqnQds/FNp5rj7VuNSmKUxPf3C4IEEjviGolwmWcAujHAlK
AI1WlJcxwl1Gs0vc1TLAQ5FndcNacMsrg4rlQsiYbVGT1baYvqYgGjCdPDkJQowXln2XJcBWY5H+
Iluq0FCXEPHvbcJcuGTW/Q7rI30k8OX7wnfhRG3ye6Kk2k7eFgPZNwrBYUYkQophPjrOlo53WnwF
yLK5o/jlVAbq3HLYU9AxKMofzLqojfFvqaaAJbDVwjH67EpLnO8n+BTz/Bp6dX0h4sxaHwQeiNA8
YFwkyPLtVCu+PhzxOZjDTe8ts6BpP0Cl9DcnzZW49kiA96yKBn6k01IGWz2Zyg8NoL0xqLCSUA5Z
JnquyIW8xuL8Q++Cy0hVbT/xM6toYCWtLlDqw8BmFzeUEAiRg+8vCS3+FhprZTRGViGyjtPzBfzd
ZATg6FRhBrZCxL8Azk2faEthSoLgUuxgV57nuCFtCUKgo7iOrJ32+M4ExwzrTp/bUVj9/KCjAPsh
Pn9U4pA7NRM/k8YtRmVW21/63MSYDrjuowpLlKV5Tc4/1SiFV1P/l8BhGNN9mIlquuL+If4RiXrI
EWLdrIhfBw7NfFbgEY53j42UAeVB0ImOhtgNzHmbmrXn6DRoz9jR8zBFRXDL+qMXiROCuS/uLq1r
s5KN9vyp7t0WXis17z17zcaQsO0d2G5ZCVGhSWjMUEr9wNA61b/RIhguctCWlUd2iUZcBFZ7dYdK
ADfG644l6KtvAtW5DNCs/15R1KDXp2rH+dfjC5aGiHDXhfWiplGp/+1FMR5XIpGM8q4T5FFGf294
UKQWWV31JD6QZFD1+NVD9rrz/+bTv3uOqMKBUbNT2Jb6qy06OyTme6GZgVe1MNCD8YHyUKYG7zw+
qnJUxnuyxUmJGhfuvo44Mj0K7R/qg3I3/aHLZpQAUZajYFvrctUgf2vIZ0aAouB0IMKlP/Udygru
FHoGZ6wH4ZH57VVvOJiMVhL4Am6hJMS2lGM25pX7FkYMC/v9/BNOUFCdxM0XTPVO8+ZaOiJVr5yJ
Fp/Yhi3DG1rLG66X/C6o7RIoDCVEsq4W4gOrNAyk66JjY7lHmHoRSUvKjPXHMVWjrkG8abposJMG
wLaGrsFqTg766STlzMcUrBHbVcLZJguLkDGqjp/oiFV/uFRwIU8I7kvxLU+EB0iBruiCRE2V9H1R
5nSC0vhhLtUTcImV+jfPFn/6O5dxSUpzmLEiyFVWqaAAIa6cqCTrdfVb3kBuW5f+hI6mjrzdCrD0
nxs5BJ5yck9US623akL0G+yp23CbD2T3gjbad3D9w0EwoPIhLuyYX1J5ySMd5eN8qxgL+/WGrFbX
YYJKCAHwJPnHeCRC5GjU+W1dJgdbGo0f/DYVl8MgDCkdIZJMBSgM7y40W35hX3766WNHlQkt5mcY
H7R8XLPboNz8WmiLZWfVKUeP5T3PkAxU8rne5ykr26C0GTJKUh/YlxzliRBWe0smCmAOp8W8Fmv5
Vj1p/2HWoIf+TO0DX+wHJiPqtN453VBg/madeBMhNg2JL1g5yz+++QlLAuS6YPs/iqbt9zm4uUZ2
DnfZB0YYMOaO+noSpj8R7Kc22+9kS/qLZI6PdKrB4MGAPmC1yd6FhFdgInE8iUk/AonfRhQltJ7g
5n2mz5ZUDCEl9ijTc479SSCqiWwBIA6pDn1OBIaeSduGMmvO+IdSBrd3lMiNfnzVYQ1u2WlH3Qn0
QU/iUg1jn3PFetGK9tD/lkHxgn3hv13ZjfRJrqv1B7hjtsyRSdpDEf7Tde8Z+eDks4YbjH4otZQx
2ENJKddrSJHmi2U6AIWHSnc+bMdUep/gGTm5xOqkhRGxv9o8LLFKDM517waH2uVjDxbfxZ5upTAw
93Dz8rJLSNcNhmOkad2vk/lL9UDDdjJnp4G5KAc06z0BJWXZIVZBCH1f9J8dxm5t0qX4aPqSXnS0
sCIncfzDnc4d9iS6eHMdPPcu/iQDWnC+qQ2T7VT9bbQhCUPCWBoTFRE+Ys0PSAEWEtmXJmtCLL1+
eP1+EVHFvpsfgChl/qIe4UHf0OXg4DS8nsQwxD5n3GUvgL9bmb1TDvkZUy6jqf3RhOUzRPgVaGNC
PhatKgBwsmLC4Xf8EfbQqwkdCubnikoijuGPmCcX6MP1ZInrXKHJCtws2CQYacu742TrMkdXeXCi
kLky+0c0lpHehveLRRbHMvxacgJSzlNF2ai7lMQh+3aLwl2X99U6dI7LfZCZebia0cYKsiUDxhN8
fZRxR936Olb+kXKkHPksD5wtD3ji6W4BSw9F7Z0+Ude1jhZln06dSqMd1QCAxbJZfZS/sGwbp4Fh
XY5H+p5SyDIQFlpseHnVse16cWjA7OEs674iVN+6mquQDUg//zAYCVNd1T8HxCHYJRB7kaFVkPFn
abo7yvK16x+jeWBOB5XqUHKLX/I3AoeiM/pvartY6/13J18h+teUxJ/sTLe4003nWlFDywPQ5C3D
RllMmis79ReDsj/1vcOaHwfUfn3FPhoGGAACUDQ/h/wbo/Qe5lW7xh0DsVDJSxtJF6IWBSEB+O1E
eNfQXkJsaBxy90aQrqaGA5zRjZ0tgYDXslPxZHLeGQB+XstdfgVNRRmEh9nQ4USI5RiSVDkRAzVN
crh1M9cyeJvRSYoBIASPu2IQGOBO/8DxUVgWmN9TNE+mDIsqqM0OsORoqW3xrhv+LWAsn/7pzr4y
o9VuR5oNZxUqIA71p5JQUld42NGLvHKN7RfnGDhvFW/r/ImcujSqCU+0vlUlYxo/P7h6QaDy9L41
d9/xfP0o5CooZa+Na+qi+ukWTEaZx9cOZN1CzWaCp8GQtb88ly2Kmt0K5Hfc5j0nL0vNTO3lB7DS
1qhUjZGP7kPodo60mZTowGvZSVMQ4+k3s82JvBl+GvV9N0QC2pEwgVKu9No1jTWV9CgelDW/FaK7
4K0ulZUfE70SBDCxv1scCwFmDh8L3br6snTtXYAnhbqC8J3+ax6s8Yk8fWFtoofklB9RX75mom+U
MLLo6uk+J78bBnKlXho8j4NsOopR1HUCP2KbMigHCHqYk12kVL9dXOCIUo7ytfvJugOKb/fj3BGK
Ekfn5gNsqwFYowGeQy7llLtkRq1fAJzpjMxCRZqofo41sFvWcQshpm3lVG2Yh12OhX5Lp9xUuY6d
o5UbPTqb0s29T0K+z/QVuZn4nfD+VIHAaQFK7T+mb14w5OBUsn/OhBsktpsLnbNRy2VrDnAbIS7v
2l4TgK4/1oIszt/8xxiHhyzOpXxoq6fV4x/J8s7IF53fX7Z01RGhFRK9tZAXTC9rF0O2iPJbuOx7
4Si/F9IMxPNEJ/8WNBy9+ppUxZ1tndhq6aBN+5RNvQLogThmZebrLGbgKJaZBoc7f1ZGvUTT7QBZ
nuawlql+4NhJuK9jg0oHR0/yH7m0UqTJKrjBcXZbK7rz8H6WS3cKLhBBTlcC+/dR/dTrgS7TjLzY
isbufUDBKarnJIC4wGiuSqbm1fy/q5/P5vrs6YUljz0vd9jd541J/AKp2qKDvRO0LRwU3yhFD53n
upElwKhB8u67epJULcd2qfmUJaqSDqrHh94uGMdG6a8CMC6pvtqn5esmNWC37VNUikK05AT/++0r
lBSfvTIncEP/MRRo/dYDxiGeq7/gSKqDvRbrAcDV/SiZFOMy+DWvYD1vDHhufEa0IiHcmmjIo6qs
VzppzGP1k7EeADdbQ0DaNoRzHMugAYT5nWv7/EnToR2qe7K4HrmwaLvv1nIoXdJPbypeLT4MDMcj
vAeGL7bgMhZHCEtRnlWplmDzKlHxXFSIDUBPzSw2Ydz9ckc7qPjhTLHmLbsVY/aLmP7HlAeLONkW
r8ByCBV/yAYkz1QfmLrZcDWMoeXR/PIKQa3FNyqmMc4ewOtC0CPtzeoR1+pp8WBNgXuAH0xWk/SP
/hJoBkxg6PkwFr9OIT0Y4B9RyP9FWKNw7zBXEh73mebSqPU2uSfhN4MlKhZ5kpyRtb31Rran0Rjp
NpGj0dqe8pOHu71QyH6p/CZ859VWMaJCaZkd7lKLK1ItkYvMAvp9XN0/oetawg1sA1ait5MuHAt0
5OiNU7tRxOOoiSCxrTJr8BdXut9PPgIwu8vSy+bP87ehWvPzmf+lmuIPP91jEdVcU+7vAK8N6Uws
jUofMldPg5wtHbonm8hREld0uiObAaNziv+bFnnRtoRfnDxGMvlwhs6eAPQL7iv49UJQcEHd4Q/i
Nbyx1HcreW18IG/uC9gIRlkc4Lr3PTZN1txYlVgXjjjaC9BO/HkK3V8Jvgr68l8UsuVc+J++4M9h
m9V+9M4lHZDvCCM+ZkRxg8uH2BE002MgeA5LM1dRv6XsF9t6ka+VUwtx47mDtYfn/XEdUxMSLuXb
Aze/pGcqilIs4xYex1IDmjngK/HDBYrszXFVek/qjZPe0NsVk3CgYTO+6xPKlgRGwKj7GahTS8w9
UAFu60lrzJflCSL1AbryDOnRHNO65fMkbo8xykFOV1KgCufJ3rBbNH9jHdeCB4Ygf/nfH56s8FOu
lUH5Ks0iITRZYneqiqUEM+z50C/3BR60ZTg0/PimnHOJSxuG8Cu9eQefOfFVO79HqKnzF7IjpF5M
yx+5sK92+x7Y1DYrRxaIguFMM/vhZWoVANG8BfT+UQlko4sgPlttCs77fHL6UaWPZKQJnRR1Ck2u
8GBukGlkgj4HTtMRVD65+CqbiBmCRObXddh5VqXzIAJkxrLU0YRFP5IlnoHk/HF/RtpMgatQB87N
ABtxMSRFwwM8a5VPbz91uLCJLC2wFcMyHhLM2MTRBNsARJHa5tC7DUg4OXln14XT8LNwnSnrqBlv
bH/YcMotLm1BR5YiNg5SU922Zy2WhOjhFejl5C1CK67Yyv/uxHmICdLAZaUh0rqo2JROKPj0c5Uj
s09ohi/Xp+GDLxbN3tI4+T2o5wJmwkPyNnSNZ3jRC+LyqKK1OuHF6zH0PG8VgEdsrgJz9+Ajomqt
x2tTvQl7ZHPzmtTe6gFvMsDqyENvQa4+VIh9+DWQEgViEoQLqeew6m7xqTBKfQSImv5aK/Pm8259
WzEd0AiaUj1x2Zg5xDbV20LXe8qaMKXaSRGyz2nuBwwlHQfBU459A9mh2hXtNtWIm5f8nqkrwHVX
4rTYf9rdb0lP1WXNUfozyFqVweiuE72y+dMy9j/bOzmFDNX6zw/TCCP5Gb7Z8ipX+zhmjFQBKxNn
mIlti0V2vQx6BUZk2fVPMRgYgphrkZ8oUBjzrwhAE0eGIHLm21JfxZ3zPbgSwVyn70MvfKWltMlP
L5663AN3jWz3tzAW/my21/c/j1glx2fJEPuz2KVDjelPNNsn8+EXPfA7uH4Imga2cGW5JqalCMU5
55A4xFnvcHVZMwI1O4kJgq0UMBNeapGGI9JmC7jJv72D4fsIkUCknebLm9ds+GlED36mDsWu5Tr/
P3Z9jl1jGV7gcdcqWAKBQl4xjVoXEjt6jlsS+GPL38uZA8MnPA8tge2uI5NguoER9rNW944Ofrrb
DwiSz5pcUrps+8/FDcj5F5iMZ3649YgKyzmhKOX/yK4g3dA2QQT8LRwE9lmaWj0PND2into32Fm/
Kzky0hxoF8Dqee2fLeyNaptZtH3oNxOip5jh1zEX1mRj2okOfC1ZEk0tlYXU47GRE2kLnnzYHvdw
hKde6GniISNBaAko06vdegj3DQSwjPgeg7PvICWNoJhsotA8EcY6/DkVJb5LlNXRFOTvtMi3MGiU
LVvh9TwUAQykPRqZlpn+P1ItvLwCNnuORGFdKAsbHlBMywfazJTBcMuhwN8Ooj0fgZJ0XWhbwZtX
ThtN1iDcISjl38kEflQwjlWOB3E/N06ge+UdGwz0Tzz3p+LtqmNfnOmIU7NirEw33yGj4gZVhLEF
WTRhbebP9Gu/orxnYc97yjr7EyOZof+lad19+/hj6pPPzxXr5G4bYwE22V3rSNrBTJoEPSu77rzY
Q6KCM29jht8xtO2CliE5uOpyKVmM0OeNfsae4SZSRB8rJqfGRtfo2wMSOox7ZL9LRHNRXOuPqzDA
CR18vYTvhRblioVv6jNksxWZtsaw8CNJrtSf6v25PSNHvPBJfXDiiE8GhidMbY3u+loOwmGwlVGW
jNWWdGDG0IaLX17SnuM+JFf/DLokNsZNJ3ceG2FaqkMmzxhvqEmB8AOGEdbc4YjHkBMvifzORNwZ
0J5mHlAnjWaEneAIST/oVeRLAkADgDEzjzedqe0RyTSZpseqq1izyoNp5MVbztCekBh6acFgy2ER
66KaGNIsHxChd6GSbVzaHfQGs9L2MxYUvRJVOkVloK8V7LDumtSWBpBTUO/SX0e0MKhOVs8dsLZf
4M1Bn5GWznqqs7tqkJrr3WNMW43rBF73/clnEvWAFN4WEqmDZgTZt5u9jVkOk+RvOSWsLNfji5KI
NYW677m8ZurN6p34p5RsFD7jxG6Cxhk0yGQrI1wHIDHhKl6Z7349s8MvshbqHx5C0K783RmrxggQ
Iwz73fjcAIKo8J4EJBrDIBh1Syeg0j8aIT5rqMYR/jF4vujFSyOFyTpm/eQ4Ysjdv45xwKsZHVl7
7MQWqpMPFkWdQOxveuR+Qmwq3Lta2Rxs0gKv8IFW6LGvN8tFzqvlKT3zoLBujgPo/8XBic5ZMNL8
44VHbe7M5qa2ZUeKAuEb5C4WVcbnDYK1Wo0if512/rGXi/n7OU89tKEIGib8yQqeRxq1ANYV5jl2
IXkmjTBf3gYulxqQo6myKraNOFF0RutymXx+bnSF3TvmDfGSKHclBu/diEDWee/m1dzmp/1LvOn1
HqEJh94GheeoDFw7kaXgZwuMU3W3D62y+m8sGrHyMImOeGnNErfqQdzYxh9dQArzvWxnxsDPJonp
YKU7XdpDhDTM479avR2M6KrIAbHWGl+F5N9KHQQoW8LtBTxlNisZ8UOHnBhm3W+kWdez62aGfjVt
irM5mryfxxzRPaIhC5fZT4RBfcPQPtOepYd8aem8bKsIXQsxytxMnWFhKYF5HdiFZBgvOZBHsOld
K2c0CZ16aMhCMWlR3HT7K2uzaDnclRGpusP0kjNhizi9eOzKWc3emCUmDtxH4pm3gM3HL7hGH+Wz
v+JH3aF0Q92BFoOLXftMR3K0YGp8+KohD5RW+5ijMn0vFIlVf1jYfcCOWQHfx1qd/CPLLVI4Swzl
wHZYsokvnemYhXzd1s9SQ0jKCzlRrI9vToHULaHlqVI+w6evXpVIRPNJi4fH8PzMajtwMfjkuLIW
88hHaoEtnQ4luERnrvV8me4eBa9hgLTrODlLv9mKvF90NPvc0ucz3tATA/2ZgNOGfE0QsERqOe5D
Os+rrNvFvZqY1Spz69HuUL26nwZGnMjSoyQ/haPr0V38bZicfLx5v1aX7POYwJ5tDuc40Dw6p22P
CfVbLOx8o5nXEP9LazoqKNvh+h6oGtLcOXMqh2GKLPx+ECJy6nh0LgkNA0+sz2soAsPyTA2pwL9B
+20FfNXumLBYB4dF+X2/GgQtEVii1AH8GYLwg61UCM3e2qhmzHjVZAxp36zRpWnok4isZa75Uh82
6H/dxyawxnntifNIg779G6g8dO/GWtlVcBcewN4b3GPRT095jc6T+9id5D+iSRqbZI/vLeO9zzH9
lA0QPfH2fN/PPLIut7a9G7nne6GXYe+M61VoiQoblZ+zE23z/kXnfulW5Drl4/oNuCPAIVDS6enM
Q3G38YXI3InDrqXgxrNTXcduOx/NVWEsqg2JTfzPMYtFQu6TFHcZ6TEGha6/xK0r3yePI68ov1YT
pa8UZWmOME4dmRI2A01/eHmjPFQGQqtruFVN8XdSPlcBZGY82lc0/2/Yy9zP+yTS4Jv3aluoaN2P
PpwD2Ru/7sxAg3ZJfjTzYEZvT22T7ZLOBaHTqZexKO/r6SzYEISI6J42d82dM9BOZ3sCF/IZkfYn
DlCGTVDckCC4nRSpNrAhteYN1cUSGFs1vzE1YLizJHIG3lzwfUJBqD/TQUja7BikSDf5lDM5yvS/
GcXrh7iPAhO/6bRA2kXlBNYXYbAg0CXo/VLbeXcBGPgScEMgYa9qIwpzQ1jEEedUbR2vuaN3MmEw
wvJ7evej0JK0n6lfkmjeojRsu/4tFu9e6OHfKWuSTByl37i2J6hh3pkiUKF85AUba4YIUHEWRDOd
/dRYe4KLriYCLS+SOPgMOE4yUlWdDwKP4wecxzkf/qLGMV6sCt4odST8nVOzhIQVuWrDR82sHATa
xwXMvjfrQK+yNyFo9Cd9sF7QTNOuJxN3WdCsodrVralZGWh/NNmpOuHrZG0uGAkv+uLGGYMti+Zp
QOezPahfWZ/MUCsPaqi+pMU0u9bNpR4vJyE2LmshU58Un7HWJ/qQzHO7zA464q4a2g8Azxy5oI4b
jkoIkZbpWwoAaEGVNARioLFciGbJNTv8NcjNHVjuZCc3eIKNXcVCGVlO2EAAn4uNRppBeBwxF+xC
D6WWnNm5cfb6v4KytY1I+GkyRCbXn0ZvW+DUBlgLj5G9Lo1SaQWmyrHKUTCy30W0KIAMBj7SZtA9
pl2jccyc4d+JOHtVs+Snu/g8gnnI/7hh6IkON15cLtD2URUWqSirzvJVfBrdQEscyDWkvmG6BLl0
iWYTEp3yVLnjzdXYJDnQbC4ReMS+cy19Bou97IWZkBFZEDD1JNvB6Ka2zGOVvvht3Ef32Qqimilw
/Cnqk6bJ0K3hVGpPmkyitm9hh0m5HpcL0JQyCRJPmmBTfMCCsWURlUEnT5KHrRyemfu4jYcN0zcZ
cciF5gpJtOsyo+uPhEzqgLSpJCPvtAzPG6TNZb6OX64yIaE6DT9hjwJhgmvkpcKMiaj+Ssz3Jnno
52w6qDV6OTT94QC5dM+bDmP8k5gPaVkW3bLjVVY3fzDEF4zsGtNPVEtyMw8THXQxMITxCot70Ipq
I921bKxERr94JLMpQ8kwTTCg8+KPAyigWcORyvUftJ0HG/lRGjREkFheq38wPEfnd9zb2fAXfr7W
qN296zUsXa5Z3LRdZaUbEVTyh5aeE6mNqjYwZEDala/FTcC06GuPyQxGl0iXGd3qmNLFRVsVNQF8
Q+0XadB3kKu8Sy8I68ruiV8EhHKVeiv2Ofl9gb0iSr/dAPWlwc0bhqEpJjZ1vuRAaVQTwdv9U0Rl
I16yakCd6r69nedPQpOklwykOTR5ZK+Ojw4k0BRmoQR8n17dnSdUFuwC9CsMBt6VG3wpsGp9S0rd
6GRZ+biQDcDIWHmY4MEDDgv70fiHaM1DMaCKlHzLYI+avQYcpX3C8WI3/3AeOMd4FhTK4DkyIhHD
rweD+DSE5It/s2BBj1S67Ob05NzwaNY7TgP80hWq6BxFHeWWgNaHAmirPHIClqeFtME9FDgTvRof
vCsHqj9kTPhXsbpBYNKUOxijpnP5msIiwcj2Irf2w1wnSTno2thsQX5wSKmHGwGQrZDAP5ghZqiw
8SAmmqBBWJV04GtfGhQwa17pM90qFTX0upXYECQiV6TpNeGHoG+3/INhVCFIc4Wnr7bi1lSuCnxg
Dm73oZU2+2EBz+CRLzc76mFx2WvczPCP0IDOryFsgNjkfR4YUgkGkkasyEQl6SD7N70FytrXQeIo
D+3eOA4Fl7QMxl7XiOoCyBoHdC6NCXvXrywSD2+nphkQU4geQVYe+j0KUe6hRcSDSCk0D/+Sl1qN
n6hPjA2pO3Y8IMLr61ScbPMAC+OTdx3sAUmuUttc/LV2G/TGXgOwNeN2Yu2HVqjpVnMWb0DHT+Bd
pzsvu25Bff0c1E4tH2HVC8PrLdvQYe0amcesHcVJOL1sR0J45NsrqYiGIZQRl8KBI47w0e2tP9Xy
g+i1liaN3IWy1Hyca/Oj1nWD6bcTrbWrFi0VKUUsyYKCBJ+gEbaj92P3a49/O7jYD3rM7THgqHe5
LNcxVQqNFg+AIiJmibzshtbHOJfEB1BeQjk/2Gnk7sFUYmN70wlK9jjKrHr/IPxTJ6lmMQISMlGk
Dq/sO4cx33Qev72OeM+7pn4yX/GdShUz5C8y1kkHMuwc3APxnzpNZzctcZqcB8fGiyvg8dI1oXnQ
j62Y10WzybdSRyeGDzxd+nVQQ8joQWUrl9UGqUSZT4Ge4NK7x2qZBnOtekezFRfMOkmC6jU0oxFW
ydMLPInZ4MDtEIvNYliHYk+3ekXgmNGjRo28KQamAIv+0uayTBgOQilqdssBCwoHoNwSED1j+PKT
jXVVFfFFRBeCa98QpmTSWI/2TkophRKf2XlULArNpBALi8ebP38CeHFw0ScgVHfr11z2hAmL3M2c
iSqgkCHM3Udj6gE+icIO5qiLlgCA2PfSiYK6PQGYt7z0N3MO6QDOD1bgPF0Y2zj+0wUWdJHETJvY
bDrOYyYJAocqh964GlEpFJmWsvdyJmDaFRIK/zP8hMd4C5lV0zNM7rHvIpV8uk1XYZOlMISdN0Ke
lTfzlzrizE90pKXCgfiLZ2NoLTm1qv0zuipbXERWgC598ZPap45gANlTb/gt7WQUeXdaxEKQ1NGd
E52nQpm6AExzTcTCJGD+cD6imLYJy4MNF77D4uEPSmVduF4VOu59qrmwk7g8BTndyYd6sQ44hX8w
pTU7DHn6RBkyMEs9Mq+vGZEqAE1qRVb03u0dps4RPzDze7TIEaBOYZHTMKH19NTat5+Mm2P+OAqJ
Qn/lgQeBQl9imTf6AaG7ttWJ5z3GLhbxO74tTJ4TB0/6j2cxcg8m24/DU5pA+wOek1kZFmDABweE
JLBpgYpXkVq23/2pZo9cCXlERxNYHSoBp06UEVPhA32ZjGz6gfNhZ4eF9+6PvStcTqjJAhlsCS4W
B/EoGyrOiqQrTtmmhiuGpAAFk2Hh7NLfcbKqdjmHv37r4lqpElfkaZN1imcsHXAr8O9YBbXhcc/A
l+PkhT2ou2VLAxhysTOeXwZJFE6UVM/845MBwCasaUABTkjuCOSFuI572EUSFqXJ/dEc7D6bfVlg
DysogfqD6eRKLVoDOyvqvDuqbWPMEDv/o/qE/n/q7xidLaey5gYkFqKmPiKXFWFICxcXa98QBdJi
UtetLAUUAxYRKcxHi887qwMxV96TGk71JyZD//H3jMpLkemdMHGi92aAJfo32Hfsct4GemiEw0ly
yQW5Gq7MyB3YlVEQdEwwsF7UtjmZYNZPgZYXN0OOVs1WNuZ5jbnF5+gXruPWTke+lL6a0Cyzgi4O
9sNhRyQAHh6iO9r+nIB3bzSIhmU3k2VnvKvAAYRwa1/YxrC+EOwzAPXiJTIa6si6DvsIaHBBButJ
RhOpqajvnFxpjcA4sEdAjLnBxyYtt0KV/wQnyYCeYoqQcTT5quEs+AC0RwHID3bUwdK5DBzb58Cr
9mFbJTPV0ejM8jqqkaC7usbe0C7iKleljjXsCOsZcwIp70zVq+GeSVwx0FCWX9KFvDHUaYN2c89i
GgdadDf5Trk7TLOJRhqWn65lSPdOSchwW8xAP4DbFpLG0s1EbfHF3G7XAChJZMcMG1TCscdyFOjy
z+NhmV7+VJCbkE7oAUGZoJoBb4jFxuN5Xy1TpFYhEBSo//nZkGWlIbDkp8A0lZaq1pn61sSMR/id
j9/2VDCsqWQtHxYiy6M/jVOmvClTPlrLLMyBWX3pWLJhF2HpyQKN9epuSw7MR+WOK/hefVYJ0Zdm
4G8xz0KEcC5wshI6GpiuhLKoJX1bIUrRCO9eYLB7FTmzuQyDjVkaPKswgJ07qh0AaZpRhB1D6prz
huFSp4ucjqHyVQ8KBcYsd0ztXo2HTTsNfWfAvl8jk3sm53VHPRrP/duE8n1NJdFaoYg2wSflhGg2
aJw/fYMUNU0WtsozrtZ/AKodHRYyYNuXtNUsv470w0KPT6iV5bEIul7oggy0oEFjLz6AvDoP1RVi
tpONM50yHSmAKyqam4Y4Xt8Ag0G6CR/s2vu2NqZPyFKLvZ+6lTfn7u2lL6L+4KTEMglh+xavD6Wl
2oK5Y2cq2kL9Gsj2HiNI2P6uivvFtJKI56BhXNTmPYAp8lM/U+oypvT7VS6e+BcOc4LrG9dBfgYg
GjIymnDDOdcCXNL/6Ew2RgMVbFm/TTIMAipHrAw5w3ddaEy6vqxwhYSTD8+0ELAqsshw+1MoQtuB
PpEcdx2XSWzA6N+wZ4C7PNs83DkQHlhams0GhxGNHCOn0vea5FYIe3w7sjNwFUHNLB4GPsBAPbUR
pjIFhxeSaSOL5WJD0l5+ga3OeTuvtwvrYl/B4Gfly1vg/3LM/VWxr3qYDKuMsb/qzw98gTab3Piw
T2h+GW+g1GRlhNlKrRCeMnsyyIeLMWZle6bHNGB6CKR4wtTkYYlAgnrmgQuM6dpT1EW453+KDXrT
1QpTQ8W2aZsEzzACstOJ2lN87PfD+Rd56O0c4DySIZkh60r0VtE0JWrUqCxftYN8K6gEcr+RUGp/
DtO5brp3Ks3eGArsfQ+tbgqfBW0Dw4rILyXgVmd2cFGCC7q/jjkZhPhPJOAFBFP7pTIzGz8mP62n
a+s3Y4mhgUENpVMjVg6ynybqeFzAYzuvBq2goHgCaGOdPMbR0k1p0QEEhUGJxy0s0LsK4/CPsILG
9N7lCOl+HDzVHVLPzDu5WgjWmqLM1kA41Ylh3UQ+1WJebcxJvtDR1WRcWYpfusHIKCq9yCspf9NS
Cy4NEckcw+Ez/tAF7qDqRe4/6ZGyn5/iVCfziSmkumUWKNKUkX81kQnk4S/zMjlL5mY3t9iitnEf
0NGE0rc5wsHtPEqYMVwBW+SY3XeLgoQvqzgrcPKYuEToYGcfLJ+o0XWWf/OGeWYfulQenhFcvfgK
DbOEzkgtq42pllBoNJHcu59NP/9yzfwBs6F9/nC6qusXYI4iHk5eR6w4YU0JbpNjxKWSPCNyE0LD
YAsoKwHnBXdoXgxpYhgsNM6HOXuHFPSYdcwN/LDy5qvQBVfNnxQsK8qPIXToNz51LUUA02wsAd0q
fdkYn2F2Dx3Y464k+QbDLn8aPZrltXfUGHWqlobPy5tAAVWPhMkT4tz7Vot5yh8yLEC/Q6JFGVqf
6fr84zez1X9s7qJ4mhLnLls3H/FJc+0cWnLAfHv+WDM20BPNgBNXnCXUf6Zep7bGXWHAnnyt6JAg
vG6JP5nWGdKe6crMs8u4qTu9E7dtHO79uqd5hWST3LXRjSAaPbJPQkPLDDSlvQrbZ5SkcoigZpma
PMMfLY00zp6Sxof6s8amQAhanRY59F6e5pIr/muYHCC2Fia9eNyQ7FfEHl7sx+iZ3d8JDSf8QRCA
WWh3u10rFZxNG0BjhGniPJheGAJufh+e89cFAhXGzAqSHrosxIuK0aO2otvyOOI+EZuIGAuV0WMn
D22lsoh9VkZSy4crtsAV19EWZ6Voc5HNoQFa2eutnJfhcfprTrmWONcGHQQQ3Oy45IsLY8/BTMji
xxyGH3TFoSzkvXC5ysk0p3o4Gvt0uPVCdeigbtvsEzPFf54RNWPUaOuztJ+FF+NZatmyTqzKllRS
HFLNHLuVB0hcml7Sgc48QMlpRZEIZBiRuTeeShrv4V+DPyuieSnfb4SUs8+05+zl0W3uqV6EJECy
T6/3H7cf9N/0MfnxKoofTx12Q7yyFf+HFNk0sSoimfTLHsSWcpZT+f4OjqQM1mIvkrz94v4uFrv0
jPewiwdxVGE5GviTEsyhegfjJrc1k4mq4qy0FY22sUvSSo2bcuTPmpNxVIQb3wt4vm2vC0KK18TA
mW65EeyFG9hFd/niH5rdp1RGz2/Id2eKs8QnGHwJoJJ9Ei27c+RrfUkc96ChmLGxdX8aiEtaiTH7
VwsAVjql88C+VlCcxOHjdw1aDOEoLJE2kXsKrmGU74sPTvI1s61zafO7gzFa08b33TpF7YjArico
vmPgp6740J5/jWXsOzAtrDD9U1mxGySknWN+vjcuogI20+ZoCpsyIrQ/ILctudZgyMccCgdBuL/A
+LGSeY0XwyzGkNICUrtRmSFoQTXKe4pM3o1OTIZPF+H6nJp0kvUZgRtLuwUsaqhjQJBKS7qTWjel
6Er6GoGgt8/p1RUYBOb4lz450T892IUlzFlie8nZeConGM771PQM6Bn/fgFqq/0m8ULh0dr+sRtE
/AkZHWZk3tDZwLZC8lCSt0ulrEEThekBfBIy62Dbb9haojUoTismFKR5bf5JvzOZrWOY7+buNppq
8GN2g23TLqiZlfk0MHuvuTMoUyvA2bgPG0Jr/6a2ArDv4KJGnyn7V1RQ5ziM9mXq0gcsZEQLGY/D
9Wx6Xc4HAkzCoHwA7Gk94EFDbg2cpLaB0RmE69y07DToujIhUiEx1f5LryKYuEh3wLAiGKkIW08N
/4bT9d5C2fu4pJsZEka28T9MgzRIJs23oNe+Wq341vysBRtpPz2JRxU6dGINGnUmsfxiNUxlJHWr
7WyAwVe6+ueKXLzikHORi5vAe7/y8vAWOreFRtmDljqhlxcY40zGNWE8Sh84eC5OLtiT38okZ9W2
0BzrtVBZv5Pl5rMuLALZvj8zPMzJOIjjsB7ypXHJ9G0ptSE8xngvP6N1khBH4YvWu2KjPtLt+nGx
9w/dHm/IugKHvPk64TrK1E3Gs+VA7398F7scQBUtkQkYJ0kTXenxHuTdEXOyqJHECiQuTe1wZZY6
OwD4gDEIZHln9vAeCQ/USgLXcDfLUbXlGhy8jB3LDepXUfrp+TYwm0HzfEHO5Q+yyh4zICIKAoz0
Kx0vhd47dJ8xTDd3gEckqEWfOksRrXwbT6O9fZErz7C3li5dpYYXSsVsYG4XHKOKDIJZ9ztptkzN
RIengR4j2rRn45L0nILLwh2ZQnOP6cPKsEBL1LkJ0WBsJhL+znqZMKJQ1LyMeo1e+d8hCSO5vJ5t
/zk/u4CiMVDlbdoBOaU9cJmkNf1tUaEeOK7LffzgkYSZygIxNMPVAlM9kpKKQTBajgayFE58WpG8
mmHQMzip5PSRPk1dSbBBj+nLwC48Wpi/isiMW3UZ6YCzxKOH+g92vcw3XBHeBnJ/J5LoGNF0kpn3
i9AItxN7CdZX6bSr8q+Vc4I+Zw7KZ7+GyWavxNRHCS/8GpD4wIKsK1rgoy76Hb224qxGWhN+tPTL
vIIkdFLqOXjGgEBFcYA+BgZQny6gsET3L/7q12ae9JrfK7sG7lDhbdkqdaVc7q6AXVfoZumJSaEb
PRcE+yPTzdbelLOduz1oc5TdmvA8mqIUs3gsrxetwrwp1UyXTVEdL/Duz7gfbuzzqxYAYTaC+G3r
ungbNq16sc98jRux0nYTq7XguBAhRSLgB13P3zVUyN8O07rWLAyEKPj7RFaOvbC2dwGvXlLeUDk2
D4KKgqQuRvQ8QmpX/ZbskXaMecNRACm4n2jPPk2nxEu9Uy/scUNOkLU0pE0BS1zPRPaTvxpS/qML
LnWW3SqcMMC0fbfSicfNAUhRLfWH0U0R8aO8WQyHWga7Unb6bLmQ5Zq0qwMf1NgAaEnbJ6n2xF57
5dVk4OMcIzwLH//JefmBnvtx4lc7hLdSk0HcoubkLyxFlPxn787P2CAJnY3qgHTMN1wkZbXTI8ol
5eWWWe1ot7koUm8p6oroPSipk7vrzuNE7Qr5xd9IeTEZnyq7ZZk+TPzCaTDlT6kI4S19nsPsqK0k
UmXLBfWmGeFZBtd4UsmSMgSDON3uNt0OeSjB+kDn78JY0IBz9ozdz9m+A4K7r26J+6wj5/pcNijA
xqyRAcGvDBuTIYQ03dIavDr3OnPjvEmKa6se2j11+pTm/kczzQALIeaapSFbj8vJTZ6MjCA5obd+
UrfvKLjsAEuav1FRQZKcFzNzAJh1iYAQxeyMoelkAZuUeTuL2ZBfNH9Nl4IcXRYEGM8x9yQ78SR/
9skJKVhQ4OpHy35wSa/J1uUCFWquzYWYFIQHgM7cNpKcC3bmFy6K3VZdT28Kwd+hZJ8hY62AxJ06
Ofcas3JxTbDdxX/ZJdIVQJigsgZAxrYG9+nHo/BjYFzQsV3btwap7JM7N1Iho5g8qoBWOpbYu2ku
mGxd9nKNA0eXlo1Vh5OFSCSkiiDClJAFJZJrgdTkoXBquMHEPnswolXxAWeICzHA0T6YO7i22lYP
yrluH/Yr8LJS+YITqplxY60dT7vLsM3rT8fZDM3QcJS9NKCCEXVUzawHct8wZOo8iT6yagWUhf+8
LmofrbY2YEHyuLxPdJIWGMygm3go7KIuOugEhzF+mtntW+zm9hwL6xGOCALf7ryRuEJRcUVBP7Xn
iY3p7h3yC94mOcRhI1So8ELLGbQN+BLBdBPRVYf+tIwV6c1xyEGKFLQ7RS5n+khasqWpFXPlttBH
SQUAv/wBqxPX2PxDIFZ7OxlgvstCaCZuPj023t9hygFb0T84qLVbNDSYx4nQpsMoUGXDuj6C80/k
WXnbofG604UzKIkSVqhlCpmtZfMiSRMOO//oPbpYCLn5Uciz4Otcn7MhpnhHsW+T0pf+7uqqd6/j
IF13iKnnNpS56THCoSDebqb5ykPWW80RL+vLh2rJeY0lTLz6aQlmgBFBr3Py798U1QRYOE58HiTZ
vBohKAHNCYZG8iBXyt/qUOL4xgN5/3xmaV/MDtaCiTHcXduKD5WXO93rVnrOTEimSe0v169zfcUK
9p6UpkFNCqpqpL4jg4ymsQlbkDdA8FLaKfexVocYed90UC8tI5ygnQGwixG903kKWsLRmZ7E/EmH
M32Q7Q9Wkg70prm/Tg824jrqV4ASKEY1kNwFDtbjnV+p0ySIFcB8sfrXCtwswO2SGPH7Kt6OnNyC
DOc4tlqmB39LiMbUQmm3PC/GlYJOfnmFPUt+gXDliyHSporZVpTGTiBhxMqDVRGoiANFEgzgDHfb
E4gkuZlOTXP7f8IWEPpXA6WrJnc/qtzH7ni1NVC353f4sloMXpY/XlQqvF+kyJoh5byPzIoIOrFd
pv68ZFw5waedCtXCSrXxsKeH11HGD6EceDHE7XcJRi5J00MBuP4zkPxDm2twTzVL1nHpb6gSh+q9
EeqSSlpl4rrXMb2OErQBbx1mIV/oUN7Nr71mLtmtmOWVUuFHKBBZHcW0u1PNlNjvTA5eWtAkoFL3
URb6hLVbPBl7TpAqoWw93sdp2xpg9E4kukS1GbXOwaotOXOW7/BNTk0MjXn/I9UoYlmOzXgtk9Kk
D5BUrs2Fm8xkfh+On79NCdQ0vA/TW2+E21A2+P8o+6sEHsUoOrH0osI/FIE+wDGAfeLkSvPljX5P
Fm0i6df9vumZz4jq2RtZUG7wkXfgris7jqjf2J2lOB6fyq2Gf1THWEvS/rVk9ycE208AhxaNR5YY
wykda65+sHoCNKFwAhgSDL2JJKltxeR4KJskMwtOzcJdipsNSXLOtuvj0nq0ZUgLqKL7CplG1GbT
7f9ML+tZXk65CeQtTKE42SkisgfFhRmQNNXezcLbtRSQYiYVXeWzwwQHGvez8GlqoCVBjYxJBa3R
DY648alB4wyk3Gw0QboI7sRuCMVQ4Ch543TA0AXlkA+BekVdTqC7HGJDnk6MzLBEUCaqDDhs3/ws
PruolNEyJsHUwgbK7axSyEzZAodLURKG1uHabwyxngk+mWHgpywNNM5nRGk5iH5XljNW+RJhQhDb
VzBGFjA1rJdD/OWa/2OirH2kMbQP5ZnAzKANMqeDob75a5UXpTsWOV2PwI+luyXAkph+qTxo4Kcq
gy+1XJQhwAMEHxFEIPldg1dNrhkVd47Y6LGjv2AcVnVfyKPWogYXvK2KTQ/iP97XjZvDcwhawK75
BP2b7djqF5mLvEOfjhoJIiaVkpAZkHCAsjVyv4HdJuQq454yZ7Wibdikz6nWpNA7muNoxWnk/KO4
wBQyd3fAFLMPjNP9ofJkrwWerZoubLKHETYyr4X/YOsTTT8xqNk7ICKycnjHX4MiZJC4nVxF6+81
8dTrQBIs6vq2RAHSsXwxO77hy1H6wmrK0jfk94xtlClrlhkIus3hH+8CwWnnprWpSOAQ8zHGpMmn
tzYz2eHDdB799tpaO0/L4KsNp/S+whbusJhTlQukJgRUBPPFMatUNHSb6gL8LlYqPxHtUZufgpzc
ojBB7AyMvFDehB1HkbicMonHxKQ4RwW9K00hMBcanS7rRrnMF1Nux74FAqi/w1Ha7KvtuFAvOQrl
4LRRvf6fQhvJAZUXrMhYSn0Gb2+bDTsqbimSgC/dY/n4tgnRXKa6v4DinNEZMbvRcjTki/MjJYzK
2HEXjmLULGVQyolfmC+plHq0Uj0rjK9hVxAkJjZ3GynY2tCphynwzwOGWJC0XTFeiNMTI7XdL2T6
d3u0LY4wToIx+T5dmJhuTx0NX1nMusy3Zi3r/S7kXzdHpWfsciCzDUEDW8J81mNtHMsGzVKkCYxj
CmZwjyN6qSoTWdze/6vKp98fAPunNsKbTbQDfSqAeNg8G051stJJ6VEwC4A419HioUl7+ms/xh/0
oVJlt05jlv322F4+ly8cSYskDHcKqHUO6deiaQy+8vwbegyg+1osg+y0V1LYnvr1TcKiyitp3vxp
zHpdoL1QmUYIziwOKSdhTvQf+732WUJ2vmDQCaSV2o/PKrWcb8O04VTJSpLEFZ0dM/SfPmCy9slE
+yebOapSZA9QAjT4zihiix0V9dSiFJTun4DLyJNrNAC5M4hD+XGxPVHMBOao8fnXTcbvxH/RIKnl
inrR5Vee3pC4YPHuGpGCY4s3viep/DWX8sVQ1YvgwJsxredEXn7HdxT8AR9IxN/l4j/JbHBF+crX
WcO1frYfYKJ8dwTUPoEcVUZAPLONrQhVu2sxenVcpcBIePrZfpUjBek5Wzx0RKk8r95P2WnwhwTK
KGjTkIwNsTNSAYfvuJV5oHX6TgInK1hvNdLJH3SpSm1OTY1b53EhSFlzUHDI0pOUr4LYWxhkEdeS
UGH3qn78GOgJvby/xSv9CdZYxaqyHHgQlEvUzYWM4gLIMTM0cjUpSZ5rpFm73x79baWusylx8/vC
Is2I1fFCfK3C1E0GCJB1qw88sP1wmCGJeZaImqAAc1zVm+e80p349n0r26Ea36SOllKYxdOMuJCx
Ket0CgbM9CHPVAe9tr12xKIhpsMCtd2WIUBdt2N9O4kXn1/nWhNOiU4AaTIiZiZegAPnfOt59Q9Z
iMV6wTJgz344aQL4KMGWZswEOs5S5oGPuAf8dggSW5d2fvbbcu9up053r6Qw5c0nvKEF6BJRblWp
SdMGLkr1jgtCneVOvnoxu9aTRdKNW8OropNTP0W7A8oGlf8foNW8fLLi0IskTljWHBYRhkTeMb9K
wIod4bJIeMbDROkIcmg2A7Ya/mupIpc2MkFTZ1hKGB5JWRTO8BkvIfWp0z6R9fnbDjq0Xz6JoJ9z
PCgzxNjv8+pduUIaQPhXLM3v6sAH4nZ6gHYZ5ImPLGWZqS2vtvZOhp4oMaJW7i7pxm0nkKFggt4G
Jp0qZuWtDIXdAR5/mNYD3JczOsWLxlD05aHnt6OrHlHq+9jVjgNr9GmFvmfLEBOUqPr9HY9IY/yf
UkZC2JBXRrX41PYPPOcF6ES7+JDNSmrU2V/nPbGR0JJkETUmNGNNfSOmpeipcKXKZgWmCBcsJDgo
K0XYLOzP3OSTm2hv94ELmofRwh6lEkyPjOympZBh+EQ5sIh0BBlfR3TBCxZj2zHbiUD2OSu667O3
O3ReM4MhG2p5hkoCsfAKXWfEOk458bg7DYu+QVIA+WxMT1MN1QTTewtieuXcDtGADv4Z+JQ/0rfu
xhRfdQuErpENBdzXEcbs8qk5Gf031sGWjm1LoiQjJ0+bJRbI71cSN8RcRSZD8kj6pnNBQ889/BvH
wf1xQW2C7aypBEZeoYc7Aib06eoIyhEGm3zGxqissXMmD8U72ZGMKX5mj0f0S0zYHfgZITbtlfEJ
HXrWtoWlLBrJZ/G7ayqi+ktSuktgk8TbCUGyckB/kAI/ECsf4EycWjtM4fNzyzHOfnUkFbep7HnJ
3AsVSUy7+igjNZqO0joCb8WosgGxgebackr1jygTkXGs8FWLqJo5XNLq87r6DmamXVHzBGWYPuNJ
XAjPbd3kcJEPAA32jsHIsaBGsgx43bHQC7OQWFKGVH7dpJzyjzETMikKqS/Lqsgs66TBoKzCQwA6
C1/RqcST90HBwH5RiHk8DZFscKOBege1zqwZ4titUkET2bgAcpoYbRwHIF2sTcxWPkO6uu0UyM0r
fAbAOFmA0s8HrmhizJjkNJYT2w4EwIyNiIVqrCWtuUgi14bSL7HVed9pEE00i5Qj46CX2KopBJB7
KSATdOQjGZBJfY/UL0qJu8/7Q2R6quAxuZypjljasgttQnuGb6nWPu+7mkhEy0XY0O2Knroe3niX
wKogwSEG4F5FFBNZvlYhoUrg3amDxjb1EtrBxqoeTSpNQAl1q1GM5tuORMSC22tOR6nfgJwpspb5
SBChOpRg/ubcsYvwPL7ayJm8YNSLRV0DzRtogD0cqTC3nb8iygANuFbMRnEOem9SUG8zN2oHf6G/
BglHRa2JzgCfHGR8YBvdXFMpazYcDptwQQuwwbXbrXJ89cyowyWpzFG6JeA8tSQnxzGMHvQVps6C
KtCxSaUb62Cx/c2jLa7phEJpF3TQtJYsLsS91cQJjrlidbwfqDAGTNkFjHrqmwpcFL6sXns6DYzA
jJz33U2fWDRJrn1bhRMPi/pf9zXm2tvT1uq3Ol0n1OltefKapBIdL/p7feePp+sFMhL6U869lWqo
oEkTzsp9O7e8AUkFlWBK18zBFAO0BlcspgSznvY7N6TjfIsyFbai4yWwFZDMzrQOvj6WX7hHsaKU
TLPaJzOjpM8G48c7dShlmeN5/RCjcZe1xkDGfdojX1zohc/ZfYx5vemsg+lG4Kv9YR5WOiDmxvNK
+zGLexJc573EuFGP9/T9HAOSHL+Io64uE26UybMJdjTiQD8lNZNYDvL5qZVI0calIOA3VPiSiclf
OABeL+KzHBD8+KBliVNtP0nf9qszRTfwrd5XgWXq5H03KWoRqSW9fRqTA+mA4o/r9yzDY0RMTN1H
Fhqm570LlgDPj8GwVOprQHoRrC4yaY6hA3/YqTwAHt6xNxKyqjl3X/Iw3a9CnSxTMGttfdpu1aFH
Gf+OICUX3l88P80JWNWPuUAlGA4orYfu55XjeRjNcZT7s8f2ZKsmXVlOj4mCrY6twvF4t37zLb35
npBPRIHvdUgbN+PlWgaB3zvwzUElqgcVklHtapLq3v2sVnqqwcEH66XIOng4Z/M+Z+8c/CkGDryp
lIELvmgZDlhjtANls2WQM2sI+kVJyZ+8xNkm6TyzVOppbv4apGYaFS3KfWxA8MZhgnvCRos+VLS3
uaYjT/oz6HR4cU8DKGMKGWBKPXFVCNy9kLjz4C9AY7E/OMgk/2tQXMkpIQKVvD/i8KVkzWDSNoRk
35NlirXGhV+dPvDPa/FSJklTG4/GrD6CvOHmLkWgVbSrHPSaKiEpq0BO1sw2AAHiz9sp3Agb7i7T
AjpVnzfHZy41npkf4z4zy3alAdtsvZT0f4GIfnTaclUoGm75tgAmj0fI78BfuoVMtAaYY8gWyOFU
C15aWkfLa1X0q9hSdLIQ+WgHQA671hkHUCRDsGHCQKEnQsl6fOPq00lOiWgLyDxbRgwdcxJbzyf2
w5DMzMkh2ZVXsA==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
