// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2026.1 (lin64) Build 6511674 Tue Jun 16 11:01:26 MDT 2026
// Date        : Wed Jul 29 17:56:29 2026
// Host        : amd-VirtualBox running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/amd/training/clk_resources/lab/KCU105/verilog/wave_gen.gen/sources_1/ip/char_fifo/char_fifo_sim_netlist.v
// Design      : char_fifo
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xcku040-ffva1156-2-e
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "char_fifo,fifo_generator_v13_2_15,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "fifo_generator_v13_2_15,Vivado 2026.1" *) 
(* NotValidForBitStream *)
module char_fifo
   (srst,
    wr_clk,
    rd_clk,
    din,
    wr_en,
    rd_en,
    dout,
    full,
    empty,
    wr_rst_busy,
    rd_rst_busy);
  input srst;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 write_clk CLK" *) (* x_interface_mode = "slave write_clk" *) (* x_interface_parameter = "XIL_INTERFACENAME write_clk, FREQ_HZ 1000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input wr_clk;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 read_clk CLK" *) (* x_interface_mode = "slave read_clk" *) (* x_interface_parameter = "XIL_INTERFACENAME read_clk, FREQ_HZ 1000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input rd_clk;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE WR_DATA" *) (* x_interface_mode = "slave FIFO_WRITE" *) input [7:0]din;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE WR_EN" *) input wr_en;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ RD_EN" *) (* x_interface_mode = "slave FIFO_READ" *) input rd_en;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ RD_DATA" *) output [7:0]dout;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE FULL" *) output full;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ EMPTY" *) output empty;
  output wr_rst_busy;
  output rd_rst_busy;

  wire [7:0]din;
  wire [7:0]dout;
  wire empty;
  wire full;
  wire rd_clk;
  wire rd_en;
  wire rd_rst_busy;
  wire srst;
  wire wr_clk;
  wire wr_en;
  wire wr_rst_busy;
  wire NLW_U0_almost_empty_UNCONNECTED;
  wire NLW_U0_almost_full_UNCONNECTED;
  wire NLW_U0_axi_ar_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_ar_overflow_UNCONNECTED;
  wire NLW_U0_axi_ar_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_ar_prog_full_UNCONNECTED;
  wire NLW_U0_axi_ar_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_ar_underflow_UNCONNECTED;
  wire NLW_U0_axi_aw_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_aw_overflow_UNCONNECTED;
  wire NLW_U0_axi_aw_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_aw_prog_full_UNCONNECTED;
  wire NLW_U0_axi_aw_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_aw_underflow_UNCONNECTED;
  wire NLW_U0_axi_b_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_b_overflow_UNCONNECTED;
  wire NLW_U0_axi_b_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_b_prog_full_UNCONNECTED;
  wire NLW_U0_axi_b_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_b_underflow_UNCONNECTED;
  wire NLW_U0_axi_r_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_r_overflow_UNCONNECTED;
  wire NLW_U0_axi_r_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_r_prog_full_UNCONNECTED;
  wire NLW_U0_axi_r_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_r_underflow_UNCONNECTED;
  wire NLW_U0_axi_w_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_w_overflow_UNCONNECTED;
  wire NLW_U0_axi_w_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_w_prog_full_UNCONNECTED;
  wire NLW_U0_axi_w_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_w_underflow_UNCONNECTED;
  wire NLW_U0_axis_dbiterr_UNCONNECTED;
  wire NLW_U0_axis_overflow_UNCONNECTED;
  wire NLW_U0_axis_prog_empty_UNCONNECTED;
  wire NLW_U0_axis_prog_full_UNCONNECTED;
  wire NLW_U0_axis_sbiterr_UNCONNECTED;
  wire NLW_U0_axis_underflow_UNCONNECTED;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_m_axi_arvalid_UNCONNECTED;
  wire NLW_U0_m_axi_awvalid_UNCONNECTED;
  wire NLW_U0_m_axi_bready_UNCONNECTED;
  wire NLW_U0_m_axi_rready_UNCONNECTED;
  wire NLW_U0_m_axi_wlast_UNCONNECTED;
  wire NLW_U0_m_axi_wvalid_UNCONNECTED;
  wire NLW_U0_m_axis_tlast_UNCONNECTED;
  wire NLW_U0_m_axis_tvalid_UNCONNECTED;
  wire NLW_U0_overflow_UNCONNECTED;
  wire NLW_U0_prog_empty_UNCONNECTED;
  wire NLW_U0_prog_full_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_s_axis_tready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire NLW_U0_underflow_UNCONNECTED;
  wire NLW_U0_valid_UNCONNECTED;
  wire NLW_U0_wr_ack_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_data_count_UNCONNECTED;
  wire [31:0]NLW_U0_m_axi_araddr_UNCONNECTED;
  wire [1:0]NLW_U0_m_axi_arburst_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arcache_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_arid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_arlen_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_arlock_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_arprot_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arqos_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arregion_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_arsize_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_aruser_UNCONNECTED;
  wire [31:0]NLW_U0_m_axi_awaddr_UNCONNECTED;
  wire [1:0]NLW_U0_m_axi_awburst_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awcache_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_awlen_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awlock_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_awprot_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awqos_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awregion_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_awsize_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awuser_UNCONNECTED;
  wire [63:0]NLW_U0_m_axi_wdata_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_wid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_wstrb_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_wuser_UNCONNECTED;
  wire [7:0]NLW_U0_m_axis_tdata_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tdest_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tid_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tkeep_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tstrb_UNCONNECTED;
  wire [3:0]NLW_U0_m_axis_tuser_UNCONNECTED;
  wire [10:0]NLW_U0_rd_data_count_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_buser_UNCONNECTED;
  wire [63:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_ruser_UNCONNECTED;
  wire [10:0]NLW_U0_wr_data_count_UNCONNECTED;

  (* C_ADD_NGC_CONSTRAINT = "0" *) 
  (* C_APPLICATION_TYPE_AXIS = "0" *) 
  (* C_APPLICATION_TYPE_RACH = "0" *) 
  (* C_APPLICATION_TYPE_RDCH = "0" *) 
  (* C_APPLICATION_TYPE_WACH = "0" *) 
  (* C_APPLICATION_TYPE_WDCH = "0" *) 
  (* C_APPLICATION_TYPE_WRCH = "0" *) 
  (* C_AXIS_TDATA_WIDTH = "8" *) 
  (* C_AXIS_TDEST_WIDTH = "1" *) 
  (* C_AXIS_TID_WIDTH = "1" *) 
  (* C_AXIS_TKEEP_WIDTH = "1" *) 
  (* C_AXIS_TSTRB_WIDTH = "1" *) 
  (* C_AXIS_TUSER_WIDTH = "4" *) 
  (* C_AXIS_TYPE = "0" *) 
  (* C_AXI_ADDR_WIDTH = "32" *) 
  (* C_AXI_ARUSER_WIDTH = "1" *) 
  (* C_AXI_AWUSER_WIDTH = "1" *) 
  (* C_AXI_BUSER_WIDTH = "1" *) 
  (* C_AXI_DATA_WIDTH = "64" *) 
  (* C_AXI_ID_WIDTH = "1" *) 
  (* C_AXI_LEN_WIDTH = "8" *) 
  (* C_AXI_LOCK_WIDTH = "1" *) 
  (* C_AXI_RUSER_WIDTH = "1" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_AXI_WUSER_WIDTH = "1" *) 
  (* C_COMMON_CLOCK = "0" *) 
  (* C_COUNT_TYPE = "0" *) 
  (* C_DATA_COUNT_WIDTH = "11" *) 
  (* C_DEFAULT_VALUE = "BlankString" *) 
  (* C_DIN_WIDTH = "8" *) 
  (* C_DIN_WIDTH_AXIS = "1" *) 
  (* C_DIN_WIDTH_RACH = "32" *) 
  (* C_DIN_WIDTH_RDCH = "64" *) 
  (* C_DIN_WIDTH_WACH = "1" *) 
  (* C_DIN_WIDTH_WDCH = "64" *) 
  (* C_DIN_WIDTH_WRCH = "2" *) 
  (* C_DOUT_RST_VAL = "0" *) 
  (* C_DOUT_WIDTH = "8" *) 
  (* C_ENABLE_RLOCS = "0" *) 
  (* C_ENABLE_RST_SYNC = "1" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_ERROR_INJECTION_TYPE = "0" *) 
  (* C_ERROR_INJECTION_TYPE_AXIS = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WRCH = "0" *) 
  (* C_FAMILY = "kintexu" *) 
  (* C_FULL_FLAGS_RST_VAL = "0" *) 
  (* C_HAS_ALMOST_EMPTY = "0" *) 
  (* C_HAS_ALMOST_FULL = "0" *) 
  (* C_HAS_AXIS_TDATA = "1" *) 
  (* C_HAS_AXIS_TDEST = "0" *) 
  (* C_HAS_AXIS_TID = "0" *) 
  (* C_HAS_AXIS_TKEEP = "0" *) 
  (* C_HAS_AXIS_TLAST = "0" *) 
  (* C_HAS_AXIS_TREADY = "1" *) 
  (* C_HAS_AXIS_TSTRB = "0" *) 
  (* C_HAS_AXIS_TUSER = "1" *) 
  (* C_HAS_AXI_ARUSER = "0" *) 
  (* C_HAS_AXI_AWUSER = "0" *) 
  (* C_HAS_AXI_BUSER = "0" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_AXI_RD_CHANNEL = "1" *) 
  (* C_HAS_AXI_RUSER = "0" *) 
  (* C_HAS_AXI_WR_CHANNEL = "1" *) 
  (* C_HAS_AXI_WUSER = "0" *) 
  (* C_HAS_BACKUP = "0" *) 
  (* C_HAS_DATA_COUNT = "0" *) 
  (* C_HAS_DATA_COUNTS_AXIS = "0" *) 
  (* C_HAS_DATA_COUNTS_RACH = "0" *) 
  (* C_HAS_DATA_COUNTS_RDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WACH = "0" *) 
  (* C_HAS_DATA_COUNTS_WDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WRCH = "0" *) 
  (* C_HAS_INT_CLK = "0" *) 
  (* C_HAS_MASTER_CE = "0" *) 
  (* C_HAS_MEMINIT_FILE = "0" *) 
  (* C_HAS_OVERFLOW = "0" *) 
  (* C_HAS_PROG_FLAGS_AXIS = "0" *) 
  (* C_HAS_PROG_FLAGS_RACH = "0" *) 
  (* C_HAS_PROG_FLAGS_RDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WACH = "0" *) 
  (* C_HAS_PROG_FLAGS_WDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WRCH = "0" *) 
  (* C_HAS_RD_DATA_COUNT = "0" *) 
  (* C_HAS_RD_RST = "0" *) 
  (* C_HAS_RST = "0" *) 
  (* C_HAS_SLAVE_CE = "0" *) 
  (* C_HAS_SRST = "1" *) 
  (* C_HAS_UNDERFLOW = "0" *) 
  (* C_HAS_VALID = "0" *) 
  (* C_HAS_WR_ACK = "0" *) 
  (* C_HAS_WR_DATA_COUNT = "0" *) 
  (* C_HAS_WR_RST = "0" *) 
  (* C_IMPLEMENTATION_TYPE = "6" *) 
  (* C_IMPLEMENTATION_TYPE_AXIS = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WRCH = "1" *) 
  (* C_INIT_WR_PNTR_VAL = "0" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_MEMORY_TYPE = "4" *) 
  (* C_MIF_FILE_NAME = "BlankString" *) 
  (* C_MSGON_VAL = "1" *) 
  (* C_OPTIMIZATION_MODE = "0" *) 
  (* C_OVERFLOW_LOW = "0" *) 
  (* C_POWER_SAVING_MODE = "0" *) 
  (* C_PRELOAD_LATENCY = "0" *) 
  (* C_PRELOAD_REGS = "1" *) 
  (* C_PRIM_FIFO_TYPE = "2kx9" *) 
  (* C_PRIM_FIFO_TYPE_AXIS = "1kx18" *) 
  (* C_PRIM_FIFO_TYPE_RACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_RDCH = "512x72" *) 
  (* C_PRIM_FIFO_TYPE_WACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WDCH = "512x72" *) 
  (* C_PRIM_FIFO_TYPE_WRCH = "512x36" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL = "6" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_AXIS = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WRCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_NEGATE_VAL = "7" *) 
  (* C_PROG_EMPTY_TYPE = "0" *) 
  (* C_PROG_EMPTY_TYPE_AXIS = "0" *) 
  (* C_PROG_EMPTY_TYPE_RACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_RDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WRCH = "0" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL = "2047" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_AXIS = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WRCH = "1023" *) 
  (* C_PROG_FULL_THRESH_NEGATE_VAL = "2046" *) 
  (* C_PROG_FULL_TYPE = "0" *) 
  (* C_PROG_FULL_TYPE_AXIS = "0" *) 
  (* C_PROG_FULL_TYPE_RACH = "0" *) 
  (* C_PROG_FULL_TYPE_RDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WACH = "0" *) 
  (* C_PROG_FULL_TYPE_WDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WRCH = "0" *) 
  (* C_RACH_TYPE = "0" *) 
  (* C_RDCH_TYPE = "0" *) 
  (* C_RD_DATA_COUNT_WIDTH = "11" *) 
  (* C_RD_DEPTH = "2048" *) 
  (* C_RD_FREQ = "1" *) 
  (* C_RD_PNTR_WIDTH = "11" *) 
  (* C_REG_SLICE_MODE_AXIS = "0" *) 
  (* C_REG_SLICE_MODE_RACH = "0" *) 
  (* C_REG_SLICE_MODE_RDCH = "0" *) 
  (* C_REG_SLICE_MODE_WACH = "0" *) 
  (* C_REG_SLICE_MODE_WDCH = "0" *) 
  (* C_REG_SLICE_MODE_WRCH = "0" *) 
  (* C_SELECT_XPM = "0" *) 
  (* C_SYNCHRONIZER_STAGE = "2" *) 
  (* C_UNDERFLOW_LOW = "0" *) 
  (* C_USE_COMMON_OVERFLOW = "0" *) 
  (* C_USE_COMMON_UNDERFLOW = "0" *) 
  (* C_USE_DEFAULT_SETTINGS = "0" *) 
  (* C_USE_DOUT_RST = "1" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_ECC_AXIS = "0" *) 
  (* C_USE_ECC_RACH = "0" *) 
  (* C_USE_ECC_RDCH = "0" *) 
  (* C_USE_ECC_WACH = "0" *) 
  (* C_USE_ECC_WDCH = "0" *) 
  (* C_USE_ECC_WRCH = "0" *) 
  (* C_USE_EMBEDDED_REG = "1" *) 
  (* C_USE_FIFO16_FLAGS = "0" *) 
  (* C_USE_FWFT_DATA_COUNT = "0" *) 
  (* C_USE_PIPELINE_REG = "0" *) 
  (* C_VALID_LOW = "0" *) 
  (* C_WACH_TYPE = "0" *) 
  (* C_WDCH_TYPE = "0" *) 
  (* C_WRCH_TYPE = "0" *) 
  (* C_WR_ACK_LOW = "0" *) 
  (* C_WR_DATA_COUNT_WIDTH = "11" *) 
  (* C_WR_DEPTH = "2048" *) 
  (* C_WR_DEPTH_AXIS = "1024" *) 
  (* C_WR_DEPTH_RACH = "16" *) 
  (* C_WR_DEPTH_RDCH = "1024" *) 
  (* C_WR_DEPTH_WACH = "16" *) 
  (* C_WR_DEPTH_WDCH = "1024" *) 
  (* C_WR_DEPTH_WRCH = "16" *) 
  (* C_WR_FREQ = "1" *) 
  (* C_WR_PNTR_WIDTH = "11" *) 
  (* C_WR_PNTR_WIDTH_AXIS = "10" *) 
  (* C_WR_PNTR_WIDTH_RACH = "4" *) 
  (* C_WR_PNTR_WIDTH_RDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WACH = "4" *) 
  (* C_WR_PNTR_WIDTH_WDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WRCH = "4" *) 
  (* C_WR_RESPONSE_LATENCY = "1" *) 
  (* is_du_within_envelope = "true" *) 
  char_fifo_fifo_generator_v13_2_15 U0
       (.almost_empty(NLW_U0_almost_empty_UNCONNECTED),
        .almost_full(NLW_U0_almost_full_UNCONNECTED),
        .axi_ar_data_count(NLW_U0_axi_ar_data_count_UNCONNECTED[4:0]),
        .axi_ar_dbiterr(NLW_U0_axi_ar_dbiterr_UNCONNECTED),
        .axi_ar_injectdbiterr(1'b0),
        .axi_ar_injectsbiterr(1'b0),
        .axi_ar_overflow(NLW_U0_axi_ar_overflow_UNCONNECTED),
        .axi_ar_prog_empty(NLW_U0_axi_ar_prog_empty_UNCONNECTED),
        .axi_ar_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_prog_full(NLW_U0_axi_ar_prog_full_UNCONNECTED),
        .axi_ar_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_rd_data_count(NLW_U0_axi_ar_rd_data_count_UNCONNECTED[4:0]),
        .axi_ar_sbiterr(NLW_U0_axi_ar_sbiterr_UNCONNECTED),
        .axi_ar_underflow(NLW_U0_axi_ar_underflow_UNCONNECTED),
        .axi_ar_wr_data_count(NLW_U0_axi_ar_wr_data_count_UNCONNECTED[4:0]),
        .axi_aw_data_count(NLW_U0_axi_aw_data_count_UNCONNECTED[4:0]),
        .axi_aw_dbiterr(NLW_U0_axi_aw_dbiterr_UNCONNECTED),
        .axi_aw_injectdbiterr(1'b0),
        .axi_aw_injectsbiterr(1'b0),
        .axi_aw_overflow(NLW_U0_axi_aw_overflow_UNCONNECTED),
        .axi_aw_prog_empty(NLW_U0_axi_aw_prog_empty_UNCONNECTED),
        .axi_aw_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_prog_full(NLW_U0_axi_aw_prog_full_UNCONNECTED),
        .axi_aw_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_rd_data_count(NLW_U0_axi_aw_rd_data_count_UNCONNECTED[4:0]),
        .axi_aw_sbiterr(NLW_U0_axi_aw_sbiterr_UNCONNECTED),
        .axi_aw_underflow(NLW_U0_axi_aw_underflow_UNCONNECTED),
        .axi_aw_wr_data_count(NLW_U0_axi_aw_wr_data_count_UNCONNECTED[4:0]),
        .axi_b_data_count(NLW_U0_axi_b_data_count_UNCONNECTED[4:0]),
        .axi_b_dbiterr(NLW_U0_axi_b_dbiterr_UNCONNECTED),
        .axi_b_injectdbiterr(1'b0),
        .axi_b_injectsbiterr(1'b0),
        .axi_b_overflow(NLW_U0_axi_b_overflow_UNCONNECTED),
        .axi_b_prog_empty(NLW_U0_axi_b_prog_empty_UNCONNECTED),
        .axi_b_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_prog_full(NLW_U0_axi_b_prog_full_UNCONNECTED),
        .axi_b_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_rd_data_count(NLW_U0_axi_b_rd_data_count_UNCONNECTED[4:0]),
        .axi_b_sbiterr(NLW_U0_axi_b_sbiterr_UNCONNECTED),
        .axi_b_underflow(NLW_U0_axi_b_underflow_UNCONNECTED),
        .axi_b_wr_data_count(NLW_U0_axi_b_wr_data_count_UNCONNECTED[4:0]),
        .axi_r_data_count(NLW_U0_axi_r_data_count_UNCONNECTED[10:0]),
        .axi_r_dbiterr(NLW_U0_axi_r_dbiterr_UNCONNECTED),
        .axi_r_injectdbiterr(1'b0),
        .axi_r_injectsbiterr(1'b0),
        .axi_r_overflow(NLW_U0_axi_r_overflow_UNCONNECTED),
        .axi_r_prog_empty(NLW_U0_axi_r_prog_empty_UNCONNECTED),
        .axi_r_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_prog_full(NLW_U0_axi_r_prog_full_UNCONNECTED),
        .axi_r_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_rd_data_count(NLW_U0_axi_r_rd_data_count_UNCONNECTED[10:0]),
        .axi_r_sbiterr(NLW_U0_axi_r_sbiterr_UNCONNECTED),
        .axi_r_underflow(NLW_U0_axi_r_underflow_UNCONNECTED),
        .axi_r_wr_data_count(NLW_U0_axi_r_wr_data_count_UNCONNECTED[10:0]),
        .axi_w_data_count(NLW_U0_axi_w_data_count_UNCONNECTED[10:0]),
        .axi_w_dbiterr(NLW_U0_axi_w_dbiterr_UNCONNECTED),
        .axi_w_injectdbiterr(1'b0),
        .axi_w_injectsbiterr(1'b0),
        .axi_w_overflow(NLW_U0_axi_w_overflow_UNCONNECTED),
        .axi_w_prog_empty(NLW_U0_axi_w_prog_empty_UNCONNECTED),
        .axi_w_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_prog_full(NLW_U0_axi_w_prog_full_UNCONNECTED),
        .axi_w_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_rd_data_count(NLW_U0_axi_w_rd_data_count_UNCONNECTED[10:0]),
        .axi_w_sbiterr(NLW_U0_axi_w_sbiterr_UNCONNECTED),
        .axi_w_underflow(NLW_U0_axi_w_underflow_UNCONNECTED),
        .axi_w_wr_data_count(NLW_U0_axi_w_wr_data_count_UNCONNECTED[10:0]),
        .axis_data_count(NLW_U0_axis_data_count_UNCONNECTED[10:0]),
        .axis_dbiterr(NLW_U0_axis_dbiterr_UNCONNECTED),
        .axis_injectdbiterr(1'b0),
        .axis_injectsbiterr(1'b0),
        .axis_overflow(NLW_U0_axis_overflow_UNCONNECTED),
        .axis_prog_empty(NLW_U0_axis_prog_empty_UNCONNECTED),
        .axis_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_prog_full(NLW_U0_axis_prog_full_UNCONNECTED),
        .axis_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_rd_data_count(NLW_U0_axis_rd_data_count_UNCONNECTED[10:0]),
        .axis_sbiterr(NLW_U0_axis_sbiterr_UNCONNECTED),
        .axis_underflow(NLW_U0_axis_underflow_UNCONNECTED),
        .axis_wr_data_count(NLW_U0_axis_wr_data_count_UNCONNECTED[10:0]),
        .backup(1'b0),
        .backup_marker(1'b0),
        .clk(1'b0),
        .data_count(NLW_U0_data_count_UNCONNECTED[10:0]),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .din(din),
        .dout(dout),
        .empty(empty),
        .full(full),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .int_clk(1'b0),
        .m_aclk(1'b0),
        .m_aclk_en(1'b0),
        .m_axi_araddr(NLW_U0_m_axi_araddr_UNCONNECTED[31:0]),
        .m_axi_arburst(NLW_U0_m_axi_arburst_UNCONNECTED[1:0]),
        .m_axi_arcache(NLW_U0_m_axi_arcache_UNCONNECTED[3:0]),
        .m_axi_arid(NLW_U0_m_axi_arid_UNCONNECTED[0]),
        .m_axi_arlen(NLW_U0_m_axi_arlen_UNCONNECTED[7:0]),
        .m_axi_arlock(NLW_U0_m_axi_arlock_UNCONNECTED[0]),
        .m_axi_arprot(NLW_U0_m_axi_arprot_UNCONNECTED[2:0]),
        .m_axi_arqos(NLW_U0_m_axi_arqos_UNCONNECTED[3:0]),
        .m_axi_arready(1'b0),
        .m_axi_arregion(NLW_U0_m_axi_arregion_UNCONNECTED[3:0]),
        .m_axi_arsize(NLW_U0_m_axi_arsize_UNCONNECTED[2:0]),
        .m_axi_aruser(NLW_U0_m_axi_aruser_UNCONNECTED[0]),
        .m_axi_arvalid(NLW_U0_m_axi_arvalid_UNCONNECTED),
        .m_axi_awaddr(NLW_U0_m_axi_awaddr_UNCONNECTED[31:0]),
        .m_axi_awburst(NLW_U0_m_axi_awburst_UNCONNECTED[1:0]),
        .m_axi_awcache(NLW_U0_m_axi_awcache_UNCONNECTED[3:0]),
        .m_axi_awid(NLW_U0_m_axi_awid_UNCONNECTED[0]),
        .m_axi_awlen(NLW_U0_m_axi_awlen_UNCONNECTED[7:0]),
        .m_axi_awlock(NLW_U0_m_axi_awlock_UNCONNECTED[0]),
        .m_axi_awprot(NLW_U0_m_axi_awprot_UNCONNECTED[2:0]),
        .m_axi_awqos(NLW_U0_m_axi_awqos_UNCONNECTED[3:0]),
        .m_axi_awready(1'b0),
        .m_axi_awregion(NLW_U0_m_axi_awregion_UNCONNECTED[3:0]),
        .m_axi_awsize(NLW_U0_m_axi_awsize_UNCONNECTED[2:0]),
        .m_axi_awuser(NLW_U0_m_axi_awuser_UNCONNECTED[0]),
        .m_axi_awvalid(NLW_U0_m_axi_awvalid_UNCONNECTED),
        .m_axi_bid(1'b0),
        .m_axi_bready(NLW_U0_m_axi_bready_UNCONNECTED),
        .m_axi_bresp({1'b0,1'b0}),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(1'b0),
        .m_axi_rdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .m_axi_rid(1'b0),
        .m_axi_rlast(1'b0),
        .m_axi_rready(NLW_U0_m_axi_rready_UNCONNECTED),
        .m_axi_rresp({1'b0,1'b0}),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(1'b0),
        .m_axi_wdata(NLW_U0_m_axi_wdata_UNCONNECTED[63:0]),
        .m_axi_wid(NLW_U0_m_axi_wid_UNCONNECTED[0]),
        .m_axi_wlast(NLW_U0_m_axi_wlast_UNCONNECTED),
        .m_axi_wready(1'b0),
        .m_axi_wstrb(NLW_U0_m_axi_wstrb_UNCONNECTED[7:0]),
        .m_axi_wuser(NLW_U0_m_axi_wuser_UNCONNECTED[0]),
        .m_axi_wvalid(NLW_U0_m_axi_wvalid_UNCONNECTED),
        .m_axis_tdata(NLW_U0_m_axis_tdata_UNCONNECTED[7:0]),
        .m_axis_tdest(NLW_U0_m_axis_tdest_UNCONNECTED[0]),
        .m_axis_tid(NLW_U0_m_axis_tid_UNCONNECTED[0]),
        .m_axis_tkeep(NLW_U0_m_axis_tkeep_UNCONNECTED[0]),
        .m_axis_tlast(NLW_U0_m_axis_tlast_UNCONNECTED),
        .m_axis_tready(1'b0),
        .m_axis_tstrb(NLW_U0_m_axis_tstrb_UNCONNECTED[0]),
        .m_axis_tuser(NLW_U0_m_axis_tuser_UNCONNECTED[3:0]),
        .m_axis_tvalid(NLW_U0_m_axis_tvalid_UNCONNECTED),
        .overflow(NLW_U0_overflow_UNCONNECTED),
        .prog_empty(NLW_U0_prog_empty_UNCONNECTED),
        .prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full(NLW_U0_prog_full_UNCONNECTED),
        .prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .rd_clk(rd_clk),
        .rd_data_count(NLW_U0_rd_data_count_UNCONNECTED[10:0]),
        .rd_en(rd_en),
        .rd_rst(1'b0),
        .rd_rst_busy(rd_rst_busy),
        .rst(1'b0),
        .s_aclk(1'b0),
        .s_aclk_en(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arid(1'b0),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlock(1'b0),
        .s_axi_arprot({1'b0,1'b0,1'b0}),
        .s_axi_arqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awid(1'b0),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlock(1'b0),
        .s_axi_awprot({1'b0,1'b0,1'b0}),
        .s_axi_awqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_buser(NLW_U0_s_axi_buser_UNCONNECTED[0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[63:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_ruser(NLW_U0_s_axi_ruser_UNCONNECTED[0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wid(1'b0),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(1'b0),
        .s_axis_tdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tdest(1'b0),
        .s_axis_tid(1'b0),
        .s_axis_tkeep(1'b0),
        .s_axis_tlast(1'b0),
        .s_axis_tready(NLW_U0_s_axis_tready_UNCONNECTED),
        .s_axis_tstrb(1'b0),
        .s_axis_tuser({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .sleep(1'b0),
        .srst(srst),
        .underflow(NLW_U0_underflow_UNCONNECTED),
        .valid(NLW_U0_valid_UNCONNECTED),
        .wr_ack(NLW_U0_wr_ack_UNCONNECTED),
        .wr_clk(wr_clk),
        .wr_data_count(NLW_U0_wr_data_count_UNCONNECTED[10:0]),
        .wr_en(wr_en),
        .wr_rst(1'b0),
        .wr_rst_busy(wr_rst_busy));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2026.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
dGu72XHm1SGA216zirXmRscTLLxxgDIFDG1CSj42adYdijKpZDYj+ILu+mshlOULAXrM6Gzh8sqR
gjkpzk2bTqBXI1oAKib61FH9j0h/c2Kk67bAnIohh6OhVjTdkvwLBltIS6uYCO+SVX+x/uca8x0J
hS271jg9N+9k3174JEE=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
jAgKubpee5TGRufSmwz5IdjfscFwjHc1yqlNg9LUyu5pHMpAQHQaMiQmkQjbj5fYZ5w4EdWylgqy
S3eglb573KQ/3EuMsXaSoYyZWrRaVw28x01p51Wu/eTaa1WdSHgP+yW/req9kXycB+UV1GAU5xdt
108WyFRDRm+c4TRFyYjhPe05qVBC7KYZ6CfomQYV4kev3Dk1ozrvXQFjJjLO9Z2jVTtpT6u7zYIg
PXli6RBthoO6IIpAZPN70vnTGgKEUaIykrsMwErjQiqQqXX0SjLimfTf8oVNXCYIMkkpPo44A8vb
xbUQE2IuuVT5OUOh2iJYNm9np3/RCXO44y1TWg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
ofHJWAAWazm87fhFR2lyQWX4juOLKeKf8hjQHNAv5zwbbXR5g4D/wjJgDTFFbkeRy4XuOyS8Cpev
BFfyCoZybCYHLvUxNlHNlsvvU9Ux7dyWWSpM4N479ZnquC78QmbRrkLsx9oWSlf6Vdwauphn75+U
GIjP2sYPUOJWr3u3J4I=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Jsw64pxYqcqVAmPKqIusKkdRQB4PFvfnT0Euam7IyIPJxaaaeu9ieYblbNy+y2oJ07eQr4LN1EIu
evo6gymuqY/LQFZ9Nb1yy63anHFP1AEw0+0zjJv22W/RxcWecu/xxe53akubf8kmiCLLjcOEbvhr
WUPY/11WLHxq1gnwIp5yO4Xk2Q1vu8wH21rHC91wgHd0IsIOy7bzkDE0bpAI/4NU5SVOxDqxzLuA
KsAt5tHuDweZmpJ/rWTH2oRh2z7rXtQxcuMko4ci6I8glBCI7XAugBbCH2BB2zp6UWIfGI1rQ0vX
zETq+wfrAzdwZTdu5INoadPCTe6lslTS9UAkiQ==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
awF0UjMZcCSeDeqx7MRqHHTRr4vMwGmArBKeAVuvTLkLc97chMMEhaT5MZwPl0YnpWSzzmOAxmsv
CxzAjhssr1Y+4/PTt6QKEs9tBg8Za0PJuk6EhTTsq17Dl9znTn4YpZeqiwTqZAhmCiDSybWzoAtb
3xy/LiFqf56ZS0fLgU8rXGpM1J6fl3qCrR0nNMU524RVnMx17AIqO74WrcpwHtkNqiBWMBNAGSCt
sPBAlRHAaRn4xKXgRP8hiLg47GBEBgpljP46iiQLhsJu8SDRRW9E0u6G0xJWTgT++sW7EWtcWj4T
o1p7FJBZmE2TXA2tDydEDhuak3qEsUx9bo+E4g==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2026.1-2030.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
O6g4Bct3AvdCEa0UcYgIOeIRMvgI7hOrs54EFTgH0vBQpYdL128QBUfbklS1zJAurm5FZvD6LFF1
bdla9ZI2NlvhgskosJM9NpVVArV/DbVEncgt9XJhTT3OqhZdRSZrQRcpywftfeQFXwVMkVwdq5NH
4ShbQTTHmWGAuSbkoUYHbQawmaGs799oLqORxYgpCkG4CHB8Hw1r/keC13gnVnk1GH4d4HQiqxjb
rqO+v6SAaJf8Fyr6Bop1rVRzROp+qDFcisFY9l1FUGn/aJIDM9QOpWhcDrG4aG1YDWfDVDEX+TTz
Egv4jzRuNPMVczkJqpL587RxQKzEBYhElPzp2A==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
V68jRgp2Idh8t2VkW45MCRphFQ4jl6V0WK7N7hXGZhaQFsp25eBN22YnMQHi/vKVgKzINwWdgrbw
TauibdyLbetzAsQFObTjoyqh77h2kCz2iv0ei2wyYTiiUwCB9NABDyUR+ztAv+B+jYyE/uZaSidM
n/zZBomwvV5Zd0hry9RDCuuZKqSl+zwT9NcA20nIzIcNX8IPpFvcXz5N3G6K9gZWbKhMty4t5tkb
GBYbL0QT0p0BNfTZXNQw1Gt4cBSz/qYNJ2Xu/YZ+V2jdOpiw7Pe0tUloRyD525dQkGM7uD4AAZ1b
83tc9Q2pUphUI37u8ekjug7Q9kOBAFz6rVkB8A==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
t9b4xEQcRDnFfZmWCQLVBO9PewphBWYN6oXD50CF2LVB4GR3tWt62L4X4xNQ6zNZSLMMtF/1Dh2w
W0jzUUEQCgZnr8kGvxNE+R52CG8D73dLyWEBezD68MtX/dd2ezB4nrfnFg4evJFJ/9F48pjyEA5o
eutM007fUI8YWnW7TIkzHPZ+9JtUvDd/2tTgIAgq6oOZGT5Cs4I1Uqb6oab8wRyxwdFK7oZVP4xV
gqt/GKZMUQAjWtA43uf3aYkOx9nhDEXiBItzPa4LAkZpGjc0gGyQyVShxg8zUzSWEJR8L1o6vMAX
rarDYDTIk5yY/eQmh1c6TA6ZqJ7UQXMXRTDTiG4h+s9gSb44wCGbqkOmCyA4gu7UDkCBNho4JM3t
0Zerk+UAsp5sh3thdVCr0AS6WQ54pj8UaXpk+1u9lqn4QRys33f5FjD7RC9cc3mEAyDHoyCaWGWl
/2yFk0+ulX3d0Xi32n8Qs1csusgVZIk/BKb159i8IWltRgQU/7GAAqC/

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
J/ylEIABu6C1a0vR6D5fz4s6QhyJCRQqJ3LfWb4Xkc5EUgf6DELxPobcA0U6M+Mkko3Sy4sKsU4f
yQIugHb+jIYdRO+T1fSw8guFqlHtlNiwUQdGSIw1rcuy/R07qTzZF3GumIKCyk+TrvEOcVqC9+fH
as71DAS12EFnukvZoNtoXSI5nZq5LVBPHf8wUzZxpI321LyJQLaFU4JJFGwcavsd++9tmra91sVN
BwDwv3mgQfT0TqE/TdCX9Zwy7zK/jW3EaOfoo5325gcSUR1jjSYwnWmM6Jy9vziqWHwvsjDhQJxl
aeqehWJ2yNrgq3TDVRpUY+M9W8QBiAjkbkTwQw==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
G+y9CtLjIQklJRHMRkGTB36EEOykn/z2Rb9FX8IZujxNAMVZjI0+MC2HSZwAzMJiZ/ogIA+Axwli
VkLXpi0D85gmlZ9R4Uy4Qg2cJQqn3X8ZPVEGOrirWAFPV6I6DLgiuDyblEbGT+jAegiYgxOdmYzO
rda5v0cSXpnfMFyHbUQxbket+AHbf/bIePv+J96W35zJ2j98Mzc2hLPliTDmteSe1nP4cpQnxk2V
5/tAfDdod46lN2rH/hTPA7Fa/IZpncNG27QQHpYAt+spI8YH8R25wbEreqhuV+kam8wXF7r+vUlN
kqz9GkMcA10m1F457xYENfO6RxR/Eacf9s6IZA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
CZYvRQs1e7cle29/SJCfOGN0qoef3T91yEF+XdigtvC+8ndM7QsKiobbpPCboNixCdknEuxrAzJg
3RzWEAjWaGsM966jIWJ6g/DOod9MXgQov1slH5VvCGn6SQTEkJ7xBjAcuMaMFZ4QkFKWi16EHhSY
w+iKhH3jCMHq2+05eyvFVte/6liuwhLASVXCYyqpUZX/pGwIRDAjIMn7I9hPW6J8cvUKM1CjeFve
nsG9Jf1JsFmkLaJZA8EWwb+hO9gFGNUf8KY89/0kDAANM0sDW3D/jI7AdnZ2SOEyw8ZnLR7bvuxk
GnvM0uSdkOq6ub/Db/5ToWmsDfvbMVwx2qyjzw==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 51328)
`pragma protect data_block
MzledPhI7HFGmXDc4hfiPycBkkhs3nGCrANqmI6cC79WTGirVj9TlJd+QudNZy4c+1Sw2z/HurWO
3bURdsgGDTuTb8c1CAWGDbx0ot5G6+WBxbqbEIpc4A9Y/49CIs2UG97Z84NX6SvXvzAuHIVawa8k
DJCBjkAjqn9rMr0hGxs3KwvYSLsJdPBQhUSXm5dm8rxwPgrr0dUPqqdeiXmrnYbuQ79lZqXxL2AU
VHS71THUMpCJJjgARAU1bMK0revKP4q+S4FQJFFG9tNj4eq77lDrX2mMM97jxmeIipQ0x+xdhR1n
MJcoq9x08B5M2LIncyKbZrBVTeAbDcrsXfK1vlcjvhNL1z6VQJbB5Z8fSTzZMaJ6e5feaksmLGCl
zNZRYjG9u3EJ5KeUrsvPCQRkX/ZAQBFE7GfPKt+C45ixx9DlZtlKWbTeUHJAylNuoTYtUeta7vJx
l7K2Nbb6XzAugbuwCvzL2rlAICIfezItPTV56G9QSEbT+cKvCzvax+5CDmsol1pfKAQiN3bSfDNr
6rN+Rg7i1VXWYL1qA/hL2UCw3Opin7w3HoxWNKeiN1o9JqV+mtHoAKf55j0o3rVaPmA4p103s/+K
aB62zdvEm0wYo1n0rTQpnAHKEyoIJU+P3DuAjngftyk1cENgxW+mDVq6EdBanEdq852hxvUD9//t
Aab2DMCtWx0tk88UQV2a5NRbAOSGWPjbNOAfCd+hDXJm9gosleXovrd3tqwfRc/Z/uSMtkCCquhT
ftlpxIRTAko1yvTxmG3M3mIeEQCO7GOt6yzdRsu1UZi+3EL5OCYCoRCMvlvqtH2euZMj63GhMuYD
zA3fz+bLXzU+IOySvArqV2rZaIomhg08tiQ1RHJHRcqvVNhhIesWWq/GnnenAaEXzfNO/62oJcGr
JC5WI0jPoFCuGiLL9hM7I6BaoMu/RPA+9bWuojzSmNxEvK45IeNOKH1h25W9K1V1ioPhm83zC8BW
idsIvKk/gk5m1iS89XCTIlY5lZcPI+H3pXr8E7q+Ew3k13ZMURqEjUAOgIz8dGzGlY4L/ogXHGVj
tv7ad9jtUmX60UFRJu/mV246S7yULsHNioe/ShoOZX0xN3bSTDN/o+yG6S87UE/fWwFoMCO11Asl
zro8WGW8qBEzJibfVozABcvzzNH77xxilmXPYJnxbsySOOmNPjK+3LTADOYTuUqQxkHq1R52b0Rg
44wTcE9ScSI1T3PWtBu7bg6qGUptFwoSAE4jnSftcOt8dBTqtyaISZr1AQDC5lgGOM+Xy5upUAvL
TG60ItOHtCfQS7wiRMCIyst0foYj8TavpUmMcUFlsSRvHSN999bfyAsqqDtT/QD/6EpvX3AtZbIe
0/q6kxCBX9iEbPSfSCE3ooLu7p2hIsH8EJKmQsHBkJRwsB5V3v4aEkumOCO+g/331t1iYS4MA9BN
bjXtUIAOwsyvReS/Jr8D2gkIC1oC0BRzy9vxpoVXgtv+gXPS8hzTJ9cmsE4k4qUUSAirmNF0AITI
ePsLY6EnXmwVt/kzGmzeim7K9+MVXf1nnE5hBq+QzIvw4sAle7x3uplaX3eH0pwnl4oevaCdtTjY
oGemhywGw5HYIm898zO9ILFv2IjtqtF671iHiBOcgLJ8+o9ni5V+Y2rKMiSq6FEr4jGOKnM5E3R4
HhFfrNbXBQaSOiuV+N1LONnBRTyTVltdQyG1jcVmuheKbc5xT/k6ticv2mkBkiZvH0xXRQBC0Mrh
E12CN6OapwUMK7bFZuYfmdHLNOfjvtt4RiuLSweXjd9o90sg9DcS/1vwzbfFjQDa15qbATZPkZd0
SMDqsoLXQKQPMdZrk11iOVvj9lYG4KXK3ubHgE59fB02hXMS7K+w9tzeLN5tc9bCx0QMgr9MKRRK
x3kQ1DMo6650hmp6A1eQ3vz+hlJoO9kHKKUI8qWY2fF2zE7pW9C4m1ZWHksqBvL4A86lCWgDKLK/
83/i0RDGLkx7MeYfCEIeQCGpmjl3StTqYNHkx06x5IPfFmS3sBkQxHWfZIZKTUQ6ZS8IqnBdZI87
ItB8TtC+sZyaz5IL5m6JWAtL4dLz9rEQyr42hu8Yvp7lHX6qokEzZUBUXBvh63j8w4HZtKWC9DPo
IRXFuzmDWpmPm+j2JUctmC0QM3siuy1WXlIOebbSKP1CeWcxpFghJor5OGV0dFVO+nu3ArSTNerO
52AFqXXLKn/8r1OWoT5sk/l8dKX+lK6yqBrHyscZQ+zGQk2KwlB3l9Ff/AQOwWV8+ldfRmvluh9C
RPfYTvrmRYowwodbWNG6KXkPtowxxC4pZinXwb6VpQeajBHHrEsefVgzHxNIe3D87xWw9jS7VYjg
rfXMM9fr0A4weHy8kNLN9IeuMn0PTURyUyCTlcEu9q1nvnnI7oPF/3Tw5C58f287T2Bpe/XQyr1D
K93KxIOCvTv18GbJR+WJk9jefhJGWhSgwnxGw6hmTmY3fKr6c7j7TjsV0On8mIFPAenNk9iAmBfe
U9epvFV9REM1OCIvBPApOjJNqPfcppWG7a2wuFj8m5oPrC4UL4TXHpJuVcz58m2IkOj6Xqcpj3e5
ysFcV3hxyGfbzPrr2ruJoaAz+qi3gYpTWI5rJhh4frahlyCLSCL2C4r6QF+EAiuwT3s2leti/F3Y
mHEL3zbTI75vIRQ5tz2T3G5mX6S5Xpl0ihPwHfn/w2FoTFQAZqCtCIDQF+UX8rLLApPk6RAzDLKq
yQzE4jJanxBwTs0eiVg/4Fz54F8cukl/T7e9oo9uFLnGepKQwMFKRSWMCbklvuwdiubTzkYi42Zm
k6QH6B4NS4nUwCFBhptkNbhfUCWU11ORZIWltUNvob59vWL9ZlDJPbuNQG1IVfJXsaOxjqmjndDZ
oum9sQh64roTZZeb7ckQP/3PujbHpYOEJ6VtDKhjmBiIhSSnFD61KtPg2n8WmFYuBQoKldrIzYJv
ZyTY3P5HMv49AnGJnpVICwAF3nSzVlWqj63n315HODTDE3BWsGI3wQpaMEDW1UlTg3oCWDRCV1qW
/yA7ZRoEiZ923tqYu6qnQQfa4liloja2FlVLHYS+R93eHUq7BvxelwcoSR+RUNEAJ1fYKQmYmfDl
R2O9QO+g8jSv/b7WCYkU/fAVdrnuqYkrLWqxfA999t85zf9+VmEkmrMTpsBSvE892MXNbjHuwCJh
Go3oPSZTn8A6+0cJscgIoWC+iNia9irehUmylkDQMpWakF8Qo9pFFikjDS6+4Va0X3NIMB2e1qJd
PqoZOA0lFHWuCFxeWFfSLchF7dwxamJb6AZRfjxrS8AbHPYlu1WwgGOSof2ucO54+burrG+1sMZE
J3kJOs0/LISzBzPH4JS3mMP8nDDwERC2XT1/3ZpwdfsVQW/bwgkmpZTgxrYhZTkVFubD8NlJ6WIh
mthuLbD4nnBNVyPDYlC6RENen+qjj2Un5qubKeuqspSaxqskQBKTiSQGMvGRXi0aXSnoTDjKqPXG
GF3pxL1Df3nVJy3BtkoDmYskiXy41bEI+kvKMyJS+rtYuMj1SbFERWS5RV9x9JooqwL/6TCFHAZU
Sp4alB7SqFnKygO4XBOnXSvESfv+03zR7vgRoRnOMEizx3EjmUhtlGebPmCrYZmZzsi6wy01UWbt
YDyad1JNg+KREV4bjejemqWnjs2oN2F1IqCS8GMll4NUhtQRe87D/msn0sl4tUYDGp78pOUXrgDO
/XzHia+QRm3Jj81CSS7gotsHWGPn3lT6aIzb8CrEYK9zhqQpUhzcCZfID6rej8DSLsOz8sc1LXZa
5fCrQs98VSWkDiXzfs2q1RqQQsSTpMsx7JLDxx0wKvqzNFBLG0SN2lxzwGJ3CAkmeQacOpp/VCY3
7o55yPLLg/EafyI6JbmT3vtUthwzvvJsRofrrKrD1X590gesaPWQvbBhMc2BzIBLDgkFHtdqgecv
g7B50YiWHF/tCrr1nDozKZWbLMgpVCvtKYRlwCdabkvM48VoaT+O1RYAj3HEnxNICkKl8s9Z8V5I
L5Bu5haE8bVEPNgdDRiuHCpXcS/Wkz7dsBuIN4/UFGtx6k62oGfa3yu9u7xDUNAhguVt0Fnz+Fff
BxKd0NbMcp6/Q3e3XjTK9mNxfQ19yA4/Xb3TxaInaKFqpPqoXilZud08rvbq5TbjiMCUxXXXegup
SgWR4Fhx/XpUBni2PVbTT8rj/4pqmL0wpnjKvNpISjm0raXSHFgW4UKVcS+lR/xA5XNFDVEcM7Yk
4AMs7T+KpxND5TrYkUH2G5W5v9uSn1eKmadt9R7l/UB6gbU2VjPK06nuKP1QRmZmSJVrjIxw/DD/
tR/pzXvtnBT252cqohkoeYWOKHvIL34M0+N4Lxo9+in84CHT+M+ZfIHwMQwMl8IBzBlOkUR1gg3H
c0j7jsQJaYKozxScshRS40bbEuVLosJ51Sc5o/zkOt5oSGhjJqM4nJ+V3tGXeRmQz/f1aL+IKbxs
ZaAQzANYbfU4yTgEz+BI1EOl+72MfWLh5MBELLcA2VgyB8sSR9Se01fvjb/hBXW/ChhY94Ihr0ad
qa3fBQfn/Ncq94lRoDI5tomjVc8Z4Tn2+izyNSpSCA3lNANeaYU3jWk8bkZIu8me9E/M/klQ6kIv
Z7dEWarCdYA85oXqzBM/w30c+aXufQfz4Icinnh9htyieV1Ph1sTfwRT/FECw4iQcnr79yLar+fR
h3vThpGNUJ1SHWLm+BdAF7Ll9rzR1kVPRvuLx/2RWYr2ns1r3UpaiAGBEawwJfRIzW/ql3+0fB8+
rhQgtB0zJwT/TTf8vsGE0UIA4dq9aFXnAelihzc72wLqIxEz7htZAIFF83RukCKhQdhbuqLN4uNz
YNHsaMgjFNDVg0luKMvicYu6SWYde0TrsscajGWQMOWB/Iff2PZ807qaXdPqe0Xs2ZPgiZMKMKbZ
RXaJoAZPf6xeQUbkWsvg+1e2fnq4xyTRvk70BpgK7P+l8VT39U46et49bBB/aj6CCZZwwEw+UMtD
rUkjeoPGn/Vh3HCOo0JZjADexZEdNbT/rGidKlTiOMdJ4RBy1fNGHJa6u0fl/4y5412mLr95hdqL
+1eU0zdSOA+nUYwi7jzAOO8GW58lLDnLd+mTXHohjRWGlA8PAl0qCpGesmCsING5FZria80rFmyl
RbTs6wnj7aAddNBC/1Sei/BImaeX1tbAKYklMv762HqsvOQJuLZgPOkNf+Id502Ohi1BjVLkNRYf
FQFLOfZ9I5v2oIWcZn/yOVAv0yPImPb6nLUM3Ulh+fDDETSou89kWXUwhU2d8rGecqDfw6MgKoh7
zPXZIwC2ttvx8Zni7W/SjT7kAYUonDbVdNPVbfr5s4Pm2n59WglUtx0xWnLAh3gIhC1ibrbwmktf
/ed/Jmy+CCkSg8ns4axpJmkIeHPb9l8bILWTJk/C8TZfXPfYBvulRtEwaPgJiXAI+T+qRH8SuKDS
eAKoBq6pkcpSz2E/IMzEkLvsCwME1pHTKIEQZzJ1WdExktp7WKezqC9p59aYPH4WQPfA/OGtNLWS
YRN1Y4COAlEx8HHz0ZrCoW9zUP+Hg8eTv4Kl74wusO3+2rIzXA94T96oERdDJGNiGz0XjFNGAGLC
XkRuVobg+n81qgnQCILkCQBqig6HsQ7IUwZXDW/xiaDygrYFId2Uyhejf9gy2uWxq4jQkzQ6bwlV
5J0pkIzm9BcQcECwiqB6bvCEgdlUn0kBMJIoaHZIQdb+hlrsMceirlatOOi3oARyK81ZuKAfEhCT
+VmmFsESBxbMfbVSTDbBVMTU4qWJeODXfPtvPY2tkvaWW6YIykesa4jyeLRWBmgKBvmgBZb2CqRE
cy+w2XXfR4aIruLQUCHC8mz+PK1FDdKMSZjaMx2vXUA5xiAVes2pCglZXb4YIESJK9pETVC2cQoq
ftlOYF3cfC3P7hFMtifsfdcopFQXsqlgeuYGis7vGxp9y60N55oTrIPI6+LXROSiRtV0eKqouXcz
5eCuJteJZ+HsrfSz/QXiNQCXkaIiQM2Xzh5Wy0HRhIuo3AqDNDw0C83H5mWK6DFfmKkRGjet201v
6FVfbwfFiHsELfh0tTcxqBtwQ52t9pIoV+7kT/09rhJRKDetru3pH25xgZwaC3BVpDsiALEapFsn
BbjERa34BoaxjYrXy21QjMm7w5HUKZC+dfTnHWXR7P1Esvsf/MPYJqFqGUQvg5sXvJmPxDh+5ud9
55wEi29I5ytdYUPZT4cTQMAYdI3lH5L3jx4RLEaiR5v4H/po8+JMcyZZEOz/BdYnRrA1c57mgGV2
1vgsUtp9AfA9YiY/tMGpeidNd1tDSCpTwhQWSwIIJq1ADOkCn7MFFxuYxl8nUrzi5bNHMvg0/UVd
73q9zWhSy/KYXVHRLDUBfW/21SX/jxOia+zJeSvKshM3bbG7yjHDegvJmNm3J2u0Khiv/cNVGfja
QbasYeVfCwf1G4efmFWe04p8W6NvPdyvlo/45Q8R/UQT+tsgFgIcmmkY64uaTwuqjqxdtNd6UvE+
84TpN+tKYVBTG5jt1NFQRwusptdfhZI9zlxhx5lQ1CMIXakIMOCYI8Rw6bBMytSA4nFg6udmBFV9
r6IJ2CakOL4Z2WOjtIFifO7JggvwUzKCE50dd8dOkSeol71n85VDT0jmLVCazmbu2gR0kFiTeiYk
exIXN21yIf7YPjeQN3jpBj/Z9zLE5vfj657datDVfrFDvKasol5X90CfyhkGfkaUt7egA2n6vWNi
IESabHYpqMRZsR32rt0lVzhSThmvvyS2UZp5R9hPvwAqpdQSp742LEYKo7kPv0JdqJkFjLm/Ty4q
bVX8PND8MTiejsoGpagC9ZixP9Q/px4NxrU/z/kMsBy/8HWEN4bcT9loI5NYf4AajpJGyxepW2ZZ
rB6s51NXsTrSRd+G1Q2pFici9d1oOFB/0HAk0vG8vmapu1MlUFZwt09gcGgZbW6DT7JDPz64APOr
XmYMhorSwsTEEv18HtgmEMz8w9EAzqhBRf33cTu/QaDI64XoJio1jdZNeCSF67zqLtzSraMuE2Cl
XphUHZfqgnOjDGDqm7sGyd603VX+EItNgIGuTnh3rJfdmnuUS9/UbdhOxtQceap6cS41QjYyIDAR
cj/u0YEvsBKVW4vfpl6bo4K1/BgIUd/6goZyvEv53u/cv5WKKd5VhpdBdl3n+xJVyFg9/F0m7vwh
GbIi6gR54rJm7a/xeAfLhbmUkIqJ8HOuvwSwL+NhmQFjMOVIX9BApp6ET2CgCTHTrfHAtveFPptA
Mcwaex+6fqVlWcrtrifR4GdcjE9xF+NqJFn0YdlPmRI2/cL8GIvbpbphgjUH/1T1vsYrUStIOKEI
8zk2Gpfxx5mBBCQhpLWkuqjul27aOx80wFLuzLEpFiW5kBqL718+HyghUc5uuhXX0e2vJlOpgwYg
jUCdiJ8V493jRgZAOZsC7vj48pX2He+2jGphrNQg/z7RxckrvNbXwX9xImeHa0m1+QMPvpG5N8Ev
2pc7QLJg0bWrtoUhl4NMeNdeL3zniT6kRnPg0UU7tGh0qA8XBVU7Oo3wj88Azq7ssH94eWBZpso/
6DGKZnkswAot0u73QLrWp7zNWOExYAgm2YaYd8Q2Ti8VK3re3tONWJy+VBbyerePEPPxS+l2E0WV
e+j5K7wPWR3Pp/dLmtzeRDZ6ZLvZmJagLGU24htVtB5g2hATj7+6R4Md4xV674o0RFmXAe1bmJuy
7aADrhVkV+8mPjcDyWOh3YvZ3bp9g2a0tUaf9t0ijyVQFkh0s3zmCUH5gJXuaKNUIpfwRs05vK+g
1vzxofo3UxF5MC4rOgDRUL0zfYYFHPGpskDdg3hgF6XzYN2Xv6ogsqPqzl+qgMSHzjH3YUFi+r3U
hPisFF6j/JhXoni1f+cBnnAOnFFdCd28Vgzh6F3HK9Vd/uxKFFKLeV3iuf9sn7+WwtsY2VVljNIQ
2Mzb9ZeFp5WuBPu9cPYISr6fVYDnCGmEP1vNHof7oZTbcflqnD2JQQnMiZKCHDtoH3Ey25/ODUex
zjklID/Hjbr1pkhZHk4CV/nuMwz8C8Lt/o44zDE0DprsWbBwMaz+PN31Lk/THQunuDg5nXHRliz8
0RGXi8xn3wcTMERjEeKxgzHZRqQ0mMk8FwG1LvQ5qxHcyCH2nnelngDd7GhJitFkxC0QG8mMNELT
MerwXUqSeJFxx6H3WLWDpMwYKr2zEMvbgSd9V22m1+kJ5Ou4I2Ihh3pzKofHXgnmY+ykyciwwiIf
1xApvfR2pHuA6TN5hBWyFK83hgwlhfxvYnAjOnKGjnsJSqBeq2rj6++0wCzZsR4OMRdfYIWDoaaF
B/sUDNQFqAkWmmGFaRHQVVF6ydtNQS98uzI/6OqxUxdPq93gSJW1AmKzn75BHV9RUfYISVtDaaN5
/uxvqWRgACsn6HSB4WCkrmQ+PvyuZjNX6F+QsueWyjj7rGLMpGxf+qEUHsWXcCKXBp/QPLtjAKUR
hvOb084tFPQYmtwtcVkf0XTUclP5zYIVwiYbebfmeabPrn9JZvZXnXxcnVjr3vtcs+suLO/zB+kf
g2bDXYN1OLviRhUidR2H2QJvLkyTiWgwoIfXbp9R6rhpLYtcBeBUmw3mwfL4ryfOr8Xqw6KogbzT
By9wpgZRI8pEuXUCxlqYVu0GTTHLnhkxPNBut+x1a7Vr874mK6JjQekcW9uS64TsMeVdO9uGxuSY
06Zko+LYsSJUN7lxAQ5//xrVxc1ceZNilIPgLzPYR4p6cE3P/Nk9nsv6uL9ddVB59cyeUYSO1Fdm
1+2jAzW4QmkDmtlqIlwy676UZGIn9ULJslDM3jO1B9eFeKfGSnh8LHx+oDilthOlOqRgY3qgHbrL
wuu6dKFusZbe1tv83tWfKrUssWa3J3MfV/XJCuUs6a8us1Q+Zsuktk2btQkAeDsaXtSMflBo3F5w
ibRcjRLpfCCC/D8pz6yQXvobtg+VvBWGpWDg5IpKWoJaadMXjgSVfTvV5H4u4VLerWEf7T8mt2Mq
+exsw41o7oTvQiFRLhmFLRkhwlXzCuf13dINhiCVemoMfa8PiybkpCdeFzQNg64L6rgrTny2cfkp
zpYNTUixHG52Juhfe6yYY0fjZRckM3Vy86t4M6jMCmpRBUf4FeMkuIo+P+z9nDPA864aN5cYE1EI
3WNBkHclIMsNJs/blOXxo21PxYVTpGowhVRJbb+k1+3ajoIo2WdY3tAfM16yTBAK+kVA6huwyobs
GyClOw0x7VEnq9HwwLhymvhHX2GkaUbDUN9KuP1GZK90ZPBgBcepOqGPJQy5MYvaEMIj41yoLA+t
DxoBspjZKm4DuvCoDIz6zaYWNlMQRXt0yN68Ubq4qEtxuPIK3s9DwrF3LPZOjWP2xpjWRfTwftKV
rIf+VbBKusKhZkPqDPUqjGxqpB81mnR2lW4W/KV+0MLAdKRXiTk7Qyu1dFI8dUX/+jiQcOW+K0VI
kqc3kAVA7IDB9I4VAAk3xQ29lh/0eHk7WetNj2qDbCx9MARrBsNgPNSJNU6EVglbZ+Q1gXyA85ao
8LCWJR/F3ofgcW7SE269Z1XkrNlYscZ6U9QpKkQcEOFlIgs45pRmtTFof6MiRV4Zn0aBefLPbL74
gXG31gvnAvWcyJ54bBU4vajc9fSvO6nZnPuwAhayyUGUI6x9YiaDbUgbvgnHnSBb1FFjI9tj1rlI
J2K20F22xhz6iuXJ+FRw2Omp0RbVNFbYU0NYy57G49qUH0NlC5dfJnhUB9gfMsxzULD2c6iu9MG3
/c7B6HXyVV7mEX0aioWh8J1xboiivY5BTx4XOSr1F9gc5JhF29GVTTMTkeet9P3S4AufsScm8v+q
+7WwKXLZjBTnWxCnbubWEEH9C6KdeGSc9B3mLkHT2gzkHiEMNO4SnU30qN9yZJ7BCpLN7F0qb4OF
Sfmpi4j8EeKP19m60GzetOpZBiqJpKXRfUWFM6nXuDBXWiHDm96JLaj0BFuONxOyo8yfagq2djKL
PwS3MWSCUwxyfwf1adRAo/2uRRvZNfL3MzIuWJEob1U9ktfuzHpORNi9ZvRUgEB1PJQdm1QOpBis
TN+PSb7ZcCyVFrbuu1zxut8W5+JBvpTrZnAdDORH7pG/WMpErnezq9UTYeDCnWMkBQ1gztMPQF3m
o7wPq9ph4h5ExjjA09Fqq7nXJvNMX2gRT31sKR5rxFF3xdO9v3Mc+9Ll5/uVDibWfz96NdYRa2gp
wzcirDfK89MAXf+pTNwv8zb6bHktew38i34aDESGG4qCPt5gQ/efn4BxRtltKKPuTXzbBiY2avyY
Lm35Pa6EzLu4me52pyZwO+Pw+qoGYzsexMIJNS6SlgVWbsip+pBZfR9pNZ/0qSytECQAgpVnigvC
HoVM/nnFQADTlgog6EH5MnufRQCzLGtpDOHvBp+0n1Ndwnnf22YmbjLOssDa8Onblw8bRZsiPGs/
gtHYCYWeH0o8m6Ph+8hcjxlqWq2qIGYOuUHPiqb9sTkfF2XoXOWIWZ1/fHo1cj+rkaQb3eBgEgR4
GMzlG0SUZ1bmirOo0pjytp0hj84+fVGzBHcUlLqsNjRqGq9dvs6HLLOlCEihDKSLdvHXZpvpVmI8
NS7jvRgUpTYswKPqVvxwlX+OZCQaiIV6lfFa3/Ahg0SQivZykJ3VCrgp1KBMJxB+9Nx8g4dgzkwk
dW5kvNpZ0JW/DUaRBoZoBCpzbr9xXHHYmka5UAjPG3OqfspbE3B1NxvzH4Z9Ijc+QdNrH014Q60T
FCsSrZH0sDZ9/2+Ab8u3zc4Po6B9ROET9givw5QXROC4UNU/FArMKN06XwWZXccEWh1kbOSoQKje
WuPLPUIjclpHq/EoGIzrbVcW5lY/fWnQM4DBfYkW3nCM9Yh4sbDz21nqj7+pdCDttEPjGKenGijC
79gizFFWBc4dutTf4uFT/Pkxb7ryI6p9RfWcYY6ofQENe6rRCrDFxW1FxhQtt+7lJrBKu+/1pgF3
bzW4Ck2cIcDLJSoNbhq6mjtuEP210npuA2wqHxClRI6RicJxGdiNIgU1Ow4Lu/g8ONeU88KFO9go
ViYlU/dbkBh2CN1kDP65R6ygX2Rcai5yEpGMvJxoa2qnmHqf7tHqAYb85gwBunn3zJx6fRjmbRyk
wGIysmtvXPseNuGNleC95VctOasDgPYtxJr8RGDB9LWFOY22JOXDG7shR5GDLl7ycQpcAy80chQZ
XxEM0VoiPUQztNAKc7c/PWH0UteGW2mA26erybpXx5d3zDG75ddS4o0ihUfcVTn/5WPKWPt9hGve
vLF7Menr7NYTU0ZICNhqxXAhGpYe2K+LuEtLEB/3XAhEFzcYDz4KZRijiMIaSC3xmLLIo5JxHxNi
qA+HNMQJr41pCmg6CYZ8PZ4RwNQ3sra3pATT/6BwwC9VApH3vN/dIyfWfHhNL+etlaEcxN9kz5wS
minKYz1FHwzPgPiytimytXhb+oVfYmryOIefe5hi/giWKgoBeAQIyP50ROdly1PikJv+Px4Eci6r
wbV8TZDqTGDAq32OriHJqQFlf9AlSaIOdz54nJGheVYxelX/Zi7VYYKrvBQbUXBOZ61LrpsYWnwR
JiY0x0NvL9hFxFE2ppXW0HTGNOYPhKqT45Z0pjNC3Ww+zHQ4+HKquDTa6DNW44Rjod5JT+L69W5m
8b7CuX+TzaDT+Mn8ilbpbiFDlX6LYjf0NPf4Brh16QuTtsXGL/jN2O4qonfSC3+yPg+6hfALpKzz
8J1UZun1vQ0v2NXRGT4Z7cefCyaL9sziOQtM5HU3Cdb1T23w8P4lTgpbj7cxE7Qq9El5h6p5ezHe
cePynnJVkANz4HL4rkn7Ip7FZVFt8NOBpFBEn/5l389oh51Xc1l0SmQFysl+x77HsDm/hiaz1bM5
uhm5c8bfCWkWkTwzdd6mRLOmTbHnH2gglveUbgAdDvQPfN9b3aMlo0gNp3ZYc02Cz9/OTEVHPXSw
tsaOuailyyGMJ9YHZCvpybrllUXA+Zm1FqgY7LunZRptdAaqJaGzgMQyZqH3pz7z2mEtP3t5Sh4/
w6IVk4tnDLjcKJdc2MdAcu32njK2UKGA1HmAwJsFtKVumcJ6aLEDUDQkAXurN7ybBbSVcRnf5R/F
F3BI13WjerpXHYtGxPLt9nfALeTAVnb6KHJIdXwTWBFiXlXDdYe/IXVoAQ/b21Gkd4pjoY5npJzV
ndiAfUfQs1/ci61jgkEebHfoHy18OkIMZ2Y8yH8LJZsHn97XpbkL69zp+58wObdlpKKRkaLVW+ru
KZGOhtbUrqXFmiTZMZpP6D58fVxNd8IwAuRK0LNr/rXXqhkiaixjquiOV0zuDIW6++Stl+pS5C9P
YwT4nWQn4jqaOzcj2ip99MMd/NCX3Fy+WKFH82d9broHTxg8xmB73HYiV2mBmbEqgA4+6QfRXJUe
H/z1Up8B6dvFanC68Dt22dQg6RUFPlRfk7+hZM32Ontg02JEuE6GzJ45XhpPeX/WASljUqfudc/0
o0+5JxpoVW+2Ob/3t7DuTWMoHpDZlOzDKF9l3pNN4ZJ+tBzSr/hR5BIQUwXcuaOgGfdUwuNDG8PT
Q60PLAMm5+bHO0P40ow05Y4jNSd3ps59Sl7q9S4hvcXUDe9OlukqmKEd3j7yx5IW8xebNV91LRXZ
Fnn3btzyXCXCj2DLRR9vE3avR4qfHCr3DNk/vKoUBDXXvv553UtXTgaO3EfWt9VZH3sCUplCgIxW
K+VDtSBkr77MCHhR+IBSrYGKn69Ltq/54+Tx8AA1RQFhVlVsaVNwoWBxp5/vPVc9NGNwXcojg1z6
wZVMvYQYjAzIlX4oknk6ggPpBwuvf5HNjZRE6jGbYnkNlt12XaYXCePfARbWAetQ0or2s5xPUK3c
cu2yUPf5ePLUn6ODL/XEXmCB38pe43225qAJkEPTcAjB824y+4ew43/O/bqecUaDP3eCOk2pG02/
drSAgG+sABjz6KS2fVxfX5ttftnuSiB7qOTqbjp0sZ2XdwfA2aINef5utaBIppc7ZHfiKNgAYOW+
IibKsmd1/YKEjiCPLT0ZA4XNfPJkzxDWXJ7L41C9oIat/lu+WbpSDCa3d62JLFo/mPJinb2PppFp
WkIWA9D90zlJRkwIEQ4fuXBnqupMRonD0zvaqR8OkIbPSNsyQm9UU7GRfAi8eCnOKJHapmQrRBGv
5m9P/FPCUrbC7vga5v5PHWHJM9bOOmetywcv8Ub/UJtM0ZC9e1EFKeHkKy4M62ol4Jd0Wa0qpRrn
uW0G+aoHeq6sHTtGaXD++LDTode4BTc37unlq9aFWwbwdQIlwg4+f5A2sBmruIftWR79yvjjkR0p
UsPk9yO7OgSAyNWe2LkK5VFNudeZGyEY3MFIRxj/w3CRUQFAnYy67+V3P4+mH60br7F/GGXLKfz9
6JrguOD3RUcn7TUsdIxngw/IHn4Q60vGV5Iq4CcaJnilwiI2QWfXk2MrHwWOc0kCcBSEWs19fmhJ
IEzqYfKrHsXYUGUuVukqoQ+BkHoPhabdElXHQ8xXL9JgtzyiKSSstakGj7DSCUjzHzQlddlSKZ5o
3BEFJLfgLB7oqmE1HWCwtkVvKNZ7gKizNQh359FLr9/x12bf0WrIwNNEdQzuNQSsnHBq3bfkuKK9
d/MbIT9q3Kg3X7Xydgbb+MVeTBurpBkBXJ8adePBX5y5UyL+TwpiLu8ff6lhBCm8wbZj0POVJUuH
USlBsbZl7RrXVSrmB8EjNGoHevapLnT+7XzPB5bU///2ZXammS8vXyCOBj+xUtVzPovHs/tiTuGQ
bCdBvdOPeeMpd52T+iaM0YotH6wtycJBWneMZ/ThmTPZREXMqwvj0TZ2z8x0JpFMuWyvZnYfQRYv
hIrnh0MzciJxD/Q/qMezWhtpZGqrCUmy9OQX8un17/756Jbfzot5FQltkIgYTSCr+aEmk964qOiD
qgCf0f67nMPZboLBNVx07bd13oXI+4qhTM1ip9c4pPSy9jIco2UvQKx05hsICFwaeNGW8alIlWCw
c9P06fDSorPao1SxIve4ymWnICZ8Hb3Q2I5lay/XXYz+l83DjD3oKUmpbFfEvQglAZUQJEH9Ppv5
+iNwM9yV0b7jDYZXbWQAKmybTup2n/07bQE+55CiJikkL32LU1QhiLXbyQOEKQ+ViOp2ykN98Q8W
zG9DZSlplOa2IdwTluSza0WHj99yW+CTmPtT0mYGOoQzuteWjWiT0NzyxsU5ZJkg7slXfwCWNedJ
M7PkwbpZNrrYeULQftZEIg6CN9PAmz5AcZrI/vXeBx0mhQUuynZ+x+oqGA9acVI80sZdxO5E8yol
J3I5JRwaKfQTWQ57hgNhveCOfhf8yjwO7qE09yzx39th0rkKLiDO/NCnGk3IengvDdEDHDuE/8uS
+7INcriWCs7yLgahuCq3yuRdfJEWKzqarJbuq9UXEGbxX/ktKAQcpZn5Kaz/+1RPCFcmTRcjBJFi
JB/dI/uPKySBiuO/UeEc0eVo8zqpyaVPrqXntH690PcVU4gDlHIagdyNrQ91PZ1LwUznJJQnO6rO
0z+YQHIsVNapCGVKHlgogPzHHXgrD2l7k7WOLrwmcsHT33OgkVNs4kV916uRvsF3V2RgNyEPWnt7
RIhkEbm6wTbtz8BxsY5ZTXlg6PBJbKIrikBz0pk7UkoCrQaGCJHSvtyz5yOEl5P80cKE0twPgSLy
dOtwOujp46uL+tjnNS8JJ5Fk21MygktiEMpP2IvCpNWNBBYt5hGw3JcYe6gWzA1EqhkDbtFN9qQn
zyIjb3rtc8UKFSyEOdkGCkvgsPsDpEnJMu0VftXnsuYhFNqlTZM4GnQw6mHT5noK1CRXt4bxv4J7
jxSnuQSDZbbE+egs2oK1p65Wawi/xoMP0s78vw4C2uWSVoLeOJKkqQzj904UOiTD0O7adnVCRREK
rV7g6fj1OdfU7ee2hYeqtj6ii7gRMX2VwC/M+rINMeTLW1JIdPg7kIWIbLs76Sgo/c8l/6CB1skr
Yy7vyi5w6z0u7/fhKGpg8kS4FIN1Yqfg8hBbZUO45RBXctRKBecBLOLhLmbrqLhcjdyPd16acZ6s
q0aiF7mjBEroy0cFIqpGH/NYsSyQLkh56D0FWDIMXLsZegzXDS6BoRnFIgB7utdGDhVr2YsdOeP1
lP6JRTU9eAnXLnx2nl+Rf0QGHm4rdao7/g8dhDc96kyatKe4LK5h44MyAZpPbyMfC58lfjhYFDv7
iRwYf8pYnHYjKogYSHCHjOenOtfZynUhU1xaKrJad0ASlD+IYw6aWDWEPGDGW6VnJwWoaIeCictg
+gmOPePgiaCsZOx0raQyW5dqXE9x1HFyRVfPC10mNw8ynGspy6mcGiJ+kbXh4CCX+oelLCq6K6sL
H5hxvu/T9+XFwiUveJqU6GLA9IJn+KqNOWVflPDbFY1AKbiD+kTabG/xwvCOUuWUNe9anL/0glP0
nsxFl8IhmDD8JlWkZuR4g8t9aUqDSBNMAWuhNkKa1cgwTsiFOuJJu+2sQv5GoBKJN89X6MQKKPQn
Spk4b99nCCsqkpo6u/0D4sXI8So6wqZ9Lt0xZSg0rluF1tsXSZ0wLJV+rUlA1C2DmdSNwY1x0GR+
9aAr+NaJZmPRt6nOpky9QwVeqC+yLo1tLE0ytCm6JiGkrpVfM/0f/R0g9MuqLDoX2esj36lldo3E
cw5M8R9Cpx7I0V1Vd2AcXz2s/ezl8Mfi5h6Nsrk37J3rfeLYq5kwqPzTr1MzEbMjBFX7CBnOVcwi
Pn/QGmOtToyKc63I2AuglAPYD1Rn2Jq+oOblVqm08Fqt7xeleNY8PPVxeDQm/fy66FhQeciamrfT
5lr3v5zrtCGf5CLEsDXd44DeJuT81fOkNzfP94W7oGBCnXRmAAXDpObAsrMYWpRZDk8XZdvlP2zY
OkZqkRnKPExGThjYNISLTQTWMo4SuREvvSMO8rlij/I1scWyOvIZzlVYSNEkZAskHgFcBuOD84bE
PnjBUX7zjTU5Pu1cy3H+CrDO9g/6+ALGTiYdlKNHaH6gmzSEZy2keweLmAQKceCSxvD5ylY74sPW
SuYJvQN3GB1897M1xnVwIZYlsSOyLciKdPjNO3tgxfSzzVrVor7ZkuSUHKhA2Rr+aADfT/TRJHIH
Kuh+LeiRNth90CelOqSBbQpIi2Tx7wuN+XySHXxX209eVdg/+kQRWFzgOYfZ4QCpZ9MRniy32pb/
++q/BjP9R3lr7JhDn1LNSUKJZoeGx2caxIfBEyYpNCjpFfKGUdHx808gvV2d462H7SyotRFl9Z3r
8oJRisJPTm6yz0k7806uNTXYx90FENDJPHgUdBRCrWU6uevpZR6CVDanrO1sxMgtpULJs+jp0jMK
nkrXFjXZrv12QH69lVPO6f3Dit9ZCxsuX5bra0hVH4CE+dkM4OjA8DwTYt8nsSWdSlAZgQ/lvTUn
P6hsJY0CgHxX908IrVu2DPJmJWKIU+Bo5HLhNDjlKL450fVX2+sIWRjECGwK9iMyzZISSZ26cpsP
Se5r2AWdyTDkm+9sQrPIeORAq6jPTeCpypDQ1DDKD58OHJWI7+dDPCa+UBfiELw4j60x9TO+ADhz
2ZtRmUjRxCxCvwOsC/s3VeAfzwGcgnS1D6qhhL41IEzd3l+NBxQVBi3uQ0X/TVAiJupR2LwSmBeB
kuJU0aURNyG0WAv6BIpPaGnM7XbDmI+WcK69+4+7ZQC6PoGhoLZ7It/Ea7ANQYIx0MiHRUedhgF1
BypgYGQCrIwfSQa9ml5rmskQNV3apuRNTcSk9jDOZSiLYxlqpEyWWoxUG9aDlcS8Pd/mZ60bLv9I
z1xwO/adc6aNgeBi7xzDNlTcWUl2LZKL62LOe9Be8CgkHg5nWPanah/fPgbjvqShlHdLtB0vPogz
JlKA1678lVMPw1KFQ67hBDo6lDHOotCHdziVG8EVDz46zwPX6REv2aO9d5PDDebJeG7j9UP21oux
8MbvRHiv6J5D2vh4t+jqyBJRwoNTTwhSGGU41LpLMT+dR+Va3PVu3eFNeHOR79nbw2f9SWV8A13/
KM6DDERXaPg0hbOlozSFXHOo9xQvyaBQKorYVWGI8U/aJ8Urz1ANihLhL3k09bcO/YPRSgDd7QlZ
ugBwH5d1T2SKdlAI0ijT2lfVEX5l8oOZ6l6S5oKcWgakiGgIwBxNMjpV2F7jj4Ii1dF4RTkOFvJs
FdfeG2T4uMEmXU5NSzPp3UgUjtLaJSjRSlCRI9aqtXV7EKOI2eE8CEdjR9Y/2VlBrwrQ9DD/GD+8
5p4GofAN46CYth+3P2ag9Jx43XbspiEZ7AdMndiyMCoXeM31z1r3tuk/CDBVl5oSGhryxSrdWaZl
hxsUpUlePKG5x3sOl8iF9dPg07V/Y83850DodO5/iar3lPNCe0v111/Mkz+BIyRB9vIm4t5wSu5y
9M5e4q/XRkyXBnuz+KGUyhFQzwTsdd/eTmg3m9sZrRtR5N+OWYFQy193TLY+0yZOGkWaNj2dcZW7
DHqVD0TYJhnlo3SQbO/OXkx3uJCQ/Dd+C32qGHUL0F+3oCOSGnlcTgPubJzVzUcfmLukvf8HHhKn
6LkhxTFfm+6B8rjIsDwA2gcKWDlhwD2kIGTzF/Z6igdChjhRCQ3IcKVyYQu4XMv8ZcCYyE+VgqZM
+xKTfmtgb5vnLNFrD6VkfTaSxRW7b8Zh99487A2QZawYk2b0zfOeg9AXQ+bjAtgLyio6zQSksxzf
vYEdBhwb5PM124pCSgWst7mYZrU1bkZIIlIeZfXSu8Pni9U53nt2fu+WV8Vu0hO62Js62KO5j9op
4yEA8WuLQvP+jefiGVusOG6AZFApGFX1MZ3YlxVTco+V2s1gW1T3SsLm4yLCJpLfsmML5rLK7m8h
Z54qYlfwRtMjRsHZxGG/8M7W/Y1FY9o6woLq9yqWeVQZx4kjrLpkXXDZLC5NDZCQ4yZnS8wUU4bB
mqDSZf5rWTT31MJe8LfXg6iLspiKtge+xOY1YGBVcRn8Gca5jWwJyoT3/ge7vzbG1az01w9QIQ9U
COTCEu5yHW4eUenHNNUtyHvl0uz9mkKws7TbAFPzCt4T//7eIeJfYo/R+7k9HUmBGMWu9GmExYKQ
bVxc10zWj8DLdBDWX3uHRaQ0hrnXNuqzYImU7YMqHMMnEqYpYJ0rfeWyyT2l2eLjMcntdhj4UKv+
qud58L1jpoDpuaIIbLYjo64+KrKHtmRrPy0pq/OaG3XZ+Vv51UuTMjaP2KhN9E3sIXSgsnYcmKQp
3HeZUXQsaA6rNJsERJMjrhyHwskuXAHczXUYGDmzPSyTFYLHXLPa8o6GL9iP5+ThMRxd2cjpXAkk
SJiLi4q3nxktga/z/IOVpH4XkidcfKnVH6JSvYZMda37C68lZiKWXu4roMjGRR/at4EbYlvdNx0p
BCFo2h6YzbkudcYRj2ldpdI8SH8NnvS7J2Ua+lc2bdGjyHYrQQ/8v7fD91NmeIntTywelu2j7AeK
23TKbN74pX+gCwdhf2Cm+338neo2ZFLQEmuYnsXibQlynp6P8oW0dpF94sVVN0kHyperjxOjvMQB
WnWtPNrCF9E3PSXAQEtUD13B1oeBi3+12Ii4jh5VkMhl18dIpBPYLUUR2zZV9jPvUg9EGg76Tp4i
uvB3xJ8qXHn3iohIi/sMhBrU8fFEnwOMuu7TAfHZtDbBRnkxjJd8lbW55it28BJ6pEzU9yxAlvMX
HCkwF6CAAGUkHb4JgBTdAyXttZVMJIqvoOaYMgAzsn7s/dv6zxWYDcEz1Cmkss9X9AdkowCbncJ+
hHw0TK0mbiQ5z/0+A1Ng1xah7O3uD94Ll+lxGJOIVeeefF3PF0xYF9k4VqSiQqUNIFgwMj5BLCJL
e0gmpfnH2T/KG7SIa08FbrvvbeT9Aw0IBIGDMdSOJ8kdLb2stGWELC1tJCrDmbDLFiM/ZCZECcWj
4j+wUukfJ2y6XzrFv7IOy0smKfcXURMNkJHBKRD1fSkoGo2w9tr+a0Ug/b4ca8vlABEUb7jn+sO6
+1eWeTATlJRHMhXyUZVezOWoeLlOkXpq0qWxoySoXc9lEn+fIKgNY6tX5c0Z9I3XNvowqpT4S9X1
LED0w3cgPVbZdYf+fxgl2Kmf3KMtuqejWTXFuLm5BYFbMAA71lvxEl3ygMbG3gfQQKwZo5uQyMAV
FLuSlJdcDbiGAo9NN4lk4MIfSh8KD0YaJE5sl5eorioV1Lxw8ZQdckrjsHnmtybUgipjXH8ihQNc
k4ikE1H7rz/LP41eSFpsl5VZ4pIgaDRa+KYCbfz7qBqFy6jWSHBqXNFN2Y8Lp9cbawy1G/sjmQuP
L4KF1wbRtMlPhz6m11/Sx8xjRPLgmjucV6EDjY1PS35QaQ2H60BG/4Wk8L/Il/3HCW8IMWFlAyd6
fsMIWupdpG6eueBS4hX5pWAXuf61t/ArKaIMI0PUIvjwcpdI2Jtf8YwK/trePVSKIHYAvk4+pdOv
OZ1IQl+AjjYIrWhGaXdj9y8xeB7LSU//dBDtu9i2A37WFUQczLtJCyMEJt7ZDMIurqBa/8gcjpR+
DPi2K2ffnIHujI7XamAJEGZMj+1HXOqoCQ4Yg+OjdKXJdO+XV9vPF+jeF2XdSPI7btY76pQsKzS0
k8yfW74X0a/tCgjN3tQhr98MOkBnnWiSJ+vDL/1Yo1w0Du+J64i5mpp+/8Xg8xA/JyVRNwlRVN6q
GsFV0ckwuWAQNfG0LlW2+ONxF/+2UTiD+oE/uP44XYXmo4rhyAr+kRZlIfG1a7NckNUHXg5Gk+Eg
tKqAjQBnh6um6IYJhWriqqt0ucyscJlQvzutx8873JDq8nNdq/WBEqZJQTqHXYS9GPPNXwfDJYMT
oh2x5lKL9I22Eeg/n1qKyZVySv9XJ4NW5s0CN2aNXQr40gly9FpVeDq8zFHE4mrcy1YGtK6CJ3Mv
4316eswjX3aA3r2uJzqe4R/wf3WqH+Gzt9pGkZ+BcqnH8ScwIRnsq9pm9MkHdHy5ey/UwR16s8ck
4/znuvXnSLzlXkvcA30xG8Mxo1iQlzFClFl5yl+ujkQe1WvgIklS7hRe+5ipcvJwH+xvbwZ4mqdA
wLLU8X3M/WFd2Yjgqs3tcSxho9NalPerefQ7/i/AQ/Hf0HV+IbBIwaNh3pGScMBBfGHNGfZoR1Uh
4050zhroJDKZn0pv6zgwGJB7Y3BWudzDMYnIOZ6zJdf8yv7Rhr2a9TfcCI02CEPnkcy4dS+VPIN1
RY1WI5Mm3u0Mgc6zhinl2/BewTBiLrMMqjQKuHuQTkUdXd49wIlQT0+S9lJ+qbOOlF7L8c1gxdJF
Pxw8PY1AGAeZrBv3Accx+PwyM43Qn1lY2Lk+GyYvohk6Gh80YF2pftAhuDuzXEEliskMenixP2X8
ia/jpP+u1kjr26RTj2vhVReCjTZjCs5tSTZTNcvW1pAc6cRsUkzyPUmg6g2Usa/G4CKu4MDMdbET
MTP8FYyZq5fWEH3SsnYnUOVjC+XiWAS/mmUrdond7reeOeJYAeA2V70Q4YuGWM5iIQX8R0law6an
JzYReGeNTiK0DxLnBelxplop/xTA1mZd1yZk1to96BMpfmFugExq4fsWLSqD0FsbfTJoXXydvFPO
0lYJmuFRtnIXWUP7oVZMQ+Tx0Ix84E9vXk3vgAMKW5NsGtYrzVurgGuVdfwli+Ia3NRw40Uy+x61
WLtQlOrSL4FG0iz7c3VcUu1SCJYp4AYRLM8nUyOnxMam528h+85x4QjZXUcr2Z93daa6HQw6+aCv
mjsO6WV5JnTzlCF0niQVVTX5tpFnUG+/rvRfztEVLkntChA/++wO/3ktzK/0R2ZjIDN2wgv5eZc/
2SLD4JPeY/PBZM45vhJcYcNMHqs+PYXxj7zh6R6rpFvFY4M7Pt/1abUosHE6JGIzcnL5KuscFSFx
gKHZj6Ds6eWSVa9lBILQ8euxNI8/9b+W9JEl3mPXdbVJAkBGE6Vc5/nzIU5Z63nnmwXhjbWd7gqs
QZ0qsNV2eeV3xpmuBGJhp3RNJv2dmgxoBTHf2KB7R7AzgHHfN2gAW+ikY4HnKTEzGM7D6JWTQj4s
UHATQxx9GDRowfdBdIOqmd/eZ+pQu3eCshX42Ve3kvxlp7NVnkIKqYu5bMaWQn2+mFS64UG653CI
UVtxUdypm8Iw9HcZTW8fAQUuHg0/K1Vvzc9PrNniPLTcoEk7VggcNN66zHvfdiSkkbaxyPSFxvoW
zVP5Xdm38ODhhgRcF0fZIMfxuzQYhYAm1P0oxNgElwtS5znRD0uKpPmzNTDWVSTuBke2qe7Ssyse
TL74ibZZ8ocK6mHSTp3EvbBFoO4e5fYfBq627F3yJmRtjy9zVvZn6cYdKG2aa00FMda2SBMwbvry
ntsDgA7dKG7gzNlkrEyiaPHMAGHrdfnmAVz18VKyWADKg3UjBoeqZJk+VI3DSBm72vTQXGzwg9k2
UTXoj/XbPJqrbzh6FF3LjIvGQOWzF6vUVDlSVm9D/pSiUD9Fyp62U5DM2kLqnrK+2cJZUaZ/seZo
zNMD1AOhWrHA4nejrSTm5jlhGoP6rbkctRxTU7ClquNT+GFOjaJ+tQ7pyPcUTAcbC9WMC50g4SLJ
iBq5odtsak7saywigGx7EHtKBlVccWVTshx3HqrtC28vELCM0JlaVxx8iN/PSeS7+XRaLXTMGX7j
9dokfyrQ+XGLCgfZZ55ml1znPX7is5UfxtOYX/15wCgcZNgWF3hsCGkNLw8McUbs6BBZn4lvgsZV
mLwpjEw7wLa5tspOyOydQqgYNeY+IEMyFIc0BKhOpETFrxfmnS3Ip0MIyXbAgZ/QgsFdmQSY/pjT
0BMW9yzYbiQb/Lva157euas9jal0Te+OtCg1ISiakYmRX3OvOAKU8PIlCiu4r3sMf07oW4OnaV3m
68EkLTrcxbEwKw+7nS1QAX7pG3vukGYyruPg3uAFqVnW5riT2/CGEbSYV0ALxT1aQmRTj/V6gZfN
y5XLv48O2V8SIzeVv/4LuPLc9H6tGxk/b0id4B6IvC3WA/dXgh0a9KI5QCCXAKZljY/MUhz/1l5e
E+ODrU1xnfm5nFI1NaO9Rut+5ScpDPbACy7y8U+wMbHd1DGbgmw74MfRo10k+OwOb7AIyMxIDR1U
Ux1cVjieh0wovN8RhtUoIyN6S649Utt09kB0nTxoKPAgMWcVk90FyExNp4AwkxkcNC0FLQjz2cJl
Bo0G4+waJJl+SkKCjOTicN7XDYYe9dX9ofuGHyHalPTDqdkbL1JP6djqzFjs5nWy+w0NPUIISZuI
lEjqELJLPSYKm0lrjeyMMKI/MoWaLJV+IjqjnIDGDSsax/Iub7B15Uih4TXcX8BLY1kNIis8iYox
PTO/i7yzVylCSETxa0VHOUP23dMiJwQ53hMaE9gdbPGuOu9OZ2qQmSRNa4Q4fjlQXvQz1hm9s86t
jEx/tOxJ+PTIBEuPOxlOH9pI4Y/qTVEVDF4JsqMOdC8Mfqm6vB2vO1wA3ZDog1OdpFSlQVxrBlaE
4lcnJ50qtiSJ+iE1+TaxGDncufej02an9NaTi0eaBCFwLIVWxWMt0kxhSmX2Akf4DLSjtKiRIOy5
+56HvktWfPuV9kwksUrecOiUzc/9+lj2Ifp662RlSx2e2aj6PiaJVD6ORIpc8IrVGJXN1qgcoblr
wsRQnADb5sWp/nwlblFH0+AKMcxOonDCV+uCPesNNt7NYaoJwqBViRA9D9f8bxAO6GurgNHMf6u1
VeXCOe7b+k6AYqVPreqPYrIXX5/cq7ma6uSPAHDF1P3OEheMIg/R8o+SVtO7/igSTTR+VPYbQ4kt
t61PbGq2komtw4KnfY4HjHrFxMUdQ1dGKUQssKX7NoaNhadxhbtOUIJ3ynWORGCpIJKlkX53WuuL
1QrOHcHEiwmVBxETSklkJLuuNz+gURr88Zl8vA1x8K/WkkFYO2cYVQaNKJ8HL/sJu4wwqEUXZ9bm
odfyRfhl78Uch/T6eLFtFydC3FSgcx0IlNUg2YoeKc+XDTSPF4xIB26uF3KOYjuugnQcDASbWcdm
O5ylsfppCkU8aIpWhbCjauiCB0bYuU/xUBsnXoBkBKINd3haAz7x4XTuNlt/eg2WIguOkqqM/tad
3HTDgV+ObweFU8/k9nTmbpImewyJLNMgdcQnHbKhL2iLd8c4FXdhUkfK4hh35axrgOwgb+/01uDk
btb9RXiztQvfjljVLQBM+WZVzBZuDSVR7vnqUjohq3sHHPjllah6AoEvPVu/QoZ14zYgnfbnF23k
v7ZLK9yLB7uxf/mIaKzy4yD6CNakA1/7dQUqUTKngSv8CwwNua7Vn8Fe9Ak+3X91SKi5FxW/sY9B
ixbhy24QE14PLz7euVidaXmsMcIJIHoESrUSxP5UB2IgZyLffUb4u5z/oZ78P1Zgx2xzZ75M+wiG
WHR48n2Z11Cdh4GIaDtpbvcTwQxeiAfufftYj5oALIpfb2/VZWDq8h0XhnyAivpsj5ckM+IRq3JL
3zV1XYtf3PXNtoEjXD2H0WPd31sNDZDG7Ofc42xMXgUI7MhjqZVgTSvdbC7GWWdv4MJEIzDaFB8O
XpatF0L6FKhP48wUZJZOuiC2m826eD0Y8eEyPUmWkMur20/OkjishZVLsJx7NYwavG9UXOK8Bvbg
4iiiZWExCNJUgZyTyN4eoVDTuCeczznYScMW7OL5sWrqLdn3Bqf6JR1PCUDg74Ng8BrW+fWWBqKu
+KGkP/+W6AYrOvX1qpCxDNwoEHVVo1Q/Glr28UZp3ICeqZUrprMEbt/IeYlzldz6RFm+L/7S/9rL
xI8GBZeRPVpb9Xu5jIBActaLF4Y9bT7rdOufkYCdEbOdEySOsAa0cyYTmUfyeeGeNN+LcGUEQcCT
J/K+MYU1md9gIV9Kz8aZHs6Ow+KCdg2qT+/V2X1R7PAJwfmo9sWm4AgSMqedtJstNPEAdV3HKGyG
gvXfiNJlvxYbtB7eati9auLTUNI05WMl4K/4AVyuhe6VgUpQFsZNBVUvRz29+Cn5qnRyhGNOfl5V
n4ybUYUJiKImH8j/OmiFsxvyzlYgucevF+kkjQs3mBizs4XKuTonrO1z9kSOUOB08ih0DA25aG0e
fbL3N1nIfP0OKUce5BB9Yd2IM2s7Yo3NJ3xLta4mD5Jn1T6VCnsW+Fduf2ZaIN/o/EXrG4SVg5RD
o8EuxoOsbX3ZCiOVdw0GSP7uSKRa1cHawAibs1MWeK7fxJ6NxAyeGMEKF2WP3SEcImFuDmS2QwkQ
AbZlYGq5tR5zLSIrZkI6iNhhVu9qwKBJs6wAet1TaVnIkRd9sDzrUQ9uowxV2IIIH8UD5Izo1y+q
GI/LOnPYLm6jSiU8tdt747yuTwb/+UxBMge5zdEhdAmaS92vzbc/C1saWc8Iif3x30qboTdyHT4+
P1A9P/af42tFKnkiJkSXEiho0pBni0IxyUpnAWieWjPfhgUDZQHzKaFnmYMBfHeDGjdAU0ULesMi
1wN6ixII52eJfPgq5wat8aXhlU44RP00cy+TBHQLVU/5lb+ETgPKrXnnMMr42OLyNtDSOR11Jude
anfnX5vbvX7IeprtkkB8AIam7bdcATPZ0EDEWEIJniSclqS58ujqpYdNP6AhgYMWZcIPO+R9eAtw
J7Huk1yQZpqLKlP3f/yooFfTkedsYjuLg3zm8oqy8JGKpSt1/Uv+3ZmpUp1bnKIWBRi15azexOSO
xxmmJ5EuzGHkqpRPfdGf4VC7G1LuwkVJxGuJk8pMDJ02oARXF+yekSconLf8/gRUJDWgssxR0nSM
YRmri9wv6iSzeOc/+tTcHiHpSYeUDngypHw9ACdSM2JsxZnFzUk0r9W6ZpkieAKVD6tYb1K+bPck
lKclFnSb6MRwKQYwNg6Z+8jKfBkcqwa1u085dPsFTkXSXobiGTe1M25+N9onj0xAdwE2Pzlo6h6D
8q5fAOj2YkelrGKFSMldglLDhsyicXKgSEMAtVzWilIeee0V8mF/NH/aXarASkgjke2MhPP5MQ9G
UKVrSEbLNb1NwhdaoWIDDvnRPcFbeKnKKv+NJRC7Xw+t9S5EEjVp1MDDm2r7/eyt/5XzQY4/ZTbG
slQP7truptry2i2Pl0l8zGZ8GjV2UBDfOcje0IaWUZVAVqxS5n2qbp/TDonYtviiohGZVP33JotG
P152ljkinuzRWcjLhhcMRr9UiuiE9f5WmfI++gYk4HmxCIWUPGA7rC6kmSH3z+yu6+Jf2j08CLKg
0VdrClYcO/eoockKZl4Z9nYPr94MS6V7XNpMXkXQL7y7854a33F8bWkU+3Vge6BOxClAeCQG1bby
p4ryhT0kl1z60gJO0VgLawD0HDJKiXxt3aaZ9Rkpnxdnnm3agnUoagLSuEi/5R0FJoWcjg5NWL4N
zFDzO62BlSZ4G26EmChe2eCRKF7tF7BqrpD/wYFIu9R8P4Xmgcz1WtNJoeE5MbmtYTTXXskKuQ3b
z/28sdS/kKWwutHzqxw3Al6gDiZZnwbEA768/3XoBMs2AsqxQXcC1giyzAOKB0s3nwdBXjknIWcn
83jKhbZ90Gj/eG7bm7mQxNLXBLgH4L14vKZPAWPYRN3kHRx/22I5uNDBC03/aV+69OcQijOZweKK
b9MWBw7M65a6WM5WEecBb1cIs3ctN1C9/YCFe6eKTi5a0O4NPetHT9FWpoQTPecUbkNvRIB7fuyd
0VP8o5AyIOmb2cnLxM6jalNteqVM5ZxQfCQWUwt+R2iXgFiJXokXrVCiuh2vpQqqINztGHXYsdNX
7hj4oJF4APZHMN18al99FI1khkAoFrka9ac2JCE0cC/zh7QRRXHN/1qgYTHKkJJnXG3umkjodAWX
UAnjhoQgmHbao5XYNRSkhydASXxrM4ksE2PNAS/x02MHmqhbwSNVeTJ4IyvuUvsa3uAOpy9UUTJ2
nyOI1SerWIGYdrjE3w9kyQXy/ZkcmOzqCByvIw0PS7qznPJRvZaWyhQMjiGogzt2kUwJZiOnqhHQ
eGwGv8DJTSXoCW26m7tIK4ogrHq5IIAK5FJZ7oe96lb5yW/sqDc4y71hMFKNQGcg08SmHM7FjcWx
OGoBYUZgUjcs0Q9Exb+o/QBBTeJA1HL5Hz26N2ihpHKDlkQdaelgi+OLDLPVdMobQvNrhJ25aSSY
A+budJUzhCX6E9h846OAffInhnxrPK/gPyd+ZrLt7noexu68bJt04L/yVJmYc361/eakDm6SduR4
05RIUh60MMu3DYVkJKPk1gq1G+UNdWF3O4EoG0JnGHLiAOTpTbEOOvywhZGUNEPYdJjO9PlRkHYH
3cFJpuOBiwEe9BqTSlUaTPpbQ6OkqBKaOA00ZhBdsYSccL04YICIVFTax//q+DSgHwfncfXP3Eqz
2+Lr/pnPrSDJgfAu3Y7MJVQzjUS06hcJS2Y9Dbeqqp0azWn2Hg8ffg1uqcQdvuDVY6451b3Ss9PJ
mGh8ChYbjlB+s9GwD4RM1RzG8pKCTWLfZGNoGeCsSk+RZldXzTNv+anWcwe4WmVeqcKpYpgSvrQp
bqS2qQpc/RCDIZzgHr8QFN/o7NXHMmCEJuNopIZqkxEetNgbFnN+Wr+4ko4HenqZuzT4B90mBlNd
YisyiGPuKtqfr/eWNsO54hQ/7N8XSlvkV+EUqlPcNMe6NTSyH87eyIbvz3Wisj/jjwMgd32a9++S
2bdGTU8JFGQL3OclnNm3eUaDliOiu0n6TpkC6snkb16zoiZk6+2cZ5bXLxXwnfUxPVqICm8zBfJS
0BlQCryWMyMMPXq6AloxJUDDnuYXZ2JvZIYeU9icWG8EMS03mqfzQbbqdbwSy8274a0D8hCjk/aC
Jtv4WmzWNBnGSG4xET6O02wi5/uAbZ8der4XA/piznmoAmJBpOao/JzsauIvlAhIiRtTOBe1AuCt
G5of9C9EkoV1M46BhcHcJOkBFAta2dv4M9veLcWVNNya9ZRIiQDzyQaHqN7kc01BPYWI8bAAQ+BA
FV+A0sbNEA+MNZQqgvympm8Qyr4w/Ro7GH5huOMWY3VYXL1OuW5i2XWigXOjKZWeeRrRf/SkMff3
hkKci9v7p4r5VNA3pTpvNtU5aSkfxlo20IWV3yH/uJyDIsOY1QgMbrNR+GIWthkUeY2k622JIn5J
nwbIqhh/zPSUItehdIWJadKPit4WCYXcW1FAJX3Z8VCTZrpNrO+yii5BjmsNq39JfV9MEofgvVYa
dNIFXrDC3Gf1MoFtoHzyfYiOdemIcCcY9DegDNxoXm43DePOT+zmM9lUZfC9lNil93cGyejfUr2P
+mIUo+2qIIL6UJjGCGcA4J1HKy5GPNCY8+zsGg6G3K5QWUZ6L1t5Y00AgZfzDYD+mE4G+UjIx1MW
Nvq5spNhHlbETNQzz/mbrcIyktjgrCyA1Cu397CKQJVXfW9xPN+W8l9bCGc84pAky4Tf7ekaqMOS
wa53Aw8so8Za+HVz8//Tb47PsB5Y9VS6goHk2qIEspNY6vmktfAykCv+DN58AFiE8jh+upKJM5Sv
5YuHHu97sSqz0SnL51toROp3hrE6zubA2qyAF7Lwn5Qn6uBJV1HYx+PJaL0Wfd52THQfY0YkkySZ
HHPFJCUJHtGXTyVok8ZAbClkjaHsVJ6OpBubpXJkIoJxA/fcmh2Vzdo7VUixly/qDOf8aGD7kJ8h
N04VyhiL63SScAeTcdCJj1Bzog/Q/QL8yOaKjiisGtyYBbtNh/YCb0wh0VqE/V7zxftlwyaGoELq
z+xl0j/J4T3RmiHSgLRETOus2YGwe6ulQzYNufO6t5K0Dh+Jg62l3NREFHb6sDwkVpUbZdgsFwEX
szP1vz0ce8ir7cyjq76HfYJm2wDQ6ihc8Rw/4Q9Ixb6/U2Ez6QxnGspcohJP0JgDXY7NLD/+BZWG
waQ3a9oFkZSJiNgWVcl6uSPUnY08FcFqj0fU9S3N8A0r2tVeQ+Srln5OOoh2OkJxMsX0/V49Uwor
W4WzpLsMqJxOG/Li4FE5y+KuyCXML8HlfAdKDvMMzQxUqAUMurA9yfE4rrxIgJFXIXHQiGlYfeaA
cjNHgXNIAe45vKXpQEAnyOgUF9DsEvjhkkjbwJDgJTmEQr8lIpbAdtC7WKSgHpkKr+ohSsSOlrme
LUdVZRI0A3WdvBVebsATNhC637ZgCbcqHieUdOjoNgogaGi13clhPvgWveAjxZnhD+UEi32MBXXj
sYbCNr3uDJVeK/aoxv1m16RJS4XaJCixwOU4R0EzPOstQkqL2dxPN4DksI8RT0ShujYkV6pVkgbi
ZmBoEraZwtEnxaZt66ztBNEJFjdwZ3BnGhQDr+JeYo/hDvJukNWOvozZpnFm4rs3dELsnMwzB9sR
kJNWoDMSOtNkDJitWrblZ3W0BrbmomYzSNd9jsk7IIncLET+v5r/1Ctw4v3UsRqTzok6ihsOaoZ+
bd3Zbpt6Ef2vA9Wb/9qb6xfxH/udR4S+XXpxdoQYhwbBYFhjb0am6e5bNnKtOy/s8UZHfDbAcB1Z
UvTqFTtEKNCh4doderT38mFwqXU9Fr64aVk6eKC61kbv+ZREdYl7fjR0YTUGght8ImzgRQcXt4R9
Uuw8aS4aiM4iwoqEz/pZ33yyTaLPteHIXSCz/zhcjs1Nchcj3mfMLgNrfu2wYKdVA4pcRQ+MKLJz
clmrYndO703/dRN59ty4/w4XG/X332uzCYRWdjHJE38WUAbcRT5YvfaUg+A3W3t2pqtSOJzBQpp9
0sJbJT1qs1LXrWxi+58LhVwnG7ntE2G7nFY3hpdFH24eCaICPk8iq9vgNS9ARAOAW+quU5BPIzba
3AsstDL2hokA0LMXqfGpN5Zect1GC1khFPGXt3PX1nY3aNYXkN5Yjw01gQA5wmS55a9gcc+RwUMg
wr4MRa+sA5HeduCqIMnSmm/ISfqTPfpr0Vc7JK2jbH8ol5OxJtQ+YwbMBFIWlvXF9WsA1OyPelk9
2xPAaHslJlVQdHk6K+dWXOW3/++ilaiqoosK5FUyHKVjIcxJpuok5WuP5iRoeweL5vhjtu6FiDBf
ZFErPw6Ds+4NiLLoVXRq2ds83T2vlehRKKkKwPlF0GUGLVuN/6dBrifaWbZcTTArmOe3Vm3xc6kl
R4tpu6jWoBpUJkISOV9qZs+q84dMRDbgtWm6cdnjuLrSF4h3j+OGwKqHb/v8b6C1lolYPbQd90T3
vrBCtxNYjNj8PJrQzqx5LpueGnTvCKkELBB9ojckPLK5jhsPnTrfEFfoGM93TSVYQeoBC5YKZsMM
p+CReBUx3aSM21jAS/8xWqQ0/Mj0L7vIyzdzmLE0wZOYH5TnJVWoYspGxg5fmZphY3dokEHpvTKx
LcqBVpkXfaGtiEOU81CCvFKyK070sRL6fPS09KHU1uXciqORkaUDYubU1uTLGPtUWHDVfv4noVtt
oPkwflILE1spGWL0q0NZTpQndh0OT4x0COZm5UuC55b6xr2VX+7fnufWMhtkbLyFArhYnpuON9Cc
reqaGJLX537YIbxHEji0sPjMUI/s3ZPM+bjvkiJY6/deqmT247ZaTCHVPgPtCH2yW7/QPHFJtmT9
OekmBow78P+4t1/LZegGKOwtx+nAq7ef0sS5pL5tMEBip1jKw33dYbxC91o/PFFCY+gTg3RpG6a+
D/zXZLvix9Fkx0YpVr9s8WGUDXqE72cS6fAC00cY3mjUG3RN5zgn2L50Ucbdbteomp1naazFFFED
l6CFpj2xPCv+wFoAckM5BG86aSvP1T8BGITuWyhYi3Kmvofq3p/v72cgE8jn8RZm1SZ5YUOi+7HP
DexuY6oT3r9mm5zEI03V5gmZUFf9W+iVBvXbcRh3Uy0eEtKg5VFjdGh1AzlOBQOIPHEzbvUvlb4o
8ljiupeAOO8qP/+HLsO9N0IV6zqOgn4TnGOUOS22uYr+4lqbrTvDbooafCaTJiPj/0/BdUC/EcqB
SlrguEl2B3vhXnGsK3tqmOFbmiOL/ipubXGps17MTJ2aRQAwlgDWzb3bGD0XLuskC7jDMZRMdRgg
noCqhUUEwrF74OHhKGJvwl9JRtSzIFEyssuqNgWS2PRk+2SAY6gxoQgvs34mvLTHiNRnJsoZWHrn
f7ZfYEZqRb5nYcOydeyK6J0l1xahjVZrI7G90+MJUWuPI119LgXPn2lQzfPegLPWdcl36tSLsxGa
1Za47WWQNL/eRS7uRm20jpDiRrIdLlPDWIKvwE1D4dRcW5JWmCQ3ceHy6i7QIdrBAtGJv6U0A0C0
lV+iyp+eux91V70FdfmP3c3LSovVz6u1C934mLMwOyBQjzr9GMmpmq5CwvIfpIOa4sur+il4HYbr
ahrjgr250Dprvw7wyWj65qiguGGlbCL/p9oc+L9LeRc+4Yk1eF/RKa3xjvflYuCff9gA52UL/v8j
zTo+LAwIxe6XZxvQlLxhx640sh4/nB7QX6O+iEwvHAR/hHkYVjxuB0BrWXvu6hShtn8p+panzKAo
DNqWLRLYTRf9293o4GYDGUXvr1yPuwGdwqWSMXnjaZAs8zYRusYF5jPbp+wCubfJ1OVeiaQh4XJw
UQrM+PSovYlmpwCxbnZTChTx7tD7gsJCFtdqFW0KrzvqDfFfjvKdh7BceKmMwp+TauJ0wqmVZehQ
mIWKzB5+7iRatm3cLeRS1ETzogoAcVjMPNni0kdv+5kfl/9vayFInpFTl+CpYjAlbEC2DTm/o3HO
Tin/AiNUi2cXvyjb/kL24a4Uth1SyASxqd+9JfP5ktLHCHIEPAQOj+bdhQRa3g0aMHFCPtXhZA6W
kbOrYY/NlO/9RauxLkg6W4CePcE9tac1vpuh6A8e0oc+MX+LWSGrbV7DjkLSw2PjDTIILqcTiNIz
XTU3Njmhwmm9JOeH4BN7XtbsCFkwI6+vGC1p9yG8t42+sA7pEbxTOPkU99zG2/hntU5DFvP6supx
K6CY9du/2S7woiy/FF0Sw7wER2o/qew92I4cLO/mK3hhQR+0SfeEq8apsRyuIj9ddtS95usg74YE
pVdSzbyJGmOCySqZqiTmwFPYCjYvmvi42+E6c0NParcdMI1ES9DUzs0arbGSy33mPdK6A8vKgauH
Am8v15gzDNTMgFzXF/f54m5mnVhmKhVtWzkMDAZaOyQIfDcSDCYPnReFSlp/xh9M0w823K+tmVLr
1sbzIjiO9r5zPaHmGKZwV2Un4irDSUNOqSuJgniik8DlUJPumMpPwzfnEw55Z5QfvdtEnRMfQ1Ig
uAzTy88+fmWIdYp8TcQATZESvrOkR8B/4+kniCl6ydT5f/FwZyOA2YSUVqZZ4vwuSKgPTgwwat3j
IQUlBWUgtQbKW7kBfA48d4QllMKyjhcNPfTSiFb6u8qpxUXNQl3uSLLxaBjE7KLgynO5uZjbm7gF
QWfMJ0KRvvxJzp3hpbzEUKKSbkjIo+1Yb+njCNkYe3pp6CiSubctsIZj/wlhiLcvETra0pu+xUSx
OJyXfFYtMJVkv0yAHp/u8XUkjOpdRzRV+ag+VT8FpcWqFKOkosTuUYNONar7BRJKRYrXBYBPkct2
KRjyEllCV+A12jbwkR6jBjvQ4ZTKZ96BHidrTIJebOXQLEbfUzAFK5vsvXFSlYnaQhcW24pCNY83
FWG3yDf09Ff3hPr4YYHqgkiH/VJMOodRnteWjDCgm0s9oehLV4aSqr58uJ9Z+w17+cSEzrpz+TkB
6j5D1DtDQeR0Ca5Wo2k5gqWY57cbKT3NwiiTcNynXVUQicBqvhHMCLu4y9dK9umMcniYClAKR28q
GtwuoKl1wjZYzXV/6oZhZzsFBQiygPtXFEtGXejsr/0M9ccMUcaDGyL5sPyiRg/qbl/rqSvqvWvP
D3t+b+0zw6yTuZ4pX1EmkTbfz+OYvSRFGpwpdbKJBOqWEmwfT6KoT13kQZWSQFYBn+mPrX1en7pm
9XHrW5QX2c0SQR649AL8b6xs9RKxbmJbZ6uCqbskcjPguOT1FgnBLHydz3tvzaFYgCIcv8Q67dzT
bec+W8AC1q+MvjhSdRnmM3w5XLrjJlQgQ3EvbeCQNjPJG00KGKRlDTfUlX7rfCp7FyutHJWEujFN
KyurOBKO9CFLrAThITDOIPa1iLI0TQZ67MpWr56xbNR1S6S6hBP/PvpehRSPoaVV4s4PtV0OnOEF
Rh4vF2vFiyWJ+DHBct+TS3gzd38ujtWfwX6kVhV4VAPhlBtulq8h+GtrqkMEeWowkQWpVepMzAqu
NIJsMGyQOReMnrf3ZneXkSuuhvam699O3SXA4t9EHfqZ7BU2W7ualsnB7ivhQkD0i6Q0XxFels9x
qEZJHMMT2kH00vaj+NBVuTsTan2/U59wKyx+Ci+m58MCkSdtpyGRDE+qwPzHH+Ewsbh39whjYK2l
rq0vzTR5hOTwxsiivSsX3AIzgsE2K05N6bpTyjYqnyrjmtMaHPNBlg9+VbYyfOgLu2isTuXC68cb
lSnQMfimj2B7miPnmytN0HTKY3NVQRZOn/bYr2lWZmVBg8xIcVYxd5ygpo3aRc42o/5DhuL8A5ld
IFmkQRyJIvFBXJIJoo0cq2tCOvdl9Kl1xQTkgwb8C11glBReoWz7K9x1/aInpbXneIBXh6+eLpNn
4Wt6bGsjL6K0b4vv6U9mb3dbg89U4AJ+HjpiU6eV1WAoF5XGKoccft1Tcp6wtRJEMtAv/PVSbvJQ
pkhxIAT+pPk15H1vWTXbvLhs0aTqRNCl6BEFeqYQOzsa2Hfe2Rf1LP02Ler35h1XDSM5y5yWGCin
UV94BdBaAAiSKjxV+P8R98NsPgsmwnhzc6wwuRgoz1MnhqBBk9UPgQc2ZJZp5iTx4iO8O8suvu0h
ajWyDqo08fOjvz2d8Xa0hSRwFPW3L4Qbnxe9gFAIhd9hsB73ZbxvJqAuedRF+1e42anrrllvk6w/
xYPEs7oHEgjGckUE93sIeia0Pw7S7S4vTQAdNdnUHmOcEGqGi1kD9jd2g1Xz3Apq/kvoDSROEyip
FbabsQmxMSvJndWNxfWBhPN4V9Ln2EYhYznhhAPYaAmTbVTAi2CObqYS2ucFza/MhOPEwrEZOixr
uh3okevZ3H5Ai1g8G6cOA16ou7iod0LyzubrB3kBmmUV4KlWGHRLIkN1XheXUMeZ2ym13NPA7DaV
qr1+03xe9rYaUtLf2NKk8ipgBMGnaNXJG/ItL+oSmkUMRsXO9uH/oaOF2MF6v0uTxILNoruLcoO4
5D6a20CFAXVUIwtNobFt1bEP5J+T/JaeK4ny39t99ipeo2HsO0kxcqdEeLk8YswIA2TUnPw6RfDR
Xmmo51pvD1a3P++pz8DaVmk4sdraR0U3vxKhKRyhe+LNkM6MHJ61p2q65+eY1mexjDmf5O8+eJdx
+xyPinUFClrSYG32sKwNjYzl8QhrlJHmkV9BUAIJ1a9OmAfD7RML2cNlehzCYdC9y9cF2LiBxBM5
dIhXlaxwkpM5Wq0K+DcnUp24er/8co7Jetw+mzw3V5sO47qQffaUnRX8gQ6s0jHKAjrTM0pY9nTC
CeThAnrrxhPYIdGuRigeFBWQYgIXAFEbsZB1B/OoTiLyf3herHGfcT52H9TZ51CSqMDvwgwIg2Pv
3Y6Spjdjz7/BeagyRWnDgP0G8sPKaOOpHZrnx1jmgn7y2Bn/ohtyT49DeuFpve9IqO1lUXdi3hBe
QXj+bwDC1A+rBDrsd0rsDjBmr2V0b4w4uMBa28L3READ7zkIt4bg3yLTsmRedS9GCt7MAdvTHHaO
juxvvoFdGuP51VACOnIm0febZx+L8JeqEjiBIzl1A8+soZZb4oPgQF9S22ty3CK9I9wGVDOiMvHX
sWVXtEwL8qROKtplyUsr69QJmMy8wXfI633V+FZLXADC4vxjfk1h+1kHPnvwHD4NP96Gr/DPOSct
OQblYrieSHxXj3MDBCCnzHcoTO66E/TmonRWMQ6zevU0MIkZ5VBbdKFlCGrPdeNZEDrviTjTQABF
v+IxjuckeC2WhKnnAL5MHLjHHp4ZPW5IdU/ydnCuDzyznN759+WoxrVCTS7g5EbC+KtpFxmgQXlZ
qzlGI8RrYJNzHFFIbf9tc5gHJCikWozRhgTyOYx/rs3z4YlF541UaHDIYaakIMGAQXcM/pcRIu3b
mq5eZKzpVwftyAkWfvMQA1pf6YnJkuQ+m8YU+QlrQV8lTD+KxFPL//hvFoRV9rUyvbSHGAKdVDqq
Zv2tAspMjP3ogpeJ15xlXuoZ4z3qi5DUCSujudgxAiIOjf3+7QHEvRf+Vy7cfCwB6T93mvi/RVVI
NGjzV5YbRym6i5N7l7KVw577CgoMSLoOdb7z4EcJdvt55n7dhwD4FUY8/JulEP3ytEG1oXVBOqRG
9uIsK3uoJMuD7uSBRtOmm/CJbCkAmJ5DokN/eOLXw3ZFVbSbLEm8Dlp1Zdb2ET5n982JGpcsQPDw
ylM9+XyhZVEa5gl5NRFw//GVyK/6+N+EcRLdTazlRZigZgctzhP2SrWu2TQo2fYgCGaZclOD8mu/
OgA0rVzimthOmdDtAxooa1hBINp64PS5S4TQqckKogq/N+PKF2Zgd6rnKx4g9caDiajwM6Z//P7H
AmdXZ76z0ce/HLWH/pzp5RyKoYlcnjrELtIOBQfSdaBzRyJuzz8GaHA+I9u3OZ0WcuOzixdRKXIa
Fj/bd+hR+OxEiYf3dztcaTEQdPkFLKxUdmD2R5crI1MJKzCVAAFOM2wnXg4wc28Oeqz1mMnplPnH
s4Mttcv/dW2MfPckHhow6rZZISsOd4PQcQLzyF2orGkPOQ8lRBlRvuh5n49rbO0/Y4MHFe7yteVX
dpe9fvxLk85TimCWs+jrwhz19akjE7Xd+uxtzjAD7WYjQOIBAtP8GDSHvrmu626jWTmytkC/q5Mg
aNTosG4EsLyZEmDulScKlQGX0r+/EYru8fB7zC0OGrM+futqyULMntohvRrlMSoYtK7ZG9X5J/48
uLn6J2jo0rdg3d6LTJaj/JFBv6I9xUDO+uqpNlly9rfONmgt59tKzBUTX2L0nideSJwu8iuhLysH
fEVu2fQ8bSw16MyJZLoMNq98XmoRmITbOg09hf13Rcy73iofh3JwumppEanJkTC05osMIHpEGEEm
Ws8YdIz9oG06gh0u8stzhS9QL3hCSsp/kLuGaciRLO1JbraJTr7da4ILRCWbrQGO1o7MyGnHpMRq
wvoIgfjJ0Xs7YEGEi9PVmxmHdXt3VQIvC1jLayoYr91ydFbrgGVQ7G+ObfKt6sYfrqPjZ7V+LkC/
kaExzRH/KswpJ/OhzaxeyTgkS8sTasQsdlLL5XphH9Yk1SRH+gy0S6rkchVxBhbIfhkwR6xE12p3
NhOqBV9CJF8kHMISKTv3uYdJt22fwdpi/wZl0kalN5YH2ss6xEGEnORQuTFIA/HaZZCg3WVYFz6r
0NBaUTkDr4JpxgTXI02OisXiOFCr7z/w4NM1fxa8nWc9/zu1oScQ+C3PfVrPYrC3oxOodUDKC81G
W3qq5VvCxjzRZg+okabKLyTdgH/ehGWNOcXN3SNaDMNOQjiQ9ub5DNS0CTRLsagTSbevMLS8h1xv
Q5rerclejfugfThZRME5ZEQgX9WP8ut6rH145nLIqEdqBdZyX1/UdKuocmtPYavIPu4WvmEuBPAz
N7dFtfS2guW78o+AYy4Dp8HXwOFTqQ/lijy46PlZCg6pfvaqO0gfdseYA8m6Ei+3MNzqAM4QN2gb
hw/X0kZwMC9w9vdCgKEzKt5RxCEszCvwann2oWZHgxeTlHFCWGPaJWM0JJbUCJ1b42gPWMYFxPTk
zLjqE2I8kjs9bUeiJ3e/t5qj/Dkmvxu795hzo4OHQbYbQZUnIrAHKXxRmSKi4z7VOGcaL4fvebHd
5MxmOwZBH3goJoSWUDV0LtemNpaZtYiulhZ8F/bheOu4PoDBQS9W8YqU0qIO+VfEdAXAy1scI1Id
qJi3blqmeP1T/oWLBuWLvQo46IJMMyZ2w6MUwwLN/HHoY4PyJJ3B0FXYOqSBga8ZnPJTLS9TLb1B
PmKndI0nFA6dVYye9vryhSsnfbPr3ZAp8BHWfbT/AH4pUD9ckL807yghP8kTMywioPkVRdvYzXun
1p/1NdBm/al+4MYX6f0d7zAY4hMbgqAE328MuB2IsFuOO87yvCZqdOj9Ti4Uzcx9HZi3St5D8A+Q
UOI7J5h7JuweilQiQ4tMCfF0I1AS3VlpnOjWVDxKUUZU6Y8c20zW4c8qA6hsmyhqX9L3V0caF7aR
P/+kad8KhP2UdO7SB9DLKajUjPM0ily8ZZK2pT4hA/933Eq3ya7/aRfqGNSAPzk8FqpKTFxAyQfx
+hG99VBwAAlGBvcdndIYkHld60/zqaQEheFiYP24ieCpkgGihL/DUy0UFpvXfN5nTGrbDcfB64dl
OWOuXAmEUvcj3wAUjWAJDMp4LH0oMzuS8/xnbm1aLnSyi6x65NGziPAB5nn6+6d/MPSBl3j9l94M
jtYgJZMsxgOJwD9UHRpGii5glnLkFOiA0QLil7xYodkRNLPM5iqVnGy/XoyPyaZHTW1QA91bDkcG
eD9P9FLkJ6fHYFKVOV62lX9qbALJSCLXyoC3tXS47w6V7gK+mes7KCITLXxlGk075PBdI4bVKsmY
Ye6styd+mUYXDJ8gZ+zRtL+GuI/AeqBYg/GmdI8hwpxN63Xe9XXLq6eiQelNS9hDRyrUMNbUnhqH
pxVTrOcno7LIQVWYvCwnq+EtdXWFF5K/cqaLz8m/Ibu7maaR5WQz0L+tgFURit2/4eMv8MwdIQeP
lLh0WFYLh4V4ry4Bd8wu6wFuErJoizD8f1bEw8i8boV2o5FifEfp+RV1djuU1XJBbQ05E5W3idD5
yBJi2EYmBfhTw2YfL0VUhIMh9A16NbTj4jdhbTNqp/yY7KDPZDc/5UY9+CKN/4nlnWPPbjli3ZFr
98y/pTKxqbux6CDp+LOqPJk6PxADTJwG4Fa+jnqXtgtSOYHIr2LI+WAtzJ1b794cPSlQYjylgFOD
vAtd584AMKcIeWSu7fsSVW6dqNSKEqGPU99cnRmCqZmZomkYbXT4ra4r8UAzO4XkhGxXoDlRIkYx
72AssczWVqNCxLSH4PFovvE2SBD6v1DA497Hjib+ai2NtJrCMJfrr47E+UZfhVNfxCfrEbBxxyRr
bi5JrcuJf0XUThxd8mzM+RhiIgtS7O1pzUGp3aaV6CaXv5tLVWqVrQcVnjAsrssVCgNpIzku1Hal
WnUpF4+HQLWPmfIa5uC9+SUU6HIEoRSJNFIRBW9n60LJoKW/ZYydn0k32JBdr6+eS4Nxz0lkeUNf
obF3trSHECBYyHKrgr8Ms+IWYhONGsDTaCeI3KWMOs+FAaN8cjdpyecyra3YuqUZ3EPpX30e9B5c
Y38//nRDeRx6LZ2crVLdVS3k8U28iBn88hG6SZ6lP/2XTNC0sci83ZW/SceV6D0K2TpqWfhT9Avz
dDHg/0YkyPotxUQrEudKx8LyjBos1xxcvoWtZj4gPK7Chz/iAWKLO+08gr53bfvwBz2UbJBR7/ak
xm/yrhTiQE4tTbIprY8Xczl5u0LQHoq0YF8TfnMg130Oax3NLo7yhYJadroEmtPuldIvhJCvB8DY
G2TAkk1/vRaSA0bveJ8SiC9FrgKYur8fBeES82EvhCxBNnQsgdGRB4wksEt1W1UHHcyjkTJyPNjq
XLFjTCVFM1Hx1DbBd8udkH4Eo6whdgjqZ3/qougxKrBvZd1yT7A/Zs5Urgk0matGYait7GkorXrG
MG16+20cKvjD73aCcWTl73n8HcRDbL2AI58kFeGifgwXod8q2U1BikJxZcuZK9y1W04UQPOJcI/J
bUoe3dNVzEWb/zSoIjwHz4JehTXl7IcWuNbtIiJh/eCKkHiGN3SytFTFq9BqTM2zJ7+KCDS58BWO
TCWWwWJPmtmAinckuaJaz7gJEs5qzW9n+IQBZJQtWuLTwhBu0j08tfRJGedp0ePMUkn8PogUsjcP
WH2f0InyvwuRU/5VN87cVYoT2BgZom7Vd4S1Y4RATJrs3Sty6bYQ3OvHIinLfBSU49UfXIIm2zFg
2bRlXa0brR5m5hO5hESRdoqUi0AV9PWX/8FXuHY3cKQdRNJaDDOCBVxjaJba8f+vUh35Mv5gObZs
KyjHwIfL7rwo+RkKTJFDvsGHC/U3O7O9tpdQfC799WVdGknIXHueRIY7R74F2dIzPr6dJiuGf1Sj
Zy+tmPuJ+h7Et9fnRs+JnDCUTCEj3tKVnek8nDVnm3rWOTRBs9QWYFAHPw4Y1TSkbL7zAI0Hco1x
aqioRp7nr+d/MAz3cVW0yJ+w5DnPpSyOO4d/+c5OyLYDF4hT3TpdszbKOJPJSxKrCZZhbxiutFQh
SZwAQwsGmz4l0C6YuuVC1Yxp4eVdrxBzaJTryx7ystiD4jzrctbwCjxLkzIumhUeUWmsLrWcp/lO
r6CSFAVwiJWve0eMKXrjPO3ugxkD4akHwXLzEezsELXZP4Cf6IKXJEHtXQ6LT/TKIcTguH+gktiW
Q93AxRoIs2XW8WK3ECDymxS7wNa02Tbm6Ynel442FpxanvPa3UyoW7UGUkQCBx+r+L4s9mnSQkC6
WYwwJAwj1AXzJyvGOzDMGLuBWq+pIwdQU1fMe7LWubuA47ZGZyDRofaJhQTD8MCziIEdyAuTeox4
5AKBgeykj7U9IwlTeYwVE0lVxSqho4Irhl+BjzymotzCgHCuErwtJc5zK/nkZb19FPcUAnKZ3vrR
V9qP+7cHtnYXss4GX5Tn/XN5nRNnPpIe2ayC2NslyyKOb5FQ+QK9yAD7+Wua1a+ehUdDest8b3m9
l96zb610nH7SWPtbxxOlsACRuHxen5xzuLe+2+WoYyCFHAZKcsvwHRoRU1/9+MxoKgifbcxZw4qL
X2v4oHvCgGiwS6eyx8/QGmotYVLy9XCLA05Ljjqqn7SPL20jorAsfE6kuqFzLLiJUB/ykUYgUQGQ
gtVQMzxsRpCNymjPO7xpeBu30/1wmR0gzZOCJsQkD0+RmzPXndJaz9BoGV95nxrB6/xqAucfz5HP
jkgZd02Mb3LaFp20nBGR1YEwAeYa0QipOo4b2juPklADr1z9/YJ5BR+xQ++K81LDmox3D4/UExp6
++ko0yyfEGAeb0Kg0L1bUCIWWXNI2oeQeFhGWc4Ltzl73lxgqBwW5zSQOic4a0KlvlhuXMNFzyNR
rP0dgx0nrma5vvd5gOBqdJpODqM92evJxje+VQOdTrGiEqcqJWYOWEfwFORvsB6qK4Owt4R2s6yq
hyrk0S6HDLxUTKuTXshe63s3NinS4UgheEwYWzWkMwK7CmAuFoAOkrJYJCSOAdl/8SU969EoyVjA
jRQ/S+d+dB/7oY11usKn9Lu/l3cwclSnEJqxqy/R5AHW5zEcW2v7BWQ9EA7ZvUApVqv8aOUdDK61
AQ+FdB58KSSWfEoB0E2x6XkXxng6LxVJ/zvwyvxFR9MBPT7MT2Y31Bkxl7Zlxu92Em4Fqvnx6P6M
fOYp+0qPD5S6p34gkbRW8pcPS11kAWZk9GzN+iDVduNe/j2ug5Qa/5Y6ftTPBRcQSY2gj1fA6/Un
DWckkCmXxs+O3YM2kN7muZNFueRZL7odWGfTnpT80erMecoEU9auZMxleqt+SJ6f4joTe5USaXAD
eTDbs/dqRHPvy0trTs6r7eSvTiINtuf2N5n2TiuxESGSWWD7CBJtJjKl1e5eUbMX7ozpS2P1CwgL
kfx5l+j2AOznYax/1jL939Bx2LVVokZk+LKcDc8/AEr2WhmioaYhJclTHNOgnXW+nSVl2VKmkSut
9yUjeg4MBp4h4jwRDmsJBoCC8B11jfuhPbWCUlM0um53wTkR2/hI5/tGnjksGudG8qWNp4u2fBQA
IPijtg+pIAHwwOY/aPuIfXHRemqBN0yxXEDUW7Eyj6603LJ4fiv6ErIJmG6e5TTAm2jAAFPik/NE
+I45yi7hYm26QkP3Fe2+oDghNA8VflydYB/JiBR1bsyzM9Wda0vMMGCu9DLSfUWphxPBx61cbhV+
IryE77/KdPd0lDXh0jZrqlxiKDW+nUrmjMJkHQ1h2iUDE/7+lEY71ojUzq18OF0jHEZBnMoAMiWA
zA4zb4cRe48MvrUB6bv8Z/s48YC8Jv+w9nd9qWaT5ImndwwNlIR4aTbHvDLvJpF+Du/XuqerM4Io
VObp8Q981onO/nPZfgqTnmuVJsrPy4/uLpsYCtAKP1qAIf+m2X6fO+27R2OTg7ZGv6U+8tqUULP3
b2V/wChpkXW9wh1vUps9gAs9pTkwO4KCQA196lWiQTSbo5v7VeirqJ36kgEau/t8GdSZXvK4SWn1
uXL8FKH3VGPw7tnrujisChFhF20o2BI6rHqtEWN5ezpdEfQLyMDkrocFjcljx+haugBqI/b9bcJ3
a8tBO5lfhuoG+nLs707tPE3cdWbmNVOde2KWkDVhJy0Y9IKT+Z+yAXLxJlokndND5s5r3YZQeNN3
2D4yP1JMTpXRfeak8LBKbGw+MpAdmguPQ+yHLSvtfdJ581HBpFjOCE84MW4gDQ2r6GOn+lp+cu5G
svrJWkLK6/ULn++BzY0LGqCBwjyit2M7iN1RXjpfOUVuf8NCqGzLEU0QMbQSevY8MPGCQ7FePTYA
re6gx6QLJ/Cg16y66cZpvcCTn73vtoe68rXj3FwT+Zr3tRZW4n0HyF75RevzsJywX+yy8WUOZQgl
yM+G/hSRBdrqIHlKBpajV3WHeEdz8TPeahY095htRWevNIq/fU7yZ51Z6GdqfbU1/KxdDomZZhhu
7/XRS3yKcTXuyzWL4dCkGQ6bzNGw88saY33fJSZTNWsFJgcNuZpHWysRGubsReqDPC1gjjOCrszT
WWm/fK2LLxKbnV0jT8yEmnnI4ap+HphbT9+c23v2p5QHVzx91jyLZ2Kl9W6OZ7AcgaIZgw4npve9
a+xPWqfEt9/zx1VyAWtYxllt31CcQPvjZYi/QDcCYCo9BqVtBqDGLOOT8PtHs7ZdKQdGYHefCE6k
ACwhU2JKorgahqJO0Q6C9QKXwSN0iC4rbEVNm868K7/vtHakbOYDDjxoGgpFeD8frmaqZORgH4Qo
2gPAGBzUgETsNHmXJOCJBTZ6yOm04BVrbRZlgQBBIMWtnjzcDWHzI+R4MYoBhSOPrjwgbSY5M+S/
/vuc1x2c4Kxrz+uW9e6KwF5mcKtg76Bz5viA/InoMWrPopdPfYFiXvDp3IXfXM4OAGFo6XPFL6TN
Ld38qXoWLKaoLqquOVcvq1vHD+GI+ptVl2tnwLfT+pKNlibmo/CuOh6WOJQ8uzfHpAk/2nTwlSfx
v3xtZd0qyILDEcZ5QW2QO/V1qNBAo6ULrYrQ93Ygugq7kphAbVUdAxsHJX/yfn2jqco7Lzm8+QQO
/30duErT39AH4rKQ4mJZQ3kxuEYDf+kR9yNS5LsLlvUsexe3VOE35Om+wfzogGGQKF/jwfUyDspu
uEEq7u5eg1T8+Jp9trM7R77U+NmHMek3jPAECGIx3Uwzn8VCsAy6jIGVB5a111hoLgHr5AEEBwQM
Nl2I84KvyNfIJKG2//t0SRv1aYwTUnsTxrXqjYll+MOR3wlo0Wi75brB1nvwspxMvqh1M0GUFKrc
BE/9dF9geK+SbgEMGEczuM84jSY2BDYjfN6beVS7zrEyuXe/a1S/yi995DdGeJVn2pwXYquIx8Ys
eGVDY6SS/EiLXQW0/FTaBStL8ymEAeUA+tEAses86qZqHGeEm/3CoPkAtqSQ7m4o9cUpuFJ/Bc/o
arj3VTGC+ooVro5zKbNP3VZeNcFV2JKaqff25S2vguxcZ/fRCGUlaccuyHiGd/FRYJ6NwDZm2add
Qr0l3v3DufB9nr+fJ9OIrbnzt+Bksp3GoCi7y6sYaUSnY1Z/keNe5/fgYo7Fcj3fHdmdsuzIbZjp
RFu4KClo+Bvj6abLF0fYztRHhJyjZDTkdDJlzA2YsjaiSvYWZXsuRtqAu6vFWsrzvBeH4ipYuXvq
HzdWalMf2g+B6wV1Ftc2Xh1E3nZt4zL2zWgma/ExFQ0U2iUkrE/WB897cx/HxD2LdkmgMyXA9mp7
JGukKzcLT6dplAoKCWfgIswAjkxqNticES/qqiIyRarqYk2hfWv6lVN1ocVVMT8Td09ifBcjxyh6
PVXtNcoenjsCmuPBxbDIjoHrkaGyANJMoMa2n4NZakW6G2/P+U59ZWNkfULzbuRf9148XmjzVciR
+LBMj7IJyyBc0m3AXFK6c9bMvT+p3pbeuH/EVtS4I7S/X68Iicaq50zibXCJZy0HwfoiOOCiGslT
56ziO2jsbQgOylrsSoDO1qlymEG4iKpHqc3a9sbjENKMzJ5i0dZQeeg5MMcaZYKwgCQcGIXriypX
HyyYeG7eQEqarvpYBZUSn8Nzp6wDeE1pK4K9JVsuqFzZyWM0kazSeGhkQExknruvodhuwD5JtU3C
df543h1nT6u1dijvj/RLSslIiS1QuGv20h5vgsw2/71nyUEMcLRofBWbmlBglsiFCWSCms23f8OW
udDGmNp/1WnMRGdE9ccWeUQIJ1GIJJXGfSZPBUcqy+ZZBzQREIMV6FtHBgrdxU1NvNlG6c+xxYJ1
Ga9Mzv5fQikkU+t6713zemgMyJX34Frp9CticzM/hNTe/RflhcOl4dnqfpID2qN6pgBSl3id0KWd
qJYf2qC2WvBS7md4BFAA5389IpYoiv71DeyyqmKgFbwMfCtMBSTPDcQZorKAxcf4CgZRHFmRCgy9
yLuPOIAnn0BFJhIkIZ/d/r3Iwg0U4p3pUr86bEVoXqgyc7yCuStgPB5KbZDgm6IeZK+Wk85jMIow
S6vLlC6sOKkeFRE6HmF+HBl82WBopNIYdIRmVcUsZKU/0jmSiFO4aVJmO8h9t0mMgRk0O+c+n3iN
6YFgdEd9Q+ZNoJ2TGB4r4aEbsVd1q2nNxOOZ15+vEAr505V7ZfJX+ybohU0x55WMBf03wYJneldW
dnLdJe3HJP/uwiGvIE8vRRm5TkKQOBgXAmnjgG6yFy/3swg0ZAAYtdJ8iN4uk1YR4nrVXFuDmZAZ
Z6QdqW8438JBH9Sb9gJRiCFHL9r6djHtKSQJ1ltqix62hPi355/NC4pjh7opQ9EVKOg253IVJwEb
ANJydyDHuIYh6sx828i7+U8xQ1wzGScBlWlXV4gkKAWDOqvw9FAAbZmdOb+w1g2xooAanpwXj/2B
5n4616yCvGfWrfqkF7ePmcVuYAcI1OynuYGAGDeTEHKArQqrNZrpEPBJWO8I0fhnechIyf+jlt4Y
+OFRUT/EyhH3xDDv/D+pSx7EHmQB0BQMLpW5TxZnt+Wwx4dj7aMdTsWAzqe/VIWIKC4t3Of4Rkzc
50VvY92so0wPY1EuNs/7quxX0Mo4L+OTKA2bbkpHxlFg33KWe/iQyE05nWGTfDLBP0Ldg1Ju1mlT
gY1aYBKY36Sy9f9l3NDH4RXOTqQa5JSNnrT1jqaLvEBOgj8cDn8wt6NWUoyT0q6+S56r9ZFApq0z
GT9xCGji8+ug6mtzZ/Tv9rtLK7ZUt7mE6uJHK25JhfSrsOtE02F9/NXlBqE9B65drPH4YwNgAiAB
m+t1mTNivXA3mygMnlymrxZu306ZMXVKBJPlivYhbzJkWLR4jqiZlI51ysMbuQ94sFWaJmaOa35B
brcX1WiwXdzyNSd/fgjSbJ+X/5+RS2oeZdRGS1TV17rGKfTNZ41I1j8DoMDrj3SEv7/TtOtuYGLM
Nah4aU2LCArqePJF/G6/N3DI6OU3FOdKC5DZDuMh+NALgxK0Rd+rVRrxwzmTmqgYk5wvMZITjqRM
qHNjVfgT8Fk/WnDTKZZjTKtb/xkwzr+hy7wgXRPr2x+mg9RRRRmqV1eNXyyhXpFTWKwl/TkSrNC1
o2oYp94mgmxALc9x0V8Orv+ljvT5jSgJTJn+0aWHmT2Tnd818ICmj6oLN+ngLj5DJrnMAUBQ31+s
I/742OjzyJG7IokRmVbbQXGz6Ke+yDx2qMQjrKE1/snbIl73qDJVxw/RQnVWmhENg7akciOdeDrU
GVOrCvBn7AEoeHVlJBzXoXCSvKIm6GPbOCpo5fgF+GPNbpX9oqeYvs76xImMXlTG87Wu8l2eHcZB
HspMEhMKIh7ytlalaB2jOL3do4ToWGQ5B8LflPY2dL/dy7N3SgbeePrPeRkJECzW17OkrbuHCbvE
l3T1e3waE0l/x/NX2sEnwsHQaZNOMkYWswoYWLrgnNb27r5LcUxaIVYb4aZz3VrcrCowrSwpdFdJ
8XA7OgZ8i44mzFrkB24yeQWqLg+ynpmec0oaW2QZ00nPGzDnb5L95uZoHjMN8MyesSs1Y4dgBFCh
mXLjxYZoPunQXw2sYYcWo2Hqoy26BRCI3TmnrbiPO+H20Nh0U6z9+goH1aEkUOovqRYsaT3RXMcZ
yh/ab8pkFGgK3zfxIxKvbJSZAcdRtEtm3V5V1Wvt5c67qH7USo3owU7UIKaGGpgPXbjQpfmGP7ir
iB/3txuZi3RYKpRzwkWKxILghdyZ6QZma+eK2LnyEaAioR8qBjQH7j7zxTXtMJAJMeU/r1Yl59gr
/yHoIDyMfNZnKZOdLIaS+FvhGOamCX5p46Hn6LdPk+PG8TKNFcEuEqX+I6aYYJUShKcg5GRnUb87
tI28B38WzAKQt2RoFyp97dnT0oC5MFpKKjUX2u2XquV91UIG0w42LX2K4WY8V0cImOIztQT63sJw
on3HChAzq142yL0kXy1KrAtPKAkuXbinKb0pSkZcRnPxvBr9/eHTB+KKvk1Q5gJ0gV4BY1OZqnUK
762rbSO0E6D4mFjfrX4Rp9AErTOV1JNxQoBg4sSQ+7ObQO/JzytDr0C/Lo/lyDmWfSWSo6gX8zHH
wpPcA+vDBISy4wh5TNIG030qH6qNdRnTumusXmBIt7cMKzGL6yn3sdNWDKd2C+X76qkr0x92xRsC
kgoMGhMQvAcpRTqpbh8MNvV+rJSy5RMHvuzQk7IFZ/tXBwQG6bwt3mBbAuMx5Mc1MP66e3HhlCCm
2K9EI0zUEryKWu58o6rww4HTRFDc3jqmv3sebhhrdS+Q3wtvMbVoMdhEJMsEkYeHcrLcpyxxSudF
nLHytlj/CPwXw3no10nEHg3z+zW6z2W/gCrHcaBJVCnZ9/Jxw6b7SesxKM+ZdrKQHCFhH/g+991d
hJvY37Ujgy+J/TOX4p4t5yAz6MLdCDorAYSul3a0vGZjwNAsxJFWQlzOFuzG19KktP0vsEHAwRn+
VHLLWG+o+ZEv1gLk2j0vOM698PyZId+cj68wOqRmHwXh0YXPnQ3EEDVIMjJ7e5pvjA+vNHzVfI2g
LILXcCSxcNFZzVkrczOm3pzJWgOG0RI2xYByExinfnRui2cpIY/LxC1pdL5HEo9K63dBth1GkEZf
6zFAMk/t+1xt2hJN75FXPOsMmoyblWRZBzH4smhdwPscOotmCdDKJ82k6o0llfHDDYd6EJoCVgka
dkasyM23cYhgmbUaKwqNsAssjixM6fMvcSvIJpW1Jb0DHzTOGZecQ0wOv9lRAo4zOmVaYGgPEwxi
sYTgvuze/nk00/km9xxN0mOyQi4x6dCQqyVlk3EZJFZ8AcXyGZLDsLZ14/6b9KJJGuGeMViopFdY
NOTohmTUeSCXklpv/7x4f1QetOKykipqOg+gqTugLxNBfFRmqd4M4Fe/XgRKVjl7bQMf2SUlWwAS
TxDVFFGLIhMIK0yeX4bBU1wCFWaQnUgvPw8guuSDNJ/YOLSVZVAKCiAWqoCVEDMBu+um+zzwx/1s
LQOLuy5v1A7B0bcRnrpjKOiba/vOnEKo0JVcEsko7DCybGvAQQ3u0IiaALbM/vwOmhSrJLSTGkth
VVEzN3aycP/a2O2qpRpWTtSvJPF+lwJN2JUOx6dnufhhhkWzJRYHMYzHL2Aj+qzblqGSGuC/2iQi
VK6MKv7sK71o5fePhl1oXLqflgFZvAZGN+Gzg/bd5zW7XnLEmJUzuGN/A9oW4n121DGjW+GyT5ou
0UfCo3VNP6Yt5ouTWN2N233nYM86/90NnrhAMWOThSfFq/aGX1W+/iIr9d9+yR1CQZ/indZk1Oee
JGZ/GxT7xZHr8GNt5tLOmH7LeejYlyI8ThbNp54zw1KltMhCNWX/uvqxf/s1N0jTzvbS90qEguKK
+eyuw7z0ew5RUXP2w3uermjgyD6VCFoyiOf6rhOEUsGiWxsYbU2hW9Pd+0zOASb2W9RnxwbotW4w
4dwO4pRkdss4UoLB1Ykt7e9NaWjHHFNH4pi/oQmXbGnATWWItmdn/BZFhwsRw2XPHStkT05G4PD+
FYUkNun+JDkhIBhTV6JcDdvfJp0c60ENef+rrgen0qixbMf1HLwQ/4bIrXablejnRt2QzA6kuaW3
8jB8WUtQ2BOX6sGHdBcehfh/+A5zWwYGB5jwA7UqwsL3LR1mm/Src1Pqq6QvJDBZterW+4xS4E7D
WYh3vuolz7jRndKCe2C0H2W5upKFNJrW5fp94G8Ujy8qn5LvA9fqf6VnhOl94GU85dRaXT1oNFxA
ySZzXBx1oxCWVg+12JivO+gDbIJd14jWhhrvVDX1cDxdcLwikWVCYsghKIRRvexbicIFE03oiJSF
b/A+HTRwpzGsPaidWxBw6gjlDEa8+o/rktmXLAY2jdqBAFzQLR+WVRf4rYw7ZV0WMF8aD+GYEBlm
iVD8VOu178CwaYFXARIiLDyFFD9NttRYqp2l4EaXmaSSPKB2UB2m2Wmwmz9ysOZ1bcTSyccqC8QL
X66BPMxd1MuCPZd3tmVBhsfded+ZWpEo0hnU6cV0Fozek2pnRyDgbqe4Qe3eAM53HZCAp+w6IgyJ
11w8IgzHAQUrxhmb5W6WOo62RCAiezV/uMbgyWWyutuzKQCnH3KmFp5VbSurmjJdTDnF2/vbE4V3
Aihj5rNT1eiQMMXb0hUOGk8Q7YduvG6k9Ka0wYEo9E+0bkctPnD7wrBRwFKzPbmX6hsIgsRFIDBv
vOxFXmnHN3aO6W6YaF2TQlIqrkBbtABSL7Mo+vucum4PuQgc3P+dLodkmZd6khIhGy73zDXoL2Sm
lfgUJt6WxK3Ten2W2+vqxpcTM46L8UVGiO1t2kwiUYCOFuQ9klmbg7TZcoDwtdNfM9Xt7lkeaqo6
Z1JZO/tV/J/WSUZatTxOH+Y1vZ3vOsylRzVW+oS03MhPOfOYFxNrU68qfkh7z3SUnPJywTcNsVAn
eUjqHufM1479m3P4OFOr7pfmDLwfSCzi/6MtXu3HtmaU1X5SqkNRO32njMEUKKSkLH6dfsL8TECp
cNg5nhVZlnZQi15Kd0J0iJabE364yzr60Gf09+3XyZu+mLYKrrl72p06Ups9oGO4J6YY5yUc1BYW
HlzAtAHKQzo2LDWNLZRX/E0mNNZSq9wTR313dwykLGkgtd5IrL+1I0E+dGN2+ehojysGQsPktxrL
RoGb64GEoV1lXQE+4vLu+xQHlGTDAoGUtXM5K3V4U2son7p5I7oaUKJqy9RoBTCx6LNNB6WGwukR
U11GF9PfZ+O/SJAL/852vBsSeb0PhFKbFt9IctPU+x+vV63ecF8UqOJHsOUWGc1FTxxBQ8lTpdVU
EF0qBh2VTh6BLuwFF+DOuAWdJwGXBFXOiuu80Fg6h5ykxkpdxoPm0GJup89ZBalqJOB8V1Mtg7eI
TSZRpmxndU0pM7AUJNZrLvv+F2b9OTyvP8Iimh9n+UEqw5HsA8wDvhmbtTAbwPa9M+i6/BMRNs9/
tBu+BqoEDbxcGrvajHlilvIh6cPylkrcWe28rIjtfvDarqd2yYXBtcWfhi4+8K4Zv/vydS8OrtEM
6xUviSBhiOo7OiYmEdJhyCoNyZl/ZCv0LLgYdft6yGIlzfR7y4y9rCS1DZgnXoA9eLdXuNkzjGvO
2hs0yRH1vYxQ05jwA+GqLsCvx2/NXi75GXLUkNuPBgCcAwT3K4rkAVQxSwhhT5+t5Lh1bDvUl+OS
HXWM1EO2KZwfsSujDQxlCgNnOrPtCHXXw0k3PfoLbbWHsjFl52HslbsVZV8YKWL0bxj0MtPEfJ8e
C32Hw0Bg3w7TBSo17oHtBeiUsQF36vesWBRb/PONBqxujnF24iVqAnhSEqVIQk7N/JZN/pVIR0FX
kNVPk6GpvScRBFkFnSL1kZe7e1w4NyGDRj1e0y4PnN/SRe/blK51RExRDzCSKAOloO2GyrHKzCHa
K2J+3GO4X+44UrhXtuuNNPk5ZWUDmI6Cwu4bsHxC6Ig0MfYBRWJRD2qjbGLC1TufQyKglucxzeEs
VWZaNiq6ks8mcaMzW6HQQ1dBgBfnVURicRh+tdkeJ6TY6FWXWaDCYd3N6o7wVCBAiiI+4Cukc9w2
XVFcLeayA8yUuKofo7MHn0bWpD1ZsR4apzvM5Q09ivO+slo+dZ3suM54yadgjd+hvyUXgvJ1cRh3
MKPCsDfmQwoBpDb5aA4hOhNYEJ/gK/JheLkBpPQyAtxsiWHjy0fS3WqSy5B3L/4VJ6HoHILGKRAw
3r0EgntKr0fRdmFfzZ6H3iDYhise7nPL1Jw8IgfcYlPKQDwng80/bpAVUKaurJ1Oy8BeurdMrRM3
ymueeBSKSXjqDCLcba4dDoG7oUU4sbWr4tcqjpNhHQi75o4VbVDHg6ffLGN26WG0HXg0lT0LpaK3
53hMrBwN2uquVQWXvTnIUO0PiqdXX9NamXNXYW1cITHi5BaY3RU3+m6Uf49SgkX7UfQTbEaEXd0v
wB5QL4uTR5FQlbipcJq0c49rXXqv3na6MfqVLLG5AHir16WDO/A9F8hQwGbzCnZ2+ywvASlhDKP3
c7gq9rKOQnzTX/Khr78Xt+JkkJFNAukNNiZjML9kvdL8BqRewydfTg2gK0Yi3Zyl3qCMRSPU89ZR
4KSYomQayQYSrDQ0iBZNjgKrLafWmWn0z2QH+HUwoVgslPPtuQYUjbsTCzhJNLhDKXeaGT5cXtU0
RmldP8Gxf++4Jtu+7uAZP8saAkp/VgPg+q8GSJOpEsw8yxbB8jt3Uu8INcjtNqoafMVCmEAWsB0H
VDvUlRhX0S+vMBN0EB50KePdP0d7hP+YOGRa3JqYdNIls/tHv7L6eqnI87wprcPkiK0I5j5NkrYb
+21g+5grylOW44olvAsJfhv2yagjyIoh/NSPf7Gm5G4UEjnN2pyzdIYkkOguCh2ztmThbB90g7mz
5nqndapmqR8JDPetcCe9MtRx+uZ54kXuQHUvdjHAlK4+Wb9AKSU0ByhWj/gegSlCzj5SYaZCcjnA
QX38sAP8ddp0nCqEg+FL7qk7ZMmetKqzijznG6ju3g7QhHuwVe1lH9qSZQ5Jyci+9Qc8BAJLyfLx
OW4tDMCwWDlfDIIz6extyzykLdR7FA1C3ZXCqVWkFIVk5PfuYenGyQA0kYvQVsxkTC+hZLIssvhR
WSGLwzwzv19g8soXAZ4nkDChzfgtbpLJO0FzJgWYbY1Jxd+zmlhAoG9LN7dPkySFjvRo6jIhl4ML
mU0UaoMf7t56EZEAQHB12qBiHqEAol5AwtBAaGVoccpMYFAlT339UHfldcy5mRsZqC43nhc43QJa
Wa1+kRJXWYxB0iiMh8RtaCCMUzjUDhuOZrb/7SbPB+jGKqifx+0ynyaWVAUz4AnR2pcKE7Ni14qZ
+jElPmTmYe5J0fPy1uJvPYCE3GlwozzqP6Nzgk12KY42MhObJNg7pUo/OVnbKr5LJWVlskLWuCMN
v1Vy+PyTm0VGX2Zual8JSXehbMjIVcRX5Em1uegIWUUZXAozgcGAXlci/DNTmjyoxDWKE2/fmopw
HFmkZiP8MVGpZy7E408Nqy/DUGQpVuZ7qpFVZVgfSOD1QrM7kvyxYHYnQBqc6wARbmNocKSEMxpz
rqG7Mvkuh/Tf9vH52pQIgGmH14HV/vqxvNbpnHJuo7l1wMXr3rMWYtzFxniV6VGWq2qoZ/N+Y+8z
jhLTyR4w11UTfmKDjqt1iHIy8UL1u3wZzgUbH7F+PZYi309AxWsVrV/qldx6jBfOpMitOfjQKPAR
dE1xsxmMHKbACNrD87QTN3uyQTEh0x9A1fqs5qEuXJAyaDgBYa1/ujgHen3Sr54+p5mLYQS1lbDh
WiCWpacoeapkDW2Zw7/gKoI6f5K1C8f1wQWdRW/ujIkniy9+OQoMssuntbTi3DAg6rOJout86g1u
VQXFkl8JVInrsx37XAooXU6wdua0xlwMxDy8stxEJgJEm71z9bnPwJAxeSRpNwnat8tE/CzI92/y
2qjHj6DFI47H9RPOp3iveNRH1MLrJzT6YwXsbqA2Oiy/yEWac5KQhmOdhznKW68a5iKMYeDlfldW
/JvXfRS6A8XT4pvwrNTg7zrQP+84tNdiKKmGsARnCqAzQk4pbe3bi5Ko4DxpJNccgaMJ5MvpoEOt
Rb7s+o0k/6Zp2QfPwbZBs0Qtq//yRb2F+PbncYz+XgThj5dNKoGavxrgt7Jbo2ZSVnAJ31fhKPDW
EDgRyes6NxXW+jXB+sKnudbc+0pld04IJWjTkwLX9Tx8Ayh3I/bCiFhP06ZjTjrQhgRB0oEPWiDm
coxHCKPjNaLr9etO2oSOr+aW2jwM9sVezuqY4ekbh3lZzf25rCiWNz9ybbI/mDn3dBdd/IDHNzia
DlmjHLwyWyrfsIiKQd2XSL6Vmz4m6xuzaOY0r6MkuBLl6Tz908XYVpjtRHCQr3jvmo/a9d0f5CBT
pXuL/mmBwBjHAjpm38ra7Go9lhX91kw8BhwLBeYQMrDh71e32IcbkAUx+8+RYLOFPby8HiVVqJbf
uAV0a+frMagCF4RDuLEiIkrmGSBa/B82/dwZGTFr22/GQMLbK9JwpcOHp7/gn0ZHmVhefTV2sdPF
TEfe+aBwdrpNd8cTNlxhdLa+i3E/EL0WiCIyhVz++SP2s7gCvjuhrbkjOdbby8QMgYB+VhS2H2b2
UR4MwoGty3s2uxblLjzoMnfXkaYxq5MMCo+sEczFAfKrWgsyLzViFe8M8LFMFw29yBlH8B3SIwOy
mmwLrzYZVGtmPD7TwDh8XuZtlSWrEIPzDoZM24wNlL6vKN8fiKFCk5wjAybFpw+HYcqgwu0Y6qE6
JNG4VVdkpiXFWGpxzh1Ea4KZQw5siGL614+6Hc/jvSpip+ZbMRPbxWuEPD/Bp/SbFHq9LDqrj1Ea
V8XdHzwXJAFVRSr9tOIKk4SJjL74mTD+8psgVzTQsoUMskQkmgHibNUVlKVwFpD+yjChzmk8XH32
+X/NWiAVyXGZ3+0HJbosZoAqJeV0ns/oLMhb697o8l34SNb45nPjYXfG+iOAaCN6Uw0BVT8GIpnp
6OBD9Vj0reRigvxFqAQi+kLBzMNMbaKXDiSmo89haYLSwE6FFlHZggy5+0CFc3x/3VbxD+16BqYN
a6LPUA8XywNep86AyOoD/Tgh1EHLYwih6HZ2qyi8yA6GweNn+BewYDi2OarysrmKSnFYt4+rolO7
nbkoAOHlnAvW4v5OKYUkyPnsRu2FaJflZ00ukKAd4DRsZfsWlKNu510xNfLmOF9Hj9wNnK7gL4TE
1h65P/6Tl0EHRx1xCe5eb/XROw7peNv0j7b5sOvEcb+IGPqV9De5hmv7QZkO0ahTKkdEqwYvHCZ9
EgZ3Z+qIBvg2HDhbHKF4s0jlmg8NFJcMY/0r5nVjOZ7QW+yYohB6IQ+uJjEE46og/tPJYULTCt+d
BtC0PzqhlqgXD3ldfU+0kYVzDelIY8dpDE3mTFISm03K7MY2mUMyER6Lpsl7PShQrCHP6aBM6rW4
vO0o5CqLcV11EOGFzYk9TNA6Y55jfB5alg5v9aP2QBM37+RAhAzIn5QSpY1pBUKUKKpEVq6iMUDh
Rzcn9rx8hnXd6zr4hVYwY33YLWMG/orlml0Bqy0NAIRV+/Kg7/4Ibnn7jizetAMLJs7OekRz21ct
EqMLhcp89jBPqyfyp6pFm09qq3Dok9rMJPdrlY9FpXrd4Z7L2Tgv3cAW7xBCALIrKSuVoas2Y87c
Q3HB22H65rkU7mKa61flRyq4JUaXeeYH35hI9TsDzE7FQy7KEr1Wy+9PBno8dKudyjAdw9WgPHgF
5UzOEAcdOdSe6Sx3HQr1f5cioFAJ1DbgoWMlNV2fRw/57qlKR4oafgLrbl45F6+Dp+51dZPG6bqE
3uGbd3nQUwVJXJECVmZgxn/FCztd83WSxgTutuqVMcW0brBWrtqbonvgwHOjCtun4RHMYZXdrqJv
SAxMtNOhXgsTRBdmQ1HQnEJa1mQhWJ39NpBW8q+yHZq3MCIfXtN8QaCAobGacXVGjJq8oNe+GdM6
gIZVnEWfDyPS+aDSk4wTpzgMyIjdC1m3l7tAAtpki8IAVMuX3Eur2JWH5MAg8YI/qm9lfzAHGyhz
oVLgY2RD5tOHpJC1t/kKVXO4AOCEpzxTPVQOeIAd6hqPZ4/U4/LZeui+ayxvGrZagL7NA8aui9Y5
xurREr77uxN/7p3ZAIbY/Cj5Btf4Kgqwf6U/J5UFYpFgyNEdaK3zduvWtejfQJO3Bc2fPBaXI1cv
8qvc6h5bG7wiwt9sYYpeYwAeJhNMTFX6vYjyIYXAx9Mec64NR1P565BuO/xBouVPaT8rG/6Jn6qA
QxOGOI2SW1obKzQOqZBCOdONJSLna1IRz8itKgVPgoUsHGOJ0ARj0yfczx95HK8IIqRCwNkYrgdq
oR99NuK8yt4wJyFy/nFgNILoEzCoDeYlS3YK0zWt1ehqjkuSk8l4zv+iiQ/UK9lg+atrR1joXf4J
ByVhwVX6JI85VB9ykgxNpw7/BxW0Dw6DUj57Gg84ZSan3xQS7zFRc5TOulKJ9wxiduA3Z+I0XzZ5
fu7RI0SycYVEwuJ0nFIRfZIJVK9GvVUoa5ddLe8MFmad8lsVusPMoN9XoMnFNXrRSjiKtatShe5Q
LxuZx4RZsoAslo/SSN8igf2kbCkrxhmYmGNlCikk/1Csl4y8oJ3VoVuK20+uOktni/VNZyRC5lgH
8d0u0hv5pGrDKSGo/tnMRuk+2CFxtqRdxjj1WhR/BSnym/vQi1IfDMvnaVWULPxxsRIVSlCwb1nH
k79QgZdWPE3sCmvPYgLRHqJ09R0zq/uioICZ9/To2AV9HLNv1yluAaF9w4UN9GIHcKr1nyjLo+Ro
37IkDm71jxAVt7EV/GowlTiw7MxjecriyT8XanjHz1HDgInJAGJ/IRf3nEhPZki63OwJq2g97VMP
jZy2utBbVOtKQUDxWSxfCG1HuxRAGE+m2Dx/PwOBZCt/qvfkvX2XqwyJYyrxWh7v/qXLyvMkCJlA
mkYWb2d5yi/1H4Tedll3U6ejaxEbs+4aZkySsyY8KZvHpS7Ms+/9Sc9L1wLCq+JglbxuULLdFA1R
FnKVluRWSTqeW6h+iCcgaKE/ChVTCloRIST2WY63Lg5PJAfN20R5iH9pJ3A5N43lAzq5ZYCmIeNf
edlonDJm2TuzszlblrQKbf8uPHQPkm5Z0gRgTxfkaNI27tbTcQjfZItFfYmoXKU9XCHKMpUqPCnQ
pC3fber3ohWBXCwUoQ4PAlfnByJw2ve8mY0Q0aM52Gq6rpzo46bKGErfqnniTLU7aPSCWL64aHAN
k3PQbEO0wEr2IaUaAij7Onul3neA/P3m1DS9YnyDS13E+JJwdTh9TQQnN7i0rNLt46PWprbP4RgF
c/ZawEQV/VqMj2X2QP+gvDsIYh9qF3OytGh4Ddigj+nbTabwoqEUiXTdAoXt1i/XePppk5I4vJjK
axxYcRDl07bW4ZfXufE33Th9wH6mVXJLo+6i3hTs1jgL/aEElspv2TRJDQngJ+Rvj+/TFodyvTIY
Agx7Ci+bkE4w0uTxoD8sKtBuFcXlXT60u/Vto1tmwKomp3r802k/uFJ8TiDq8Nt/xIrdVircA5jI
ka26Z2aQswKGWkiJ134o5CevU1+kO4lf6P25fsxOtsNNaSPWvt0DQPNghMAeC2E7Rgy852oWqtFv
0A2DylhqZRR0NtHTX2/HuL2z2FFj8RevDsnW0bDNDZC82PJOMaVO5fZwr3ZKbb9zlSJ4Hl0Paklz
Vmv4VQQjzm8QGOPfyiudmNm1UPq42dVmLaKCWA4Sp+XdY9CcHQMWXJlqNDgYzGlkKGsJ+m9lK3Ty
ebTn3nxOBuN8JzmlHTZsICuIFWVjTmRIQG6g9CUHpV9gFewcfhqEcNlZB1MFKDSOBgOMvfuBLd6a
KafPhSGvXA3TQdPF2DYcLbAWDnpLlWZk/5VXOFyJcypxZmnsqVqottXcZI3NShYn8Ognjp12QrnN
3C8wz64VQ5RRdTzIXsp/cRxr1DpntTMryTORE9+8h9Jb7AyYqeyXiaTKBiCGBiscIoSrdhDnHMlJ
+JF5G/ISVAYNAj8b50Ywggn2rZpiV6bCK0yb9ghFP8l46tNFi5h4Ucf42FDAC2Ockl6DxIEiaH7G
vR0F38XukREAHP3WP7UlMC8ptbihnZyv7CpQ93q8KTaNXrxWmvD22lf0blZPOJ9iuj9mWEOydGVW
t454y+FMy8XI5V5zA0JAuuyeKO06FXaIJTDr8Ww3xp7uUmNRrGhYiVKeL09T/qXPniRlpYhnQhHv
AwDNeTx7esmma+YNi4Dx8s/W5Q/gXcH6Rsveatwbqdq7b5jZgqhv1GULwz1k1UFqjIrOcFowoPdj
kbUtvRqrx6RstXDFaBwk1AquHVyj+xOdY1AkBso7Wx6TgLcDPxdkdme2qHUR4My440ApRN9l6Upx
ticwve0SuL4gS58poBcpGAs3nI2EToAvaZrDQgqDf4tJWPOJGKQvncrbDDCikzSI9P0cgNwYrkwq
+6jWYwWfe4E8X9xx4O9CdfX22qymHGe3Mkx0CBtIZ+LcOjZRqrAb+bSA407iKrglISokbqngRVHx
LwevMn1r3uoYkZuprZMHQfKEQh+DjE4yVI2VKdbEk8mhfD0ii7167u2o/bzJlHxpYv8AnWMWpMAl
1XdbP3KJ3Q9uCv81YH6vsIbms01EKQYRAA02aIV3K1er8xaOEdcaoqaiUus7oye0LOr51OEczRv7
OwAAv8jIbiZMEnCX7Tzeb/auneUWepJy52FvORA/IWgk3BTemYdY/QYBqTAWUnSCJcZOPJOue0Fg
6Ga8ixiHDgKzqOwdOEl17HFZgvrAt32l69ysrBEKdQCEenh6dW2Sq+D4K+zodQJwJsx1g8KkpUqH
V6zY2/miOLfQYHtrRB0j6pVaPux4mDmtnlg8WtcniWNUVnsHmycYnFA3sPr1dH3omHdJYJn0ZQcK
I785Tm3AnS5In8dEJOr/TLtezTiYsZ0ClREj0gHUgl9qgp/fMj03Rg6h+DAaBWExHrcEkK7h9cId
htVqBmnS4bzh0SeJVsI4Nwvc4ycci9FP8e2tGLydwnB9msEG7WOVUpFF1tFdd8gc1uPgL/33BARx
WWW2oTI2Sr1ojhAyJ7pxQ21li961OmBbr3FPeOvm/fdB2NREHM0qpNehiYtPK1hGIF4EYKQjXe+R
krLL6B5eSG17BqLHqSR4K+ErEFzG9T3TFmrwIQlRDAgIMe8ATNYzioyS2+pgL6/rHzuUPEzEevuO
O4nMrn2O7LyNrimZkHy56KZxSNFgT94dGQTnHulDr5yHmqANMAk1NjmfxCSqsbWrm/GRBf1D2iKM
d4ujCtnpT1oe1Zao18Bjjb3Cl/iavfOXsT7VjtsM4tnTbaa3GFR61WVGE80Zya+T+F9z/b5prDJq
Rmy1wrPOLoNfwp8vbUI7aTC5uuv/02zupBmPzkm0uNqLjfG1fFmCHWDpwQt07FE33SguzPBuUcF3
A+P4rzPb83+4Bx2nxKq6J9aEWAKwtdlu3UaqWMN9TrNcAkNEXv3+ZQAQwq7HEKCOpWCzCAUCXzAs
Tmi+vK8WR0bHrDBwpXEmqeUylZ0Wl3q/LnPPrJStvYeyMa3kf6FvIYaLfm8QEj44YoZo2z4h+Q/Q
aJRR3yLcKcI2ZVwqpp0BCtlzXLFhYvrm9tbue/awJ+mMB+A4RKmc6F6BRPUb3eF0UP7toQkI+Ije
YeX0PkQyYi4cJMtHCSPQ5ruzIE7BRxak+q7y+98VLOJh4HKNH3TzuHTe1NiQNc+Cc1+Sov/QLB03
Lbeabmou9A/jgP2IoLFSf5ds+ZiCLdi8JUUIO9PnMBMsFeKAQoUF2RABOBRtyusBrsQJOjHkcpuu
+0Wu26mx9XcmvqdF6MJz7Ny6K+1b8Umhybeng8CCjW8teAFMmzZUKsG91FLqLIPBsvcMYdxnugCP
QPEjHYHwjIE1Bpxm7rZFY2BROOkx4MxcXhBWWh08mh+HJ7wuXC6Z4wA6zfZvWEji8g/r3VFTRFtW
OAaPBJzNb/L9dn5LttWGpKFYO0gxy0DE4fP8Sx3v4GKohfHKKz+F80e2+9aNEL5fWgO6WEdSzGMi
wGfnObWD5pf9bOX1ivSDgnzRFviR1DEpkRgeW1kWghHgSdFIs8kfCxA2icUcIai6K32I1l1POl46
51LvI/RZr6sHwWTKL92e/qN6jMm+/4GJlRAjhOMhv51GdQXyE95AsPfKcmNrgnYr34+jVd1URk5X
nonfs4Eky6rPyjm6OZCBFeKzRjwxhL7kX4fZpzX3WcNWK4oxEorioCaZduk73+aSbc/Y2Hg2gsCi
Dgie4mDSX6MH850bGiroKpqikBAZl9ChrFT+EljmNOAnHZm75k37gwYhbRUwPE1SQKr6BJcbLYi0
gZoIJEd/5O4UdmaKz9Rjn7v3Tfyvqo9WH5AL5XNUMiRYB/m8f3FCoCjJHXYaFOdJR+Foc3+9NO0U
3Xe2MSHVxiIb32saPAcjXmud/VTa6H2Rbxry1/a67qQ1OTpeXpQx1NbqZ7uOHZsWf6ReC/57ZBv5
Hi5o+xlayOtblSQmXZjJ/fs8CY7LCVsyS+bXAUFfCXTuJjB6R7ukL7UZpogXZeEnT8pVeOljg6Za
bzNXFatPEmCuzXAfIaNQ1tkC7gm3KqxrCMSLV+zpnrOuVtSPwN0vkPPivD1bLQ5AXfqdClVccqqq
BzsyfO2mVELlT7WBBSzP2HTGZBuZcReygXpXbUSsIn7Z8D7Acp0nnX4v9JH4XSVEu1i8YUQYb0hh
5wUV3mKq0KZNhm5tMd5VGMekhTJwr9ROF2uoSIQ0DYRbB120nkceBWF/QYSOrmT7QvZNU0ZPi1v9
OGfDhWoaytPN39MdDgykx3ydkbqxvdGU2+Spg8/Q8FvniXJ4Jy1O8qCFPS+e5+8y0QDnGa44rPZN
gpUPhxJ9e4SKH8QJPUGeqTiptGfY53y/20vpE/5ZmX4xW0wAiVHKYCBHgM2YP+EpINGQzG7Vg74Z
QUCv+oHUSiSzkT4I912Kd9et9lSdZUZTjtaVzOAz4U+ha2wjD0M09H4RsCq7oJJenzVuLs6ohezD
xnF2647rJ0gx5wZLXf+bwJNXppYP1FPrVa2Mq3SfAGEsoU+nqTKDGszNAZgNqN4fbhM9Ng+Tl1DM
n3G6PKSTDMDu9SKm95wze/haahiRuzbJhsEpLYLkT5bUXH8tMSYSf6xhP93R5YJxJTPVj9YTXNcr
1QcjAh2waJg0iNKPHu/oi80dEh5I/0XTwMbctQcm1THvFGeJshGW0CjEkK6a8LGBBh8LZchKHIWg
wh99GEakVMLYE72if3v1y6XeEKqb3C6qOEEe/BOm6SvlDrCC7CrWxq4ZNP82KU5TgNrJnKBPXxYP
2g6rxQ1SQcso57GK2pTFcuaOSaoJtxZIzamYAJDdg2xOXvfyjShkbhzqGv2uDvrPkQFm1UAOCc7b
rb02304kuI4dwSPiA4mJxRb4xLx/YjjjDw7KQhfrmANfAsLUwAJeMUd9MCLKoAatsfNNyBOfNajn
LmZ2o+5FqC+fMz+nNyx/bwI7P6EN8YvfHPmPDP17Jq5MEiI0QvWUJ8v82vfkydmMM3qL1AjIxvg+
H7UxXaObeEta5XbbIxd3M0wem+w5MZrYXZOkatPmWQRYj3Xbb9AIjFw26E0blFjeRGdHNRHSdLGA
Uk2IQwfJKyowGv1CP3+2yGPFsMiZqKYkPOXrrSGcmLSTyr9LrMblOm2jY9Hlq64Add8d60+kbQ8A
PhgTJxG9w4wrMWv7gcirl5x43yp7Y4Zj0VUCuiDBbFK7WQVXPKryzTeqvf/etRmgHh21K+d0zW2+
R3p6d6SNXfc5svysFcXDkzD3QXNcVEOmeAXUA7vv3M6aC+/dYrFhIxd35xJpzPPsqsYxwksz0wYp
LBH44MoZcwDm9NCxqibCdPGPo9qLNlWznHThhDzDii1283JyFSvD1u/Hi1bqlPRtilHE3AzHUdlV
j3ngMYxF4a6H63yKCA2jroqrK2VMb3q6H9Fj6Ey1RAHRNQ1WgyzlsDp1infEtNOb35QlFLbycOs0
4AFJs4bwRDJ4EEOMrCPTy1QoQAtwbsrA1vv3QNZ353BX/+zxz0A/qBR2vXvzG8SMwAz41Q9Vh4SA
4qxZW7AG56JLit1/BEtvWs/iiLbBAf04kZhehY/FGvKrRQhVF7JdnNu2sXV25XF/mr4tN3rnuHE3
ajfXJdhk12Rgtvuiff6oql9B3XdDPMPm6XiugMPOJGC5b8DJdApy+dcLzRZdPSjfPPfrNfqcmJh0
F7IpNHDQcLA6wkabpR80/Zftwu8qWQuCReNuPjnJSJaXSYROxxWhmMN5XzutHKMa848BAovzQ7AZ
zgapVCMWp/k6AnllI+BZloaFTBB46et8P8eYb3k+Y6TIx+wuJuUUAXiL15++f8W6x9YalVFtejRF
dvrPK0eIEzxp1f+YQhxB2v33y3Zu6dyxMN1qk3MQIz0lt2dI0wkhfKiV3YjbaC9NE4vGrO8A61eD
uAeZjWb425DXfKdOrWkZiWgw6WTRqcL21JbtiQyY8rxXzKTXyMcxJdJVaq+08P075GVadeKV7YMy
kvMGWZHMdtyAviDMwXnyL+XACJ61vyR0+jU56nYwzBjPLRVjJj4ktSuXnnOGg9fEC/9SEIKQ/zo0
ci+VefNOAWch8vsSMl4M4Jnr9v/sVgVC6dpLFwHh49gS8d2DYceSu2A0OeYKIopMTLMC5jna9AXe
D7BltIaEB+ZvL/vEPqDHDK3bdtAH1toN3GTV0heHaWUIkG+6nLyrqaajfCsDoaX3JDKZ4NIDYF8G
pmZpxk5aktht5DcxzQd4B4FSo8rvXlY/M9P3vVXzpFS4D1xrMH+uqF7XCdqZHLX1CK+sp0NzLLYG
CByTrNLtuxrFqPorlKl88XjiDljALJlW3i0XtjtTt5Zxv5R8wYs32oofsHAzbfQBM0KyefF3g/zu
AiVcREiAov2oXL+YaTT3rMMNdDEdW87u9X5BOw1MiQyS4KMiewnZJs2UB04gkzVBtA3C26vmXv8F
K3Zr7GXU4D5TeoqaEQVoxQB1PAic8VaZTmxRvKMUeC2mmJdyUDrjJeOZddYKoik1HACo9/OuFRv5
+UvHvza5YtOsqtgJcpvYeD+ppZIHBMB1s/HnUadKuX40NX/ZjyDKpjUT2Oho2HAHbGM1TYMfeoNl
MjXlc2kwSDJB7hL5lsiz/L6x6FkEwP1muiUQD1lndMoZokFsNJrzDK7MViB7t6a4egt02om5CuRV
CKMLOkUZglOGfXRVKZkVdHWdt2WtMV1SU0/MuARmhb5RlrHMHVZzYZOzh0zEbTiDPAHF7HEwH6e2
SseMVuYhOepdRtDY2GnKN8i7FUmeJQjhWO4Qv5Msoz0ItR0kDQYgWd5t02lu04AbIknEt3ulva9K
Bns/YCp5CX4/K994y17xpNhjSqOLCsy6s9HiPhOShG1UQn9+1B/hQOXPVGGeUWjYxlXaXnj2uF14
8R/hVtJm4UG2EnE0n+tAvQ4swRpS8/IyBKrOwvvRy4Jh1xsv025qv7OAjxCOS5ISJ9/20ddZTMnN
XI1ismW/ZKkd+tcWmsaoFcY0gJHby6ce1UZNkopZ5M+PLTmbgVhlrNyCaUpVGmy5TzS/MJnpYXqR
tJ3SJdAHmeqOaouCeaU2ERfWv+D2m8WuPMtV8bu2b6oKtpSF/sZ8Sol6X/qh53rWTJXAaX+tMX9E
Hh4MhBYKEVLjgGPAs9w4QyOv0w1Fo2tH4wr2W5kKIXnkF9DfoFlaSMZAt2d8l2zGkk0jDjL7RkJH
mcy4PHvz4BT0wdndRgFouzi7fRmo3QeV0rVjqZotXyghTuXw95bmVW/LaxxzSrxpe/b2halAjHix
nYSV6XRvqnmjit+uhc0T6/zBnc6/mD43P+WhKuPQrVfNf1wwD+0hQTZaqvLEcocpLtLnGEXz8Ovh
J8eprWFtDXmEb8vYIalBQa9gPqGI8Iumq88/9FlRh32xgxyEXapd1tIO8xGn9uP9dMfVoSR1qodQ
QTp8Sg6IUtAmqcs3Phugb5p312/LcvK4EeAg5C/b6FigxpJ/4w5/eMTLbN6UKbmOCVhg/YcMOOlU
AHhtrDOdL25BhECvHmpDOCmYMOQLDEZyRxEtVRgYA5CGmJVdmMWV7LwgV7HoIUjKKKfNKHqzWt/d
nayyc3AbuCWYZ1BgNvxrDaJCU0aCAu8yGh4U5mKdw36re6b9CNqCzP15Xj0zPXE/U79EO0lpaxFc
tW+lMqsUSA/T3qRuxwDcH+eOpfyH3vkfFBfeqc8c4KklN2YtzN6Fa3NYkJ33y2wKlP14OZCCrrBI
X1peM9aP3YDZaURk29GaPg9aXLxvX9AiOFOTo2WUHvlFyIrIyD74PpsqskDsvx7I1qUMBy8NOCaS
KbwvS7HbCUT9J9jxM/RjYg8xOyFvaxImMU3AYkkHubxdIeMX4sr/Ishf8+7WjuIJyPsWSjvy3FfE
mxANJGdWICUinGI60VQYSDB16aD8/g9WoCTr7uVq5vaEXyXo76RfCluOzFij1d5VO+/+YG2rfOLF
Kjni2RsXIfLRGQekWWS77YPb+HeRTbh3yWuPapsOiY/XMpKiVpzr+ckBsDI+ThBBmPSV8gM+Igh8
zqmhHzYH+6jR7bRYL4ZCxMNr2N7xwmWBpsxHTbHo+WDq+BrkLfzzleucjkhnxT7uITSeGcRz65d2
p8vY+VjJ3pv+Jhh8r58ob+sxrR25azDuszgzgd1it4W9Tdn3VGJ3tIKl8mIXrxqrKY9RlVrHjxY/
/GI0Qa+PUKJJ3KtngL7994wG3CoRTy+Qhx5+lAmPI4nSLRJJOr5gzfBcWJ3r8BTvRumRF6e8xn5X
0yEP9zbnMp2maQzUXYQPKuF8ztfSVD86jBops+L25FKcNMUq46dXZ+3DmrRmytEOLnY0JoD8thub
TRhDrQzq7mtWVyxwA85T2MQRkjWzeEnc5gt88g24JgZv+1B5Ab8k/woReMQsGbu1wKXkv9PWCrnL
GD3QYNSzehavJyh5xAvykU1jU68DiO4cbhO/LK/ATldLN/zs+QqfJOU/QbcLrEw3mYKIRc8DbzLO
in/4XmI99N+VOE4i7eU5vDISaOn3xvkucNqfJXgqdgO/Dvnl3q9GGNR9iW+1FIGA4kI8mGeLAuFM
5YAOZeOllbuWJrXRTQQBfx6kVEaKCc0aCNKeCHoHcXMNbk/Id1q6GeSpULunPn1UiyQ1veg+6iR9
1m9VtTN5XuGA4NrUhG26qIBpLtZtj4XL6wmAnDwFENdTEpc9zTuTOQP2VXBWOjaJcdJl0ck02Sta
R3wt6sMev/rxik1VcsXCeM382szUNODDXNFk9YSj6OMZLucooBqsH/jiJhY+2g0ahxaqPmsavE52
b9lVxFL3LkDn9OCo++8v1nECko3iMaskWku8zDoHuKlAZlQN0KJMGfMpA/nRxiXKFZBSbnd0Cp+y
t168b990bGpDt4/tP9bG2gna+rrl9aoyywMuOn6KnXQErgiy2fDNralVaX2qAP/OlU8vxcvwFZdZ
hrUcdvJ042vMrDEUt4NCyPFlmQ3+ZtTHzjN4Ysa9JuwAQxGGeMPE1u7AdaHBQIqanSn7sYqAbpgn
Gpl4wmqZ4kjhlxZ2n0aEEEQQtkFzUOTPO95INih4opPKBsWM0G7vyBNgb/LYeYaKefM4B56UeoQ6
FrL3zHk1qqKPJtpc0y1SVfZfnFTdZ/Ssz4l8m3P9azOcrrfhJnd4TqJPTslc5hwaLPd72V6VZMGS
qAOTqoxPSpUq0jiN57/EEWDgdjzTeBI1IbXpU8luxMJzrKb+vJi1xaikyeXWVxUw6/WYa3rKb4ME
ItfFq+AURcQhi0OlKeek9zpyq1LHjVzyIp9W1tO5Ato61bVfuiu6McK2mUZp34oS90kDcSy0c5Nc
3cwJEhyiGTItZw1/PKM1QBVV3SSAoG3Vb373tWMQZK4n8fM9zL60dN4efnuW4J982OAvBzIZoL3p
PklugMhzVoSKxaHrarTvxkCZ/I8JH4X3wfwal9U5jlrWjxkxa1o1VmPP4bTvArjThFtN+ofThSej
IqBADu/EE8o9dZkherGz/du6IyBZcQ2ju0ajZ0QP95p1BA3+i9EmFDvXMqT7k/wUnrNfUgs6wogQ
SZ3hDYrXZeP/dekp+Dk7WOkuBfYwFwdGljILtgoygw8l6VuuAMkclmcXfItb9pCG/ZHfTRs2+rxX
Xltf6a9f4kprBn3lcjh0iEx6+aDYxpzpS8uyCNwt5EffDXmJ3qJlt5OgdjuUbWyucmQz7ZXVbXZc
cwh7MJgrWyAp229IDwq4oS42Y4yaHWDmaHhOrVuTvYLeYt+IyIy8EbL1oa+K/ueZkB8Yi2uEwnZY
R2wsoIkbSAaWzwqe1qIfnYvkGdlv6JuuPnXwvuZWPsGBkOv/bSKJo+PFwofxHY9xgk1Uto3y4a99
PDkjVT9DL/9r8U8T6EvcgVLfuolQsfthUxRXynErOUuOpfgLsWr36npGH0hVzDDzk/shAnHD2pZj
EJiWmiQhXFR4BvRHTdiER16Nnv0GwR7d7eHB+kmu5uMlgCoGmIApoWly5/1m0ntsNjlwGk8UiVdz
hjA3vncoLo7mDQe7SLWMVQaEYUyQ1YK2eXqvnUhJoqA10YA6m1dOSKV2bv5kZkTKfhJXJP7eWhug
gRxM8nQyPmsNCVUZJ7lQHbNVQJ4eIBwk3sk2tUDqChlroXHOFsDA7FMH/zbiavwa3/9pSIHnrW1x
tgRv3nr2mWAqc6kjAj3ErDv9BrctQhGoe8nvq8X4jEfoR6txLtvOjcnQGUzzjeXFyx1lzt8URlUR
Orimq/1OJGhMw+Q2qkvwhUg4xP0Mg9o+D3Kn4UVIAblSdvZ0H1gCR1ggJk/XntRiIGqrf/gw809m
QXp2oTf5ic3ZNtEqxVi2is2aHUsQzY0BsLrw8pYF0atpYScm2w0eSXmMEPg02Xqqtp+A9HfPGEy4
FXJrhxTwynnwdc4crUL+wJVak6Ylwm1P7NegIJ93SGQwUAoCnZDZnrIWPhuZC09SQWnVrGzLVo/V
HjEcPFYAPLW5KR1jXAME0CoDz4mkN/HybYAkZRH64HcD/iuTtxoAGaP118yfSEIxN4UgeavT7ULI
X2MteK2VNslZRwbGsvDf4qL39asYBi+lhyYWxQkmWkFY+dGcqAuGotArkXk6h3J3KfG+/l4CKbN4
3e0O1FpRNaCLnTE5h7kwyE34Q+bx0/nJEdzmeOrpySg0iC3kCnPO/ZsbvIwCigD+2oSAeu0M+XKg
0hfcd2bNZyU4aODEWqtkLBQvpb/bsgN3ySK5Spwi731GI3eLzfXFDheDI4XueQhfEFRMUevTZUvl
Jx3kZbiX7nZBWcmxzdsQdnzNzPoGuTc+Vs/D7ENVhgtTBocmTJa1i2lRLv+WpSi9itI3O9GNj5iy
mupUuath8ZJxqp1k4V0M1UiJ5U+UULza9A/e6KvKVK9YijaP83O8xvmRJWqnjD9HKbZVW1RTN0BM
mFRFmZ5hVsCmp6cSODR9jsLx/tlPRaGkukcFJayx9Q50pR2fPrxmYilMhJVggO9phOrlU1Io9qo3
MsYO+yyn3m3lePCWNjod1SJzBbTLEjvIlXJqTl1EjGbMULMu0c2Gj0tdDsbqMr8B8N9Tif4QPZnj
bRIWGgN7ikSKH+t5+OWfXzMssyQ5/wEJk1hPKAhGQMvIUi5zgKywWy3YUw+n873ejMuIETkPEqlg
RvFox0hVAv1GRDgIHSZOjip4L9tVoalsZc1ynIYIJYF+uzag57jLdIP5xhzITThsfU2AI2+elbY+
ZckTHc7veD1w8aAfr+VT+vZJuKsnMx79B5fO1NKS0SONkM+jt1XqdSj0QEyj0zPxjM/NXgLKZ46m
8s7lQyycrMzt9VGeC8GLyXlgV2SBH844OOMGHnrv+LYE8PQ2oom2PDAeBwjAm6wpXYTvktTn4ZCq
1EhMAVjekaelLZz/dlNtgpmCnej3HHwj8BXP5+BYybpTlifTI5m4v2wfsphHFpDQrI0lYJ0NtAIy
cyzIRmOPa3mDHMelmADQUD7Qs1xLsiKbUcvFpmpOyu+6WyO6rTcf1p91fgZnOfKWollhf2pRela6
cObs8GK+93pcHuqnlnhNiYZpXFczTPBGbgFYlOvshC/kYdZnUuv8hrPf+4XV8rVVoQFs3uH1youD
05d1CoTngZc0Ygd/WR0qhlkV4Smul/uW2Ekf+FYr9kwFegRudbc8BZeWWnry+lrwJPMGZD1sOqjp
0CGd4d+axYcZZ60EDIwO6kd8/ntvIihxjRhUIc3iRu9czm4u2aXpgFL69F4jFUoavW8ll7PyLZ4D
8JM4eXn2JGWzpvBkeuQ+DfGiO9LDbnuNMB8bNZreL3VPKpCiw/E6yMyDaTDdnBEQPr/7OLjWQbb2
OdXyjkMG7MEwVnVr1vlz4qGlI9Acx/1JLFSTUCLuqOrAAz64NZuQm5VmPQ5J0tyaEA4YNtE9X3fZ
dp/luHqnGnz54gZPHiaV0tmgteUa6CTq2nddVch8WaaDIKn/1k5BCpzRxKomrdmwog1NJ868FNpO
75UUwjOxc1jCNPn2c3M8pkSzrhGTj9/A6sjoWnOXJR7Rb/MRns0M2NXbmGncQJIvTZ9MB4aJvder
J7P3tNQ0SaXcMX7aIkrCWGAyrWA3Cjc/9WHLuCt8v5rT4qp5WC0DlYCyC/TghgeqyNprAbowmhZc
5wBK1HQ4UbDT7tj7HpQ1jcf/961lv+DlTrcwOFa4lBvn4IYs8+Sv11WMSPtmeSRCbABNEZaJITkK
FJ2a9inNLuc8OiSNckPX0tlui5OXVOVVcit7wRxYJJZ9ue89L9jLd1lj0nH/XhA2ZUYti76BVSqn
OTHTKN0kkm1+t3YIxDPq+83tYi24QGF+vaDJn2BYvCdtPwmCaQRC9D/sd03wtbc8Zc/zyKtX3JLp
xZVtK7bblPeq03c2GNttaOaSCuVdvB+bxHON3pZ0t9UQVKbtK9AKNe0G90dT6B+LJ8mkYQcfGFRl
mTSeTEHMYtLT8I6ycIM9n9ipj6Q5x0/pW3OxUdxRCHCi46J5gbUOL+QhDEapUikdWexltBWSGHxv
A6IrqRWp9KwYTNPTGRTdqbYpWWoTeMA+rHE00/GlP+P0nGxi+D9Vz0aAsfTuJltRzeiVggkoEwO/
/V7H7jRTIZdRvAj9xK23dGlx8RjMUJ7AaA0nXxSrZiyJshjeBKx7oQ5h+elsrkOSFgaSqEgelLn9
E0lCMUARfT6q5Ai8kG7RjxF9a8HH3RGpwMB9uYD7q9N5eorUANiTC1sseuA450ogUiTKoD4yARN2
0USR4YbrjRe6EEnkr+BqDmo/SPZhevWlkmKsKMqALAdqfLk5jgIM9ozfLym1gKijQEabRVjQzj4n
KkOXEz0IbS3TerKyn3axFeyL6wYylQx7b1JlVatdcVRTlxFk9oZUuOUQBkqmcPxziw1wGhKkWv6F
fi+2vBhKESpOFxfHat6EglP0IMn4YUmL30baNJFFKQZACY/8ZZQXAOuF4jFjGpyqaqfpjFpTVfZk
qtJ764eBZY+zLPqJaolLbi6D6H0XduD8430ZI4MtFezlTGWFKbZa8poz948AJldEvLSIx0wUlQlK
vNXxPrYbT2G8/IT8KyJJGlXzAzwhRqWScmr+HW8uU3AiQ4o0F//Whcz9RWylLEsEOC+kVFwCq4Ar
YEPwM8q2NEIbtOk1RIcBpvnNf70HcCbPLCDFYEgGLzGd7pjjzYmzmZNq08cHHJvlC7em6XsWDRwn
m4VAyBNnMQxaTnjCuCkxvlOA2oxJexcuwh5hW1ZKoxbQkTxNs7T5hMrxgjuBjPUd43cmfOOaczjE
9IV2Y7nnEcxWO5g+1ybUfwcoXbRcMg74qWSS6oOfrtmFF6dBOOmjFfK3rlrYxLO27qP2jT6pPTOu
6ciFMdUDYUf18Tnzy+XZgOd1h3pQ/wWUhYTGc8SQM+DSJd4hht3xZG/RPicFT4Hb78ws+xkp8Aey
xx7ajDgAdsJXauU2iQ3IrjbmOA4ecVDRHpOtJcYwWyEcW/GvtFH3pCNUYWH77e2aE513iVH4kVhK
wRewfkhArEX8BK+SV+L99gnXevj9bBIiYGNJH73xiwh7OZPZuzQUMtmCtNc+uMioyFjd5eaLaXjZ
jnG3ZG9VnxoS3wPtPqBFATOYLBzKwW+GS619aBc0mjGCmr2V8AsYGUKLveUMupQOwNlEs9Yg/grf
Kl9NvvD8bLGlulSY3XQc85P2cmATt/LyEAXYVVCoGwspi0/5+WuFKjV2XVHfZHuqXGGXtOaow6NB
gSlIPhsBP2UFuFTrWccBhDypP02dxcgfy5TWrMvTHg9YK8Xe+S0FOrUH1KRwjSt8z8IuGi7v1yx0
3gWGeqr7jj1owd4Azy3AE/l+EETHgZmAeiEI9CFX3Pdu6svWh3btN8lntX8JXZxe4gA4iZ192/9+
/s4JnDmLzM5I0O8spx0OD+Mv/+1fQJ05tjEa6cXqRbmlYw/S0UZFRGwF8ePXoelKt/wdT46ss7pO
Q9CbaXzQ2DWs88LIvsdnDlsLpWuCbn+hDhpujO7yfQg+CUWw0zV723YCAJtJY1x1JuN2w6mD4nxC
hRLSEyTyumdhdkh6rT+d3yBNlM8FG3zjr+bnNDmgbl/6bBBjF+V3uzFYEAnP6tpzd075FTXBJlpu
uXoAaC8EECTW0O7+p8NRpSiqf9ExWooQluMpiIepb6vpnymx0u6+abkxWX8WyOzfaME8kQQrcuQr
FenYFjYMkz33vdgXd72008qWCSG4Fc2uCgmKYiHuUB2qVG4ElcJ7b5tCGq2we7vz3IeM/8Io0NCw
788UAZJZh9+7azntC7SYnslFOcyM+3Kn1/PNIUy2u9t63xtlD+5kZgTJynOLUoz8l1jYkUpCt00w
0Uxw6xN9pgsZluUcFyPuLLKv40iFlTs0OEuB5lCLDr94vlBLSj+Hh3xv2IuW9XpH7VTwr4LzB28P
LGFt93e0E1/8Zszsvi2aB0oUKWusX0IAIkV8BhjY7jnhRKFUldGkTAQgOJJ0aJjd1sgTVyhbq2cb
Z+Pcbzk3KyvgDWGxahL8yZcQtOlbexxqc0dp0ET/BaiiE341BRXyaZrQ6uFmQz2l+IWctSleKHPE
9n1I+nnCTwMsjYCTV0sYUiWuErbqgCWLub0RL5ZWDLoMdJe/fGZcdt1FtzF2+YIqa7nxbn+hrDLT
hCmj4RCmJ+kyCdfw4DM4ZL2zBPX+vMb/KR5ryEW7Rb9omxeFSRYzSVcz0E+3OfJT98rMC6pZiojD
AJZwAUTw2QbGEHMucJJ8cjynrjchS00x+uBHtZQM4zjOtsYZToGIGhX6zLtZedh5iLa9iAm9Kx6g
I4zAKt3QhKGOL3ZL7vNw4K2CXsDlWzBmjAMhJTfeizNsTdhemiE67KBi+W6MiIvrorz33ZLNdnHN
nibmwcdqr46p+IwyRYziP2KTU/hcxtm4OGXV3ZmwEQnJZRxfIjE2BO3+p4QrKU+mbn1/tBhz8qc5
XppYkE2osbT1cPHciClb+Ws1JEi+1APUKE6RVFAt4+TUaVO2pGcRMEgaIgxeVgSOf/8Qjw1Qb22R
qMRao3IPPVVK7rMsstnN3kslVqVnzhB+wsSzViJ3at0qEgUqM4xcEzCCwo8BQnFYB08D+C5/q5NF
fxCra7rvatGUW2ds7Onr6bUwslVlRO2Mfsn4Q1GtLvZ0qNeypVTzgyhW1xaBMRQ8WmxxEULKLZgM
waRtqEFK1p2Lu4asIj20iXU6mcJwaH2jE/uTTTgv5XkeVTDOmoAzzRvHk9bXxjtDsc1+1dlbtGAU
AkItTLCqMnNbmT97ElvbWkwzUmEwySCPTxpuPB4p11FOTRdmHY3o7HG6Xh1uY3w1UxP4c8qVkYnf
AKrYeBNtQn4jmyAqAdXiq3YQ1+OcG5Paq/y1xg==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
