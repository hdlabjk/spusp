// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (lin64) Build 6299465 Fri Nov 14 12:34:56 MST 2025
// Date        : Thu Jan  8 13:07:16 2026
// Host        : amd-VirtualBox running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/amd/training/clk_resources/lab/KCU105/verilog/wave_gen.gen/sources_1/ip/char_fifo/char_fifo_sim_netlist.v
// Design      : char_fifo
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xcku040-ffva1156-2-e
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "char_fifo,fifo_generator_v13_2_14,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "fifo_generator_v13_2_14,Vivado 2025.2" *) 
(* NotValidForBitStream *)
module char_fifo
   (srst,
    wr_clk,
    rd_clk,
    din,
    wr_en,
    rd_en,
    dout,
    full,
    empty,
    wr_rst_busy,
    rd_rst_busy);
  input srst;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 write_clk CLK" *) (* x_interface_mode = "slave write_clk" *) (* x_interface_parameter = "XIL_INTERFACENAME write_clk, FREQ_HZ 1000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input wr_clk;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 read_clk CLK" *) (* x_interface_mode = "slave read_clk" *) (* x_interface_parameter = "XIL_INTERFACENAME read_clk, FREQ_HZ 1000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0" *) input rd_clk;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE WR_DATA" *) (* x_interface_mode = "slave FIFO_WRITE" *) input [7:0]din;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE WR_EN" *) input wr_en;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ RD_EN" *) (* x_interface_mode = "slave FIFO_READ" *) input rd_en;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ RD_DATA" *) output [7:0]dout;
  (* x_interface_info = "xilinx.com:interface:fifo_write:1.0 FIFO_WRITE FULL" *) output full;
  (* x_interface_info = "xilinx.com:interface:fifo_read:1.0 FIFO_READ EMPTY" *) output empty;
  output wr_rst_busy;
  output rd_rst_busy;

  wire [7:0]din;
  wire [7:0]dout;
  wire empty;
  wire full;
  wire rd_clk;
  wire rd_en;
  wire rd_rst_busy;
  wire srst;
  wire wr_clk;
  wire wr_en;
  wire wr_rst_busy;
  wire NLW_U0_almost_empty_UNCONNECTED;
  wire NLW_U0_almost_full_UNCONNECTED;
  wire NLW_U0_axi_ar_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_ar_overflow_UNCONNECTED;
  wire NLW_U0_axi_ar_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_ar_prog_full_UNCONNECTED;
  wire NLW_U0_axi_ar_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_ar_underflow_UNCONNECTED;
  wire NLW_U0_axi_aw_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_aw_overflow_UNCONNECTED;
  wire NLW_U0_axi_aw_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_aw_prog_full_UNCONNECTED;
  wire NLW_U0_axi_aw_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_aw_underflow_UNCONNECTED;
  wire NLW_U0_axi_b_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_b_overflow_UNCONNECTED;
  wire NLW_U0_axi_b_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_b_prog_full_UNCONNECTED;
  wire NLW_U0_axi_b_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_b_underflow_UNCONNECTED;
  wire NLW_U0_axi_r_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_r_overflow_UNCONNECTED;
  wire NLW_U0_axi_r_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_r_prog_full_UNCONNECTED;
  wire NLW_U0_axi_r_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_r_underflow_UNCONNECTED;
  wire NLW_U0_axi_w_dbiterr_UNCONNECTED;
  wire NLW_U0_axi_w_overflow_UNCONNECTED;
  wire NLW_U0_axi_w_prog_empty_UNCONNECTED;
  wire NLW_U0_axi_w_prog_full_UNCONNECTED;
  wire NLW_U0_axi_w_sbiterr_UNCONNECTED;
  wire NLW_U0_axi_w_underflow_UNCONNECTED;
  wire NLW_U0_axis_dbiterr_UNCONNECTED;
  wire NLW_U0_axis_overflow_UNCONNECTED;
  wire NLW_U0_axis_prog_empty_UNCONNECTED;
  wire NLW_U0_axis_prog_full_UNCONNECTED;
  wire NLW_U0_axis_sbiterr_UNCONNECTED;
  wire NLW_U0_axis_underflow_UNCONNECTED;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_m_axi_arvalid_UNCONNECTED;
  wire NLW_U0_m_axi_awvalid_UNCONNECTED;
  wire NLW_U0_m_axi_bready_UNCONNECTED;
  wire NLW_U0_m_axi_rready_UNCONNECTED;
  wire NLW_U0_m_axi_wlast_UNCONNECTED;
  wire NLW_U0_m_axi_wvalid_UNCONNECTED;
  wire NLW_U0_m_axis_tlast_UNCONNECTED;
  wire NLW_U0_m_axis_tvalid_UNCONNECTED;
  wire NLW_U0_overflow_UNCONNECTED;
  wire NLW_U0_prog_empty_UNCONNECTED;
  wire NLW_U0_prog_full_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_s_axis_tready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire NLW_U0_underflow_UNCONNECTED;
  wire NLW_U0_valid_UNCONNECTED;
  wire NLW_U0_wr_ack_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_ar_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_aw_wr_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_rd_data_count_UNCONNECTED;
  wire [4:0]NLW_U0_axi_b_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_r_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axi_w_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_rd_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_axis_wr_data_count_UNCONNECTED;
  wire [10:0]NLW_U0_data_count_UNCONNECTED;
  wire [31:0]NLW_U0_m_axi_araddr_UNCONNECTED;
  wire [1:0]NLW_U0_m_axi_arburst_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arcache_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_arid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_arlen_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_arlock_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_arprot_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arqos_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_arregion_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_arsize_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_aruser_UNCONNECTED;
  wire [31:0]NLW_U0_m_axi_awaddr_UNCONNECTED;
  wire [1:0]NLW_U0_m_axi_awburst_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awcache_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_awlen_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awlock_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_awprot_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awqos_UNCONNECTED;
  wire [3:0]NLW_U0_m_axi_awregion_UNCONNECTED;
  wire [2:0]NLW_U0_m_axi_awsize_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_awuser_UNCONNECTED;
  wire [63:0]NLW_U0_m_axi_wdata_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_wid_UNCONNECTED;
  wire [7:0]NLW_U0_m_axi_wstrb_UNCONNECTED;
  wire [0:0]NLW_U0_m_axi_wuser_UNCONNECTED;
  wire [7:0]NLW_U0_m_axis_tdata_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tdest_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tid_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tkeep_UNCONNECTED;
  wire [0:0]NLW_U0_m_axis_tstrb_UNCONNECTED;
  wire [3:0]NLW_U0_m_axis_tuser_UNCONNECTED;
  wire [10:0]NLW_U0_rd_data_count_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_buser_UNCONNECTED;
  wire [63:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;
  wire [0:0]NLW_U0_s_axi_ruser_UNCONNECTED;
  wire [10:0]NLW_U0_wr_data_count_UNCONNECTED;

  (* C_ADD_NGC_CONSTRAINT = "0" *) 
  (* C_APPLICATION_TYPE_AXIS = "0" *) 
  (* C_APPLICATION_TYPE_RACH = "0" *) 
  (* C_APPLICATION_TYPE_RDCH = "0" *) 
  (* C_APPLICATION_TYPE_WACH = "0" *) 
  (* C_APPLICATION_TYPE_WDCH = "0" *) 
  (* C_APPLICATION_TYPE_WRCH = "0" *) 
  (* C_AXIS_TDATA_WIDTH = "8" *) 
  (* C_AXIS_TDEST_WIDTH = "1" *) 
  (* C_AXIS_TID_WIDTH = "1" *) 
  (* C_AXIS_TKEEP_WIDTH = "1" *) 
  (* C_AXIS_TSTRB_WIDTH = "1" *) 
  (* C_AXIS_TUSER_WIDTH = "4" *) 
  (* C_AXIS_TYPE = "0" *) 
  (* C_AXI_ADDR_WIDTH = "32" *) 
  (* C_AXI_ARUSER_WIDTH = "1" *) 
  (* C_AXI_AWUSER_WIDTH = "1" *) 
  (* C_AXI_BUSER_WIDTH = "1" *) 
  (* C_AXI_DATA_WIDTH = "64" *) 
  (* C_AXI_ID_WIDTH = "1" *) 
  (* C_AXI_LEN_WIDTH = "8" *) 
  (* C_AXI_LOCK_WIDTH = "1" *) 
  (* C_AXI_RUSER_WIDTH = "1" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_AXI_WUSER_WIDTH = "1" *) 
  (* C_COMMON_CLOCK = "0" *) 
  (* C_COUNT_TYPE = "0" *) 
  (* C_DATA_COUNT_WIDTH = "11" *) 
  (* C_DEFAULT_VALUE = "BlankString" *) 
  (* C_DIN_WIDTH = "8" *) 
  (* C_DIN_WIDTH_AXIS = "1" *) 
  (* C_DIN_WIDTH_RACH = "32" *) 
  (* C_DIN_WIDTH_RDCH = "64" *) 
  (* C_DIN_WIDTH_WACH = "1" *) 
  (* C_DIN_WIDTH_WDCH = "64" *) 
  (* C_DIN_WIDTH_WRCH = "2" *) 
  (* C_DOUT_RST_VAL = "0" *) 
  (* C_DOUT_WIDTH = "8" *) 
  (* C_ENABLE_RLOCS = "0" *) 
  (* C_ENABLE_RST_SYNC = "1" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_ERROR_INJECTION_TYPE = "0" *) 
  (* C_ERROR_INJECTION_TYPE_AXIS = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_RDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WACH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WDCH = "0" *) 
  (* C_ERROR_INJECTION_TYPE_WRCH = "0" *) 
  (* C_FAMILY = "kintexu" *) 
  (* C_FULL_FLAGS_RST_VAL = "0" *) 
  (* C_HAS_ALMOST_EMPTY = "0" *) 
  (* C_HAS_ALMOST_FULL = "0" *) 
  (* C_HAS_AXIS_TDATA = "1" *) 
  (* C_HAS_AXIS_TDEST = "0" *) 
  (* C_HAS_AXIS_TID = "0" *) 
  (* C_HAS_AXIS_TKEEP = "0" *) 
  (* C_HAS_AXIS_TLAST = "0" *) 
  (* C_HAS_AXIS_TREADY = "1" *) 
  (* C_HAS_AXIS_TSTRB = "0" *) 
  (* C_HAS_AXIS_TUSER = "1" *) 
  (* C_HAS_AXI_ARUSER = "0" *) 
  (* C_HAS_AXI_AWUSER = "0" *) 
  (* C_HAS_AXI_BUSER = "0" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_AXI_RD_CHANNEL = "1" *) 
  (* C_HAS_AXI_RUSER = "0" *) 
  (* C_HAS_AXI_WR_CHANNEL = "1" *) 
  (* C_HAS_AXI_WUSER = "0" *) 
  (* C_HAS_BACKUP = "0" *) 
  (* C_HAS_DATA_COUNT = "0" *) 
  (* C_HAS_DATA_COUNTS_AXIS = "0" *) 
  (* C_HAS_DATA_COUNTS_RACH = "0" *) 
  (* C_HAS_DATA_COUNTS_RDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WACH = "0" *) 
  (* C_HAS_DATA_COUNTS_WDCH = "0" *) 
  (* C_HAS_DATA_COUNTS_WRCH = "0" *) 
  (* C_HAS_INT_CLK = "0" *) 
  (* C_HAS_MASTER_CE = "0" *) 
  (* C_HAS_MEMINIT_FILE = "0" *) 
  (* C_HAS_OVERFLOW = "0" *) 
  (* C_HAS_PROG_FLAGS_AXIS = "0" *) 
  (* C_HAS_PROG_FLAGS_RACH = "0" *) 
  (* C_HAS_PROG_FLAGS_RDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WACH = "0" *) 
  (* C_HAS_PROG_FLAGS_WDCH = "0" *) 
  (* C_HAS_PROG_FLAGS_WRCH = "0" *) 
  (* C_HAS_RD_DATA_COUNT = "0" *) 
  (* C_HAS_RD_RST = "0" *) 
  (* C_HAS_RST = "0" *) 
  (* C_HAS_SLAVE_CE = "0" *) 
  (* C_HAS_SRST = "1" *) 
  (* C_HAS_UNDERFLOW = "0" *) 
  (* C_HAS_VALID = "0" *) 
  (* C_HAS_WR_ACK = "0" *) 
  (* C_HAS_WR_DATA_COUNT = "0" *) 
  (* C_HAS_WR_RST = "0" *) 
  (* C_IMPLEMENTATION_TYPE = "6" *) 
  (* C_IMPLEMENTATION_TYPE_AXIS = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_RDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WACH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WDCH = "1" *) 
  (* C_IMPLEMENTATION_TYPE_WRCH = "1" *) 
  (* C_INIT_WR_PNTR_VAL = "0" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_MEMORY_TYPE = "4" *) 
  (* C_MIF_FILE_NAME = "BlankString" *) 
  (* C_MSGON_VAL = "1" *) 
  (* C_OPTIMIZATION_MODE = "0" *) 
  (* C_OVERFLOW_LOW = "0" *) 
  (* C_POWER_SAVING_MODE = "0" *) 
  (* C_PRELOAD_LATENCY = "0" *) 
  (* C_PRELOAD_REGS = "1" *) 
  (* C_PRIM_FIFO_TYPE = "2kx9" *) 
  (* C_PRIM_FIFO_TYPE_AXIS = "1kx18" *) 
  (* C_PRIM_FIFO_TYPE_RACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_RDCH = "512x72" *) 
  (* C_PRIM_FIFO_TYPE_WACH = "512x36" *) 
  (* C_PRIM_FIFO_TYPE_WDCH = "512x72" *) 
  (* C_PRIM_FIFO_TYPE_WRCH = "512x36" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL = "6" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_AXIS = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_RDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WACH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WDCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_ASSERT_VAL_WRCH = "1022" *) 
  (* C_PROG_EMPTY_THRESH_NEGATE_VAL = "7" *) 
  (* C_PROG_EMPTY_TYPE = "0" *) 
  (* C_PROG_EMPTY_TYPE_AXIS = "0" *) 
  (* C_PROG_EMPTY_TYPE_RACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_RDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WACH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WDCH = "0" *) 
  (* C_PROG_EMPTY_TYPE_WRCH = "0" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL = "2047" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_AXIS = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_RDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WACH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WDCH = "1023" *) 
  (* C_PROG_FULL_THRESH_ASSERT_VAL_WRCH = "1023" *) 
  (* C_PROG_FULL_THRESH_NEGATE_VAL = "2046" *) 
  (* C_PROG_FULL_TYPE = "0" *) 
  (* C_PROG_FULL_TYPE_AXIS = "0" *) 
  (* C_PROG_FULL_TYPE_RACH = "0" *) 
  (* C_PROG_FULL_TYPE_RDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WACH = "0" *) 
  (* C_PROG_FULL_TYPE_WDCH = "0" *) 
  (* C_PROG_FULL_TYPE_WRCH = "0" *) 
  (* C_RACH_TYPE = "0" *) 
  (* C_RDCH_TYPE = "0" *) 
  (* C_RD_DATA_COUNT_WIDTH = "11" *) 
  (* C_RD_DEPTH = "2048" *) 
  (* C_RD_FREQ = "1" *) 
  (* C_RD_PNTR_WIDTH = "11" *) 
  (* C_REG_SLICE_MODE_AXIS = "0" *) 
  (* C_REG_SLICE_MODE_RACH = "0" *) 
  (* C_REG_SLICE_MODE_RDCH = "0" *) 
  (* C_REG_SLICE_MODE_WACH = "0" *) 
  (* C_REG_SLICE_MODE_WDCH = "0" *) 
  (* C_REG_SLICE_MODE_WRCH = "0" *) 
  (* C_SELECT_XPM = "0" *) 
  (* C_SYNCHRONIZER_STAGE = "2" *) 
  (* C_UNDERFLOW_LOW = "0" *) 
  (* C_USE_COMMON_OVERFLOW = "0" *) 
  (* C_USE_COMMON_UNDERFLOW = "0" *) 
  (* C_USE_DEFAULT_SETTINGS = "0" *) 
  (* C_USE_DOUT_RST = "1" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_ECC_AXIS = "0" *) 
  (* C_USE_ECC_RACH = "0" *) 
  (* C_USE_ECC_RDCH = "0" *) 
  (* C_USE_ECC_WACH = "0" *) 
  (* C_USE_ECC_WDCH = "0" *) 
  (* C_USE_ECC_WRCH = "0" *) 
  (* C_USE_EMBEDDED_REG = "1" *) 
  (* C_USE_FIFO16_FLAGS = "0" *) 
  (* C_USE_FWFT_DATA_COUNT = "0" *) 
  (* C_USE_PIPELINE_REG = "0" *) 
  (* C_VALID_LOW = "0" *) 
  (* C_WACH_TYPE = "0" *) 
  (* C_WDCH_TYPE = "0" *) 
  (* C_WRCH_TYPE = "0" *) 
  (* C_WR_ACK_LOW = "0" *) 
  (* C_WR_DATA_COUNT_WIDTH = "11" *) 
  (* C_WR_DEPTH = "2048" *) 
  (* C_WR_DEPTH_AXIS = "1024" *) 
  (* C_WR_DEPTH_RACH = "16" *) 
  (* C_WR_DEPTH_RDCH = "1024" *) 
  (* C_WR_DEPTH_WACH = "16" *) 
  (* C_WR_DEPTH_WDCH = "1024" *) 
  (* C_WR_DEPTH_WRCH = "16" *) 
  (* C_WR_FREQ = "1" *) 
  (* C_WR_PNTR_WIDTH = "11" *) 
  (* C_WR_PNTR_WIDTH_AXIS = "10" *) 
  (* C_WR_PNTR_WIDTH_RACH = "4" *) 
  (* C_WR_PNTR_WIDTH_RDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WACH = "4" *) 
  (* C_WR_PNTR_WIDTH_WDCH = "10" *) 
  (* C_WR_PNTR_WIDTH_WRCH = "4" *) 
  (* C_WR_RESPONSE_LATENCY = "1" *) 
  (* is_du_within_envelope = "true" *) 
  char_fifo_fifo_generator_v13_2_14 U0
       (.almost_empty(NLW_U0_almost_empty_UNCONNECTED),
        .almost_full(NLW_U0_almost_full_UNCONNECTED),
        .axi_ar_data_count(NLW_U0_axi_ar_data_count_UNCONNECTED[4:0]),
        .axi_ar_dbiterr(NLW_U0_axi_ar_dbiterr_UNCONNECTED),
        .axi_ar_injectdbiterr(1'b0),
        .axi_ar_injectsbiterr(1'b0),
        .axi_ar_overflow(NLW_U0_axi_ar_overflow_UNCONNECTED),
        .axi_ar_prog_empty(NLW_U0_axi_ar_prog_empty_UNCONNECTED),
        .axi_ar_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_prog_full(NLW_U0_axi_ar_prog_full_UNCONNECTED),
        .axi_ar_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_ar_rd_data_count(NLW_U0_axi_ar_rd_data_count_UNCONNECTED[4:0]),
        .axi_ar_sbiterr(NLW_U0_axi_ar_sbiterr_UNCONNECTED),
        .axi_ar_underflow(NLW_U0_axi_ar_underflow_UNCONNECTED),
        .axi_ar_wr_data_count(NLW_U0_axi_ar_wr_data_count_UNCONNECTED[4:0]),
        .axi_aw_data_count(NLW_U0_axi_aw_data_count_UNCONNECTED[4:0]),
        .axi_aw_dbiterr(NLW_U0_axi_aw_dbiterr_UNCONNECTED),
        .axi_aw_injectdbiterr(1'b0),
        .axi_aw_injectsbiterr(1'b0),
        .axi_aw_overflow(NLW_U0_axi_aw_overflow_UNCONNECTED),
        .axi_aw_prog_empty(NLW_U0_axi_aw_prog_empty_UNCONNECTED),
        .axi_aw_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_prog_full(NLW_U0_axi_aw_prog_full_UNCONNECTED),
        .axi_aw_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_aw_rd_data_count(NLW_U0_axi_aw_rd_data_count_UNCONNECTED[4:0]),
        .axi_aw_sbiterr(NLW_U0_axi_aw_sbiterr_UNCONNECTED),
        .axi_aw_underflow(NLW_U0_axi_aw_underflow_UNCONNECTED),
        .axi_aw_wr_data_count(NLW_U0_axi_aw_wr_data_count_UNCONNECTED[4:0]),
        .axi_b_data_count(NLW_U0_axi_b_data_count_UNCONNECTED[4:0]),
        .axi_b_dbiterr(NLW_U0_axi_b_dbiterr_UNCONNECTED),
        .axi_b_injectdbiterr(1'b0),
        .axi_b_injectsbiterr(1'b0),
        .axi_b_overflow(NLW_U0_axi_b_overflow_UNCONNECTED),
        .axi_b_prog_empty(NLW_U0_axi_b_prog_empty_UNCONNECTED),
        .axi_b_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_prog_full(NLW_U0_axi_b_prog_full_UNCONNECTED),
        .axi_b_prog_full_thresh({1'b0,1'b0,1'b0,1'b0}),
        .axi_b_rd_data_count(NLW_U0_axi_b_rd_data_count_UNCONNECTED[4:0]),
        .axi_b_sbiterr(NLW_U0_axi_b_sbiterr_UNCONNECTED),
        .axi_b_underflow(NLW_U0_axi_b_underflow_UNCONNECTED),
        .axi_b_wr_data_count(NLW_U0_axi_b_wr_data_count_UNCONNECTED[4:0]),
        .axi_r_data_count(NLW_U0_axi_r_data_count_UNCONNECTED[10:0]),
        .axi_r_dbiterr(NLW_U0_axi_r_dbiterr_UNCONNECTED),
        .axi_r_injectdbiterr(1'b0),
        .axi_r_injectsbiterr(1'b0),
        .axi_r_overflow(NLW_U0_axi_r_overflow_UNCONNECTED),
        .axi_r_prog_empty(NLW_U0_axi_r_prog_empty_UNCONNECTED),
        .axi_r_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_prog_full(NLW_U0_axi_r_prog_full_UNCONNECTED),
        .axi_r_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_r_rd_data_count(NLW_U0_axi_r_rd_data_count_UNCONNECTED[10:0]),
        .axi_r_sbiterr(NLW_U0_axi_r_sbiterr_UNCONNECTED),
        .axi_r_underflow(NLW_U0_axi_r_underflow_UNCONNECTED),
        .axi_r_wr_data_count(NLW_U0_axi_r_wr_data_count_UNCONNECTED[10:0]),
        .axi_w_data_count(NLW_U0_axi_w_data_count_UNCONNECTED[10:0]),
        .axi_w_dbiterr(NLW_U0_axi_w_dbiterr_UNCONNECTED),
        .axi_w_injectdbiterr(1'b0),
        .axi_w_injectsbiterr(1'b0),
        .axi_w_overflow(NLW_U0_axi_w_overflow_UNCONNECTED),
        .axi_w_prog_empty(NLW_U0_axi_w_prog_empty_UNCONNECTED),
        .axi_w_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_prog_full(NLW_U0_axi_w_prog_full_UNCONNECTED),
        .axi_w_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axi_w_rd_data_count(NLW_U0_axi_w_rd_data_count_UNCONNECTED[10:0]),
        .axi_w_sbiterr(NLW_U0_axi_w_sbiterr_UNCONNECTED),
        .axi_w_underflow(NLW_U0_axi_w_underflow_UNCONNECTED),
        .axi_w_wr_data_count(NLW_U0_axi_w_wr_data_count_UNCONNECTED[10:0]),
        .axis_data_count(NLW_U0_axis_data_count_UNCONNECTED[10:0]),
        .axis_dbiterr(NLW_U0_axis_dbiterr_UNCONNECTED),
        .axis_injectdbiterr(1'b0),
        .axis_injectsbiterr(1'b0),
        .axis_overflow(NLW_U0_axis_overflow_UNCONNECTED),
        .axis_prog_empty(NLW_U0_axis_prog_empty_UNCONNECTED),
        .axis_prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_prog_full(NLW_U0_axis_prog_full_UNCONNECTED),
        .axis_prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .axis_rd_data_count(NLW_U0_axis_rd_data_count_UNCONNECTED[10:0]),
        .axis_sbiterr(NLW_U0_axis_sbiterr_UNCONNECTED),
        .axis_underflow(NLW_U0_axis_underflow_UNCONNECTED),
        .axis_wr_data_count(NLW_U0_axis_wr_data_count_UNCONNECTED[10:0]),
        .backup(1'b0),
        .backup_marker(1'b0),
        .clk(1'b0),
        .data_count(NLW_U0_data_count_UNCONNECTED[10:0]),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .din(din),
        .dout(dout),
        .empty(empty),
        .full(full),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .int_clk(1'b0),
        .m_aclk(1'b0),
        .m_aclk_en(1'b0),
        .m_axi_araddr(NLW_U0_m_axi_araddr_UNCONNECTED[31:0]),
        .m_axi_arburst(NLW_U0_m_axi_arburst_UNCONNECTED[1:0]),
        .m_axi_arcache(NLW_U0_m_axi_arcache_UNCONNECTED[3:0]),
        .m_axi_arid(NLW_U0_m_axi_arid_UNCONNECTED[0]),
        .m_axi_arlen(NLW_U0_m_axi_arlen_UNCONNECTED[7:0]),
        .m_axi_arlock(NLW_U0_m_axi_arlock_UNCONNECTED[0]),
        .m_axi_arprot(NLW_U0_m_axi_arprot_UNCONNECTED[2:0]),
        .m_axi_arqos(NLW_U0_m_axi_arqos_UNCONNECTED[3:0]),
        .m_axi_arready(1'b0),
        .m_axi_arregion(NLW_U0_m_axi_arregion_UNCONNECTED[3:0]),
        .m_axi_arsize(NLW_U0_m_axi_arsize_UNCONNECTED[2:0]),
        .m_axi_aruser(NLW_U0_m_axi_aruser_UNCONNECTED[0]),
        .m_axi_arvalid(NLW_U0_m_axi_arvalid_UNCONNECTED),
        .m_axi_awaddr(NLW_U0_m_axi_awaddr_UNCONNECTED[31:0]),
        .m_axi_awburst(NLW_U0_m_axi_awburst_UNCONNECTED[1:0]),
        .m_axi_awcache(NLW_U0_m_axi_awcache_UNCONNECTED[3:0]),
        .m_axi_awid(NLW_U0_m_axi_awid_UNCONNECTED[0]),
        .m_axi_awlen(NLW_U0_m_axi_awlen_UNCONNECTED[7:0]),
        .m_axi_awlock(NLW_U0_m_axi_awlock_UNCONNECTED[0]),
        .m_axi_awprot(NLW_U0_m_axi_awprot_UNCONNECTED[2:0]),
        .m_axi_awqos(NLW_U0_m_axi_awqos_UNCONNECTED[3:0]),
        .m_axi_awready(1'b0),
        .m_axi_awregion(NLW_U0_m_axi_awregion_UNCONNECTED[3:0]),
        .m_axi_awsize(NLW_U0_m_axi_awsize_UNCONNECTED[2:0]),
        .m_axi_awuser(NLW_U0_m_axi_awuser_UNCONNECTED[0]),
        .m_axi_awvalid(NLW_U0_m_axi_awvalid_UNCONNECTED),
        .m_axi_bid(1'b0),
        .m_axi_bready(NLW_U0_m_axi_bready_UNCONNECTED),
        .m_axi_bresp({1'b0,1'b0}),
        .m_axi_buser(1'b0),
        .m_axi_bvalid(1'b0),
        .m_axi_rdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .m_axi_rid(1'b0),
        .m_axi_rlast(1'b0),
        .m_axi_rready(NLW_U0_m_axi_rready_UNCONNECTED),
        .m_axi_rresp({1'b0,1'b0}),
        .m_axi_ruser(1'b0),
        .m_axi_rvalid(1'b0),
        .m_axi_wdata(NLW_U0_m_axi_wdata_UNCONNECTED[63:0]),
        .m_axi_wid(NLW_U0_m_axi_wid_UNCONNECTED[0]),
        .m_axi_wlast(NLW_U0_m_axi_wlast_UNCONNECTED),
        .m_axi_wready(1'b0),
        .m_axi_wstrb(NLW_U0_m_axi_wstrb_UNCONNECTED[7:0]),
        .m_axi_wuser(NLW_U0_m_axi_wuser_UNCONNECTED[0]),
        .m_axi_wvalid(NLW_U0_m_axi_wvalid_UNCONNECTED),
        .m_axis_tdata(NLW_U0_m_axis_tdata_UNCONNECTED[7:0]),
        .m_axis_tdest(NLW_U0_m_axis_tdest_UNCONNECTED[0]),
        .m_axis_tid(NLW_U0_m_axis_tid_UNCONNECTED[0]),
        .m_axis_tkeep(NLW_U0_m_axis_tkeep_UNCONNECTED[0]),
        .m_axis_tlast(NLW_U0_m_axis_tlast_UNCONNECTED),
        .m_axis_tready(1'b0),
        .m_axis_tstrb(NLW_U0_m_axis_tstrb_UNCONNECTED[0]),
        .m_axis_tuser(NLW_U0_m_axis_tuser_UNCONNECTED[3:0]),
        .m_axis_tvalid(NLW_U0_m_axis_tvalid_UNCONNECTED),
        .overflow(NLW_U0_overflow_UNCONNECTED),
        .prog_empty(NLW_U0_prog_empty_UNCONNECTED),
        .prog_empty_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_empty_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full(NLW_U0_prog_full_UNCONNECTED),
        .prog_full_thresh({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_assert({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .prog_full_thresh_negate({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .rd_clk(rd_clk),
        .rd_data_count(NLW_U0_rd_data_count_UNCONNECTED[10:0]),
        .rd_en(rd_en),
        .rd_rst(1'b0),
        .rd_rst_busy(rd_rst_busy),
        .rst(1'b0),
        .s_aclk(1'b0),
        .s_aclk_en(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arid(1'b0),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlock(1'b0),
        .s_axi_arprot({1'b0,1'b0,1'b0}),
        .s_axi_arqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_aruser(1'b0),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awcache({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awid(1'b0),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlock(1'b0),
        .s_axi_awprot({1'b0,1'b0,1'b0}),
        .s_axi_awqos({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awregion({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awuser(1'b0),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_buser(NLW_U0_s_axi_buser_UNCONNECTED[0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[63:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_ruser(NLW_U0_s_axi_ruser_UNCONNECTED[0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wid(1'b0),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wuser(1'b0),
        .s_axi_wvalid(1'b0),
        .s_axis_tdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tdest(1'b0),
        .s_axis_tid(1'b0),
        .s_axis_tkeep(1'b0),
        .s_axis_tlast(1'b0),
        .s_axis_tready(NLW_U0_s_axis_tready_UNCONNECTED),
        .s_axis_tstrb(1'b0),
        .s_axis_tuser({1'b0,1'b0,1'b0,1'b0}),
        .s_axis_tvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .sleep(1'b0),
        .srst(srst),
        .underflow(NLW_U0_underflow_UNCONNECTED),
        .valid(NLW_U0_valid_UNCONNECTED),
        .wr_ack(NLW_U0_wr_ack_UNCONNECTED),
        .wr_clk(wr_clk),
        .wr_data_count(NLW_U0_wr_data_count_UNCONNECTED[10:0]),
        .wr_en(wr_en),
        .wr_rst(1'b0),
        .wr_rst_busy(wr_rst_busy));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2025.2"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
UU0HctCtrDGjqiFgNj8KUV1CNrtLH1fzvWozH/S7aVj0RSc24esnSs0ybsApJYbLPSCW6MJRxlk8
TZTBIGKXHEs9iSJrHyeb7Q9LsfbX2O77j94jiFzmN8lM/LIVA6RCDBtX2LtKWWw0Ex0IvwdPy+Mg
2z4iCfTMzyceiAZWkhE=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GF0Vw/gqBrc9IHG5aASlKQHzVjMUtBIwjnrAUquexOCvx+SSWyZN88WoE2YOio8l2Mng8jmA3ELb
iVwbk5kPsSQid3iLelRIejTGTCNP7ErmhAyw9N/gInxZrkBgF+99fwCp/qSFsRz+GkpjXlmNPLal
1m+CmI2mtQjH/zDmulZq9kFS9URMU7E3TrKSiNtdLMYc1ulwC3kFJ99geu/tuMfIrNOmA9KkJtnb
Zoy9fNs53bR+fUGBL5n7AwoO6cdU62PpktsyWXh1Gp6Ylf2HTT0CPMyzWbJQve0G4+iszllRawxG
r+FcAh4BuFpKqaFogcTloexA8MTZ9ICsGZkzkg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
Hzytw/FfXpsPrE5ZowzcEV+nwakl1BirWDR+Iseu9nWPYk6Otw/UyzdfMGdUJQcXxjn8eODJUMPS
SLvHyIbu8M+iaMMz4+lNG/o0csNo8MO67HX9fxa4xkVOaSOTCzBVfRk3cjnK+OAXlJEZO2/F0Im7
evCVwWE8mv0p9yv9NZA=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
aYTxAf85PVmpAktzX89uf9AJXAUs8FLk2gaAmaPtMQhfYN72ydFe5GcOlR9/W705GnhW+LSDUX2b
XQnSvIzmqRMwIqE2sgix0W4aZDvptNpP2y+gttAzQaOhAd12INExGFaZxKro7f/cey7YiwGKPPah
zcBWMoHI2bIhFDe04i/Jt1MdciCe1haFyhwBCett8eV6Laia/DlHOXxqH2bLukgGZp5p2EYoM0T8
WwuwxJ3X0IIphS/uP6nXSuuuMQcAplYzcG4PLCMpn2Lo3HwmwSo5w+0N1NFI5LYfb6ZrdTXjRH+j
oHZlteBZzQ+4jNx7/nPPCnuUB8IFMROek8y3aQ==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
e6jDiYnzLTYk/3jC49X3YNnxEmaFBYGO/cl88hMTKYq1FltlAtsDFs47xPVxcrXJmXB6FiDcQKgy
Zcri+H61avSebr0yHZ1uigtfwqLvcivJwyCmMK1zZ+tk95pu+v8wQUekejQwCfm8d4EwcPtFRBCP
VuiAB7kH68VA/rKSNW/L3Ck+PVdkE6HHJnrneJm4Aial7Xm5QOsroJRJU/ObInH0MO+tgwAysCdd
6eCmjEBFQGTjmThY8W79EF9AQGGRTMTJSajCB65vB7j4uMsw7y2m2q5T1cf5FapbNOa5qVGM3ltu
WzPHL8ffpwsn/Um4FxL0m2OELCU3vijgWPxyYg==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2025.1-2029.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
W4uYHM01gGeA2MU+ib2L/ExIRZJnY4G/4/BNSFnBkDMClm5bxdPZWGZhCUejE4JXBUBzvBBii0hv
o/qn9snazl844XvvPfn0rjgdMjBDDTUc14EhQ+t9LtnZFAV+z3wAIKGQaUOt5C451j/28rPyPkS0
kBiQMKRYL8V8HYzz8PJCw/2pMZh5nAGYlHVN7x7BRfHg/eGLL9Vxje7mRSIq9oPfHNxp9KvTPnEz
BAbFFeUiH6gtQHgv3loUdp74IXW+8+uJHlh0BbE4crWkB23UetPNvBTz30q+iGUe+Uy9cDako55V
AVXIMgciLrWVPF+qY5b7zySQkB4Xsfj+udkVyA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
R0MJeGCQpSjYsGBWKKr56ZJi8ovYpLtniBxpCnrQicvQybY+fnPA8Daj6MXdCf3qwLF8yF5WCJ8s
qgsZvXSLz7hwsKVEId08i3cpwMDSnKdPTNXjuKS2h7UKOlcr6QZ5j31qcO2XbyCffpn/pAXTmv3a
wywj0bLNK61+JY8v+VTzUKzR370hK34Ryuts+hg1InhuHxLuVnu52lVOpk/PYUaA+w7ORS7AIzBm
Ic2Gs+gCO56TT/kHzEdPXDOhyRk/LG0ir7xXNq7VYILxVh4t9QTZ+TIjutFAhElz9ceEjJ95QYy+
i58LiAOmyF9ID0yxSSYM4KQAF2bqt9kvgdWRhg==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
piBTg4FhL4gV7WxO2j/dIDXpMS0DVV+BCPbz6qHH74TfGEKWiiBMU6gK+ZbplwJNS8NHNyEzAlya
r4wgVpBFLdWysNz1JTSjKKJCO9JEQN5/H5jfiaYLOSRwE+N3Opc54BvT85yu1V+zTS+2aJj4AQ/f
gjyVCtr2A8YVv2zEjqFuQcYlcSxHTEk5eig4u36hHgzGJsmifFlP0OtE2NeoOMzFbBJe4LR9f1Ac
XQfLq8HilNwnOz4EYZGL9iJymjQ63NwSYfWcRjHVPPJXQFZSrWlI6V5kkz1/IDnPuelueoAKOk5K
OAAeaRjYDKgXhfse4B1Cy+u9f08zryJez9v+yfA14jVDkQQJp6a0qHJYuemefEFrmwJxSLUqG+Xq
QDK6/emEA9ZXoln0PNQyFzaEVDeFDZBn8LZi5SGL6f+TpO0acfI2jxa5+vCQHX/boxpyVjtxPh0W
Xjk7+E7CKFDmE6T/ZNnn7MRpaG1g4A2TEvSqCSRRnPprcg/+bRR6T6Sy

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
GlYhuN+XgK/dKipYGy0F51EWCsMzdTtEw7DUl9GCeVeyU6B0qQxd4o+WGLqPzleHUcbSjTY0Zsbn
PYVk3cx1yet4akcLytYAGFXC4n/Xi+1UqMz5TGn6+YQTvRIQ3rDpVCwwETOtxY9exyURa9vrZwN6
wg8aS7eaMRDPPrD9XOy8sQT0WrdKizBToFy2xoVRXceycyYYY7TdZikow1sCVE5Dsq8WQ5SRprGB
6XOvNlQnaIlUCVafx8nFv91VsM31btEViBrUpTqFHJAuoebt0ZL+JlrQ5nOk7XQnw6AQ+0ZlOKba
q3Ttg2CqLMLHVI+1yNiz+OEKhmPV1D5J7vlPQQ==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
2gbN0jz/o58BxZjM7+eT+qN7Q3qHE0g1JsI7dvdgaVydBYqQVWbzuiZYLMAHv8yrsn9b32oHcBSE
0o5Cui6GiD7neKU4AljBAlKAaN9vmM7TfUunNvBpRwv61T0jxsnbQPWfLrtpbTXbXa9k+COT+cqb
xPXfz1KFKZR+jUVQfqg3k9yE8k42Qekbv3kD1KU/qey8yzrOiZWk3YSqYVf+xtUpOvJY52CMhroS
XNjVVkBPUu8Qp/8HAzxqzWi+9FMbOuRKapPdzyPMn/9u5V3oDa03Jlbl/wNvQRAMkkI4MR0Z6Fef
acPXE4lO4yrbdCI+/JWNiFnMhbPxxOqB2cgi5g==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
ijvB9ebv8UTsfEBOdwLX29OhkfU+M38mGG3GBCgYR1J/bZmxD6jFCxoFCEm1aKFgD1oURupMHfs1
c3MOeOmJ+miekD3bzrkO2GpRCnMbhKovUm5w9Qm7OnK1B25OU6+Xq1Ykk4tIi1xMOMYX8YKOrSrC
twPgnJ2VHr4FFKQ+p5YO7BYb6KtJrf3+2JKYjVPpp3gkR5SZklV/ugbHgXnKTC8NtjSnys5yM8fs
hXOpMWgzLJxxPm595q7fFP3rHvMyw7H7unYraHK+0uc9zTFZ4LHWuOQvc3TRUEmRmJmaag8nwld1
2cnhyhbuZqsuwb5+2W6amIYGSDb8gPS45qwzBg==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 51328)
`pragma protect data_block
PwZeEqSfWmX6QBnVb0PacSTI8q+35oIPr5VuEqVQIaqZSpzKBwnuW5ubHUkOY6Pva2LF6UY8fAtw
gpJIQ6b+Qxewqkj/L3eVSmzS5mZqGuM33lsbwqKJOolOAAgrkTZyTc9jZxVIlfZOL9lNMEnkf6Sg
u4zrvnZCX1S1Px2+wTGE9fRpUTiGVEp+vq/3VElG1hg0CdvYK+bSHK846eZuzaMdZJoXDqXF2lJp
AUQoJ58E/cp7s/n+Vt6qeHFMITfh6DhWmgOcZ4FCBYxXAbZo95uVOiSWR0/mUUtxSVW712jD6Y/I
rEvV/QQfbhsgbnCfCEf5fegPVppjQ8TQ2I/mlMs3LDr5GlLjSQkJyjKO8vzOMQJka6Y8JZXgfcEY
Uha/P0gtAKs4hEQyRm9PVcIKMqVKmrnkkJ61MM2uYYuy+5RA2SXmTpqsGbpf7V7WSNGem/pS1AGD
3T62jj3VkIOnzyR4lFt4dM2P4kQeT4Y08V+tRkxo+Yns1hBTHZwmtztnnMEfb2c6G2mVpTI4+V6S
tHV2mVQHjdZ35hzuFkTYwsJcEgol7IeAyddzJzX1wKW6MZzGN/Vq3GS1SIIk7YXvwsdmtGCowJ6I
kLiw3C9kGJr70e55eLnFSLnTgCVn5q1jiSH55fW/jYhbnCTYrjwHQL1lq5mSXCew6E6NQQ1Klp1+
jVbcAZ6gzsxvSoIKsC9YGt8tmu+eRxaLpte7T2yMMi0dK9e7JDbWfk03vVJMCWGCMSrrRNv8iPG+
52AjwvrkqsQD9LLUw+OS2uu7CAFMd6yRwNQBesIfHNwQG7dmpAyPv+AkPvWeMHFqnyhJdhxHKCb4
f1UVZf2xMIQU8vO4OLB0sqU5UdllkpFmJ03oaXAMQOVXmgcsHWVLbvyvhzSv1wLMQpwLbBYl7SSf
lQQsk/anjOhqAXzjN5032jlPOJPnnLkVXs6VANKMLdfO+SMvJuaNrHj5Ymp+GPZqZRZDvoj0krYE
lmgvlF2n+HHZHGmnlFcE/aODJvoMCJIQHQb2EMFhMXhMGpIiQ2bTn0XMm1jQ2N7WDeINyN5FF1Sw
/QeKQotIZ3qIODM7xqkuIbWiG62k/eK7RQE1GsCt3hZepxN77qtvbD/X8SjggsqZfe4x/YQ0nJ3A
UIr2/qwxMBgT4hcb9bky5S0h6rmrRS2ipx61DD68t5FVKUg1cFG246KOWgjsVIrYiT+x0f0nIZ48
GO/+i/uI/9pt8FlBD8/KC2PeCNIR5C07mL3+mB1bZ6AU7SaBeZWR29n/JIJaKeYLOjDVIFDpcAxx
4cm1M6goQ9gxENSNJU1XWqK/EpX8C4VKNZiMwznaQN206+6FL0tCFl//16PE7EgXL9INipG4Y8VQ
juUDh9UK4PowpSoTUHTidhT+zSyFYWc6sw3hKo6q/ZwJSfezZLQZjoizHQ7yg1TK1UgSMCEmkRMv
t3JcdkOc68PMQ4SvS6tf0GlF5A/HuZFNatJwakWtU8QyivucuxlNpbqa8jaoYFhXqchcxU0g6KeD
ZzLQ8lCnvgEmQN+sKOzAiiMkoyHuf6fWvCpT1vcHUh+A0Tu0UKaDbh6n650uKK5vApGRoRYjPdVN
ckmqYVvtPvnswuO78CaKLcOqI6JmO517m/ViU0mbCH2+sB83sciUTr0n6bj8PiT1LpV2zbIYA7K6
XF4NVIcJf2XsQdH/Ml/L6gUN0DSKmeSnF/f46CFoMgPMhecnIknBrMgKBBj4ozeN44YNaFUMmCr3
H1KcdKNpl5Q8Qyk4XuRd3IKWis1ApdvjHJWfsWgX8gIqGg5mQr5SlU2uZDE1DPXMiUlltjSwPbIb
GtQiIreX0mhhEDdmOTteTvv9+WfhzBjMXu7HGzhvRr3iUhSCjIsK66QERRtH9bOW08wIjNTHUUNn
SEgQnSJCf/a9Q4M6HOSr9mnGW2oZD3g55kSLtOfjyeKVt319R12/28f0PwNKJFHXzNFnb7oVFZ/Z
Ci19NdqcDJA6imdS5MF8baRKPHSIsf+QseJ6YD53lQIiAjrhNLK78u6iqI4gchZURHfdOZVR6SVz
CcEYUCqrKhDFmM8A6W6S+xc4io9iipR1lAaODxGxzs+GulMqU2ZLBRedrTxR0IiFaeNZqxtHwZ6v
3dyPzr8UELKuEgSvuDkWN97yrkJZteZxpDUO3ZvuuSmyRg+zC3d6dUw25wNmPalVrlRWJzzx03at
QEbrcUn873gysteAbpafe+wd7J4uYljEVkYoe8ZXxJ/lrbYqIB47ze2tQ2psDiOb7XJdngQ+UmgF
vvnTzHu2Vj1gq1TTkqW51ixskZqqesTv+fFrYDmamQ84pwFdyM823BDhDglNKpXweY9lbJYCUuxy
v2v/FIJ5Wp+Qjuma70Jr3izK8W4fWmbHg6awxNn2+HVuCRt6ZZZ9rhh3MVUJcJaUWY4I9uudP3is
jghZHH99cnGkx+gPpSJ996ll7S+CT7lIHk9PE/awz9L27lXBRf5WZ/Gt9oSb3lgKCySdin0I/2KE
kTvH0v2GV7V3dSE1DIFGBNrSaxpHLGwL6Z+QaVGO3Ua0Ef0kNmzomdFDN+wzjO6FKzVPFx6vk9nN
h2T3yNaHLGx4wYqYhAxQUwr9wVUBdasP7Cjb9mO0UrKyGlxhu6U8eQoY66W9rQXzicPY1Srip5xX
Rud+5g12j3/idJ7rwmI+BpR9ugv+4UGM4fSehdI9mtANwBq8r8WXGsCW+bvgoJ1cUlb8gquoHlN0
JB8sjogEcfEinoec01E561UDOb86BcNMYbmVq/9mtgU3B6TTKmluDcf68u5lJPatvD+yEbOTgM0V
dSZiOx9kT5rLUv5XBlT7ASNR1+IeVXSfzYmlLWyIC2+pwoWjZvoN+kwyQQi1fPl0+lsan9HYzPZI
u1vvG9sgfXb9tvm6IkRKJ9Pujpe7lPHgN9RFyojA5L9KsfBgw4PG76s/w0cUbX1isfu2VXhwtgwu
BABBqhTnm5waKomTVkPUn3x+bxWIG4Dasra05BZT0jzxp/eWlQzvUA8tCkEK78d0xx0y0U7ECX9c
/Rmyb8K4s1aNZjKF5FFCVMHzi662/YboJtZ3tDhU9rBC/1y3Fn8155szGum/KMva4sHJqlW8bhyp
jfhjhapfxQo4mIcPM8NH6ZicmKjTSknXMrTwOfCYUzKEJykA/s2Hfau5TM2yQBS2catEOHO/krQf
wgltS4Gz7NVInvRArlAotUO13vXp95Gp20CIOgWBhylociZ/mwsdWiyzFL0dCNpXPo5UfkOl/mWo
/lyYuPZ33S9XPLuJlxZrcHCdtx3FRD+efMCsRYw93F95OeKw63W0rkSq+gDAhYepbxTx7aBoxiKw
uaAUcDPTg/e/mWMsTg3vIrUrRsK1uJ0rxqhOsHBxDleGDUQ6oqRuI74E8px/JMjsjMFqa4+MeTst
MCXqM8C0umdpdu4eofwb2wUaGoYycaEMBk5Fel8LdpWYhNVMYb+xwxtNWpCQbzDQN+Dz4KIMFefn
9M63wYIHUjlsWwJaYgcZ8F++pew993mfJfp5inp5QYzWhRx+bhqeM2YY4K7f5/l79JaJqAomor9v
mGhpImTabBua8NG4mqJu1sDB95zmbsCNmViIRaqGOqPICwyMI7aKXVghL3pcH8Sc9pxPUW8zYjW1
zF2sNBdK6IcCP8ibYkhjIJLp2mE3m/R8FUrv/3n6PH2iY40sNXnV+nKTlK147/2G+L4hbbNG8UGq
+osThJe/K0AWIb6oN+QpJNY7deEdYkfArrDjdyI2c60eEPAnvInblILydiEwsrHJfnFrqGsH5EIA
nXqP3KlGHLhAYbkVz3qBEk4I/cN95uqJ6luQhuOk5MS+wXPzI4lgwZ3edP80AfWqWUgZ2IEzqDf/
3GNdKsLYGQOeuNoKXrcUwCdJlVFikuU+c63WJtu8jtMxFFXWs8HRMsjK+20C/P+u899McYLLevLi
H1cqUJoJO0fdMvQUAvAzZtx6gRRc5UPOmAvX1FqCo4IejgKheETua8HfBhnKCqanpx0Q/h4bHnKA
P6DHtfcazvaLOqrAuUq3UW7QZXQnBvs0wSmtw8/AWOmcZCuCY6cZey0wxgeJH8v9zROWewzqH7RV
JD2UbaRKX2N/lqPJyQ9tEaU2A03451uCpqfMKeQ5VTFuHJWu/eZ6EjAZVZJZ/G407gflTXVJZH87
dO2yexnFHKfq/Cj0QYGa8HfWWHoA/5V36fw7X9vSNSfEsQ+pPpnGlqUNlkUWkcTAW5fgo1XKW/yP
eYEWpUthgrdKyVgTQgoSshSzPMCMUi11XemJLSydY/S7vVgbXOFU+iKg7iBxEBahRDdjq5s9Cnnc
Vtot7LGzD8BxfwbymTECEj7UFyk2i+3UVoRX+cmisNy/xZmzCRzQZe+zJkpYXLaLSZpdGK49FKPk
pegSNCsZg0I6xeQlRri2LnyoC5kyEJjHZ5jqM2QS0nb+v+jOASN0vv2RqiT7rw663pU5f6tQ0++B
1toP7itOAdhz4EF9FfctNZk9F4VkPw8lF2EVCvX1BefEpsfCJiHw98FKcvNgW8cy6ZvUvpprFbIt
V4Gq2NhR0n3U/sx0XZ6dN22ZAYxwxx3mkoVkfyAAtcIDOZ7W0ye+vKio25Xjnf67My/pBzZSpRM1
hvPgiup0ux2KbD9KgnRlddlb8+BjILvcW0iw5PRgTx7R9V3KnwUhGThpnNyOJ8I7/O/LRYNFwXVI
vapZ4qxGuACJLlL+UpGCYEpsKfDJUDeEB1ZlfCTGU+fXHVrHc3SLclOjay1lCnppE2s9GizwUf0I
N/+9wv8267O2CnvWyM+3vc9seeqdej5kBJ2ZMWI0wSeBAkpygrME9f+bc1PSxEm/HA9oGtHuIAGR
I+nCMW5X4yGJP5vq8NZGoS64e8u8Pja6NjUbhPRVSGfyS6VBvBwQVZIDcluCDpxs8jViE6iVLsek
MNyhXS3YiXiyXCu0+lVKVkEr7gdObiEJkqDwiZMScfeeU5qxMY6AgrKdMya5GJvVZezF5CiwxQj5
+UUb0ZbMc+JcVRvAgd7TnmYhibPqcOvmYNmUuY4Rv9Sz5ZrMhkhKDzpsm8ax+mDUf3D2zdvT2K8U
k3yKN9rUVBxU6KIBeoCZfLUQzfYn1U4i+MKUJQDYBLwMbEAoEAnADsMiGje5X9jrp0qz3vt0XCfB
vNnzJWyRBRSD1CDC8mYr3sHOs3SHxW6iqV1z0pKUDf4qlXbS/TqS2Ly4qCKHyIlE3LrpYNOd4cdI
53ey1cvSlcpFHidXHSPrCox2jO0mLoSAItqyAqvDOM8GkTcCkS7tEDWc+qx7vdu+6gPR+9G+iH8R
XTRwmZ/NRsAIz4lqU09MuFKfigAVkIXw2JA1HqlcoRkiZ3Ph5k4vBTAMiVp2Dv4gYKLLdkTiay/f
T64T+B+AEm/QbLWlE6oQK2d9cRE4ddBcYE20fIDKKEeb9hY/nMZCTsEiqgKFHlGWXkk301F2EfYi
V9a4X9dBnQw37dxkHQBmLdj1OLgVyV0/JP52JwZ++QTa6xifaaHOqGnrRe7BjHWnQzKo7L6lEPCk
s19/Kf43EKthapPmFxG7d56xkKu2EWv6TnGdqn7f68TEeQYvahfcV4ZLHUkLheqbgcCISV4ckYtT
9gcgfL+MQ/7aD0FL45H3RH9qr5tNicPiEtxhXKcbetLQKrJ0p6eMvZ8Jivn+eroENDPc0rjt0Kzl
aLhN7IPpBRTte9gb9S+1aolPJU3XKRcTNfRHUcRVSwAyUlIG7I7bGEKTBhAr0mM0Pv/8fzu/KQ3c
Sx+4em5CP/1N7NL57lGBzLPzIImm1TpTmL/HR3eoQX3fpCpDFI7FDJLJJ+ZlFfJkaFrmBn6TxQpB
A6Z6UaR4UMbX003Kyb/OI618VzX+TSUG9HjqSS//kSGDTmUV45oIZ2Ou9X/oVyxe//xBcy7hIDqY
kMjcKAKjUx3yxShilE6SUofcyFKr6Rq/1zgzLdPz8CM3eLYlXIJxm+D2geTLgtILMQCIGmRiZD4u
HlbUQShmudd+9XhaKdpS3sfzCQtr56lsbj0aBTzrWC3YVCKCduicU2t1WEfpaq3qCOiZw9pOeyzY
VJWRpZ8e6ugkruRI/HMxzaX/2uDFaI/HZ4cGP2tRVroJGsjKPrB+Nsc8d8+KKI/3QcuLp22aZNwJ
y1NLk/TFRC4u/XEsV9HRvT6RG6IWhlH5nRFBkHhCqanDAjBvU5VtwoiqjyexXGmN4fKVILxFTUom
IENkG/884mkft9NmEsiEeyuO5oW+mYg6FbpERaRmYE/3zumgsH62dbUb7Z3pQ8NQnJ/qbINZjNPk
P8+kskX/XY3T9iQenEIh4itjI6Ji7fq9NQt0NfvCXLcmS3Le3MIdziSu+OUE3wHfYSydnbkB11s3
dL0bhD+Fn/MtomladrdE6/bW3ItoWux3k+AJFqzOxG/8xKaThx5Bp0zOvzcXE1ikQn34UhLRHchV
jQHy20D65XvW3C9Iiaxp2tX0GbM5KgJaRlq/Si9DouhfyF/3VxCnROFK17SwDHwKW7KpYD+s3Dgv
oXxC+XxUax33UJ4xDeVFo0bkZdjheSgol/64+1YPtjG3bB/0c3BNK3AarDvTJIZZ6AX62IiaihbI
SxRItAilVOXp7KcA6Ye/SbHDhI4EapdxmfjQrXUNwrCJXsuGvpCD7QoZirXYBQTHFUI2jJuA7/Gv
jBe1g2CrTaulXnJ0+HWV0vuwBgeoITAnZ9YswyoXWVS+b3DoiBE8mDxJ57HDeNIFHlAfUGhKaPds
SenhVIEUYMRtRyROdx3QEjbrFkoYZZ6S1JQ/n8WIBY8YOeZWsFwmDhgPtplpDUZYI5e8GI0iYSBb
jmIy3zgOyIvqhK6pHmnZPIoWwnTUfFqofBfKXNKBV6dOQI6kNY0pqJh3tG/pk21Lj35/tH14SIPR
J/yJ56RGYpxE1+zUrwgACoYX0hoFVnxmGprzTV1HqShh31WeRewS7Ej+WYkCwIs9OEernsH9v6vX
U0qfveEOWCuDIcfMLSCt9rKZjaKXojS421c99/KaBg7b1SfHFtLMSkpHW3bkbrBEFQ83otNgNqch
GKh4EMKX9oZ8LheafhOSrCwGBzrolgWJq8OVcMWWDvgYNonJCO2Hqsq0hv6UGXxp2f0BAs0CDkjt
yjjEU3g5iLXwknOT3QVF0LMre2C7b83FAj3zgqe0Xzsol8VhbmyDU8rnLGr6GI64joeGXhbEtObD
QryyJ/wsoqreYzDRF2aDtzjojpSPzOt4VtSfcwnlOwo1DOAuqkpqS1TtcFXTDT9vWOEtSI+egPIX
lUKWB0cgoh+JumgcDtjFBQ99QVjsX+JdcXx2L7BhMjdPrhNVNlg7t66HdAODBNj/V4XDAM+tPbAR
flWPeQgubML0ywxIvhcIJXZsaWFJdPct3o0SEzxdFP6JFI828VtqAjBT9tNo55YIXmh6XsWCSn1D
R28z8daMtj7EScMgFfpoArB+DWAL7hhUEhZL/W9ZjETL0KIGLyy4C/cc2Y0sjSVYz/wK/BawhYAH
JTiGX8IZatnrfvQrVXi8g5HMSdUY6nBxUwspDm5bAMl0ohmzADHPmiRA3OguoTzI+9j26M0js2CD
+NlE3K2Q0/NhY3gahAExdkOjt4D/aio3QLyZy7GLJKtQrZ8KCw6EF3OGWjRLa2DNzr7NKZLOCvWf
3rYIDoYrfSSUVJhYH8tqZdiizNFKzjW/JDLG47EFIWk0b4W5RXAydiiZuron04y3O8bo/yBGh+M7
yPZFI/ZD8bRMhZj0S9vP/btPymN/Mra6vJQ1LCYg5X07Fms6l6vXo/KgRXIXKnfmugu4BeTyqFTg
+XLDYxAYQALSG5YxKOQ5JhyUVYm3hcUJ1fDG6BtOmZK6+dXYmiOhNg2rM80hAhjckNRXSTXxBT4V
rYoEHxK0ZLm9SABk0ddVXCKPNTnXlwHKscGR7poK4cmWQoQvnGIp2NV+ZGn4XqrWG0o4ehuM1X9P
2jFS12AeffDXD8VhlHsz/sTo//IMl1p6E67Rxw//v3LS3p+Q3YHNrdnjjrNBIu6SO4swGFPWXpRo
U3xm/JZ6QSikREW2EZDoa9CrXPJJ3RbBigULKxa+hgxs/oBVPIkmIhc6nRKd/SBPfTXatEiV/Nd7
hpQjF18ZB9hbN65CO05QcRhR2iAX3gszDWndY696CuBvN7gR4EKztK2KCCT3tmd8xJj/fQAE5+qG
xWcqbZi3+0gO0yKJZ0aPRmPyNZUAjIrqugpgB0+P4sCicG9c3ytW0XAzXrWCAcpvxgi/UU6iUPHH
TWHXUy9RMg0481LLRfMFnzsm9gSrrzK2frxthd4GsYVIFyYHaXqKjtVJr/tsSSdAB/FDM7W7ULTt
9wg+b2zuFU6/vFHIxAt97UVQ9Uvta6QD5O/gHpo6mryN2T7nvEy18By9FB3/aijURdCxCakTlxyj
vRZIqadC+f+4v5anKx58bm/UlSgw9TGsGjzNJsQa/7FsUy/OyDKR8TUVIUio/+/ssa3GAEmFLYk4
fCMZsdGE/Hd4Rt6u4Ybu8WjiWzVTRWlZ3Vlcf5x11vZRQVnSiRrl6y6iypRXmbtqNb0hvcvC2JL2
f7Pnk6Z7wmHNcGvZIoIioymQFnJiA5xaBg6KEL8h6BFXmLEOTak7l/5x81AvNMnxCxH6Wt9CP83J
9zu8V8pUl53HWX1TfDANtugLcmb6LvqSBVei3fcsbTK7r9EYUfbWLBm8ehi3e43LsOMeaM7TWe5Q
2IVQJTPLZiBn4Y2OzkQ5R3NHdlvq51wQmjZH7AMNSrjI0frXpzIj8DnG5grZBYzdD0YWmkOjfhs5
ZSk15wm+Otd7UUpn8gGMfsjaoAJVkphMp6uGM06ZUOtPtAtDxbkjeec6eyUE/nI+YwlYc5g6BB5j
4V+bw9bSb4fNHSJnDKOXXjGvGc093PrE25dQr6X1AH1ZuqRXMchgoO1IExzM62jaQsQySoWYx6rS
5/7+e9XyaM+aaqaNfLPyPCG3K8F0XCh8fbYT5+JrPL2kfhAXPcRnotODq3qwZp/FreFncPBhDIkT
VEA9aMAuPC6HsUn3swMnrf4+j1+5/IB+6/VXBwS0zFyP2bK3pxwPb0NPigPMppVuPm/JjP2XiVcD
a9RouQS6BkH49agwOSHToXFafuKJbha0GF/YHPOiEoIEDfS0KkZIMmqEwkx6yoBqyk8DhwH45JVu
ND/yJTn16/z8zL+bCg5qZcRrCiXuhZXwHXaa95ChdWcO4Ng3EqoJgrJMlyuCe8onntFfoYi1rCWK
51QjgiwROWQfS4xgHzL/XkooxiC31d42yFQZGFdYnvAKKmI9FZ5ZVhXZbq77OEcfMEUgB9oI2Cqc
pmOw98h+XD9HN486jGlXHxWKK2OA5l3HE4n7BDUWMzYGV+ucBmxCyRitHvcXtRN8knK2WRZbXFnQ
RbMVaVrpzbYGUR5QCG1ikBvDSeCegCJJWGKADtCyYzSaUoKAEdGT0Y7pQ3+I5yhEC8GuRLPzCq9i
KKyIasO/pGKbLlHMYUKyk7f0vt0x8IEYsm/BC71nCtogmFbicA31+z6leHK+t0MBFR5voUxtsXfX
oZHnV0Uxl/V8GS5HrhqbutsJL6ghzmbSzQiV57/97fIcS3nAbo3EiGYoZ4q3Slmxd2mHMwG5bGZy
u5nBXYnB50rwORXJbhBYRZ/32pZA4qF0SK/6ANkwCHuOI6TB4y+E6l4bENy/LGeOriMJFP8P/3c0
ILa+w5zlfWLprsW3SbWG+935KDaa841DM3x5BsN6cI4SdMc+MplCzV/uAXm88aHqxctYx4ekttaf
tNL93Ciuo2fLtJY3J3wDC5ZFFt0txnYv3LvOiaFWMCBXzRr5VCLwv8EEBFFgl8j1BtIKhV53UFyg
zrNsGSa3bfvcWBnHGZfkKHwH1SC27prC4xjjIJ0C6fBvPOfeNNNIrn+pcw7tRwjUelElzT4/GWkM
80I3rIZk8eADNWr6gjaM9ex+9gR+f9tTbx3AT1SzyFTTwWm+1JvkiKUtd2A2ltiVGIOA3qGJuo0r
o651CrkTMkYQOK4Bc/RA7qbAZc1i4c96Dz1rqdwflxcUjtcB8VPo34Og6jO/FShIBrw7DFgztDjO
rmfP/2qiHkctTI7VIe5ijBqxjcZS+WdXfh8XXM4gqUwTgnRaa8sW9Q0tgIvltUpjqy2aQe7/YSuU
0xOQJc3Q3bNt5iqVZ9/krV0xnVx18vXcxfsPKo4yZphU39Ce01xeS+rADIYsA6jqqp0yAsMNQ1kJ
jEb/urBZGyca9eyHjsgIVqHpOgDqIFUTslM0P5MP5ckvI7EaXAYwMCH1iJLiHZvZtl1rD7urdcZ1
WD0BRQRqaR581HOuvHLoYg0s71O8i1lI2cQYI1CXYd1uH9AGzty9YPk0TEwL5HDVD+AMrC3ewkOp
cCiG1GOhJxVQHwQsi14Mj/EIuAvX+FOKpAlu2td4e60gJ4Vs8cSbkdX+KFMoqXqzKE9Hso4ymZU1
AG7Yga2TxTxXzRBwiriifW363YzX7yJjgk/QNDmgff8paAST5dPUrikZvB30tx3B0j6ifXvVA0a1
DlQV+s5pPlxWCLcvLIx3EkmVLlfHSN8L8ylHIaVZ07lc4ttI8nAemDfx4YfKJHOowtS8UzJ4Fqh3
steZvW038eUP+RZzh/h7rdwtg0TUmMWW3OCQehyIly+PV9djFJ2a8beFUESepquPUC0k+LIK7u93
mps4s5/pzdRMqjxVII3qtzJlLEAuVeaBvDMUREcJ8wtbp2/xUXc/Mj9sXx9BhNmx1QhD/6jbWsN7
oGZyQQVt+4jvSnDGPGw2FrJHl1hIjUphC3UH5e1XAv2YOt0ZjgbUW6OyatlmjN9VLNbJNddLdZ/q
Vdo6g1w5WkjvXT5+t/bYcGpMRkiH6ioDhr5pTbLuI7p9BkJ3UCgX+SKALmFVwchN9BQAlfKtJ9Fy
+jVYrhEBH0rpjKfP9oJOlKT2Z7aCc8XY/12rwOvg5ZiEWCi6U/3nZhqcTM+S4pQ72NOyZpX3G1kj
CUCuAMGh9jt6rEC31fhClWYmr7H2qxYjfaizJjIBRB6/+W2V4LqrRvUfnxNq+TXdnZV1F28VvaSg
/U9R8AgWKXObNVP6zCv8hCNHDWfRRQn/Y2cuK/ZqZ1qLKYxLefCAXwP9Qkpg4zlGt+G/eIsTswbA
djkLVaOYD2XpxS9VuVf0PhlAhOESLpSKVJfFCfyEaUoGXIpybkbya1B+QJtGsaWHk3Vu+Izrw9jF
rArwOYVIM1W2oD432pT5M+NOThkopb9uWO0Tk0k5DtzxFaH4AQIV2IlLowHaLBT0iehJjfzkvjmH
YD1HwP0ov8sfKpRsEsW7zNdbss67C9bHrixaXrv0wLxUu2ZzbqtZ7mtnV8yxEDi5szAAH57N2A8I
fnUx+5NK4WIrZ0qbdNYUslUjcXHrpN35zrTrEO2d68zWTzHWB6afgnbnRvXf54tbftQkNW+8byKQ
LAlmI2fyMQTzrAxT1smuAlCcHkV5UhYDaYtM66e9wDYJ9nQ9KOc3bYBmpZDdW8KuTsPt1B4YebQo
LOOxUYy2SPV9H96Sp9Mmvx/A/+uMJspSXPIxibTQiuSXgyyCjHaQfnJ87aL+PWjbgplenQs85V0S
ldqQJxE2hBG7Tav4o3D/tkeLdCgfP2UeImTGyCYLAphGC/he7pkKjYnK6zBR+MEwWo5EP8uWzS/6
v6izKcKcEDaUBgke6lpu4u/8RLogtLwJ3xG0xSXXN1dLizjpqf4wxNupgOPWYX2MHXnCjw09p/Av
oItYG3C0X5SVT6cGmsMLE8QqtSQJBYVk+iWb9f2B5q2k6gCVCaWxG0zNLM8x9zAG7OjiBTZupmD/
nDClKYAMc+Gk9UWdaTIbvdYk5sVRltRFIcx8swa7dPF1KAVbx12HBMv3abG5yhK0b6+3oslpcsuT
Gn7o/DqqzfGCD5lWKDriZPRk713y9w3MhkXbY0jrHGirydBzdxHyvvsH5XDY8EKfiSvO3tPjG4nv
VliMNOYQiDzolFb2uDDn2phjYKyUkkbLt8tz31bNmY1DvqhKEfzhAs1pTXdpZCwpESptULpSDyFK
u0RMPAEfoXKbtKxc1FvIqNc+2mnYRddET4zwacLGjnUEzFg9BVlDHK1XKtpJ5uBlfzNp2FCWTzNm
6qd+DnerLekXPnlhx9m2+6nRAANn7DdL2SoWQweG1XSx4+oummdA2ezwKFaC8yfPaIKlHg2ixWc2
MxQEsYmOJshDohlHdY5LMFbeJt+sMrxq2ClRtD/Fb92+PqTu+TJCmaKL7+TxvMa0XoBJaiCxrEAF
Y1/F1c3R/fl6QiyvlBu5OOqXHbGM4EHwcAm3TOM3Kcs8hO8mRJoBFwaFtG2nacdNrAHXS4qGsL5l
LmF0dIUNev26z5Fww5IN9kKuagyr2S5ag48TtMMgZlM8qqFXb/86INmcVP7wzwPwB4WcnAvWcKrA
8cDDXrOHu+bZEcA0GoXvkhZ/uPgEjNtma3XGSflWW2Gpo9GHjNziu+36nbCrjPL2HQwMPFZvb1kF
Ap9JbtofeumR1jO3TPV9sk9T2plOAf3zOuHrgZIHcYCohwdJ1DMA40wKGb+5w++S8mHVe2KNP6bV
Y1KInN6n7qb89sgkM4GkBYZs/X+S3k0KVwGD9U2GAiVXKsz5gnRptCupFtT4BhNFXSbbOr51rAZ0
G24fD6mH3guqPlLaQlI3/dpbq9oH4O3ll/V5I/C+gcvQ0apB2M1ikpj1o4zMdIaS8qFQ32NMMmtf
ZMqaoGOp/IPrYNHB+O/Bwav0x+ouEehdQn2MoYJShjG43yxIJ0CNfHHAunx1GOtiQgO5f2SA9alW
pguhplVbLHIyJpUKSsJJ0U6bRsiA4exyK9YWHbmUZ5ueLBy0PBqB5+0Wg4mSax5QnsbqlCRmyIfJ
oxLZBdUkCgJS2N1yj8UbbvbWeRSqSvwVQR9YIUtmxPKv/PFVVf/p6uCyMVazXZgnU6Q0TZJiqI/J
+k5349e8l4XflALru/3aMU6URsCT+cREZJBO3Zw1JbbVi194qtL3bn/UVaD4UIb2qtXXcrquM5Ts
cmM4Ce1M6LlWuW/sZLQelFZI+TgXKKqmaqKAON/YcFY4+iyzjoAoE8TJF3foyo0HabaB8GycVHHA
4NwYREfG+a91m6PBgtvSfyHRcZUz42C1aAy8rj9AWyqt2M/CmD4fqYRDLVy39UOk8Z5Iubtt+Dk5
FWDVP98WEkmf/cGwX5d/TVExqeu4qh9V07pskzlGbZMpYUgggw3uG+rwo9SoLdXgG1QBsORRB99B
oJ+6YZ7f64MqctlaWyivuB2VkgeUMQBiRxUGFIJuoEXsQVLjYc+XGwsA40TiOColPPjP8wthhygB
rndB37wGgGDNK8DhuldgifZuuoZ/pDm6UcH6nAHs5/Cw9dK3iJI8xGR7qlq3+Z2lxP5tI3xg4gYg
wgHrQ9hDb9Z2k3cHeUMR1Dtf6Lu0fxwTbF4vPkXBAtegn8o/FVwc70gTefEE9xLb9kb9SB8Jhuej
azyc8ezse1LC7snslxmkAJDvAmvZJ290DvBlINTRUXC/9bv9LHBb7n0DsYH8ZFLP5yXPv5otHpvh
gc1evHGWAZVcTCr3157MNzbZX1rvxDOnl8DwyqLX/66t14tpBC7YIUwg+zqCV9FqSePNsd6u4Asr
mAIW5UQKRYE043N+wHuKDCWo8y4jvPnRC2AneCmNt50IHU7Oj21gvkShe2WBNc4fnX8iT2SB3fMz
yIx5ihcZGiViHpyZisv8WXpmwSSTFoYhd7dAXrqRWNwfVjxMDOG743gt/gRP0glxZyxLPihjMpKk
IuMX5EzQ7mV1n+sNgOcpnuZ6GavDmRb3f3b8q0z3SppYQ9EeWrWvXyOKX+h/m2YE0Zf3SywDGE1a
GmnnehoqeVnJEavHZI96+rX2eftC4k1tB20t87GVmpwkBZXsRD0OdcI7XvhNBGqeyAV4cYOMASX5
M1s+zGTzLISgAdCbGeXTujdcawO7CcYw2oecaycNzm+Ux66eN0V0ZO5dGB68dz3Y2uJVsOmmN0BJ
BPcataqZ7qlclSeANZ9ybM73BerCWDEIFZaSd2d/83rMba8ns8jbkr7UDirr8KM0fLf13deJC6QJ
VEOvg3ZQeL2H7ENvmrYM8/uHRtn0lDAWUwgY+qGpvzvrXjXS6gp69F1ezYfv/TrobWxWgLnGqA3n
QumJVq6Uw0D4x0OJ8ixZ+rKwbQmkTB2n1vUKtDjDBfMcPOVGmYMRjGldrZrGeZuWG9GrEOXDbqUD
1pKRfG6br0HxkfwaXMp0cK60W3ApsEdJsMedNeddf0eOIsyqE0krmGD02GqUPHnH06N7mFcIGMFu
zBu07V+MdS0bIBEbvLHan+fveXeNjwsy/AXJ/EvxnL+5brPHzbgiI+XdL97ZHulBMIaJ7zHn6L/e
bo9QAq2+S567CxhZ4/eqoXgHcIGz1JUIQ6aBGVqF2SlXAHK/UpZjjhzg0ciannWpU/NaOWguNcK9
cHfMdoLEygw2eewYLNmfximcN/YvFqM3bmnht5vQLiNqJy70mmAU17AayimkqQuNnWDvOkTXLgvl
Ulsqh8y4aHoslDBaETioL8mroer0fK0+Ocd3EzuL0v/mQkUJzNYGCx6wWK5TLEhc/J+LZ0vlVt/4
5jdzCVd9bSEyDKrOXK2HN4PF53S2pneX+p3l8LflKSjc+/yJIb2G6uf+CMHMz+mwg3UYo793rVYk
/leXlYatLlpVWO1KTc/w9/2Zzjv+Si2cWchOt3TT25DBbKl0Oa8+A3dX2WmqznxF0iPLx3a9MhUZ
ZdZRywgzFL9xcyKdOyL5Odq5xdkr/aYLDO4gNVGmc+iLFrWwbEgYv2VIAD11ysIWY78vSItQ0UKd
R+WDK9+1hFyinFlwtAM/OMLlD5JCjPPLizSSt/UVCCgMhjWyz9+mFGsjZ1seAmRk7/1lkGtdTCH/
z5Rt6Wdvp8NMl/1GeRrXuZY+mXdlZp2xgGljooo/nHIq+saXQRg1L3lwQuvZ4Wf/kpWmRvOYB0Dw
N7e+Q+iIjMjS3BnXhptXPhSEs9UNYmz8m6I5ASNcXHMf90+wX3S8m6dJm3NfUEoHcmHK3irDHdRJ
3uJrL1iLJqFbsax/HBslMnsMfWujKoLXCDTMCt9eK7yCGD8UvxbW6VJV6mtu+MpvLCz7qhpECOOw
UJkmcSvZe382vTU+5NGfir+yRFNjrJT9FNyFvoaCHmi6uceP3ol8JVIZj4p/S4GPVcs2sgZU1tsv
rOh8mTEWV61CaPdcgiUROnDaX/FNV2nPyYIj/77FPqAXZ2swBrj4uGy3djSHnSAmThb7pEwljg3t
wwL4SbxMB9BdKS6B6sWJyzsrFiLVgxlqP8o2jyuwobfJxBnwZ/Ni7RuROMFW1xj/yxweTcjb6S54
BEPPr3YtQ1Xc7VVAPj2TJPjUbL5GxbDK+Sh/9FNdPA40Sb9zuCmPN9pALEb50bW1DGwJ3OvErDEq
uUxR3ByX33bP4Z+MAtZXjLGqFsSJ3vhDBpdODJQ0YFl8FbpRqbZ1Si/tZjZVkx5yiDL/VNhM1L3d
QA20uOq2yZ9RI6bFb00Zuwl2aulbEjEbv0BdeFVt4D/zxZCyAackH98yt0h0aBB3eKT0xOSuCQEo
wo8MVLbLj8hE1Gn2lL16NDFA+bZfIllZPR2O6quYEgZCCMZHHIcsFgmFYq5meOxTQ6s5APk+tgC7
GOIEVo4JCameEoLsaa82n9HsLR6gt4eIDaxgf/F4P1TXHR8d2tDqVLGMev4Us2RcymCWy9CHHLl5
1+tDZjkxd1bx01P3ECtzQ4PGUeC+md48WDUKSDpcSaRMRJpbqozx8WTU4ET1nFDTezWHneUsiY/x
lgC1gWszpNapqOTXBtL5GpAW+NOCObUoy4/6mGD0Kk/logJjr9ggrOG8PEuHszfxYtUjcp+q0iXh
5GDxYGz7rdkwXdzet0YhL4x5wrK/2P+yJ3SJiW7NE9qvj34yR17TMG4QQZrOPrqI1zPnuOCCArhy
eGAPV3Z2IqGhVXyH0arA5R6brewPXSt5BVMa7eRJn4Cqpc9LSbJdAJU4JIKcT/KSUXbKw4cHyugc
5dAXI2Uk9cE6Dh32NVKiZOPV0BytnrzDCO2AF3bhGpa10kqXuupTq3N2DxSSKOhKUniPRsvnc9Ii
crCtADc6DxHblLMX9g6KlTuoFowqxLGmWF9NxgOTexTbZ0T6zsMI5R90A41379NP07ku9zutF/Ge
A76PXKXmBcGP4fhZTfnNlQUi5FRXSa3hHxA6r0wgRfSx1Yy9qZnQ5AOz16qnfBz2C70AoKNPqUgS
1aV39tbQezo+cCKDYKHi4i3bEhKT1/IrKkNSLP4+nGWZ07uv2sI8fEJlHN5wYqZKynQuQZEtpkYt
LLcwPwnBG/t6pt/7nJLlRXSzhVnIkT1z+OFIRaCnhM5q0/aHp/8dIlxU5NZx7uFZ4ltXV7ubjHBN
svdAE0uPfgvLH3wh2bZwDSLg3WUJZ2E3/HuRNNX069v6NyAY0LCugzcu06PgOUcCvq7Y7mAvaeFM
cxDz0jZxsqWC3YPPNGUzIi+B2puA+dn1WRqAsz7XraNgxjJxOGVE27t8bxyqrXfxDtVjEAqnBVQc
aWAO+2GGk3oLhtXDjeCasB7X7FZqbCKNuFumihxM2YRET6ywoizVpSlqpY7NH4+xp2P3MchfxbYU
GrHGRQhBK1zT+Ql9mgmJcM1MDfmkwPtBeqXRau+tcQcK9b88EqJUna1BiFnHQD100g2CnU4drJtv
umWXmLTC436O/AfXcuO27gDrrJ+O4w5b+JeEJIk6zt+C0JujiT8PW/5JKdijmBq8R90aaDkg38zz
YEHTLfoH30J4IFBbG8XLX6QBW8qUgN+zAld/FOJ2/G1TUUaEa5SwRgnLuIXT1bAz7p7LgE2DJOIi
cH1ZKgOdswcVVHhq7JbewLsraPkCTKOM5xZc3RhTQEOgewK0yRtk1+0YT6dJy5NkddauYgcZcV91
jTqI1PEKsLaF3UpJZxyFAX7tUaFNwL8XU+vu5hc/rB8ccWOY658Ra82+xz9NeuKlcOh41T/CVIaQ
Smvih8kIS8NFE9z0mWuzBRX45aXZZZNeZhGHkOcmXP2KbINEc/bziTnozJL8L45G0dZrdk+llRGM
y/VfdQn4pi7eWFNZVHsasa1DaC3si/C5oNAqlI6ciblIstOwjOJU/WKgHnSLGsIuDTzgiG1WqwaT
F1pJM1K8vB0tmQfX/ujkIbwktiXa22XQ8R7itj8ptQipnw+t8sgOtYLVBrh9XizcFhGDpPVNJiXz
RfGy1PhkgfvbMygCpybz86sOI5q2cNnMUTA+Ib29wkF5+pBk12X5v1Ay302CUaB8FxjY7AQri+pp
zUtWBtOgKiMCfnVhgBhsVeFKGtcdMgBAL1ADzR3s1UpVJ+2tj2iCZQodgKkM7sImsZ8vR+t1qfuw
0JIws4c4gk7LJL9q+/FX6IMKJmeRU5VeWrFUrJg6qEhqoCuDd94m8EuAJJyZw/ykyk19aBIMFm6m
9GGTCF1QI1zfUAuvaZJhXte3p0lcmUPJy/dBcY4PQfFF7JHl5Ep85qcrzJ8g5OFTBfSsOSjS4qMr
9nuFMNd/S9Ph+0/FLMOVGu0ytgijFhljTLIBBfksQU5XIpPqka/5i+wGFeIX/BCYf2TNjXDELTZh
G8XL9UEtYZxgCgUJnuiZ7Lp35UoMiuOH0uOpgatav9oTDCYu8BghJ7TmNkcGKsaLF9To+opCPdkA
9AvE8mInRh8SZxdMNnE9gahOgMYGU/2P5qQbecvfKE+2u5MBB069hAiHD2V9yxWLoICGhS1hW0qA
RZBki83UB2Wbk1Bara5KyEKYko3snTRkVVWnlSNrNgJWQXUu9iwCw70aICV2EBIW2tf8/bmyzptc
XHel8iNRmNLquFDEBK+g8E33lJ69Bnbeu84Q6cWGMqH1zPJ8q8+vC+GGh8ntMU/sWmmNRfuFeRTg
IMKdfOt6uSi9/7Yjaey+a9+b/HVgKnGpzlgE6VmWKiOevkndt4mXCIs1TVWeTYAfTGZJK1fak4OC
7FK4dh/mo0Icd4WQe7KL4apGm7HpGj1538lngvoG4xXVXn05AzD0zW5ChkKYNFLTi5UJKgibaZFa
KgwIuGOEtlPUbKb2XN90WW0/bR79DjXLSuhReIJr8G7wAuNNlCLWiS+v7A14ej+0iF/mpkQawJql
w9zlJD1zKyqPedaSbBsrFNMqllGQULI/daoQFo6iw0IynBmyNkC6THn3cfLs84lCKXeA9wnVO2qQ
PLRaJoIg0VnmY+mxSyOROfR6yaEZKTnElQWi3q6OSty6AEg9bdJqumrMb+OnxZNrtipcVhhURkVh
76sx1NNbPnhSmDTKvBWBaZnHbcrrb1pIy+ay0KboEn68pZ1SJZaZruZ1HZHVsv3vA8h+PJh5Qq4M
H6k9NgiAGiUhU/RYobA5ysJPeCFIpEg3JHznYvWE1XNQo0zOdEJPyC5GffA7X6ymR9pyK4zzT4d4
Y0C7nvb43OYSqTHacNYsMBLcwjVD5RGVFqOlV4GwIjB898CEYXcxAdqv+nZ+zJifyoTvy0w6KLER
N/Fl5wffFNX8OiTCEfqjyaPukOWI6/IHbcL1eHtCmSg+U60RZbC4kZqMS81gePA/k+srlk3duasR
7amaL0nghW+es4GAmMqlgT09J49Amz2g6CgTjdaTR/u2QnoBp0UQjVdR5yfHYvwSCDQ0pq9jUNAd
4JE6gGSKuoJQ8gHwbcBbsJPRUJmBsg9cZVhDe8wMgnSQuOK/dZleuZDzth3pk7g1JfyeaH7E4Cha
J+NXFAljy7uCvQ1HXmOlndRiH2lXd/lP0KNOB33ziJeIkCqOm+/rw10/+A9EkM5ULvmEQ8aj+7yT
6gFDXdFmxxRYVv8ZsgfvhTj8ts5rZnCrWBmlp3uT3nDX/HN0TP+zUHbW5kNDOL5uOa7ISHgnKQAt
3F/OdxUjwouKofZwABVZSt/ArMc2pj/jrq8A5KETLE1wgWzv7rKYp+FWR7tyDThBK4bGn7FZGsl1
j0HOsvAZguUrBm4CZ68gDbOUsG2pI3D1QrcUSaNERzX5M9C6bmgrelmy4VMn0UZYYDWNUiqLriRJ
mhq4Nr1FCG3KzvpTwc0lYz/sbXbAG6SiSNCe8KJGtI8VgLtTM1N+RG6m0wfYTqndFoG7mjkioUe3
i8yNdyZm6lBE0KEFqjH8jnaBJ4aDs7/76N1GFVin63HfzNR6MwEAuTppp8i2/7YvYfDMMUlaRYSZ
v4u/ZJq+Rb8+MHeC1vDYsrMHEzeE8u43LLO8BwWDyErNIAkivvN4ZF9JVZ6kY9nndJRZjOhyoVkn
BaVy3IRvL9CJ0B79kbJ1waWCcbJUVjJ2U2AB6v3xpE6QUPox+WsuR8KE8qEITfDzpjCHUd88GeUF
sGIbbd9wjEPN1+p9YMr8BVRL86zV9VOtKLGLW4NwDajgqhACbtWTrx/TbfYUAErle5Xa8pbojjmr
wK47Ypm29j8kwCFcI9MqpAYppYYeuQEkd5pENOfofpHr80sOoeaEVjGRvMo3rBT9Abb27mw/FTGl
NquVNoRjPlazCVzLDPxRhxyBzYVEgtnwwDx9IeQ2Ut4tRkAHlUfli+BnW4AokQzRg9Fu5dWukLNg
+Cp1IfIML1rzKb7YDMri4hYjmWusWGERFxCEpi8qjPyqnQN04Y6kOXiP7rf9qLA3JdgWmnZptqxQ
oLxIieoLlVnilFukU5TAs/o6oTx7C3mfaoLB4rNLoG2uNFLJH+iXsOXNxg3tfDHUfHdE/HPSDk47
S+zqcz7JK/S+viCAnpIO+8WDSnqQXQlAidqt2JGAbN5utYZoHgyOWIWOtTqoDBHNnCPM7Ud8srZv
OyhN8XKaNCC9Q5Ri4XsEJaAzt+vzthU9x1Whh2HH/XGQbuG4eOl9vBIz0mwKe3sD6A+dvTYVYM3x
QM9H5Q+7SOHm5JjSvtcZhVBM4LXnDlHfvkiTfgApsbpZIhBglPQ6MaZp7vu62TB/ofwaYyFgGycH
f1rfm0q+MK7G57obqNbcyezxRq/zcu6h+/iZLnEHsbUngswnWCeTc+ZY4ckdyXyks1V2tCeHi60h
ll/F4sW7d4/KxH5KYSD0ekH1OcKx/y69+du4+rEaXTVMwa4L7Rj4nGLM1D/45De5WlQyeeZtfcpB
B3ZSXugWcV5KsSF2sGAW6S2yzi+9EeBtcU5kGn2UBQIh9IPJVsueoHKW+DSqsOZkm+vOYERs0Zrv
i+t+679Nca0Z+Svq/eUmVnHaq6zSUsFEJWOt7XHhP6LiBH6MQk1ZKmh6iTKS6o47JILyCvqGpaEj
t8SYDEyvsvA52AkZ6O6EDwsAbEWUj6A0E3TZiNNzn88QaeOnhK8YzxDVsfwrLxRSj2uL5wde1bft
4xx7TAFSnWnV34pqtJjAJi5wIVCaAHNfwG+tPWOBP8uQUNhQK1xxDzVVVbRPsslQCcKCCzceSLaB
i1XhJWbwFjRYLwsqHGlCf+BA1PMCdEix/vAcbTTX574/1qTITwztfePs5OqicuiVcWQ5N4/tSaC8
fwF9xErGhgmsbGRYvVYwVGinfbbEaTQEA6UWmgZo9NZ1N+KY5X2WajRl5qHmHYdWCkKJG0zT/ZcA
+m8186Bj/ToOp8LYfK5PgJf50hW003KvJFnWryuzH0q1TGogNZojd7TpJCs0WHnKbpvup1F/vK4C
ok4qw8crI/VZqKB1+DJ5FUfDHSKdLY5W9ILuUff5AJagrPqLUYypwxTf8nzbRTdAw5EUyXnBFm7P
5mgfa5xoLFaqYskGHojhiWKXERdVEloVc0JNfNT29uXNTCYoy+W2D4SIofsg/2vBKjiSu4BT8neu
1FvtvECrKJatYRJHI2o2E5uz2LAmdRvpDF1Nzh3fbtgGvf+oIuUDOJIdJNdQNl/42+5ZI6N6QXvM
ahUyYUYe5XigoM+2VtpmJeCbA2m/luYwBIQnnCYv69J6TvYG4Gv0Xd9lrQy/BsgDCwmtI9AAik3Z
CXidGB2cufB3U+NCVe/xFhTaieEO+XpmnSkAZJR9IUO5Vvx3NUcYxaZR3jPller4aqajz++oEw+c
2oVDD1eovXwecNIcPbihGJldwOM9m2SIabU+yxo8ZEQ5lWXmclEzxlkoH7+qqKGc/0q2hfY2ney7
8UIN/tztduASSpm/4cyNAfnnN7CmJzYhRm6UXAtj6O6MoiQ0pKS3klkMhlSK7TUQyb3eqw/U71jm
hwQ8+27dq6vFZuPvrRVzyKQcWCyefBxKcD4L73iTBL94F1MxTxS0GvCFpkU70xMikG+6AagDAuTM
vtPUwmQ997coGCWWXK6agoWJf93o7KPEtWhd4eKUwXxwwhxXct+jSF9XBs32F92ua3ERH9cxPhuj
djM8yqPBJFI/TPNIbzUNlFzT/uLVr6Btl0U6pwQ0Ko6nanfDReIlxTSN9do8ggNnWv0EDmTpsO8l
j8+70ZaE5CowZ+w1vb+jN/IVbQd5cG7epyy/NlzvcgT5ythqQWagbfRCjHAeL90aqFesMnw/kK10
1oEYHOqls7nYG7Xcw3+P2JIAWBLU5Z2VsE9aB+gNZjcVAt8J1rf/Uu5phzM/kYssrYEpwwPON+kj
PYJv5SWqCDJ2oqZQFJ6lqKoosBA+2nIs/+Z74DvvpKK6w+sk/Vq/5X9OU/4N69WkDsUohdqNRnJu
AUmxHDKwTYsqzrABV/FrhQvm15KMbEp6GUFQyD483JmglraC3/CtYGZdorE6+yFysXVNmXKoyY1W
Y5+GoxDiKqZ5kN84uA+IqeqASFYXeMJs0RTyZpmdSwOXRF7n/oF21T517nzxoCvAa0+TvNwOfgRF
jXoNPcDfi8v5QTs/jA2t4rSxNTaxXjmkHzrSZmEUXmL97Hr898ttG3NcECa9FMhu80fzwb5JclmV
zUTx0+hUhK7XjQu/X8r0n7yp4odgkNlghQ97RwEsYLwfFnPnGffr9PBz/nDgwBKjhQ0FJSSNKoi5
F5awuMmOFVVvoScV9PxqlyLYdYAUEmIiOSwatY4hYdTXmVwWw1kXN0NEpKBvuGKFhXdjADLUqxGz
Hd9r+E+hWwpU25q45Zx5uQbTXWS/cM6ollTuBuCmKZUFQhHOqjl4y7Hyo822XLklGNYoatqTlRaV
8Z4vcLFGpIDEqVIK5ZQ7KHrzE27YFZFKUrrf54DgCY+FVEpmUXQAN48xZcqFmkPSnM0x1L9t9x66
weHa8lWUZukpuMIkp9OBWyxrIE27u4kB23GeoHnA8FY5/Bo7kL1bHT6A9YHLBerGh2A1FQK5760i
/nzGJACBLzM3+sceK9msUQpaXOXyHriq1IuZCQt2XgoGRiqI1EpKhf+aKDsQDAVuOrym7jo8VJaj
P/B15y8PjEShthxDL1nk/7hU2RELaXkfbL8vshg1hp9qWCltw3Hll25nj1MhB2FEomY0zrWeERD5
FLjiypsdqsHFPOJ0TmaGWiqYl66LbE9gwujlzPllgM3TzK2k1WlG39u9Iv2A2Gt40oDNO2mIzaww
MtcV8/t/WI43xQURNW6BLUJaveZ3+wqmkYbg2d8w1NisNyl+HOWbZHXJ/LZFy0vTI6WJCF9XJe8x
eXCcTiOTr2oDOsAweHHfedfhOUBgUt+3BdcSpVQus2aXh7DR2GPxCtVYILpa41NdSf78cdUnZ8go
p+li5n2D0/ScIkCPIVQmcaHJTx/MtJqw9Fb70JogHA3wIwXx1zKlDo+cH8wJBvPPj5ApLiRoBcAi
zEct/scA8ibnDKx99+KgRGTL5FUy92c+XGuw4UYo5uO9QA22eZIFI9GzU56LxsM56jySCyAAEFcA
mOVrX+LlqK3Pg6c2wutIpwBUZrDR+pEgjKXnrxgOaZdewAeGlvlT8WHLPc+GAaT8HKZjewUYcQWm
26teqGav+gOr+7owmiAY8JIuJ/tow+8VB95VOKKYhmcRJml8qCFTyzACDn+dQSM438P4lmVC4/UK
sfmyLQFtH/BWWAA6imF6bZrbBTfKPwuFO0IgtU78V6Abw3qUDWmrx250/e+Gt5lMoZOSHrL2R5pF
wfYIlW6IOgcvNZuZCQPAQ77NJ7oZdlAigr7VbLuwcpt1yoxj3BJCE3pZMaZRmIgUOkIvKqze+PVr
iJEDUHxpvJcBM+dw3l9IBiFIgY7+qv4Gv6BJWZh8zNzZJOAAagKVuhEYglsyC1TS1WrNLsnxRN6I
l0M2faK6e/6RrEoVoqAgoqqRgVUG5tG84k4AJFjNn+0SyPxZA1zYXjscZvmM0e5Eyf6YmF05RAiV
5Bqm7TXjtE84F14dLPc97jkoqXyngb7g0vsFUwbI0tblA6PJYDkgsvjpzHko8uo4nqn02N1Y7LfY
7sob9PN+YTE2cVNnI7ggfXoRFYhO4LiLoJ0zfJYfk1rsInyqJOUw69WUP6S/Nw4F0M4KJKLim+Re
ECiIQvNrJeOzna9B/ugOl5nvtT6igwK1V0TDTQDk4sVNz7Jip9+kySpL0OhaUUlxP7RDdx33HSrk
rPgE08gD3R+xeFhMqoVo9/3C7IcRYn0bx/9ejqIJ467lwRwLGDWf8rIFHqta5VwCvQn31QwLZRA+
jV7hh93oUbjEkaCOIi+hoEo4QqqHTdIFS9YbgR6Kf8AD57LFu3Z9DjTylrbtr7GupPiZwW6lCvtS
1ZhxVyfVqjaQ9TaNke7vqD7kE+/Lyc7KGmndmg2VvJ6VlEB0btng/ULbtAZi0qdRH5ii3UJDO6uv
b8hDsaYBTPHgqQNLABZcq0KJYaqHFALmx38pqlhBcQuznOVZ2pcIHkUuQEWDuHdhWrdgZiT1VIXc
ylQMMY+zyuY1CZYppouDwKOt4iHIBTU8ZKoSGhuXxh7BQvgB6n1q2W8NNsrbnaxd1I7jqtyFHYlk
XcAlzGqh+O4mqDSGhAwOA7JoX1LZNikdTtdnWxipyhjLqTtUdSmtp2mrUkjNqjexZy0RgT5qRdVU
1OoEt7MKQGRgzM67PmVOrrwp1Cux7l2lFIniArK3X189Izvn0BkBxiYudltvrMBDWrh0xVQR+dyS
EfkNJfO3+p2qJxjJrmXuH/S9qheL69aXHQFN+CgsUhSKo/ALGx9gxjcwUF2yeWWLk4WomLi5XqcN
r97J6/jHltAOvxEe4jJzlvu9BtvT9reMPBwz4tjF5StsOtsSKSPOujET5qSmk35uSDlSmS2x+vAz
CGdXb1E6OraoQV3iEW45XWTP46NNLHE6SYXYZ5rvlVCupi19Uerf2vGp8K6naz+D+H6CdRbbxSBl
dMoEP3GPBUkA7+UP/ZFAtFUNXJHp3tDQKxoxjNfPKo6J3gBJ7BbBB9oUmBiWLlv74pYnvKTYXvkN
l0zEjq/2VLbbFhOlKPHah51cJ2piwMSM1EJJEX7yCEltpbx17xmlitvEDZnWC6N+4g5mRdGSeZSR
2h3v8zbvbzfiUj7/Nx8RD4s9TCoHe0tWUP2uLtAbSF/erbpG81jBuMfTv8Z1x90YuJtdBOcoJhlR
yhsuOydcGiFCUXplRNk7SGqfmLUfz0EHwnPAQe5V+gX+Pn7nafh0Z3XiBBdZwVz88W2W1XPqGQY8
V0MgLbZAJ6Sj+rVlMs9e9iV26yaYvflY7H5b78V6d0/dV3HBphAEFD8utT0RTSCpVkPMckg0dDUU
lmgzvMG0mFQue5DnVJ/HwRlvFmpkpdzJiOZOvZvt/KttTitFnoHsnfhiaT8kTmd3LI3GsFm8cnqW
9BtCaFFu+7rGFGoQzei7P0RnA+y4jlYA4CDbvp/PTH57BBKozQbMs2hhwLwSZxqL+NN7oDw//VRj
Fk80vdw2zb34qBh17686akk8YPpVgZHSKZDEJIVYxwe1WWCxhVLvro17e1lnEiOO/P6dkkVW9vKS
iEQeIlFlc9tuoP9eJv4+uuZlJKQLLwoQaS8BeB08njaxo+A3+TXVBUCkLMinDK74d7TVYVmPa+xt
GFUuXAT/9yoWiqw6yK32fW8Wu+hKVDbiauAhk6NmkTz+H8XtI06daaXhGCH6NPFDj+WhmDdpPzeP
sBgQ2xqU7vO2jJxu+9tekhOveqlLfUaLbgchLo6zpCLpeBNkzeD1XEB/LRZHgb8qd9ujBHt85mJb
wu0HRKdtKzG5wsRt509dO57SWuGjmS8radaEHmQlmPihGH3+SMujMskw9ONbimYq5qYzVoU4lqzN
SbjDtACdfLlUPsPKipC4Gel6enUFHRTF29RTYy2+d8+7+bb/Hj0bSHF6tbeoefCZ5Nl8cOusLVDk
FwWQEERefy+vramwZhxWWOBQNxUlqSP8WMZSJIY0NVu5/BNUlg+XGnwrG3lGBSv7qUSc+wgMVZtR
wV8R0T3t7mrmoPTvYCm1l6Qe3SiYUx5O1QywHBEH2VzW4bXsMPGS9kFO7zlgJygCSTUVvANDQzwT
Ee5okHlKfANPX9Ki2At53L6B6Q8c2qof9UzMSr/SCcjcZzcqmJLSyDykgqfMSnLa29p8k7bMwxEX
nbcfxZBMZmR7/72KSmK0GIHEG6y15bSaxJFN8xyGMT23zvyLNh4hiRwIwuxnl2QSqFbg/VepYYoX
H5x/FVyb9ny9tsly8hw+xmQDNvk2MGgUVov/v6NZFrtzqdea7Z7lMAmekA2uAEPABzZzj+C7Uo4A
W5He3S/m6y5zSUqRzU6V39ylEYhaaHgNjRQ4/9XyCMget9UsN/JQ8tzEY1yNJKAjXefneI6Ro2Ph
GmmzgWm+hXohXQ2YtjFavgYWH3g0eEIkdQVO/z7yYYoeedIEvWjG8auMJYgpKmMu4xVZsmQQpvv4
XRqUCOVuR+4AOtS6ahibuNXlG27klB/Ps0SftAYVB32GlE22Spjms/GckTZKkzVV2qWSl49D4Lh4
B1Ina5JO+Hab+v6d66evcTCjDnm3s/edZ31wPX3XaO2BxA+lgsBS9syNaXfiYSGHBeKR/Lc0vwFM
7HXXUq+QdzResEpioSStgkixijrgJwuyHSKXpeO9PjgTU+tpxSAui49pJ8oYMj+Qeq/ScaDuWjNp
7doDDCxzSIlxGT/qymWNgzD8YjTXdS6SiqU2S6A/YeaMe9iTBseMd1TytCc6KlS3xjA2mYmLK6KL
yGAETPjLUd5vsYdaHEB/GpOEQ8ERsnME8KltGIvhzJrOTHw2qTrGCkhd7AlSE0PTfgIWizKEQ0iK
FtUqNhEegsGuT9G0AoIsTg8N5bTW3X6NyCXI+F4DcqYadGjObZXfgD/8b2EJGXPw7/96sSocJqdl
iuFquI0qJG38KO/Ekd0RIKb7ErFElWlsn3m2i9IVQ/pi5ACEaTWsRb0i3j4W5HerdePNk45djBTL
H4i0k1J5R0No97+VZLzjfsJk/yfNGwomdd9enddWoOjUVE0KdYcecaYZwUL7PeWCL+aXs3DczTzR
uw+uKEBUL6ARtF0DvJg2SnRUOuyqV24b3T+rbCK6fkBtmFRmW07z+LNU1/CFHgTmlxtyOtM8IZ74
mNx/FW+HuV6MmDFpS4bBqVsEsobFqSddH4i/Hb3mh2W9McQELql+Ma5GAiGsy79i2XP0IhrfxcFH
Yp50RH+pEC+rJ5uw+gCDx5XRZd27Lpopigv7QKdyd1Q3bw6q1ELqB8Pm11/xYneGqFSOQVyHce+U
XqOcTVvkGb7J3VQ4ECYozOo+8giMFc0CF7DbUN2grtwtiUFy+ya94vuYaNdCeEBxkJvDUMRT2AJk
wMZa6PnKiMPYXJNazyz4yqLgIPkpmywvdmAGcgLUUlnkubEARMw05k5AvtSHeTaqhwl9IHr5G3Me
XiK1k8LhpzNuwDtWhMQLsor/pDR0QHKh+NbslMslC7COYrTW+/HABpo+16f3ZxeVX2B117iTkQXk
QF3bllaCGnkyjU5dJp2+3raUpFUxDhnBCf2Hf8Fzl4LzshheXGyVyfMzxmh+/hfr11drh9uVYgKt
E4PxMrgoCx5oUoJsNArny18AwV0oerQBdutlAZsMDsRWvPUb9oiSMBnHM8gTYFFgMqq0kTN1QhJ0
IbNEV1m8v4gMEAHDzLTVDDu3IZGiqjq3pRG3BzXef/d0EW6c4eiGQkEUQ52V1y/0lvZKQYKSzmH5
lQ8p1e4KAZ+uCtd/a7oO/U5VJ4ZUWZ1jchgZWn78ZQj/Uc6J4L/ibgIfjcLRAj//B2LX8259B8E4
t7kYqv+owvJvBLAl6r+Chw2fODCDKq5HOVxPlZ/ReU2yRCxd7K4r0YGA7+hWPeF88eJ2JysZrJrw
50Ltf9OoCHA6X/UNKyYCEDSNR4z+3UMpD9tUq/5sXiCXw9Trhjq08w7XsVtyPLESCszv3jF++Xyv
/oyObsmXr5l575QCUyLSNSuoEEJH/QQEjJ34L3kApcR10o9fbDujoxbX1zQkg3qG1pLdwQ/uWOya
HoF4HYG3fn32PKgm+eAppQ7reo1gFZAyFYhV5g29st//N7OBvvKtH/Egk2fvZJtgWYMmJepJc2uR
C+zUpOqsVOCiRBFX8YlWVHkUhfLRcGAs9+e+N3DNCityNmZ9bm2twdQ8jiU5YGnGJBlgYjyXbqkw
9zwv5JeeoN+e0Ti3FBnocfM9FARlYZauHlLj1NpblsyOVZrGBpED6Y3F5QRiHHkQEc8nQfFHYjI0
App+3ry4OE/wXJIsCtXKOdl8MKI6lvwWmWYceKsBkkcAV4G4MwtryY5BwZwc3wPJ82yun00pNL6h
ZubD80exxHQpr2AMCUAbw1mfvmVDaxYofTRkN68QWMy7GUfhddTnExTtzXvZYCKRiwI5okQYNfhj
0g8VAMx6NR55aW3i4Mh6cPt7c/VCGHE1Xvit2dYsNdjWzpwNjCCtbG3Xi3EUWqezX9cyDsw8mSUU
hExpU299rGNO8LdjCJsn426HRzUVZvTby5G69DA9vLItalQLlEIwFTBmXtjiTc0ulxT9W7N2zuyd
w3tBy5936SuPx+AiRTZOrFK/FXQdrH/gs8OoxIDJkLPkokP1TP/MlsW7m1YvW/mZKFEkl8aADIO2
bTVtIS8qTCUlXNbxXJ4qhqBjo5FA8qxpkIin5qZvlzlwM+3ImiKKjM1FE5Vifw7M0jwX1CJUucWg
9AT2dWXaooKUwi3VIA9jpH4czz6PNdqD88lPXGacX7194BpgYf12W7LMawvrOmWkEU735L04SDuR
XEFNydOXx3nX9ZloFsxga/udoNr4DQnwWGu0JKSGlIkNQBK+PcLrxZUC0LwLrKKKjXkhvyy7Gzsk
ZkH+uHhuhnAWX/oK22LYjSuQysUqrd+TUd3NMqcdoLH1dUp25zdHLGYHi+K97DiaUXcHNpyB/6bc
BpPFdTmd7S/SdDmKjpB2dPsePDzyfcFj71L8lrT6+r27Ec3gz8EMetP+lgJyMbdG0YfDsUlOLTPo
MSRhp26lUpoHPGPLHU3LJcHNjGc2UKRbu0BV0bnu8SlaRGZXVUnHg5yeHadlwRZImEDlgoBQxTfe
9dLf7M11DBuDbBBgyC3FUcF/13STulCvQhL3XXNxE8CkUmBVJaI1ixVqlOZePrKAAzLukIH5bDsp
2v8U5wFjNKZpy73G4rRHrFowikhgMlhAbUaO3EM/9cGadyFyth0OsUTtajTPUwnwue+08PiEtMZE
KkkjttCST8/oGheNNoY3Y3N5Y4YOnU71/oxZ1g6YkNypzBURW1HV+5mO8jfhvlYFlAftbM7df6n6
kEbvyOhGBuNLz0UyCpqCe1XNc6dilTqrhsFug11CR467wOIUmR3lobq2Bi4YzUbbIeJpe4C2yVxy
1UJUDFPcxC/jDWtCmRzXO9TEBbN+VyhlRI1DOFcE/JBrsPpGA2iqusICwpEIepfcNDqVJzMq1VQx
fecyWt/AdnPSyXbrjtHyPi8/7JkAqlPaIBzLqBrp4R0tm94phc33UOIcyyyU0706JDXw++2gQyXY
rfQO2V8CZWki5EINiD1NjHWl8uALKNTVBjYbSKtATW2LQkkF8mGYVfrgYoWbIcq9SpbKmp7nNtps
2fuJjxwYzBFUDG8jS9qjsjuMPqksIV4ZzwmiJo7ZT6l1L3C7RgwlRfRwCgexAJYFdkj5UQGSkL3m
mhT5x+q9lfBrj8IUpZD3RT3ViGlLEU/QCOWvyXu0ERn0Y/ooYbZJvNHniCxJHejfWC9aVVoDf6SA
78C3YWppFzUPCyp0/gQQumIKbIHEHvSYDIS9NMbU36KyBDDciOfa1mB/WJVayJTn7KIJ7DpAbsLe
QeSV7JyPst7dDLWP9+c0e21KLqv+mN74BHCgP6Z6hfS8XqVf+KXca/xgT0iV1WbjxZ0fxwbVactl
JW9epnyi7T1VKRYxiM5y99FXW+UBvUmJmgGE8/viDFWU2PyQmwpC9shh+rIIbk2oiWOODxFYqip0
9hiUG0AcpfutK38YyWqmI4TzCnl7iwLFyOECYQ0GmQvEv4fyrN8VtVNr+FvIdJ8r67/jVsczcely
xS2LuxKNBWLiNZ7WjYIeZnS5BO8jJX7HdDibfzGCNcIht7THYdVu2KiyLtKmvmifNroMAUd+7Z86
qa2d68/xTUk64Uaa+2DZIxTxZJPW/rsrUNTaIOsY4mjEZ8goQwhs5wrhZZuliQ5wlz9W0X8NksMt
pmJWiLjX6IZpXq7zzal+EaLDzBqtIoKSUvoihiSe0i1k0rvIiuEgy2fX8aT+EUmqUBVySrwoa6NM
W5gD0J/ZZiJ1gGxlAYl9RGAIs9jkXPTDYMS8dGP8ENX1aYFD7i/T8gsHF9iO5cnMjG5qDUT4KX2r
Sh6QwfuTA3xG05C4SDq6qMGHFYwRd9pi8ikNmDmrhN+8TpCgpVglwW5MpjRMmgsuwkkkmjX0Jgh1
1U6OUBPgwIXt0o2IKPiLEc124pOTvkmy+LW2BHB4fkaJ67LK0aPtAY73MUnUzaW+TdRulNrPTTkG
pEUTTO2LLKSQS2Nn7rEEoqy83QlJKJFsXPVyO7N/3DDY2WpLolQQD6yRXwnWVHuhaU8NbxW5lXAZ
+Xdk+bW6sgnG1EzjERFD3PB6y5v2puB9+lZnWO+kTMeRDsKRe0QoC80NGKb51RENn1PCXz1CG3DU
FDAM691c0tlgTkdwvWVjBUgb8oHuwXf2RJI0PQy5h/NrzR8FSvsBc9Dq1CDgpwqzNe6av5KSHxHi
plSH17Ox85KSNtnIieBPwUWIbjOOspE5ZLNFd1z7w9LMVO62vuX42JZ02mny1DNvARwzx0q9j+b3
JyDru/BqNqjpCkHWXXlLE+ngT/2U9UM/uXzIkMsb09CG5DguaDNitp+E4rVMNxzxYptW9Kjcnx0b
96YwAZNIz2I3qHxXcijw4uXwuVct1tapVWJQzRDW4ELOpMLMKbnUbzxi1WjuKJ/zixm4UvMS78pi
ovu3aCSYDPyZ6GhrTsK3RKhME7rkH/i7XTPIfi+9ZV5XAkHxTgqb7rxU/G+tYlkpe1RY/QJlK3U0
fN1VF2fay3ojtUC9kOTAj0QLbKNvJKi1wWQ8TaK8QSOy36Si7OQgtt22XazAAssRdNAH4F6b1cAH
fRIu3cKAsza+Pe33aGLpH28zwzEHCW0YVH/bCoOhudjBFJQExaMNqLRMlPuSVscz3mu+g9zWdEpZ
Ez3t+YJToqlnOpZcwLR04xwh28Q6vIA0ONfG0TQEguN2VSspe038cf9jkWbrwRS5t0u726ZChUky
MLiohnVPR8PlxLfQWy6zORYk4F/GQ7iGv8VOIjXHBwQfkxC8dbjT3PVEkIXnJpq+WoJ6lqJgzlDN
eYoQ9jzpWmdOdv2lv49IDHtcyBJRaxXCzm/JCPbL1p/co+Kcg1KDuTI13oWkyY33/Jbgb0zpjZH2
x9Nbsk2+HRW+C1+i/1mug8191DWmWOltfIy+slx/t1Zz8zWPD9o/KdvdNlO4gRgi0snBZ3w+ISEe
jyZ0nVf74XUY32couZwtLOjTTpHgUkO5Cjr+ALClw3KjzgyHaatobqsuzDQiieMZZh0spLq9dy8Z
BkKHmjNcfQdacUYQnTQpuRSXkzKhy8143BLwvfR6Ub03yC+mbzjVlhyjxfV6v5xyLPngf7OLVIhE
n/ZGikCZCwSajs7PnIjXuWv9AnLSZ7s7GyTyPH1erNNoN2oriegtvboRZBKTaxVmUtJnb408EFwx
wSuli8Gp8Gk7h9ES5viMr/er9OIACBc6CaccJkTdC7KiydS41TxXQAnWR/hV7nUtZuhaxmaDeICC
BHvsmop7xqIghDbeOFdiDguDMj18MGmuW6MHph6S6Izc0w48+zpdHz/jDMZtqHabDnCCNKJUJIAh
Vk/dRq5Z+BO2DWic0QDlVBGqT3PNeMBljXCOBzOwzWecqwpmRxM3YSwOfU3AO2MrQmJY7LkwUeAW
FIbvQzPVHQ/dELcfO1NDGkRGDZz+uUEVpQrSUsJT8Sluh7eSpv03IQXwY6nEZHMxz1t+FDOhqI6A
RQoZoBUoOct7YJerKQGVFZfb+it7vEMVbqZMXNmbSEoo1mo3EQRzL4Aku2GxXcaeyovyomHNdsCm
2rFPyDHilaW9h8RMEVMsrGN4C8jcj6z2vyXBfsywx0BbwRYV0pjE6x6gZHLsVMPFIUwm41Gad426
B+rSxx6HBTxfc1nF3yTgp9u1g4HIrDM0xZ3UL0LT80GbDewPvVRfEN528AAtLfYhY79y2TYmtV1x
Zurwbtb6+J3LeS2CL054bcW4STvLRyor6zWMbyS4qBLHjeaWnUHRVxPp4uOnPDumAo1KdIpYwE3r
6TMIwjeSMXb17DpQnpzaK9IMdEHkCOXDmAFskkT3Ika9P9ep+e5V94srotffqgJEPmQXrqtvm6T6
s29QSFYLbaNGAxwBhQyRvORrfXeYjgCF+lkfFyPEnmFaVsa8EftACfLGJ9W2gPp7l+kyOc8Db5xi
XJ3scogRrGvoSsp4x3mO4XsTHPJioNr0Y3Bl40CwsOtfNSl6tXPQ+STV2DXn0y0IWgw1tjgpK3+z
QFsrOx0D2eHD2RQHbTq3Ix6ZSlvaxzQ+H931d0XmPEFAAALhJJ9Vzg2Tr8PWWWNTYGATifBM1rlt
hKqhsLs1UFRYAuJn/a2lFaKDfsz7hn+OdB4kZ3aZnaGW15ivITQUDOOXjmNuNgSzPT3a99z8Jzxt
AyScjwxd1ZQQa7JifFb2tcAfCH9e9anM+ZKOQ0vxaU1cCY+meJzbxO+pIIRJ5iFWuPwzeCvNp8Mw
nrVN7/f8UIE2Bpj+kACynWaFzlYiPyIZJJtM6V127nLNl6XVxyzrsNWzyp6fwNrCRPWV+sWnBRq8
oeuFuzWmYc9Jv+wB8iD6G/Iu8GuQJjFpn7JZbgK01mzRE/Dk7StvuDx7qAuOtc+PK32hWXjcE3lk
j4kPm3TiD7nh38kxhq16b5CcuS9vNWSTp+mSsXsmwVu2IEePbxclehi1bAeyQT5zYaFKSJlK5wnA
SWnqGBrPq/QCK+xocm6dpqlp+d4kty7KK7lOnkgfniiVT6bCQoeEMJ0BureJmdwv52GSMzSrXo0V
aqtoyR9kGaivrfWg83RowHN9kZMAijwCP4gVQDt+YRVtqUNx89kr5c/aGWojHzN6fr/krK8WoI3D
02SWKLaGL/tThD2nD5CTPZjse7xe8OzeRbxt2M79AKSeiTs9PFRr0abJS4/LCVlxo+T1m8wfNf91
BJwJOVFD3JYlCa09R6LkDzati8iX0nWZN8Q0N5mhBftVRqC3YSjptwzfDOwTE/e+PiWn2vGzGlyv
5gE8l3hc5fogvATB43mbbrB6gMzWnIGBHhx63zCk5Q1NFtPSQtxOnRqfV2kfAsUHiAQ53MDI6noQ
+kDA8/dYHwzMFsqP06RN0yr2McztJB0IcmwPlqjP/DH76yasO5BTox4DnRjzueIGJhBshHobnA0m
tRXkOWsKabmQuwcRGMO9N+w/fABehU5OfAi+HTDDNesBntAo4u9ym/BjnGKMZM4YzNN7ugKZOq83
EoBtKwHjTdkcJ+9Gd20Ht2a1+owTflHLdacB/Ro2JtiC1UD35dL/hXvL7pxHwXOWhgkXCFEBbt8P
x7cQsomJ0S5DdekCCxDUks8BwsDLOWnFslHpHstk0tVHpuJwNYoT2U0gt4LsJEqMnfn7xhWuYNkT
BCZPnlFXvDTcEbDaZD0kPLgCCOLkJi5kjikm0RXR+xKz7ukn+5GN6igB+1ulKifoV4ZM2CT7JI77
gJkdY4S5POYQ9Fh2k6A5Rov/VgBGqgHTFgKaRpLCaY8kU5fYy48xw3egXsz1GtB2RCDJ2JeGBtUb
/K1LauHYsoid7yalzGu3dUueSQUxSJdHbeYB9ZsWxlHV7hISTNl3Szs3coT/J0lFlIT98fdHG/Su
ZfYwlLms6uAC9JYrnIDKjarmi6i9dinBYAiLZqaMfktxojFeR2V9NTpJwmOfFfyDkAlmgTwob8mq
UnaGHst80T5PVgPGmNN2QZshefIQiR/41zjv3NYm9gDcoJwaF650PKkyps4o/+GYmp4u7kZV0s1W
PWE1qDCuoPO+ctbMcEBAGLggWxP4YDDRCURgyLKxIigowZf7K4x3Fex8juI3DC6bcE00mVnF8k7I
km4Dsu/5BVQpDw/MlUJftnl3XzH/lhtud92zrStLcLfeRs+jubx6ZurTsGwNvai5PuCPban3ptZj
QfAOwisFTqFskJmY1NaUXAhrxkv7SpRXMWeusrBenbKfabuoxJ7OgNiUTvaaZAQb1Mft7UgSgOUK
f8OeRGqaLmsC/D9unm5K1N3h6QBuRlA3xTsIgaC+PhqmTdreyvC/sWcaOAizBFWAQrrUg0sJ+1zb
azOz66Wl8LJmNuuUFBbUqPZJdMU4x7OsaClzZF1c5Qoehfcog++TsgWuNvh2fcEA2RJ56mh/iU+8
tx8LLKTidziBMwxrh2y67HP8YR+AbU2DZqcGDoPG1D0YJLBm/UngNa16icNiFQpuE20VJCVun/Z1
PTlZwT3IWj9s6ZWww5QK5fQMhe8c0sg9D6H7OCwtgpiRpO7NYQH4D9MYrVkpnOwq8wGLcsN9ycs2
GR24phAKXbejy7jeRbFqNcTbN/CFYK9+LG8Gg8hN5JaaJSSAx8sK4VeKWQhqWKMrLaSTgBlJza5K
12uVqao0LSFxeItFJqL05RbbmjPJZA59myW8QU6h+7icP1YWtJCEKJsGX7142kOUo5BZVKU0F5NH
/pyCTibNvWVIoHFWQXdgbeAao3ExSFd6P+fIkSClCPV1Z6bc2HvpXuDrudbwIkEejQtKEEeRcy9R
/xld7yXIYT3+bNPxoVizMWfvFAAzGkZ5Oc+AaYpi1KS78hPQhfVS9TtN33tlT47Zd+zeZw1sg/ci
9tkvXen1LkedJy0q9WrC4vqBZOR/xI+UHMikfzPblLzrl1oGDRUhv8MIPumFnxED9dx8cNNDjZS2
CzjogVs+Fh6myKMDKhovqSunoUEnX0GYjjGcoW2oFRYaXDrOwPh+OwbkER1LZlVMPDYm2FnYE8t5
IUZciGGYySb8kxftFJJgv4lJ8zRlWpea0WDbysxdNcHbCG7F1EmyB7yBzFRxL4EFxmWtcKHWtna7
60QYheG/QBXP+1+ZN9TNzXcw8tzbOE9YoXF7tZnKyOL88EfzwojBGs9dqyopYROc2gJcFNvn/b+0
U9+hwU485j0nHPmvTivRNXKRYb02SVITyimFVp9fhN4jsodq+bdqO5TqDlEs777Ttn6X3nRpFedf
t2ioREGUFivE5bp06Ej0X19i6baHtI/++Mku4wARukVYyKry4iKnSsA4maHcE7GBI1tHeR2nWaZY
0c6OGLC97srWmYyS2NM4k/+FPvMvmv5BfZNjwNXxyz0JDH0JHT9EdrpKtIOGq3leEgExGkrmBpT4
a9IGuOnQcg8YikvakS0YDEpRYBmjLiX1I3GI81mbP5EzCiAbTpCDdcEtyH3PpQH3DfrYo5mINN+h
5BV1kj14Plasq4P0uqbiWDFHxJLYlHwTwxVLAQfPcNAlGuaySaBPO+7OLVTkxYq6ttKzjOsFcBee
BMTOxW/4SF7gwgjb3YxCOpreiamf8pCCWYmauq0u/TUY3dDozG78xPO0CUkD/rA//UV4+zP6CMsw
/KzeeKtqCdMcASe976eG4gy/ErFhHnc+w8VjmJ6Z7w47zZlpDSi2LoJlPqTEnBXsKWQfpEt+Ou5G
YnG1fNwCyDCUAR/4NtcN9IugO5qqIYpaYVlyUzx/Yg/cqjh2pRdB+tt5jSyWiiq5uVeZc3B4/Gfb
MhnzWIfBd6MSd4SlljJVIlxyBbyAkisLCpsS9QRNu9MrqZEKd+ruHt6dc3tzSuirK6Fw9/srzzrI
wP90OlkrQnFBHeEhx84P7UAL/IX9imerfi7C0LNtCfT4gXgjAAqjdDk8Bm+ev4+ij+FfSgZ3rVDg
mX9tKDkbE2RI6M3ysh2VlXlN9Il549PcPhwsbWlDnYqIvvUdHW+DJoOk0F1EJ9qJmguFMwkMOb7y
CLOOCsJ61AUMbHZKAUqsi6j5synpOTk+UnSc/twzCxH+f+hX+Y42LSOZK9VQSmGc49g3kYMzeX49
7MARjK3DhCA3BDCuKqj0qZQDeTC45Mlm/kPyCd9G2jTK2LxxyWpdyRWMKC4WPfE7NifxHixcKQrI
ARv0Hhwe7RXL/Vm2WpAw9lui+TvZTSpsFGKpkq72ciGOx71q7TcMzNGZE2xCVltM2TV2QXn7sW8Y
bd3kKLsNUceg55RdFZeMIxyeGcs0dmed4UdZxeByAQ5J9GtslI4mxmT4fwYwuKzzzgd8dNOrqqu8
iG/rtMd3VxBCZixb2g5j3AAOCARs54TYmMfVzlPQc22VXAIQimfNeM/0GJHtHouOzDDT+MF5cTM0
5qKMoxjAiyvHlLZuscGz63nhxahSqoSdqaVoVgl2lgNqQ1obxbw+VIFUCZGvIl3bgu/EfUexjhw3
4JXqjYv1dJ4+VsGF+s5st3FxenzHrrxpgzqT6WmhZpd2hlVw8ALTKq2pw76GAq9ufWkL5uUlUOmj
nyhRKFCj2Bi3EfewoO+1OZ8dO4QVHXX+sFZAFXKd5ySEf8dd8UIVM2IumyDaY+K5AV4IkT7v/Nfs
3oOj17CJkN1v6TgigcokhYMxHCWU3HN9ape18eCZaW9t0n2qqpexVV/uiVoKL6PVookhNjLZT0ie
4K0Pp2j6/d7tMwUtOTGTG3r1Kg6WojA67ZtNmJ69sZDTUp6Cbmvyg4Ct2d76vjB60S7QQxQiV9SK
l9djUaICYWW3bowitWnoFrnI/fErAqAP+eRHNjX76fIpOqbV3BCSc/FnP30sxiRL1IGg+eaX5Tcw
vCc/3CIryT72gCYiuXdo/MEDsBIFjnBTipPzT7zDZ+MjYg8YJE0suHmkq177UxQRbFHImDh4kLbH
opBY45fi5KEbZgOYEzRqxl29y50t1eUijyNA4e26bLogPsAYv0Wg07fhN/3Ob5nb/plLsnGINVsJ
cs0YrwlASZ2WUkC+hrT/sBFSH3xr8nNwXZFHnuG4lG5PUDEkBqP48WoRAG1aulk2WcTDuqv+lkFU
SHM6v9x2oE1lPH7BToo64zs8p1wzY1qbezQlLevEbIaAsi4oHWnDlkf3DWWxy+2YNMMG/6cjI8AQ
9wa8CEjufLLiFp4M7NW26SbD4bYBPrDRY7FzjhRko/PpooUuU8+Hwt/Q9Jt7+ske5RIqyy800aMt
pomMigFiAYTyg2XGqEBF5x+gLutY8hKf3B6pB+aWCClJG7tJ9Igb85znK5g3uUiso09H2CqWoFRu
VLzvSDEsvnwmOjeqjtX/2RSm7yPT+P5gm0zV1sJvKsIwkKy07AIBQ8HFmbFRlQi5ve8w4bWPWRWz
UOlsGRKArsRsD3mmOsiyFmLvNq3g/MK+U+B+l5kn6xGbc/QMIj4QJU9PY9LJzc20+iZlaBTKX+we
bmd4CKcZdBhIty4L3kj6JKnApi8wLw9cpaCcGRRRLRhgj+RYAByL2FgHRqufYNyahW6NaIiEAJAQ
+1QG95lfG92oFvC4XMlMShOCa/Z8LT2SISHfJ2iSludSPb/qAyYR5jV1pEBxT1bHby16MXvpgOqC
NeNgNhKz846KNCK54hQ8orXhuXByHVKW5wdBPjAWaFpTrzMf85Q/d4b0idigYll0oTyXy1/6yFZB
szPes7GIPl9Jle5rOPME9yF3ejSF/36cMpnCIwNlcNlQ0//JaZo+HBRLZIXoYFcj0N9oCpxsooD+
AJKMcfYHqx0qBPuyhMdrYItoE9rNbnibKie1mVYonlC2gqTA7cH3YgF29r6qwzS0feBExCQ9I15x
VcfGf/DqsXL7PKQzxBRYZ6o0HLKiR4c7Gtq55rYigf1tDQQgRhOvYHkwyWD1cHvDx0uLQr/Roofe
a03w1gmexAtyl5+/q5idl4GVdYAFwSgKWMlAAG9o1Ye6vdCkmDAPFND++KbvEjiQksvWSl2E6heu
KjP9ODXEy0NI77lrjV5BeiUZrl6XABQsEUTPU8RYsMJnhoJaAfBlnBx0lWRM6i+yyTuaZXTzjSfR
DgjT5CIM05qMRc2iixW5/fxAEne9QnEgMeCsW7k3tBtoO4ox9AQml+r/aebiVXACF21ebN4Yak1D
T610YPOYAWKlVhn4H4buXyelTKQ0SEpGTxFTNXBqjfvDOUo+Q+BfR8sX/0DW0Na/vV9xcFLYN7zA
0OOn4ipHw0gnG1ysj7xvnKJwX6GpAZItROnp6LcgvawsKVfo2+uCRD+nZAjxn/1dxnHxPjC01hMh
7cj0Ht9yYO7TFzq05VxVXwQFFyEIumsHc7DJgkQZzxVCYPjaL4Ua/uEnkCkPv5/LoBavO0o09k9W
i1R9Y2WJu5YGcsxYwO06/kRbq/anBLqOHF5pQVD0LJbGQNq1Ox0kf5+kvaUYVR/39Sgy3bqizvE7
hvfi/rPLis3A3y0HPOOklOQ1M7HpR+PngqjZlIyOmiKpJR0VFUSWqksl9zmqTLaD2Wf0msKDTvvL
0D7KkLNCG3y7YlykldU3QD8yi1ioL7CsESQ033U8pTXtu6SVL7ykJtppcEf2GRiwdQMXXhzmjZdg
HDAIz0YsdAiSNohvfnMdfa7rp766K4F2kxqAQIQjGs6mJqFYNZS8PYPBzwVCRT54z6yNe8XLCq6M
icjSzfhEv7kbk0KiSbDYFDzgOdLpjWQ+9JfVj1bWLFscI10clEfghvd4upMX+h7/czyKVp7mNOuS
BCVvr2sxA4VwohybLrVKFBBvGvU1MYglcOMbkmP7qdSAzOnDCoH9cUVmb2abRDYJZlPXD6Rfs6Hv
o4CSDx/2aZAsymBBnHZJs0M6KPM9CEbW2A5o9Fj/ARfnjYVIWW/imRB1LS2QTFuBLoo2e4iqLdU5
Hf4FXiILj0Eo3lVP2X7MbAUd5XeGfy5U1bHLTaIkGqMv2N7WKABsdub41fcmJ/dhS9l5gVQnuUcs
NySWulES6Z32wiWK6kHRJs08U4ttv9HBsod43ZFJh9Un2/vDFcCXmtSjxnclH4l2abvz3ASs2F5H
ILWwA3I+bfNhuwWWOidMY/lwXjtPjK0PTAYgpi0PgUEfFVyqE/XJWyNBRaGGWlzxe5sinmkivCjU
M1I/f97tMz6VT31/8qk11ny/WU1FLuxm1C6Dw5Foq2jfSFBVUhlr6JlNlZps84n2bIiTl7nbiMmb
C7DynKT09RVWhHnEPK5KyefZ1/1HMNBA9PmEHRtN9S1yNbZHyL4dKyla6uvwTvbYLBy0UdwjNU9E
JC1lY6cqKvUnMOmDsVhjD+CHT/9w30+MsEcsC4bpDJXgfEEN2WcNdk4TmNoB3WU6De4a+hFNPTxF
wDH5dvKuh1/LEpFzG7zsOQER92B4rPOVzU52va87+gxgOg0xOwG2fESoCjvPVD2iMhqsFifEEGvY
DMnrXsBIM0UCeFqpzjDZ8eFbs3pqj6m7TwOgU3/OBjQvzyWXLLTOPsIx8LfvLmDR/MfjI31OYWQV
TJB7ACFpkFrT8TeQGuf8ntBAx5Os657+S0RpYDE/nS/YEt/o5D2d5fDNXI3/RjksJxL8wuYQ4CiN
v+zBYN/Ui/7OCABk5omdP4t7TIPGaSP9XGot4X6NRU1F+aJdYx2OD1qs3eMH1Z9GXKq6DVlXPBH0
xmqgnwFyVIjbHv7H5GCv0bVMDgGvai5GPzHEwVQjvPqPozoazczDjY4YQ2CdZfaCTT5MAnSgnVFF
cLnTFQuLeTH62ZTjHKBbULfoHDZDqhJQm6Kk6UNzY0IvxWDmlFfcnMMT++RJsKSas5ePGarW1aVk
r7Xu3mjw77Yi+5BG0GKetfX8oYCcNnp1Kyvge+IBexIcUi8DpVI3VipP3GlOlvHJZt+ycXIY6b9M
5vUX1IC+heCORd8wb9ZNohGx5tDF11mMX7XxYpO2vZUhl8MIxknP5eYMiQTjYN9fR0tDEaF/06Jd
Gr/P+ouOCoQXaHQ9DUW4B9ghCcSf/GmEgNipVPgSWeJHZqs11jX72tcouDRGED6hM0KDWLi9eIMG
MTpc3ywHJHrduFeUX1/t7UEfC1jsvNAEKAxyk/IqiuZp9jb+YMzyio9G3x0qB5RMq+T/M+5A9goJ
mCpdCghAZOGL8NnEW3bg/eCCh+VbEfndGypKRf640Oz24AwCC7bq5+KRtgPnMa60J3HtZBK11sX8
IV9KBH02wmLj5nOcYTFz0Q/gi7dNYibjzV4AUgENX17cEsF6SThgAgDkoJygIgSz3VOO9m6u5cAL
qi5AS/5CQbEMnnvM/1hExgfND05nhQXnngHkOm4ngoIkC7E7hn7UISf9p6uP4MF+0FqpvR7twgFJ
srL2HYwPBIjH4XPhFQiULa8um9hd4yKUOX+sri9qwT6OYNRwHJ7fqObvu+VYoptKsoGJeHoyS2jC
51dcX9LJclKgOy8WDMaQrv8Q3SDQ5ahtCf0t6JvGDjYW+0cqQ71U5RZZt5VgXoqqQyLdIqcan+tV
UPyXV5ABd3VX90oo09xaRzOEUkJBxFAYsebebTaSF+wuyN6B9fbBnPMwWyif6iNEJ2oSCS6wnwVl
J5WTIMse2Nz5CRulksPtPld+BMF9fmerXa3PrB7VFOoCIisIe1/g7ZsxrWgxqp3fqHpKA6ZifMw7
pv9BPMGWEim/fuPIYH7XFmHPfu14mbSs9ENaM4LBm+GoQeBC+FNNFNr4X8DjVSfRF9S6KnDVMtVp
/sZSJaL0BKGxaOweIIpihrnAjzn2nA74s77eC/qy1i92onoZRf4rQgt1Oq3sn0/YjrMSde4GrC+M
u2MH/fr99UI1cCW/IZRAGmg/nhf1T4Opei9oPMZbDa9qG0206y1a/R+/JrqqTeGhxcNNP6eQOYj+
dySsYho/L8AoiOgRXulj67isxDphc2g4a1G0Hg95sWwrvMMiDYLlPL9O+pI0OCYcn87eX4/JBPkd
umHEwtV2thwHftsa+DV2J8NDbYa0knZSsfWh791uIdTQoZrKvO8D+55LLgE2uiy8+NR3z8cBRVBL
W4OTGjTd4tAj0P1Yf4pO+xFxXQdUxGXsFrkt7FeRKsPQt2b+G4tBaH76++XCueWAwOQqe5NMUtlV
s+QZFnKmjeVyNTjZEnsIgEXu0qDsajuI46e9n2jhOQb4xUxqstWN8n/fZF3sPHYwA/LkWQ9BnW3H
NYCpEVTW9ty1vTyaCibomLheDJPwXg2PsvVuZHwi2nzyGwvAei+WLXgiyOtJ59mwaAFXtsx47AyM
KcpeeRKC0lmKTo5dSpraS/kV0Fmf2e7KezDC7HEtOMVWBsmJBRV3XyCp7n9iwRloUqgcORfhekoH
CCyLnMJ6FO9hP8X85e0kZUWku8SQArfN/DeeOxOJsU7JE45B8VZwVd7W7GyW462h+H9kaOwdPs3r
RZr3981+JFyBI4O06c/52Ag3k29RlO8wO6ZXi+zuVyEsHkUINMt5tVqEBFMoOgLdd1H21lM7YlPM
0dLsFfR0R4sGwtngrTKwGJT6AIXpPlLFTjIegsO4Tcbdexi5/Wck5AmYxXl1oldEdOMMYSNdK1du
+tXo2QFsJFRMSqpMgbw0PrLdIqV51pNHEYuyhvwNZMNupTdY8J14upf55mTpuRXPLvAcl0OSdP6J
rIX+aXb8PF5CUxsIudiVIKPfC6BEGoSq1hC7bw22FNFTrrlo97/qeLs+uokTLjXEH7RA3IEJ43hk
wSd8+Ld64Tfm+W/lqXxN8c83YvP3sJM3ajF3F0swVFnTp1rPpb0wXsmGdhRy2YMd9/1RDjlGrxeb
RxZjB6VxkWMv1hrKsZmAlk/GC3+KfppQ5AdoNYoHp3SqXOUE9GZzstCv6gR9+/bIat9xTGtEzjkt
9SB0H2HK7ZWISxckrUisJ7AK32t0ojaRK5uPfaxVI0OtenbvbkyT8AMjqi7tcM55sWnJyrULRWlk
cwcJlLsYRtjt/k03JCxi2BMwgjnI9/YeUQYJ1nubvn9Y0kEOZMXM3+UUa2Ufa3p5KgA9K0oCyQnO
t09FI2GTnAkAxxKjPXqDw6x3v1FFze9moPKOx0CXCiY+sH8Q63nAxG6uDaNsscfK7zV6kH+1+5c6
3fAGQjmM05dMHI+LwGUmy7RZKMegol3/22TLJlyVmrTO9mQTyk9vetN4TQ+O//s7zkemqdKt8Op3
/+hOtGPeyZTuCOXUpE/Oh8DU6di4ci5aDk4aAxN3MXeasfsDCRDQRujUVNJ9zKFnP5Gv8ogP/wkw
5ZstOcmMkzw9i21XlEfyjJj8anK/QCTwlsv/apolKKq1TE4OIh93kybOWXlGzOLDIUl+RK7mSw4K
bTNyMzjz1AL//LUiyE31fApaXgZ6FnjSey1aerZOgK6HDoJGVdh3ToM62sQCiQrbqRMctY34jxrV
T5V4gSld1Nd0Go9n2Zbp+GMeZ9UPU+FFpdQG0INpVFfmQcX7NvEXceWiCzYn5zJGQEQ5y1JaAICR
SvR4v9cBL5PlcXHHW288LWR+8Aqmc4VVeB92mQ6bnbXJtT4N1gWnTTPyLwbhu9jQbmOJZU7X4RCh
7mUw4JclSLHS1PxIpFuT5ITzRSy05r5JRhlze/3JTX4CZN3Ai6w1SlCAyEQPS2Z3yUaquNjCf8ir
2o7O5nv6XlkAZrwsQHnnyOTbZ2iT99rs8ZqirGIP3FVe3SJpvpmPxnFeIHv2KwfyAjD2awLqO8JN
CopXbg8Ou0PvekJ97Y1pTdLhxDFE8VpcR8HNknuQh3LD1SnwpLV1xGwTpuTleEmDY/qo6HKig19e
pBv19TXWvPcl6KaIJyT0MTOElMARYA392Gde4/J7Rsgpqw+0mlJ/MgRELOfbwzVYA7Yd9rDpmoQ5
XvU8116bFhntCdK6GftUW/TI9VREIZVMgl0IbPNk0neUwIyURToAhROmqO6O+YIME5oOF0Kyh3xX
R6Xx8VZD3Tt92nCDi6bIPLDEU1OHmcNMvMHomp3svgxMjWJIuaSbTS36XdaAaF2GYXgmfX8ijcm8
7wjoxQTHZQXnhpaGdpCkQhkfGJ1wu9qSN8mKLMDwUYNbBaluBY+WEHZ8oSL0WQ+A8MH5V2CWP5iL
bJsJhTfE90RGCnc22afNXRJFdeNVAoXj47ZzFUeQXYE4hUCrMAI05wd5WMDGZmarq0g8OVBJ/tdf
7TMOLUOtP3ol2HyiN21L1FEhXGo6zva+jHxOacp8p/L6xbt9aUK5HeGLvAiTV8YCcCraxdM0FjXC
WRFf76cdrtXb/2ZVGIIG2Yf1bjUNtmzn4vUN2SYsaXgbAsyK2j67d2vFTvUA0b52VYLWIFpXItND
UANFXZWelleZHHUegcqms4F+23F8BFfz/Vm16JmQIyHTcyh/N+a0JUiVensnq3l2NzU1OguQ2Toi
Rh2fQ0Qorv1kNMU9Q7E+8TFQA8tAB1ipmC61icpXDf3pqcqgAVYexeMHgPygKqQ3YHr3e3xEXanv
p/pZFHgG16f207zi5kES1u+6QuG/IrBN5/BqKqNTpAv5fJr/qAaQdC9iGUlktayP1Vtuk72aO8E7
cp5y3Pg6do6CdwYzW3BMDZztqFSq5fbshvmmXT70MfiZSq1nG/E5ZVEvENqHe+dnZ9xKDT0xY2h4
OBUElw08hRfGFwtTQV/yn8HXOtrJg1IEDBNCcwonC/hjSWZ2rJRIERD4FRnyejgWHMazLrKWdEZ/
47eC2iYeVZ0gYItjdJr/cpCGydt7ISU7AVgCyn+oiW7GitlkL0Xvi0Z7algU2M1Z1bs4tMxr1ZEq
/OHZkNhhKXiIgerWuxNxUeoIaGlxYt7eZ31kQu5OEZFjGZfzo1yXydHx7D5TH5XJsZKaHbKtmaLY
vT3shsk20sqq9aprFsqMa9bQF/UszT2vLUgmlwP85r3gQEwwH8oZRGUSXe87YRA/x1XZDxp4Ad/d
jTq++ol0vrqrQdv7RtVTaO9okMR7PSciOe04yjylMpPMFLed/vpf3A6CKgljdtPcRMH3nAmycaW9
r6fZDm1SJhwRVpIcoDkScqrND0HWpW7VY3BySFVhnAL4T7xVclyAUPHv2L4uEaWq29itLBv2swNo
1QTW7wzBO90WyelP2FJU+Zj/DTIeBRv7o9zR9i5k1zIPHW4Br0bKr7bGy/Ddng/v7vanmmsAbirz
z4r5LmDmtm6im6ILLRbJXvUpZpTv254JBQEelidM2+IucI5xzBn5UAyvyTU6Krbfv4vAWK4LOWRD
gdvsk/NjRLiGae/nofUTToG1onNrmxDCnjvn9QwK0OxY+rNqWb3Ph+dpNBaMyYTTZiRvXeiBBldM
qOE5mzS3hNwLweTTYSmq0zkgt6VnqN36nDuRrrFCWow0b3TK57hNZKHNJ3hrqrjKTulA3ExPHhuk
/a4nF2vZjfoAyRvv/55d3T9koIKVrB6RY/gC9aE9BVYJuJTco10UUtguhsAm9nfNzYHEyR/NZ/41
zHkzAN+OMePU0KYVLaUP6WjYilF1Jqk4u2D6k9DZR5O3WQuYcELoXTYnuhOIQ1LN/khhsE+sOES2
k6nYEZ7VyaaFSKPgDI7ebDfzeJJsi4CHb/Y5Mgx44dPVjGz0pfJCYC++8Zl0G3Oc1HpZY/+EKv+s
kqoo9Y5lgoi1eJnfkyzCXK0K1gabrglhwULAyBKpfvO4LwvmZNta8jjrtSF7a7JxFxC69Vdac1bR
9rgVwYzbUzLY1cIawrFqYvBQbaQ+9/960i0ELryWlNK/LJGUKjQt1XmADy13H4dY4VarLppgggcv
YWOnc+XR54wHYo5joq3EY2xYAY8BiQk4KSRKktBuTUkW5E+1l4Kr2dwELXqM3YXBcHbivCfjpXHW
ypzPd+ItWg8sJs2RNvFZEpMK5XcpqzOnARlBebCMJtmnbyO5vIGzCX0gSCg+Oir1ssUc3I3BNboX
tew6TtMvb9yxLTfEb3A7rwsAL5U5TBVZIbUCYys4e59JXLAvC3P0xuISOWq/aREPaGwmeBHrxnrE
bbtsuLweKJQQCwiklh5hVP5Aifp83O8NPDBjWvKB69qK86L+2591tDf9iTEc7WBOqhAsQg3Uez3f
AFrPacH6O/u8ZuT9yfHn9sOFPWHuaUEVWZr+iNPiv63MbWn71Qdb4dGN6tagcN/wI2sxKdVl1nWM
mmIushtO2a6JvSf3rL98sbli+jsOM4Gb0Zss0qGtXyFx2ZeMiYej+87ML6+rPGZNw8TnwP+w/0J4
aCsjus5XAAPCEmkTnyklyfk0+crQXFp8QMacOKZvZXLxg0cN47ETDl/aEBjUI9FleHHjCrXi95Zt
AiyPnGCn6M9a53kqmO6hGlG7sVZh08U6wAh18YQLWw2eYscRHdptWhGJKeuXinx4X/6xl47UA74y
9NHv5VnqAZdSG2j/rDwSYLgf46JvHslIq/k31NMhsqjMP5YUvjJQ7qmsWAAh+OdGbzPgByNtDMvT
bm4Oq0SzAEAXce0PolyJOpNBpbLIOM7ou4bz/IjxrXxhAE0BNJmDlfXhrUHxuhsZIeZoJIgAuwqi
i4wqkHIiso8MWZYi9TUCMgvTj+ycfMTlQzCPvmY20me8hbhoJUwjr1JM4regFogpBV7Gig6naSIF
8pfbkW62xFyQqnEYXUKQeinzC+KG/h+8JMs1Y5NM3/d1lZrnlawl/H17hW6iGgkPXPbgB38ewkms
M0a0l/WIXUAgR7Xot3Pfa5vnKB+BJQX8APJTF4Is63KWM6QZzJ2b7/hevmb+txnF6zqdG1zXnwnY
v2e42xAvuUE/aInx+iQ5rsllcHlFEQ57PTXEvDnz0NpR/4Mn1v8UR0/yNlrdcoAwQf0B4Mn2IRJ+
gf5v+x6S3cEZYeznMfSdN8ffZiXJU4dbMr1R/AWOFhqbZ6aG9e1BvFShNoiJHgD3pfu/rvtLRLqg
uQNMbF/j1ZA0Cu0t9q5CH1G9xprm7VnAWsP+PsL5LBPtmqGLwCyPTmIfNpARHM4yYBmu2eh49ybx
RkeWqa7hsDQQGX4JwXRb4fFt+7ys42aEgtvP208R4hV3FdGcjC/TuQ1UlRU5jcVcpoTXG9u/IQYS
xVHPwaicJnYqX5FLXmBJqBXll01BxyfY1Re0tZyggkQ0DehPhUWKiy46MTWtjfUpe4fkE+dGKkF6
uCUar5udBTZbT/o+nRi58e18Q452epo/KlCN30tUwpB+4XdM7cPYG2fzIWt/TmGLXUZu0FVdkmmf
4EpXhZMsRrfnXDkEEwM8WeQwnH3+DmvKxnHjMGzxCjSMrTWqZPu/qEgBiln3HAIwA7qXOQ+NZhbx
0EePEgrx7ehh6XU7lYyWQTYdv/uF6Wuqdfs5/t/mkYzs4hR09TpK5kDEA3j2xtxx/0wVaobgepvP
tQutVAEAqNjQL0JTiXf9doCB3j+bEFcE6ZyICC6KENBAPUtGUhtdKawq4oUwdrVCKvKYlNTAkyBn
/rg88GgweAdoNMbl9nOOgKSJnEO4bHesOHHVNTeDRgfOUG4iRoPot24SRaSk3CZqbIG4gffijWsC
jVGkbkm810Lp3zXfC7nllVzBpsVqdh1pkTwEM0mDaTKmQEGXkE6sP9ykb4UY1h+VzUMnC0mZCi9c
bB0ACf4zLAyZlBDbc1dCE483Cps8bsntMVK4Nhdt7Om/Cnk/UvCTUTW+0VptGBGzBTVpP3HcIFnc
wTb/EvlOFXmetsCDlEwstZ8PQeukhri4slm6m7cHM40YeSQQGgT/A5LPgQnTxdA15CXaVVm3TCuD
C93nRzeNeY7GFdtbL3kQ2CtiOQxlt0Q9b3ugd0L6BdpXu5cxggCKZplyjLJdaIfU1j7/2oJdM8C9
R6MDVbGU0iIcKuzzGerB2axzSLtVbIKPuylx2rmcX2lFVBGJL8U5JWarA989tzQszWEGTeBXk0Ue
0df1BsKNz3Rm7hx/eQxS+k/SrhMM5lLd1DQPNLe2u8ntAlQcIIesAWw8A8TxoseGFgUPEX1SE2R4
30qeE6Wm8QW9wEUtjYx58GFqZjIprob9CIELLpWZApRvD19G4rwg/uZxGO0dWZt6QRZBZH0O5ALA
Tsq1eBRj4p+NZGWZN8SY7J5tiBOillqHPUuT8Azyd+COkEephOv3zjzJk//JxRoaOxJT2EBCHVLZ
8Z6BkoiuKNgXRvKrsuTPbK/e8po7rmJPm4YqTLlpS3GgXvJrl1WsBzz8xOJECZUwWipHFay8/IXe
UnGRL1G5KAhHOnTqqKEEN5vufAY3lxF7vIK+kQGqeZ10v12kFTLTbywtmMR6MhJay3PQnBYz17sj
em3yCZjyc7v+94InWkvDkjZ7afI17AHRF2IopchF6vRS/ZVBj9mrjjygmBUBs69OdFX6FAkXD2UN
lq7PvMj3YecduykLZrIdQLC841CrdZiV9NQmx5y+E/faFArQkzUdVN6XvFylP3MJNdkDbo5YMu3G
CqaiT8odj3+y0T4E1gsDXrknvI8Gq9hAKVxe9yKjajRkx9OgfPKJqQZqO6vG9WD5E+oAO5vFQ8kM
uo4dz111vepMZxklyPj7R7TZwAkI1oM4MQ5zC1hNzEUnL1JaTzBLabI50UBhtnDdJddw27eZQs2J
DsLMieZ795dobxeQa8r8FgYMkLOh8ek4TEHTd8qIHEZE4g0PGGkPzewr5A9d0hUwYXEkc7rBclMg
oymXhhPHt/vjyhfIASsmYN3ket+MIklBAmp1Eyur2TdPKa95H2ze3Nx4YjFbHgKOsdyYuAdMFdlq
WxVVpN1rJta9yIvpf7KO34aYlC9NxcNlkwwZjbkxBr9K+RmSKp1aaF7uiIY2FSbSBn0YqDWMAdJQ
dwUggtKs4UeXNVF9gQWXBZHzq3cA4Z/111M3Q9gplTo6fxv4aLVqg086GinaddIBykNKHTsU2ouq
fwgvZ88Nlfw5ymKUXpYFTrVzpGp9YhHLT3/FuBv1U2yasg18pq7u7TjlUWVDTkPX23ANsiYtKJfQ
k4GW2JDwH5T2mgDaCMSfsKwIB7Yd6o/ts4MIWlzVJq0dXcht2DmZUPzlFHnxsQ64k/ivnJ91mmkm
xg9fIWj3vD8/SsBBm2a2DyYKXMB0pfJrGnIcJOLY5+VNafWvhj+JjNbIl/YSYynS7AeDCsN0VsjN
6SEuYGjxZeTi7lCIftBAbCazZX0l26kAI6kyDvtlccq1Q476HiM29YMkNZ5t64zQrx+a2XGRAcdn
uxQ09kkpdYwzaSB7sxE6DCMJ6RpK4IXpY9WLLqxEEqOA3HVlVyFKMWrz+7lAEybwVdY41I2uS6+Z
6JT4xSM+EkVPTwCDJFR4++wAwSfpmZuUrIvqObC0I3sAlCN9QkmanE1KD8LrCkC4x5YTftg4UGGs
bh9ee+eOz9LxnBXeg4z2lvDSi59c2InO44fKlp8Eu38prVlMXiiXbHRV7p3UPOwdti+YYrNsqpkr
eIzjfnjFin+7GjmkgMko1KBHH2pyvDAraUlUofwhTM2NtQ5dmvdIG/dKX7cGSVFR+IFYJUWWEXIZ
XpATCetcpQwSF7av9+4PiKivEsmzoqe/uHsRGggFWeu4tPCkY13V1I8hE9CPWEqbOSLuh09SfeQ3
ISbrUDP3J+9iuTjYId+32AkdTPXc0f4elw99elEMM3CDiey2QnmmL4DXg9C4aogsa3A7A2SzujdU
rA4OgO9dVxdSy01VPAhffZimYeVVgAfMWFJ8lfavsMW2e1r56nkugNjPGWPBBte17v04nvBZ3fTd
j5QC9QSn4UuJZl/kGPsiGJN8IpTreQQEkO167/OgC8detzTt1ZKmAcpWHP/f92Wj4KG4O3PZ5IYs
VlhR6oS5Z632/aJDRx0fkl6k84P++KVu+mSIM+Jx1ewr34GI3pIp0frKbVZ+C+pbtBXxcX8O6I3s
k2c+C9y+zYW8knS4pzhaZnMPuGWdDmVZgE/CopgKeuwVyTakveedIBpcbHBgCAP2t32hGUxGB4AW
n8g47uisvGwrkUquV9pS5ZpYoU2W94OkfSYDhizckMgnTdRV2BECKDQN6BTMzv9zUFYry9c2+qUr
sEjB5sUhUz6VhXS5lcHtXSoPeiAAOBs+oEzBU9hTAOk8d+PWMl3jMp4+Lki0s+DKH89zWzDBupAG
i9IJxRi/BJTF7sUY8FvvFHj3tIgiJyowCSTv903zCR8ZIJrIsz7IvkkUoLy5NJTGeLd/4YbVkaJ/
6e0CuymSUIoXX0veiIQCe/1LZP0twrp+YZc/mJY4mVZHcHDk42QH4S3aXWnxXIPneludbWq+yhbW
tcgsb/l/5s1C6tcPAXdNF3gNgHMdKW9pDHfxeQtrouTTUl8zwP5Yx78oxWfmoRzPTAZtW8dl8Ugy
UUlbsXKaezPkc3Xgrb8axqLTdlEU0P4cFycgULgu6kjG1X8vL+Tut8X2c2P/4RBfFpAcUmrFgbuF
RIUatU2s7H4s5SLNTqSclDZc/zli3iNRwMYz52cOxkI4byfwizEHWvgNKKrl57jMVZJKmVh9AHoe
vSaeGpPgIVXv6BKm7VUHZivyeGs5yXBDLUALofyD2L/Mw5U98aNu64ORhYH04L4uX+8R0bDDnay5
0FXBcdiHvFQZYhqLYC9aVRzEd8beOoPQPh82b+1BlsVLnmWO8fsqwr4k1TtX+rrNHF6JrR2QPxUc
lAIwUIvBWEW8CGmI5pbMEJS7xDVAwOVW9tggcwY7LF0lcOs4fosGj1k2EGzOkpfGgF4aoBiyWf9I
v2OtJQHEwU48rctZ04FUxG+Qmxgm/zK9hjRBI+SIm9xLyPve6hsz9N7+U32t660Gtk4O+bhVtudD
hzbTK+cugd2fo8tVfipeZ/QI0oBpx46cPhMfa5i8XJUwQm6RqfEactkMY4jLZNLTjryWml/qAO6m
ztv9mk/HC0vTuWVvkr7lTkLj5MjCuDQowQw16gpigIzHEpet+CMFz0PyJXQ3dkJ/Nbl0c7D/y9K9
BuCztmyoaCuRCz0/kqTq5ZUq5m2xP5A4cDhvw57gTPDfkb2FiLO0GXBiGnBKkRlkOk2FwmiWnYd6
xL45kEBfp8I7eT6KaCoiDRvKhATa/btEYi+Y/m1aJCKbVv7sQs6UyMFGDJYKGGIpbtVdp+Em9ujR
x2XUM+HQ8eyt15okzNqWd/c3i6HFeUUllfMQ97yxbbQeYylQQJN2VW48xxS4iRqfeOOOuuASvGTF
GAHI+3GCdxpvkE5Jl0INCrJSo7uMbryHyh6XM2qgKAKNTblUR5K35tv6W1AGIBm55eVMaJImDb7K
1bo2sC3sqrp6l2uTyXDy0cqNWCd1JYOmZDBaBenXX1/XVsGMry1xtgNzCcosnGZO5t0EzLcCeEKF
cXWQHHlx4z/k/eBxzaHdknETYNkoqy/6Scst3VqHiOP042QrPN86pAWhannsjf1tWfclfHYI6NkU
rDguKeuSMwDrU+zn+/FkkWzvibfTeLFAH9r6FD1LNCQlgDMtWAPO9P4oWZABrNAm8NyWjGHokaRz
mGZNwu2DwLEj09KIYtklxWP9ZheJEmjp8hLPt7RRoOdZPbXBDKurHk+3yxhMf0lg9oQ3d4p5mzhR
xsTg6KhLAfWr+dkZfWQAkFFsYh0jzQmVbRkzPZuw5IbEHqlLG938+L0iI8tO8qtD8G8r1drIebMx
xX9owXEYXmXiU54zDIO7ZK0LVhcOvOclz6pn0JI1fxWF5b/dOhvDRjhbvYj4pE4VWwBowC92Yxvv
6iHm1ZNrsnYQPqxOTD0CQY3aaZbsTsjblu5BH7fpSqwSlog/6Q1+9+1tjPI4mpVWZl1ubufFRH2N
zPwBkWQVvdzJG+8wmSv+a7kuCLeescvUNO8gKJEJPwH4jo0qFSbESCSc7ECiXU679Ctylz7l1O0q
EkaPVaJWsSSF0WM44xhZ6uKq3JTpKb3hrmBvm0b155t5XKuAZ4tAwo2ZFAS8pTKbL2nFEsTD3wT9
Yp25teRR2rmZ2oxdAr0nH2M9PE1Gv+BgnICAnPEwx9kpkY0oKPmGqx8hUdO0AjYOKYjx2an1YT5d
y+p3A4zqys79Tk0Pv4pH7qH/iAInZz/ttolu94Orz3xtdonZVNRhdSf4/S2Y7YVWEnIoyTu2vUe6
XoOlXPQwcdsgmHtBsAJ+cq+ihHEwdGsKgou6u1n9DVr45Si842c6iPQepYl1FYJi+zKgJlOSlBSa
cErsoRoeMKurssGOwaFp1uBS4fvgM73qJJX7yZFcGwr1pAp5MpVKeA7yPs2S/yhBAKZHP7ChdCFY
yM03pfNZ8PHaaBwwjQHUfs+gcE48YZlzlHuSo8hASZXo6ffp55+tYK/5OFq9hO2q5ScMWsSKYCCn
A7JM/X33EimtccdyB4w6aKvcrKIbRq0bRws4or3GTnmci4KalEOgR/3AvSFY3TmyiyHDHCPnisy/
ZD3TkQ6vzTHAIsFY9qRjN8j1+Uu9AwrxvgZGFZahvQjA35/6oIwZBOP3Lv8JXcWSbRFefHyxoC77
qGvnpUX7eJSrgRvkCEqyRCX2oF2opwik1f6CD+T5A1JvNMR+92BQROSo6eQ2MqAw68ybY8KQH68B
BAvtmUYvcKrm2jxaL1ayjN0Fa9udKh8wEGF6a3s3mMoi0YaNf8PqUTgHHSXr+GpxZ3OCz7oqUSoE
rvWnB9Rd6MjqgL//770KKBakPykits9LYXi5KIcyUYNe3PtEKO73rPOjDatzg5zRinb+Ixm57XNJ
BZlfyJXtRv+K+KNF72CZ2vlJ+bbHZefZhx6zfU+hFsY5LYCKTA76QZOr5bOBuOPi5euQf9cSDYmr
W98i8FvxmDt7hNzqbRZ4mQ+ysvACGZhmNqZj0/CcDdDQ4NVzfQ7pSLZw6sZMKZzrg5wEZ92S0Rtc
ILni4yF0jNykP1HB4nTVqjJPM6UPA9RjqcKQVB9KzCVwsXaxRSaeCGKbmAYQUfCAzVYc1uajxLnH
74V1f1WEUAPDavgkiVIzwBqR7rfS2yIwc7jC1fx0qrFBNCzqER4RLVhv6WPkVXMtKqJXkFZZzMGU
FJODeaqT2pATMoVl6rFUtAii5OsofJRh/y3peRItov+OJFeJ663suFhmhIAC/F21KzT5uwotG6Bc
A9P4TO1MoYTCdpDDTfhtMuGRcsKC3MP1cR297baMkYCgMqEplXJYTAGNf6XnyF2/p2Jpt0C4qmuu
GFgLJC+6aMpbIUICjKxwfOVcJ2wwu4yhrya3Fl/DckB25AitKxx600IA4LLW/8+WMeOOqlfHCtmH
ZI/5GB/sb2xuX7y40C2U2r3FvSiaDWkF3QYj6JYNd27uOTcNrhGedWHE0EU/bLIa93vzu3X+q9zz
rM7O2PZ8jvOYw0Xr0HmbHiYPHraTazuZCZjqrUTPgBlrc3Qz1F5ILDavSmsq5xr0BxbwSwr0Puwz
UMqbQqYyJ8HFgvhCOf4WVVLli1CXAHc3bRbqXAZWz2WT1GsJ8D2JVlFYCm/L6WZtWVVL3xGU0qQx
D7StmhulradaaCPb7OjgYOf2A71sYQZLkHsnmcZmbO8xOTozPlP6DaUIwC8LCrggF89A7h2jqjoE
mgJ717ge/dH2iimc26Ae9kM6jvOsIE/06SHAWeclUFLl1CQZSxK3Nuidw9sq+Jd4ogm58Hodybkb
+U5oeSrJPwgVp3CVBHBo0Y6CLkEHITFvV1hkTnz5z01G6R7FdjsycbewpGwP21Sx2VSkgsN+w34n
7BYxhumlFwub4jbKJwNvcVdgPtQEPf1LG1g6FQOvPwiQ+ODHWcIl8aLhiwfQGbxfoM03M73OTPuN
yqt1wkndb1YWJREhoLiCqZ8LvNiuQiXfVxbJOCK4ASDXZBki9cf/s49krzCOkr/53P8YhOxKdfNn
4SFBfhO6Y9+l9NKIJkdfIs54H4rs52GFrZ6xetdx9FdE0k4kG10ZvUfAzzFv4rAtUs81qPcFv0C8
2kvAKHayiiMlnTD4rrKVQ4h6/2sSO87cjnRRMD0x7ANLAarIeM182JZVrZaYRXoY4K3RDwPT8dM1
Z3k0VQpgux6qPfa2NRqqje5x2/z/lDTm0PD0g4pAKeIZfpaLfruzhWEaSKCpkwPcOup77/h5s+Z6
UzyoTqKjpPKl5RbTmMSrRKxcvYRqhuTiepiD5Z1a70tee4Q9UCPXYZVHQ9I51bV3LAYbGJAO1QgO
SP8kJ6YJlhwU3vYTIeDUvgQOo6Dq6zAO5YkjeUq2+NpvM+AphTABrvJoU4UyV1M0bQI9Dzt9YG54
3JeNH0eXf0nHyVff8iB2rcIzG3hfPgVAqVtAkIM3tXPrlo5VVDcFA9NbMFHRoGl4Yturm0LRpzFS
ToVq70r6VTReFDfKecEWS0Ysv9A62lBdT/nSl/hPC1Ho/trWH9m31EAGrBfczizBQnGbYSHV+ehX
7lPTzqUDj8pdqSJnBDAkLdUjIlQI3WcWxye5zmi4A2S9x7l/f5PqInOUu/3bfIU4EsCDGKOrm0NQ
wCHAv7R5OFeYsqxaH3NOlp+Xx86by9kiSNh8bkWL33oUPIUIk33hK1412ydc21d862eqAqfnblyP
8HY712NVZCdbWTzGuo2kkSNDBuCypMKmtSJyvPDlQVLWMYFrLgWKQQgoqRmmnId6vCkk/QPQfJ4k
HOBM2K7NOgE83Mlmyufnm36vHCjCU04Iyusey4PcTrrKquTWOa0miGS94hBjGS4GuS9spQUFg5yl
JNnl5ntOkk47Tnuz9DAMmSURoFsr6teiS7PvtRFJdCcmUbUYwk085Zi3SsShsAfzyYP9vQuZrgdX
OeCYS6w6ZRwRVLD4gMsyg+2cZ+gxqW+RfTg1l5CHz9pTAeOR1gvTDxXOKS9MlRTiai60dkV+XMwt
yHX53Dti8tgZdQ6vdXViuvlbzCw3/1BXi0fEAtY16GedxTv0/bclmSp/0XUfLJ7ILIzpClEl5QiI
/uqBd97W06HHCSADUr+QZHM9HqJ2DKqf+yGfnjVUlVWT7Tlc+NNXMji37yJxo6+8Z2Tb25jFr9Y0
ZKvI4XpL94JlncYbsIEuLUZZF79P6TUru+JBny8dH55H3ldViOnfDKLgiLpA53vq4YyGKHP+g5Op
wUE/TU20wlKKnIP7oVWxmiEAw/VjrL4QAAdTRINmX8STnjjK/4OnKZ+XOFyC5RO7tUxYz6nHsoes
hWlHkVm68K3PUpjg1BHE4wJ5orUrKFAY+svO5yCbp7fgXdYC4JIT+ztiih09jrKxxms+X5ceOt3t
d3DSH7DWPVMSdzbSgm2oeLBXr0VHi/mxRRT4ivsl6z/p4kfGorXaiUl0OTTS5AiwkDKMCTHG3Ty5
vc0iiCHl7cCfpeLQgqPNDKkVwCpFhlzO6kVugvSOxBULVrnO4MwzGj9mss7MbWDOFD2SZsyfUom0
gBdk0qlKAsO8advf1Q3nl6gSiq5Vy6xSHG9QyWVCPFYENdc+lxiFqwBYEIhkkKLJcH3mScqpEhCT
Ri87U/s/RHCiceL7jrRCmOoAkfDvsSCKCfvyPmcr32YIpiBDeD0BtNxAG/t/N6b99ETyYHoO3QY1
XkjAG5iHY9NyT3OVlAW/76hbCuNVX0QuZLmIoO686vR2/+kFKWbO9hjuK/zetsYJEwdS/t3w0dnj
84zAYnDeKzNtep69RUdwXyRKhG1GO1OFXDaUKq6Lt/zUQbd+OvL2MgiTvIqzwuHr5z7P0h7n+EEu
ACQXcbABp0fjBraGX+WZIMrFBwytkKPOLHu8/DlqjnV6cJS1rOOHwg4QVYAZ8YmCkTeb4LQak0ez
stjcKt1GbRAKc3Cmgf38yuDv2SJRekR+x3XRKW2USrE0nAQYx2txiB3xy3rghB9T3NR68aGLiFcj
T4QOl+WiPG9iaVS7oSiZV3dxjvESwcM7Iz1Wqkczc+u/7xt4b/wLq9KQcynUOB+wqH3gBeYKjG8/
sYTSn3SqWlDa4Fre4e3aGBluB6w3/V9JRD3d1TnenElxmVaDP18hiagZi8MKVNVqEl3W7ScHRMIR
XCofQSmU/Z923EbnSHGFOGuWuN+Aikrg6IKLIHCvKdxuRKdxwro2BNaOC5fjJj5dod/2FDna3IJZ
LIWUkY+KABZY5X0sEp7gbUqje2JecdAZav7ELk6JRHctbK6bfJROqaqa7SAiBSeClLcr0A4kQFqG
OCxIqzHheAIvUO7+UbTzSAGkkiP6iIs4RUAJVLvYFKN4IQwyzC2YvruQFCd8RqcbAKoDvQOgJieS
WqDVvJbjUjlb66lESPig9UCTvx5w3FZ53KE+DixM6O4rhdkZR+rJhWIfw+77W+3G1xiZxlUs4O5k
lCP/I/oYEtn2lWUSfV48rTZoDWIpHZRriWRTPYr31IgUdBxJqT+6z90pLSH/WYPjMOcrvjML+xrd
W7lUx6lbin/sro/hiFVTJ5o6lq9LjvdoalQX8qOsIBPVUBvmm9Itp953hhdIrjh4PkCTMEVDO+j2
O9UoC2R15/hBV94BCWWO6tNni7ldZefSx+j5jg02yDLY8jNr2IbIXcG9EIpyjLYE81dWkbzjPAQ7
NAqM5GK3DxzbRo8o0R1aRSJ7sPDeGb1Sn4zW9zcR1CsmUW1ACqad04vg4ksAe9Jxpk2CH3DsjpKl
8UpUS4SSUybd6afekNT35SxKrd7d/hHrDgR0lbiyRYwPdy1QHTrFa7hfgjpPEfzJ/JAWAwBP4Nyk
Kxfh5abHREUCvMcpzSOobzI09iRatwAGa/KuhguOAtH+chXTTmaWVTInBxx9pbE5GCSYtq3tv2Vc
jHtN9eb2B/bI0ytq05kd5xzW/xCLaIBmcm1qsN8UQTG042p76uQQKDIY3PcoRQvFzcCtNTgOKDe2
SvCcjfQWrF/BhYsVQ8M8KBOlR5dqx/Rc3vQW2tF8+Z/4trL70L3OGPrDxPTa92BSa8/0ahB9Gsrh
FmL7UVmrCNcSY+2n22H3Nag3mXFST+0lBcqNagkE3o6d4mEGApJ74t0TdKbt3J5ETlxcKegVylIO
SqdYCx+JG8GfQHp1PCF1OlrNaiW/YpQiZOa/BC1+tIJIawvTUPXubB7t8RbpM1T2WGjXI/K7kvVm
ElB6pWiFdm4pROf1cWVKo5xtdSk6Zm/BHZw7+Tz6OgPTUecrZz0JuVhR8zlwg0Gjs6yDdaMZyC/G
9P4XYYBDD07pJc0+wsxUPJWk/e90WE1ESMaPCILsGjwiFVyHZtdJg4q1gYzG4K0zdPUFHksin6I3
cWE9VkedDck7x5ejCgc8p8zr7OMTYoVurA1D/6SmWJ7FxGFwi0cK5XwqqRWJOfap5B/3KkkuvId6
gXwcUBrAL7SPqyWD8Jdz0CoIjtmS3lg2Tu7o9WoymU7iKK+hjPTZgD9/2hyV4m60qwfIBwUW09RA
g21qqSrw4Sp4kOcLwBK2TwHPP95nL9UzlfQ1HChi6xUICGLak51f8ezwaC5yA0QTUTceRHHUR0C9
SfldAwombU/+mJ1s7Nw02S/HNJelAL1qv3UVtQ4srmgemF+vUJD1SHA1qnw/bsxOUpCo5S0IwQMb
rOa8i57izRubMf2cpnte5gL5cFJkiGpgcGgcEvMwOTSGu78VSzNUZY9vvsyePaJSqr3SdKqjSQn/
U8WhTUWzTrPI3G0pbOH8WJECyx2hURRQrbFxuJ+S0kl6A7WCrJidzhGG2ST5mTZ4PuWNLRafFOYS
f4KSn01w7pqxlCTR3JDB0/W0F+uppLM3ois1I+kX274ww2P9yDMqkKwt0Bgg94mZihjE4VjUIgD/
y9IprvDizxwA+vZIwWGQYxXIzMiXxzEgNV2RGleNxPQzFKSBi7AV/9FF6plLAKFBmPWHDH9okQZS
DeVioJ/MTV6Vc6HyDvWGKT47pEUTC0vIGjz2kzdAYvmDWg0KLhKG7ydLzLiXFYwgM/L6mc2StLWp
JY4WV4mYNo/ftdTFq+2ut/JxZ4pd2O+4J6KNKrHP97pjoGUS8Ct+kzPja3cX7b+U1YgY2ydjMDq7
1Kt6qVJR7SYlcg6h1+3H8oAq+PVYGKsGZoczsGVgqdtaZpd7ovy7TZW5TCla4c50JTVZl4QgUbbs
K7A+QVLA+ekXqi2ClTTWBa6oN/L2ET1QMewqKffDNxISoAsWgX83CiZCeNbOD2nHzcAqKshVS2qQ
7zy8VmwrE3vlvPZvZSjd6FeP5oQLonPvjWAfEO7e4nkUtjG+8x71kDHzhF+6+l5AW7aajtpx89Q4
we6oenTMi9TXNMOEh5LxF6ADE5ddUs9ASh5hrBbonXK45IeASBeqg/twSQtlwO5pF6gWU2WHIdaC
omtkC+9SqHACOz9JykECgWe9ZTGRurfPTr2VdkWckn3Estxg3UwTTQeYDwcy1N1QcjwPgVwMYZJS
SsDY1hEv/EJnGUag9pbfBZckqguRlj9uOhVq6vpnkzdD1BX5ISN+YrVoSMT9sUD2hCrR8nTmTDHV
JGJHSxN8mr4x4GEy4djQmSX0hnWlHC9EpA6G3CpNFvL4Voae5lLPWxvHhqa/qkYZB5ZQMRNB0OaZ
/PCdG3Im+zyLNzdMIQ6y+bX8/7atJa8oFptk4WspbWkUjwEcgne45Z+RNWyoZh6yXLWAmaxZLjHy
dzTBD4xductTG9wUPTjnUmWcVZ+GS8y7L3IPt1vSpH1XDNhuju6VJ33FI1vYWzxeaAZDX8GyVg4P
hgruDMY2K4nLI3qwK5KZ113FbsgexOztFdLPab3+Jgt6VTH6VUa0z0/GtI9WEBkVqyv6lkHQMIq8
Txk74glmnLxVH6f+OO3gL+PsCdTZqPkCEXIWm2onexua25QMhHcupokygLP8LJIv7bcASU481jxL
2XUw1ofIgdgvLhcbp3yi7op3ptbkVt/+mR6bIbZSoAM1n9Mwlhbhiz5kG6V+IFHaGetadEgSUZMK
4Va3oHc1CGN/Wx/0sR+pQ30Jdii/qP3LriNRrrgioxAtQh1k9IFzfXSF67V1BhepP8onBiXjzSuy
gtWgquWWiGFeQaMbN58OlZqfG5OLgcfPjiEo2rB5e8QT/BgeOF2koJViVHfy+bTqU/VkGDuVo/EH
JIUznNBgYPU3Dv9edHG4Afz96BtrwQoPXbsPB0B9mtpPUrCsh97JtNDcXmYEeV3+SV1ypZKsO8G1
KBbEcbrjrD4qXpQ73VjgfLMgXPw1YQClUS9sEW2Z8vFJ6LO+h3d5v18626UU+R3TCvnkjj0RcGeu
rwRwpaLxuCZHImW5FGnHNcjNREsUfftSnmvZHs/L3GlcG2AAznYYdpP+Jl9bLBN9zeToewSVw4aa
cxpvBDrqNbEUQIh1XvU8e7BmIyemfnnennCVn5ADtM7ndqHk9sNSTHjXM9ZHZodGeEGsHfnDlZbZ
LRm0K3n9Ki+vLbrIuc4Mjp5StxZZv4YzRg2cHiVQsdM44dKxJcWYFO3eJxHIyBWLFEPxbmS+orib
2ZywV0s3mtmVKEUq/pPS3cWdnCSZBgAsiOgtrkK018x13nHxOtaoQBNYar1cf0gV1e/SZ5WoIl0k
QoAUUFIn3f7eByolx3SRlvyGKscipNKtyD7tOK0htF95TDrI0DKu9qNooKhGNxo5+dz51odSI4Um
ae9EUaelPij0j4RXtc/vaSPh7f90wpOxjNwxc48s0oaq667MjnkxAPZpku+5oVnfLBEKJsjQStCT
xsF7paNrKR0gEMczuYYlDsQ4IfXC4cC7Le9S0PJ0u1gn2G/h+sycOGXUeED0uSvNeh5ZfpgbqRMf
KMFYYNQiWjQQGnYgn8Fta1N9E7jyj/NVydCIQ7n8ZasvBbFCJEx6JUfiibKslg8Y2v0dudHUa9X5
qB2HLg2UPJJbBYEbtUfQ6cYaXgULJfkH/NiSVR1PMKDGZfnB3c5L5fstJPXk16LhtcAW/spYTI/+
oZzBrhBjCFTj2LxsBuzpA6nYs1KnpOiXiekWf/49Z2a9+Z45FfZlhis85VQTrg4y//NiJbl1ONNa
jC4KYH/kkcCAz0SBTEosLfEu25yzJQs92haVLplq/dEN9lDYjEaoYBRTv3vMBlZYi4toccDX4ld/
Zzdo+Qk0JV50yRQEFdnoXfg/Q2tOtwwA4H5dixPQlssa6Dbx8L/TgfKUgjfsN5ICyzdUXxTbrAng
i4ebOWVkEyr4/Nrlg3E3gAfMASurXBw59QEWqyhzctyjBJVKRzhXMhOGwI2iZUquPdHuiwdqsoMX
U4jrxwSlo0mBw9Cf+7pggvMjsxmvg1FkXnPWC2SHNYcEH+7wmDsw3AWbiHPYSq6xouC1wjjeGbkm
ykaizXYrLGhKAH2kAyOJyS7ppCwB1asQeZ6d2TPkJf3LfENKUc1sTcUQjRnKQT2U12ihWR75IiDJ
jrOmWwfHMNSqjzeDSdyaILRrJsZlm8Zj1SlthfquXffLHEzepko23QU5Wz01RtrhK0ogk84VSKui
Ylo/+X/sRH3jaNwCFlAFHD1w9b0wU3FX6bk9Qw32tomsWA+svGA3RaB6K6kLC00Il+CB6P5IrH9V
Oo1Bp+oDTz3d/q5MT8sVZELW4+n4JcpOayNEdq48htvwMdy+BC1nArplugFf23SuUAqzYUV0rXi1
jhW8v7ppRj/K9VGH8k7pRa33Bd9s6y7DruegAzs12BK/03H/Y3zLaMoOkVpBEOM+a/PHFJxOjLrm
1bDOSK3kIac74QGnWIBS2qOCNfRgUNAaQHGbatxmpLnTQhcja3JTplNUF2nxPTFWxO9CqpGEKvSU
SzaGMF4ul+ijE3Xu7Leb10WQ3kbZKe7v63jNa6yycaNVJocQnVi7H/mcFPfIRMLlDr3OueQon4FS
nrLC8854TSbzHIVQiF7EE901lnZZQkxbg/9SZetl0GRETzW+EGbJPBVaWHvVCwtB/pH8dy7HY4Ok
7r/3fvW4ejozlGUZvZgvFj9tqamw4q6+U5YcUSveMkcwN36cVNTsIeLsxvzaNR4GulGBZI07b3WL
r8t5hSiAonMy3s8jrQdHw+bKIA97BugQTslZb/LfkReVmhsS2NWFg96psjzfbJ0xIW291zli5FJ9
yaWEx5t51WNKuZh4bkaCTmBVDnIA0ZqtvMm55wM14DYcuFcss4Tu9kk2EgsmwUDMO8G5SRvry63L
pWinjfJSpkfDLQ+FlxZR5NraP74gEVC4t3cubtJF/qaKzUv114W0OJD27AsnaapMgjayF7bJxu+t
bPtRwL1ANAcRZqRzDAyILwt0hzYivcwKi/ED8XvcS2Uj33v1D7qVtqG6iZMFp6KSSBAIRjifglIX
V7T/QsaNhuFwcluw9UqARzEDNwjIsXGKeS5WqRk+hTjo3NQgNO5fmugqxiLY0kIKWWjA16VsP7T8
cX1DU0jTzwRIGqDCzlOiiX3/A0qb4w3VZia83SbP6DSU2qDLHzW3weaLTVgHOo9iNMKyE7Z9Rt9o
kiTLvutrQkLL8ZhEszwnytRanqC2KTPnlsHfAsKu5E0BmztnDr9rep4hu4BhZb3LZGBCL25xyjsA
i54viQbITqXC9EmMe+QHykrWhfQ7X1ZTKvl+2SJe/a0uhJhby/oUaZXQlTjXqYgWeNWAm9C+ICEd
Npcyov4Mkoo2m+5409qyUTFoLH9+q2vaO6J2evMaezLNbejWuUXipzNpi8Vvr3Gz3Q9C228E38bt
5fOpenO1393Wiftbib7etr+giPTF3GTWG1DeySCythnHguDPCPZVnuubF4aPtmTAhYcjpqoOnyaJ
Uutwkl915Kt4oG8Oc1z3BjX4ahkiLLxHvx80TcM64k7x57j9S9yxxK1dGsPdCR1a5k7TIhaFvXtu
aqhXZJ69M8QUMRqybHOaEfhQDHTu7ft1SKI743xfjUHKdP71UhQEsLEZrcusK18uOGx4idPIId+Z
dfXvP2RPBbPeFqWBqy/FhzYKKXw5w82xqH9vNZl81n80or0hd9souJiLxAi/7RBF6vKK6+TYYKU1
oj0RicA2p0gsrXQBoOOVkcwGwlj7YxRLl9AUdMHUEPlhNcn3Ahvdjg7uIiFekMWl+qOPBWyC/ICJ
STQk2pz+Y0KyOy8nR8Hqh7M8qFUO5411JDUaFOek6KrXCYcEp+LE5AFdDWhgLICyWfidZ9eMNoAU
35S5KieeaBJLjXgNWk66NFacd1T3zO92FoLvr0yA9slhjmCuE3PZtg+ic+9GTq6jA9IBTxncGneg
Di6X0Z6kC1k88brMAvbe3PBn0rBa0xaa+nwgmuKAbbcCepOkm3SqngDdA8hKsVtqnFOKVZVlp38L
OQKbsXXtPS/e8ccj1AAbBOaEbaciU3TDiQzGqUAgj+hL8JdMnRs/a1mYbXToAId1pMPb7n12E1Up
C5NPNYzVxNJshzGuRmMEPrCwBmvN+DfWTwVY5ukC3mnJEOnZWLheyHbPI69K0dS4jX59mdZ6Jqaq
hUX7gaU/XKl9JaenAoYW4b+5LSeTnND4bhw6S9anyhhlNFzjSqFx9Q91Aa1gbXr+4hCL1pTbrU1u
Xwt8pnCsYfO0yKFkHf4y36UIo63+7WGkJ8gRfsnQCxaCjyKUMtw78q1MvZYGkUvSVSSQxEy0ZpOt
aP6GH8REPLeNQIj5K9xtQ4oSmYv0zBL6RleOZayzrNRRGjOtRgiABuaAjlyMZbufC1FzSBRSo5s2
4lYNvprChyyiJAt+YxPPVuMO7hmbK3T1rztxedfIlu/Hg6nLVa3YgxMeuQvxmK3ANKOmTff1bygF
8SrZu9kXAqyOCX0TJPRwJ+3v1IvInfyobIjrZMr7vXf6nXrzIAEi2+RhKrO4J7TCQLkWUriq3ax6
lr2BiaB/Ljv17cDwiRQftfAbXOtGHJhWkSyxbkGG2/vqx7BI60Tpl2Q3S30esWxd7OY7VOXhBowd
Edn56WBl1FIwSoIJkBI6/Y+dFuFUZVdH6byNV8LhTiM2N4pD+glzp+A9l1QeO/jDW1fek9dLjjGC
uFliHgMytJqpf4lopU8ENl4v6K4EoQkMfYgvItOqRut4rTTifS6gOdjbnhSYbhkS5O0ygTZH2ERc
EcIeX2zQBzVTPRBj96X3uKXdNmF5GXUkz0xqhv2H9fg0J4hUxiGyueH9x4Q1Avt0HMeuRs5uoRRR
Ci2j1ZCpORbp6unajeQKN+5jvpFd/ApaklWxC3q0dP9n0zCiAXlja13QXOp5SqK8DAHd09yXnGE/
g62YeCrEmOVQXBPYkkwu82B6UIHrQXrutlT4mT4qknHCHANLDCVd5dydFY/DWy7+V35mOD/1G7Ij
Xk8977nQm3Bby7/cF8m+KQLQoXVnTqDldI+coHGb6KIgfaG+MjcjaF0KB0h++C6k4iv3IgAxSXiy
wQP4OzVPX0cih9WjYZNJrENTc+zqi3oYnlsoqyR4yas3sJytfYU86JUi7qE3RfTIey96KqAgaVa8
zez6PX/4JFS2ThCqboIIlA5C8dUErXDljPgI4vR+Cgfj9t06BxP+ac2GI0DPp7Q8En1OV1Z1yk2L
ClXmIUtZytSKl2OXLko84xnFPfz/+M6AzxzfUvpeOcHuTWLJNntCZQerXJiJ59XR1x8o0lS6P0PK
2TIaNeRyBdx5zZlKgObqiLi5+mYSCop78Q+lMDeyWEEJxn7YmPAqbebEHoGr7gzR2FCzdrl7+aBo
VDU8yDwkaFULQQ+EsOYcs+kXPwY/ra0ssmtlRt5PZlmsw+nHyaKIiR0ABWXUJ94AskmVfOGXhygC
AGUHiytpzO2tfssLJLu7QQfhQngsvpIIiDmDJnNyAMy8g+WkCfNpDAX7HMYqNiMBBAJVQvWfHF4Z
Ts0GMnWwFJlrKVu0a/tVTXizMSo0S2W5scEhTSbo71Y1KHpn9rtEnHVEO93pdjlIkMQOske3kAmY
AFwnRmEFUC9xvinoc7ZZzvwNlPa8ecARVNFnweeTSoIge0E+71UdSxqOYV3YW1syPdYjlErUVo32
dcBiQZgh/2VjsLQDm9IbpPjby1WYE4NvdxXiauRP587jArPeg/jZbTBlk9wAFKF6cep0RZUAxqXJ
fALZx/qpToH+iwQYv1Ogdb3YrtkWTM8BqZsOWYofFFJBv23K98FjIPmxufj5jy7hPTViBnC4kLgE
T+evk6nx29S4HVjOAZFBYSqc7OUhR3y8/wRrkjrghuYcAYnetcdvkdwCZuC/jys3b/GLbx5pPDgx
ZvUFtSWOMWUELG8evbU8H//UtuhgpGSzXYHz7d+W8eHWWVFAmiN57WyaE1ZZzfPvc4TL7A411hdI
XGicR2YAkWYgV9toCF/r9XksorGmIZBmi8ncaZy8tt4OeDW7ldtmFN7piHU8vjsmBiBcnw5HNWE5
Ooh/KGV5b0Zgv/o/v/UjFsSNfC8/K1N8iFbSi22X77KLiLb9hs6szcmSH+lSNLvQH2u+7P94Ap0V
SL9R5aR0/3sQPEURijb1ousPgmmlvd55k6ktJFc/L5pbCOMUtPhZ87Jk5QGz/ovbSeqZPqtVraFx
2Nmr+t7Meii2/OJJJcvjUFmOAYO1YPcUFym7/Jz/EyIs6ol7/xBCMl7IENu3OjruO3FWF0A5APuS
iE//MSttdfJISWXKgByYXRMQr1E6YM+PSTjLDUEOXjNmbbLfzL0WIlEdxDUZfMaACoHNbfWPdTGb
3N04V6SfiktNvDNTuP9xDXvWcB9GGWM8iPPwltZlSvUMdZIBEzZgu30CsdASlk1Y2k4ER/DwOfvO
xfLRW61/1sPWEysa1Sawa2O1HFM5VacViK38cl7OuUVqdITaE8O4b6OlyNRhRaVG8l2oi92EZD9p
tnEf49lkf7453DQS6DPlfeCHMQPqin6K/1x2CGFzkbbqqvrXT0oyQLRK9Oo2tRX47EQfHWyPd9Cl
WfYzn4vrbKOg9M8W3dAjrKF883O9M3wZl1fNNau3My4/yQ3VvPZBIlBOHWy1Ng61pWBislnDorzF
QguGzCTB4V+BZPw23yeONx98ZBt/m8TPTxE1LbJYGrBB780O6PZ5AdV+M3CPYuUR7u15SOTsMdsM
VgB897V0qcRTOJwXdJ/TqigkFIt83isut+Jt3E5nLiAW75RtmDoz2G7/WQFCJLBE3iKHg9Qe8KPd
m8YEa2Yw0i8tnDnRU4Y6cllmFPlHDHI7N0Ind58z76J9Mep8EqFWfeyVbNwHQhWxIsDznT589Rm3
a8WsyP0aKoqLlCQpVUR1T7SMemqdV5G+P3FfjUcwLPHw98IqoAO73radNVvU6xAkgJx9yE2Y8fX6
qCmCQilPkTVIPEntL8fRdA5C3tdoNhGTZ4u2v33ycoX0pcWF+dhnaaL4dxfvPDj1qIiSaBht6jVi
54ICtDdvjRjKXdgGBVsmgLrH4ys9AZNv8jf6etpBEI66LN1g5epb3QbSx/l2DJoV2M2v1BNz/DVA
dJ46ud2csZ7oD9mA9RSCzUxYlJ32fl4KHiKrPJu+iiTHegg8/uYp8aJf76LwgWkBKNxB0ik6ccpH
F4CasToFoYY8dQ+irUoZMZ2ZGEPRpwRmTOUmrlxO6PhOxc2DNtK86/Xa/zq3cXEPxhvrcKzJoHm5
V9PpJt9QIr4u/QSeASzgJoOOS84gdYTYoX6M9Y8OYY6nvHy30UFD5oCdsEBAKQr+hW9tJ6eo5d6P
RwSIGEeWUXbtJ6CSbNFSXUgKNRZmFSbIAyvy6CUUoLQ95yb1TkzZzDOl9KEQb7FboWqrZkFW+P8r
lprqXt1ner0QO9ZfziymTiAncENREv+gyXYuGSlPjyKpM1SW/B05RXz4GLE3sG614gEBbGgpjAvh
dn05vaXJe6OC7E7Wgp/3lgFTAII8AgeXdl6SfsAnamUIzdXcUFwwO4hi7bnrrn5yFtmUtErlWuZZ
pQ6pyLTWeMLmF8KEjmOJG7fN0obrZFtVxfZUKpDDupyNCKHzKZbPrWQtBGvIQEQz9pQmYesPGrCg
MaHozJCARPgKl0iP4VjGPnpBMTtshE+EaeLsx2KBD4bZIcZsYIHjn/Aclr816Pjm9dPFqhWQM6Ha
PHNLOpcdAifHJk5e+/e1PwsSFsCWYS2sXGmpHBY9xYOrYozNjvhtfIMtG7VUFM//ge0TrCF3n47Q
fzOwCvuwSdN5iEpe8/3f5naOoeSdZ0+UjYgMcmtkQ/4ME+a9t5sae9ZkxWhJlTnBeOOzcJPDoGwo
EIfmPBX0U7LGvRz5rXVCb4a2SkC29U1AOpa+2PnK9cQ4MskyHKdC9wtGgVO5t8GOWHurmjCOSIQ0
knkqapHhQhh/ipxcp16W3XQ/PBNHIiODCFDcQCh49MBQIKZp71ocqGi+v/pI5xLozbvFbVYTptAC
v8PiJXuPQblCP3dCWvWHZWE7B1kRMVYa0eGXJY5gex2Kx7ny/GGLAHBgtuKkxS5oWNOMYS+RBeuD
/Zy7vunsjbYqgxt+sWrVPPl8Vsz7GJdajelHXFlShThJX9GbQSRM/LdsYSIeU/ieCE3kB555x/b9
WFQauaMU0PXJZp0Kot6kSWuG2KGkOtJbh9f/DREMOfh8XLOw1d5MrjfCiXMs9lecWHwgC8Cx2j7T
q3W7Fz6BBbCUWHWCrzoSn4TN9I2yNDLfW5wkz/MtFWy4WRK207fydJ56mEASnjQXubF31GifVTSi
e8oqj/LPeOCI9cp0Ewd6gsMlCeY+JfslmlbBt/XAUxh1QAfm4WqkgF024DrURy8AuDOPG+mWJkrO
LiG96IyRbp3efDqyNu2UcbA9Nfisl4gP71ZNgIHo1SIgOG7zXjWuINcvsl4dRjOlKUF6au08pxIK
reCkCdSOK/1+Ihc5IKRTjPc0uRr0mK2Zfpqjd6CqMsbAi9IKULydJz9NpSZ/RPTE1XjkVSS1lE67
SQ3biVF2ti1k/9yE/cjqWR2lqmGf/C5uJALcbd6G3ja7UGTLnFTqy/OkNJI5uLkiFOdhSXbjfXwi
ug4l0dwXS2AS0SPl59MSkK13XkrbCbQYWU16/+crzXji9QrwEGqbNi77Eoqg/Yiw8W0WhlMeY7ha
X4kmsmcan5vp/DvhKAe2fdqII18kAI7cyNCPaFTocibT3OvbZ4GTEqeT3/yvqTy4KlRQAF8fnepZ
K81aPqI9/aHhB5kjL7elfG9Hq8XAeex4U1cZJljiY1bN8WnT81Hf2knTni+L6xWkCQBzVIjEqU+a
CrdSET42GnS+ib73rtTvO6ggUIjfavrc7/5ej7J7acDYd8lkNrK06otC8l/XAW5dgHDqdE/wJ7ti
2N/4oivG4po9ATC5u/EYyrW67C+Oi7tuDOB8p4xAZeBL2HgbFNckP8R/I7v71jQCIKlDqRP3TzYQ
F+oz60PjGyRRDzm/qB0pa1buqcoQKKP8eFnQMybr939G527M6a17lUj2XWwJdcHYF7UakxOoLsn1
+AB2eKT3uiKaTiCbGzQV2syCT7GaiXdrnQak2C0+1SJMSGs36jXE0udGTLgtp+dnV28G86+9gyIH
Bk5VhFySm7XjUVSZGL6YXubq1AbC/rcy//+f4iPbBpKCe5oq3UuHXguzSTDDp2Ok9W95XHSTk8ck
34Rw1OAWfxNK6s9Y/jjpsXSkTEp0u/usa5zMsNY6WmSBIZW90Hj86rytWsPUCvNELfnwxVhQfB4E
sexkEPDJ75mPEzmTfgGaWrPuamWSRrj5gpZJAGvf6AHZAk0lFQPq0GLrJYVPRPbifzv4xlfHSXju
Xpekq8g+gDkrzD4+KQqoQKaX51YEGt4nhOIW13zBE8Wh+gqwWXAsL0XxNmFFdLwrkdDJ+feE7h5z
M9PlW9WUw/CDVFWVzd1ElzTtlGmfXRwK58qIdI5/0eSJJWRADVA6STZjiiag+hhTeWLa7juyE284
k1HXwaXzYdtIFpJwBs/ZND5H8GnWT3BDGTZdIchvImLjiux+4DllDVbZty4LAyDdqWpp4GEz4GFn
cOVx0ItHymaYhSsTsOzJZHAcNSv78io7YdnCJkLenL0hjS0VcRm6sPJovxb5V4BL9hr+v2fr0s9i
v2LUL20UbPQyEc8nhDZAjeWc0tVxswyyfsd2G34I0hBAZI1TcMQ0R/bGpc4DykPSHoPwIPKRcoxB
LznW+1hl0XY+Wok+7KU4ik51U/o5v2rnJA6QpIbsGpY1G+dYD1Mu25Xr+WZjqzDwikKTE/pe6HFL
1jUR9OBYJEPtkUxwHCotP1LSrgPMqmhEZGa7ZuILJpqpuZIIbOdeV/g8so2Iy1UqjgqeKSHUXyCR
4YXuG8ZAMjXHafQT5Inzl4b7e69CwY0zadWz0EhW+RPriWsVFaQ+eoIaOxJNCyuReK3WeVLrMGSC
ytBQpGR1hqwzEv9BG2j6ooKBiePl+7pLt4C4pIIQasxKqkbaCAmVh9wtZzcMctruLsOPZ72xmTmH
ITps91vx3mpkmNYS4NIBflrlivoaXq9VHuaep2hYeE1/R9c0c3TqWdf5tEBl2IL8qX5ubct0bZpE
NOjmeTbH18MJdeSMAd4abyAdSQlucAODUSUpnsmBtEBC1jCA8QOIXfmljifZ3UdHB+QbcFlctnw1
NyKAeJN6v9fsrtn1ZFSFcD4KvmJxoq+FY1pWBMeqpxVmF3K3f0oe0xMfWXr//levM1vPQUJqnm37
y7Lc+hqeAIEJQgQ9bgiSHlk5+l1uF/pMbzOsEn/VszSHWH5wLvyx+HotQNA40Rsvqxut2CEA9Hhz
2NlmutbyP9+WhzlfKkYz73MN7uM3Se/NYnUXxetiFcOxak+l3875w8hFJQKiihDDrc0eQi0j8nr3
jl8/Zgkm3zt4dJzzvqCI0ZUkApXb46+XviD3UqVs+dbot6GPO8c7D1BpREkTwxNrFqlhBs2Nul0K
X8D0e2gWqKpW8Cl9KnscrGX4WkQbiwnw3lYE0YM528BKtuCV0BhFt5TG1aKJGM/e/2leTcusabfj
uaw6p8fsWpBZbno6WUgs89RzDV0BYoE1idsHh51/dfgY1j1UIlwbkM7e39tXaA3WEx+chzow8tbm
HfB0jYo5cR+OJWvEpOIbwjewwnKZl1rCraDfEjjmpd9+bDMfyU2zaFDSmgKvOwTsZ1i5wlWxsSvh
eDeIwWVCJBNTp+xIo/LMttc1H0kxzA8Kdb9OJWZsqyrTvy6qpp9bHCc8lYJDWCHAezBOhON9zqHF
2NjqV2anChGzia0E0az2hj3NIUrCT35qSHIiby47+j9Adq/sTMMYkUvdC/cK0yHEG6DrcueC9azi
sPMX2LcmGvpwyaMEcfbXgfQ8XlkTC+v7iQf591gk/N616yE67TaPsEUEZx7OTbQanbqRgpmM8Jkg
Ol9T+6l8iTGsCVuu1Y6uwhEEwaYoIvZaOHMJtqebkKc/PMqHrldCHje/ZryAGNhRYEOX0+ttF5ru
ELxNehOV2RkbUtx/5aQACiIGd8uBD2RzVG93er9dWmXKSXnk5z2Eh7zg5bX9GsI5mu5r/TOqhJME
WLGKcV8J3t3wqWjGXSLKo8m9kmtLVga8/xcPKFBR5GQ0OU4JkRm0KDi+STDo+EchH7YWZ7iQsQ6e
JfU5mFwXBzUuxaFZV+Yrl6ku8oB/9FLze6YxOLO9ExzRsS3TJLJnu+vpeSMxnKi3MOFVRlEqFZVg
rE5J9LNXJMEFOz0/dcUY9o7V9DIelHDD9NuzCntYJbNDKND27NS8pS5co9G142IO2+jXQbEHM5R3
KofwJQqPm/Tl3JbO70ZkVMpaproIay+dMAmzvPRaOZC5r5M0flL+SoKrjye+1UzyMzV/DLS70+AT
WKNgzwh+FIlGlDDvTmYMADv5TvMxLQqnqVZDTZnGqzBhOF1miP8nW6qQroXylBSAQyo4+1vaWaNo
xDbELW//C1De+3iy1fZP8FlxVe1BMSagwn5e0eyxuhhj+ZbV52+4gcG81SANA6W/8cwIFFCHDsVX
yjFE1IszqmAelDO38ph4d8Bv5Kx8yTgeRVqRjimQZg3JKEoTIYXvNGXeJuF/07scXilQVwTQ+0O8
MFOCFTP6CrxtfIVErcrI0ffm1B1MujgM/YspjkbIIKAU2e50jbyVGwdxHxtLkHGnBvFVppe0xRoS
kdEspWz+uHwk9SzzpOLOu/CnkA0XFVMxv0ayoA==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
