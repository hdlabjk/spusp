set_property SRC_FILE_INFO {cfile:/home/amd/training/clk_resources/lab/KCU105/verilog/wave_gen.srcs/constrs_1/imports/wave_gen_timing_us_clk_resources.xdc rfile:../../../wave_gen.srcs/constrs_1/imports/wave_gen_timing_us_clk_resources.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:53 export:INPUT save:INPUT read:READ} [current_design]
set_max_delay 5 -from [get_clocks -of [get_nets clk_rx] ] -to [get_clocks -of [get_nets clk_tx] ] -datapath_only
