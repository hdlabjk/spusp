transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib riviera/xpm
vlib riviera/fifo_generator_v13_2_15
vlib riviera/xil_defaultlib

vmap xpm riviera/xpm
vmap fifo_generator_v13_2_15 riviera/fifo_generator_v13_2_15
vmap xil_defaultlib riviera/xil_defaultlib

vlog -work xpm  -incr "+incdir+../../../../../../../../../../../opt/amd/2026.1/data/rsb/busdef" -l xpm -l fifo_generator_v13_2_15 -l xil_defaultlib \
"/opt/amd/2026.1/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
"/opt/amd/2026.1/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm -93  -incr \
"/opt/amd/2026.1/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work fifo_generator_v13_2_15  -incr -v2k5 "+incdir+../../../../../../../../../../../opt/amd/2026.1/data/rsb/busdef" -l xpm -l fifo_generator_v13_2_15 -l xil_defaultlib \
"../../../ipstatic/simulation/fifo_generator_vlog_beh.v" \

vcom -work fifo_generator_v13_2_15 -93  -incr \
"../../../ipstatic/hdl/fifo_generator_v13_2_vh_sim_rfs.vhd" \

vlog -work fifo_generator_v13_2_15  -incr -v2k5 "+incdir+../../../../../../../../../../../opt/amd/2026.1/data/rsb/busdef" -l xpm -l fifo_generator_v13_2_15 -l xil_defaultlib \
"../../../ipstatic/hdl/fifo_generator_v13_2_vl_sim_rfs.v" \

vlog -work xil_defaultlib  -incr -v2k5 "+incdir+../../../../../../../../../../../opt/amd/2026.1/data/rsb/busdef" -l xpm -l fifo_generator_v13_2_15 -l xil_defaultlib \
"../../../../wave_gen.gen/sources_1/ip/char_fifo/sim/char_fifo.v" \

vlog -work xil_defaultlib \
"glbl.v"

