@echo off

rem  Vivado (TM)
rem  runme.bat: a Vivado-generated Script
rem  Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
rem  Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.


set HD_SDIR=%~dp0
cd /d "%HD_SDIR%"
set PATH=%SYSTEMROOT%\system32;%PATH%
cscript /nologo /E:JScript "%HD_SDIR%\rundef.js" %*
@Rem<copyright-disclaimer-start>
@Rem  **************************************************************************************************************
@Rem  * © 2026 Advanced Micro Devices, Inc. All rights reserved.                                                   *
@Rem  * DISCLAIMER                                                                                                 *
@Rem  * The information contained herein is for informational purposes only, and is subject to change              *
@Rem  * without notice. While every precaution has been taken in the preparation of this document, it              *
@Rem  * may contain technical inaccuracies, omissions and typographical errors, and AMD is under no                *
@Rem  * obligation to update or otherwise correct this information.  Advanced Micro Devices, Inc. makes            *
@Rem  * no representations or warranties with respect to the accuracy or completeness of the contents of           *
@Rem  * this document, and assumes no liability of any kind, including the implied warranties of noninfringement,  *
@Rem  * merchantability or fitness for particular purposes, with respect to the operation or use of AMD            *
@Rem  * hardware, software or other products described herein.  No license, including implied or                   *
@Rem  * arising by estoppel, to any intellectual property rights is granted by this document.  Terms and           *
@Rem  * limitations applicable to the purchase or use of AMD’s products are as set forth in a signed agreement     *
@Rem  * between the parties or in AMD's Standard Terms and Conditions of Sale. GD-18                               *
@Rem  *                                                                                                            *
@Rem  **************************************************************************************************************
@Rem<copyright-disclaimer-end>